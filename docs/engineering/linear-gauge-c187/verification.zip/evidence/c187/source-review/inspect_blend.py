"""Read the sealed file, inspect Blender's native data and re-export into a temporary directory."""
import hashlib
import json
from pathlib import Path
import sys
import tempfile

import bpy

root, output = (Path(s).resolve() for s in sys.argv[sys.argv.index('--') + 1:])
native = root / 'gauge/deliveries/blender/gauge.blend'
assert Path(bpy.data.filepath).resolve() == native
scene = bpy.context.scene
spec = json.loads((root / 'gauge/assembly.json').read_text())
specs = {p['id']: p for p in spec['parts']}
meshes = {o.name: o for o in scene.objects if o.type == 'MESH'}
assert set(meshes) == set(specs)
receipt = {'version': bpy.app.version_string, 'build_hash': bpy.app.build_hash.decode(),
           'native_sha256': hashlib.sha256(native.read_bytes()).hexdigest(),
           'frames': [scene.frame_start, scene.frame_end], 'fps': scene.render.fps / scene.render.fps_base,
           'native_parts': {}, 'frames_checked': [], 'minimum_gaps_mm': {}}
assert (scene.frame_start,scene.frame_end,receipt['fps']) == (0,48,24)
for name, o in sorted(meshes.items()):
    action = o.animation_data.action if o.animation_data else None
    assert o.data.name == name
    parent = o.parent.name if o.parent else None
    assert parent == (name.replace('_shoe','_carriage') if name.endswith('_shoe') else None)
    curves = []
    if action:
        for curve in action.fcurves:
            keys = [[float(k.co.x),float(k.co.y),k.interpolation] for k in curve.keyframe_points]
            curves.append({'path':curve.data_path,'component':curve.array_index,'keys': keys})
        assert len(curves) == 1 and curves[0]['path'] == 'location' and curves[0]['component'] == 0
        assert [k[0] for k in keys] == [0,48] and all(k[2] == 'LINEAR' for k in keys)
    assert bool(action) == name.endswith('_carriage')
    receipt['native_parts'][name] = {'mesh':o.data.name, 'parent':parent, 'action':action.name if action else None, 'curves':curves, 'vertex_count':len(o.data.vertices)}
left,right = (meshes[k].data for k in ('left_shoe','right_shoe'))
assert left != right and [tuple(v.co) for v in left.vertices] == [tuple(v.co) for v in right.vertices]
receipt['shoe_meshes'] = {'separate_datablocks':True, 'identical_local_vertices':True, 'shared_material':left.materials[0] == right.materials[0]}
worst = 0
for step in range(97):
    frame = step / 2
    scene.frame_set(int(frame), subframe=frame-int(frame))
    t = frame / 24
    bounds = {}
    for name, obj in meshes.items():
        evaluated = obj.evaluated_get(bpy.context.evaluated_depsgraph_get())
        xyz = [evaluated.matrix_world @ v.co for v in evaluated.data.vertices]
        points = [(1000*x,1000*z,-1000*y) for x,y,z in xyz]
        bounds[name] = [[fn(p[i] for p in points) for i in range(3)] for fn in (min,max)]
        for side in (0,1):
            for i in range(3):
                ref = specs[name]['worldBoundsAt0Mm'][side][i] + (150*t if i == 0 and specs[name]['motion'] == 'translate' else 0)
                worst = max(worst, abs(bounds[name][side][i] - ref))
    for lane in ('left','right'):
        shoe,stop = bounds[lane+'_shoe'],bounds[lane+'_stop']
        gap = stop[0][0] - shoe[1][0]
        overlap = [min(shoe[1][i],stop[1][i]) - max(shoe[0][i],stop[0][i]) for i in (1,2)]
        assert min(overlap)>0
        if gap < receipt['minimum_gaps_mm'].get(lane,{'gap':1e9})['gap']:
            receipt['minimum_gaps_mm'][lane] = {'gap':gap,'time_s':t,'overlap_yz_mm':overlap}
    receipt['frames_checked'].append(frame)
assert worst < spec['tolerances']['boundsAndWorldPositionsMm']
receipt['max_world_bound_error_mm'] = worst
scene.frame_set(0)
with tempfile.TemporaryDirectory() as tmp:
    out = Path(tmp)/'gauge.glb'
    status = bpy.ops.export_scene.gltf(filepath=str(out), export_format='GLB',export_yup=True,
        export_animations=True,export_animation_mode='SCENE',export_anim_scene_split_object=False,
        export_frame_range=True, export_force_sampling=True, export_texcoords=False,
        export_normals=True,export_skins=False,export_morph=False,export_cameras=False,export_lights=False)
    assert 'FINISHED' in status and out.read_bytes()==native.with_suffix('.glb').read_bytes()
    receipt['direct_reexport_byte_identical'] = True
    receipt['reexport_sha256'] = hashlib.sha256(out.read_bytes()).hexdigest()
output.write_text(json.dumps(receipt,indent=2)+'\n')
