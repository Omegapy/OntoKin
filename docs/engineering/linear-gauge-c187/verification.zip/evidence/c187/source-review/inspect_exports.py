"""Read only sealed sources and GLBs. Run with the pinned interpreter and checkout."""
import argparse
from bisect import bisect_right
import hashlib
import json
from pathlib import Path
import struct
import sys

def digest(data):
    return hashlib.sha256(data).hexdigest()

def split_glb(file_bytes):
    magic,version,length = struct.unpack_from('<4sII',file_bytes)
    assert (magic,version,length) == (b'glTF',2,len(file_bytes))
    nj,jtype = struct.unpack_from('<I4s',file_bytes,12)
    nb,btype = struct.unpack_from('<I4s',file_bytes,20+nj)
    assert jtype == b'JSON' and btype == b'BIN\0' and length == 28+nj+nb
    return json.loads(file_bytes[20:20+nj]),file_bytes[28+nj:]

def differences(a,b,path=''):
    if a == b: return []
    if isinstance(a,dict) and isinstance(b,dict) and a.keys()==b.keys():
        return [d for k in a for d in differences(a[k],b[k],path+'/'+k)]
    if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
        return [d for i,(x,y) in enumerate(zip(a,b)) for d in differences(x,y,path+'/'+str(i))]
    return [dict(path=path,before=a,after=b)]

def accessor(g,data,index):
    a=g['accessors'][index]
    bv=g['bufferViews'][a['bufferView']]
    assert a['componentType']==5126 and 'sparse' not in a
    n={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']]
    off=bv.get('byteOffset',0)+a.get('byteOffset',0)
    return [struct.unpack_from('<'+'f'*n,data,off+i*bv.get('byteStride',4*n)) for i in range(a['count'])]

def inspect(g,data,spec):
    nodes=g['nodes']
    name=lambda idx:nodes[idx]['name']
    parts={p['id']:p for p in spec['parts']}
    assert {o['name'] for o in nodes}==set(parts) and len(nodes)==len(parts)==len(g['meshes'])
    parent={j:i for i,o in enumerate(nodes) for j in o.get('children',[])}
    assert set(g['scenes'][g['scene']]['nodes'])==set(range(len(nodes)))-parent.keys()
    bounds={}
    for i,o in enumerate(nodes):
        m=g['meshes'][o['mesh']]
        assert m['name']==name(i)
        assert o.get('rotation',[0,0,0,1])==[0,0,0,1] and o.get('scale',[1,1,1])==[1,1,1] and 'matrix' not in o
        points=[p for prim in m['primitives'] for p in accessor(g,data,prim['attributes']['POSITION'])]
        bounds[i]=[[f(p[k] for p in points) for k in range(3)] for f in (min,max)]
    assert len(g['animations'])==1
    a=g['animations'][0]
    tracks={}
    key_times=set()
    for c in a['channels']:
        s=a['samplers'][c['sampler']]
        assert s.get('interpolation','LINEAR')=='LINEAR'
        key,path=c['target']['node'],c['target']['path']
        times=[v[0] for v in accessor(g,data,s['input'])]
        assert times[0]==0 and times[-1]==2 and all(t<u for t,u in zip(times,times[1:]))
        values=accessor(g,data,s['output'])
        assert len(values)==len(times) and (key,path) not in tracks
        if path=='rotation': assert all(v==(0,0,0,1) for v in values)
        else: assert path=='translation'
        tracks[key,path]=(times,values)
        key_times.update(times)
    def world(i,t):
        own=nodes[i].get('translation',[0,0,0])
        if (i,'translation') in tracks:
            times,values=tracks[i,'translation']
            j=min(len(times)-2,bisect_right(times,t)-1)
            f=(t-times[j])/(times[j+1]-times[j])
            own=[a+(b-a)*f for a,b in zip(values[j],values[j+1])]
        if i in parent: return [a+b for a,b in zip(own,world(parent[i],t))]
        return own
    key_times=sorted(key_times)
    times=sorted(set(key_times)|{(t+u)/2 for t,u in zip(key_times,key_times[1:])})
    max_error=0
    gap_trace={lane:[] for lane in ('left','right')}
    for t in times:
        actual={}
        for i,o in enumerate(nodes):
            tr=world(i,t)
            expected=parts[name(i)]
            actual[name(i)]=[[1000*(v+d) for v,d in zip(row,tr)] for row in bounds[i]]
            for j,row in enumerate(actual[name(i)]):
                for k,v in enumerate(row):
                    target=expected['worldBoundsAt0Mm'][j][k]+(t*150 if k==0 and expected['motion']=='translate' else 0)
                    max_error=max(max_error,abs(v-target))
        for lane,history in gap_trace.items():
            shoe,stop=actual[lane+'_shoe'],actual[lane+'_stop']
            assert all(min(stop[1][k],shoe[1][k])>max(stop[0][k],shoe[0][k]) for k in (1,2))
            history.append((stop[0][0]-shoe[1][0],t))
    assert max_error < spec['tolerances']['boundsAndWorldPositionsMm']
    assert all(all(a[0]>b[0] for a,b in zip(h,h[1:])) for h in gap_trace.values())
    return dict(mesh_node_ids=sorted(parts),parents={name(i):name(j) for i,j in parent.items()},
                channels=[dict(node=name(i),property=p,key_count=len(ts)) for (i,p),(ts,_) in tracks.items()],
                union_key_times=len(key_times),keys_and_midpoints_checked=len(times),max_world_bound_error_mm=max_error,
                gaps={lane:dict(start_mm=h[0][0],minimum_mm=min(h)[0],time_s=min(h)[1]) for lane,h in gap_trace.items()})

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('kit',type=Path);parser.add_argument('checkout',type=Path);parser.add_argument('output',type=Path)
    args=parser.parse_args()
    root=args.kit/'gauge/deliveries'
    spec=json.loads((args.kit/'gauge/assembly.json').read_text())
    program=(root/'ontokin/main.ok').read_text()
    sys.path.insert(0,str(args.checkout.resolve()))
    from ontokin.budget_runtime import execute_torque_export
    from ontokin.execution_budget import HostPolicy
    from ontokin.scene import ExportOptions
    from ontokin.texture_bundle import load_texture_bundle
    src=load_texture_bundle({'schema_version':'ontokin.bundle/0.2','entry':{'filename':'main.ok','source':program},'modules':[],'assets':[]})
    native=execute_torque_export(src,policy=HostPolicy(max_operations=1000000,max_elapsed_ms=80000),
        caller_caps={'max_operations':1000000,'max_elapsed_ms':80000},options=ExportOptions(end='2',fps=12,helpers=False)).data
    assert native==(root/'ontokin/build/native.glb').read_bytes()
    native_json,native_bin=split_glb(native)
    final=(root/'ontokin/build/starter.glb').read_bytes()
    final_json,final_bin=split_glb(final)
    assert native_bin==final_bin
    diff=differences(native_json,final_json)
    assert len(diff)==7 and all(d==dict(path=f'/meshes/{i}/name',before='extrusion',after=final_json['meshes'][i]['name']) for i,d in enumerate(diff))
    assert json.loads((root/'ontokin/build/export-diff.json').read_text())['json_fields_changed']==diff
    bl=(root/'blender/gauge.glb').read_bytes()
    receipt={'native_ontokin':dict(direct_recompile_byte_identical=True,sha256=digest(native),final_sha256=digest(final),
                                   binary_chunks_identical=True,bin_bytes=len(native_bin),bin_sha256=digest(native_bin),
                                   json_fields_changed=diff),
             'ontokin':inspect(final_json,final_bin,spec),'blender':inspect(*split_glb(bl),spec)}
    args.output.write_text(json.dumps(receipt,indent=2)+'\n')

if __name__=='__main__': main()
