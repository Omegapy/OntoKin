# C187 independent editable-source review

The two sealed deliveries match their attempt-1 file manifests. Both define the common shoe geometry once in source and expose separate left and right occurrences. Each delivered GLB contains the seven specified mesh and node names.

| Editable source | How an individual shoe is selected | Native motion |
| --- | --- | --- |
| OntoKin `main.ok` | Both named objects instantiate `Shoe`. Each can override the class’s public dimensions in its own object block. | Four independent dynamic bodies have the same +150 mm/s world-X velocity, with gravity zero and collision disabled. The base and stops have no body. |
| Blender `build.py` and `gauge.blend` | The lane loop calls the same cuboid builder using `SIZE_MM["shoe"]`. The per-object override lookup uses the generated occurrence ID. The saved scene contains two distinct, separately editable mesh datablocks with equal local vertex arrays. | The two carriages each have one X-location curve with linear keys at frames 0 and 48, at 24 fps. Each shoe inherits its carriage transform. The three fixed parts have no animation. |

Blender 4.5.3 LTS reopened the sealed scene. I evaluated the native geometry at 97 times and then exported directly from that open scene using the submitted exporter settings. The result matched the sealed GLB byte for byte.

A direct call to the pinned OntoKin compiler, bypassing the author's naming wrapper, reproduced the sealed native GLB byte for byte. A recursive comparison of the complete native and final GLB JSON found exactly seven differences. Each mesh name changed from `extrusion` to its occurrence ID. The two BIN chunks were byte-identical (11,552 bytes).

| Delivered GLB | All animation keys and interval midpoints checked | Maximum world-bound error | Minimum gap for each lane | Time |
| --- | ---: | ---: | ---: | ---: |
| OntoKin | 49 times | 0.000023 mm | 15.000008 mm | 2.000 s |
| Blender | 97 times | 0.000045 mm | 14.999993 mm | 2.000 s |

The independent reader decoded vertex positions and animation values and followed native node parentage. Both lanes retained positive Y and Z overlap. Each gap decreased across every interval. With linear translation curves and identity rotations throughout, the minima occur at the final keys.

The coordinator obtained the pinned Khronos glTF Validator 2.0.0-dev.3.10 after the offline search, verified its SHA-512 integrity against the lockfile and ran it on both final GLBs and the raw OntoKin export. [Official validator reports](khronos.json) · [Package and lockfile identity](khronos-availability.json)

The source-edit mechanism was reviewed in both designs. The review used the original starters throughout.

## Review receipts

- `seal-check.json` covers all 12 submitted files.
- `blend-inspection.json` and `blend-reopen.log` record the Blender native data, sample results and re-export.
- `export-inspection.json` records the compiler comparison, complete list of changed fields and GLB measurements for each arm.
- `khronos-availability.json` identifies the exact package pin, the lockfile digest and the offline availability check.
- `inspect_blend.py` takes the kit path and receipt path after Blender's `--`. Start Blender with the sealed `gauge.blend` open and pass the script with `--python`. `inspect_exports.py` takes the kit path, restored checkout directory and receipt path, in that order. Run it with the pinned OntoKin Python environment.
