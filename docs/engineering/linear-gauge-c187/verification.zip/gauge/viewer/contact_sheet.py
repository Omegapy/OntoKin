"""Lay out the unretouched Chromium canvas captures for the C187 handoff."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

kit = Path(__file__).resolve().parents[2]
shots = kit / 'evidence/c187/playback'
paper = Image.new('RGB', (1536, 894), '#101d25')
draw = ImageDraw.Draw(paper)

def font(size, bold=False):
    return ImageFont.truetype('DejaVuSans' + ('-Bold' if bold else '') + '.ttf', size)

def label(x, y, text, size, color='#e8eff1', bold=False):
    draw.text((x,y), text, font=font(size,bold), fill=color)

label(38,25,'ONTOKIN    /    C187     •     STARTER QUALIFICATION',17,'#93c7bd',True)
label(38,54,'Two carriages, one shared shoe design',41,bold=True)
label(38,117,'Both lanes travel 300 mm along +X. Each red stop stays fixed as the gold shoe approaches.',23,'#bdcbd0')
xs = (40, 533, 1026)
for x,t,gap in zip(xs,('0.000 s','1.000 s','2.000 s'),('315 mm','165 mm','15 mm')):
    label(x,181,t,24,bold=True)
    label(x+130,184,'Face gap  '+gap,19,'#9acdc1')
for label_text,route,y in [('Blender / Python','blender',233),('Native OntoKin','ontokin',550)]:
    label(40,y,label_text,21,'#d2e2e5',True)
    for t,x in enumerate(xs):
        with Image.open(shots/f'{route}-{t}.png') as frame:
            paper.paste(frame.convert('RGB').resize((470,268),Image.Resampling.LANCZOS),(x,y+35))
label(40,865,'Common camera and scale. Clearances rounded to the nearest millimetre.',16,'#96aeb7')
paper.save(kit/'gauge/comparison.png',optimize=True)
