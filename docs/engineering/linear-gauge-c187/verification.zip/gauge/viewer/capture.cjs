// Run under tools/run-browser.sh with the extracted kit as its HTTP root.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {chromium} = require(process.env.PLAYWRIGHT_CORE || 'playwright-core');
const [binary, url, output, ...files] = process.argv.slice(2);
async function main(){
  if(files.length !== 2) throw Error('Supply the Blender and OntoKin final GLBs in that order');
  fs.mkdirSync(output,{recursive:true});
  const browser = await chromium.launch({executablePath:binary, args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
  try {
    const page = await browser.newPage({viewport:{width:880,height:720},deviceScaleFactor:1});
    const errors=[], shots=[];
    page.on('pageerror',e=>errors.push(String(e)));
    await page.goto(url + 'gauge/viewer/');
    const canvas=page.locator('#stage');
    const state=()=>canvas.evaluate(e=>JSON.parse(e.dataset.frame));
    await page.waitForFunction(()=>document.querySelector('#stage').dataset.frame);
    for(const [i,file] of files.entries()){
      const before = await state(), route = ['blender','ontokin'][i];
      const sha = crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
      await page.locator('#file').setInputFiles(file);
      await page.waitForFunction(h=>JSON.parse(document.querySelector('#stage').dataset.frame).sha===h,sha);
      const after = await state();
      for (const key of ['eye','target','fov','size','time','registration']) {
        if (JSON.stringify(before[key])!==JSON.stringify(after[key])) throw Error('Changed during swap: '+key);
      }
      if(after.meshCount!==7 || after.duration!==2) throw Error('Unexpected GLB contents');
      for(const t of [0,1,2]){
        await page.locator('#time').evaluate((e,v)=>{e.value=v;e.dispatchEvent(new Event('input'))},t);
        await page.waitForFunction(v=>JSON.parse(document.querySelector('#stage').dataset.frame).time===v,t);
        const name=route+'-'+t+'.png';
        await canvas.screenshot({path:path.join(output,name)});
        shots.push({route,file:name,...await state()});
      }
      await page.locator('#play').click();
      await page.waitForFunction(()=>{const t=JSON.parse(document.querySelector('#stage').dataset.frame).time;return t>0&&t<1.98});
      await page.locator('#play').click();
      await page.locator('#time').evaluate(e=>{e.value=2;e.dispatchEvent(new Event('input'))});
    }
    if(errors.length) throw Error(errors.join('\n'));
    fs.writeFileSync(path.join(output,'frames.json'),JSON.stringify({browser:browser.version(),errors,shots},null,2)+'\n');
  } finally {await browser.close()}
}
main().catch(e=>{console.error(e);process.exitCode=1});
