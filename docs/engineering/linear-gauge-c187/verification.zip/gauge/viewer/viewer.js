import * as THREE from 'three/webgpu';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

const el = id => document.getElementById(id);
const stage = el('stage');
const eye = [.46, .90, .96], target = [.19, .014, .09];
const camera = new THREE.PerspectiveCamera(34, 720 / 410, .01, 30);
camera.position.fromArray(eye);
camera.lookAt(...target);
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x21323d);
scene.add(new THREE.HemisphereLight(0xffffff, 0x788894, 1.65));
const sun = new THREE.DirectionalLight(0xfff1df, 2);
sun.position.set(-2, 5, 3);
scene.add(sun);
const renderer = new THREE.WebGPURenderer({canvas:stage, antialias:true, forceWebGL:true});
await renderer.init();
renderer.setSize(720, 410, false);
const manager = new THREE.LoadingManager();
manager.setURLModifier(() => {throw Error('Expected a self-contained GLB')});
const loader = new GLTFLoader(manager);
let model, mixer, actions = [], playing = false, previous = null;
let time = 0, duration = 0, sha = null, loads = 0, frames = 0, meshCount = 0;
function draw(value) {
  time = value;
  for (const action of actions) action.reset().play();
  mixer?.setTime(value);
  renderer.render(scene, camera);
  el('time').value = value;
  el('clock').textContent = value.toFixed(3) + ' s';
  stage.dataset.frame = JSON.stringify({sha, time, duration, meshCount, loads, frames:++frames, eye, target,
    fov:camera.fov, size:[720,410], three:THREE.REVISION, registration:'identity', backend:'WebGL2'});
}
function pause() {playing = false; previous = null; el('play').textContent = 'Play'}
el('file').onchange = async e => {
  const file = e.target.files[0];
  if (!file) return;
  pause();
  try {
    const bytes = await file.arrayBuffer();
    const glb = await loader.parseAsync(bytes, '');
    const tracks = glb.animations.flatMap(c => c.tracks.map(t => t.name));
    if (!tracks.length || new Set(tracks).size !== tracks.length) throw Error('Expected independent motion tracks');
    sha = [...new Uint8Array(await crypto.subtle.digest('SHA-256', bytes))].map(v=>v.toString(16).padStart(2,'0')).join('');
    if (model) {
      mixer.stopAllAction();
      mixer.uncacheRoot(model);
      scene.remove(model);
      model.traverse(n=>{n.geometry?.dispose(); for (const m of [].concat(n.material || [])) m.dispose()});
    }
    model = glb.scene;
    meshCount = 0;
    model.traverse(n=>{if (n.isMesh) meshCount++});
    scene.add(model);
    mixer = new THREE.AnimationMixer(model);
    actions = glb.animations.map(clip=>{
      const a = mixer.clipAction(clip);
      a.setLoop(THREE.LoopOnce, 1);
      a.clampWhenFinished = true;
      return a;
    });
    duration = Math.max(...glb.animations.map(c=>c.duration));
    el('time').max = duration;
    loads++;
    draw(Math.min(duration,time));
    el('play').disabled = el('time').disabled = false;
    el('state').textContent = file.name + ' · ' + meshCount + ' mesh objects';
  } catch (error) {el('state').textContent = 'Load failed. ' + error}
};
el('time').oninput = e => {pause(); draw(Number(e.target.value))};
el('play').onclick = () => {if (playing) pause(); else {playing=true; previous=null; el('play').textContent='Pause'}};
renderer.setAnimationLoop(now=>{
  if (!playing) return;
  if (previous !== null) draw((time+(now-previous)/1000)%duration);
  previous = now;
});
draw(0);
el('state').textContent = 'Ready to open a GLB.';
