"""Remeasure the C187 deliveries, compare rebuilt bytes and validate the receipts."""
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys

HERE = Path(__file__).resolve().parent
EVIDENCE = HERE.parent/'evidence/c187'
sys.path.insert(0,str(HERE/'checker'))
from check import check

def read(path):
    return json.loads(path.read_text())

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def chunks(path):
    data = path.read_bytes()
    size, = struct.unpack_from('<I',data,12)
    return json.loads(data[20:20+size]), data[28+size:]

def verify_native(native, final, receipt):
    raw, binary = chunks(native)
    named, final_binary = chunks(final)
    assert binary == final_binary and hashlib.sha256(binary).hexdigest() == receipt['bin_sha256']
    assert sha(native) == receipt['native_sha256'] and sha(final) == receipt['final_sha256']
    changes = []
    for node in raw['nodes']:
        if 'mesh' not in node:
            continue
        i = node['mesh']
        changes.append({'path':f'/meshes/{i}/name','before':raw['meshes'][i]['name'],'after':node['name']})
        raw['meshes'][i]['name'] = node['name']
    assert raw == named and len(changes)==7 and changes == receipt['json_fields_changed']

def main():
    freeze = read(EVIDENCE/'freeze.json')
    assert sha(HERE/'checker/SHA256SUMS') == freeze['sha256']
    for line in (HERE/'checker/SHA256SUMS').read_text().splitlines():
        h, n = line.split('  ',1)
        assert sha(HERE/'checker'/n) == h, n
    q = json.loads(subprocess.check_output([sys.executable,'-B',str(HERE/'checker/qualify.py')]))
    assert q == read(EVIDENCE/'qualification-replay.json') == read(HERE/'checker/qualification.json') and q['pass']
    assert (HERE/'assembly.json').read_bytes() == (HERE/'checker/assembly.json').read_bytes()
    frames = read(EVIDENCE/'playback/frames.json')
    assert not frames['errors']
    out = {'fixture':'C187 two-carriage linear gauge','pass':True,
           'positiveControls':q['positiveCount'],'negativeControls':q['negativeCount'],
           'sweptSolverControls':q['sweptSolver'],'routes':{}}
    for route, filename in [('blender','gauge.glb'),('ontokin','build/starter.glb')]:
        src = HERE/'deliveries'/route
        seal = read(EVIDENCE/'seals'/f'{route}-1.json')['files']
        assert set(seal)=={f.relative_to(src).as_posix() for f in src.rglob('*') if f.is_file()}
        for n,s in seal.items():
            assert (src/n).stat().st_size==s['bytes'] and sha(src/n)==s['sha256'], n
        final = src/filename
        result = check(final)
        assert result['pass'] and result==read(EVIDENCE/'measurements'/f'{route}-submitted.json')
        for gap in result['gaps'].values():
            assert abs(gap['minimumMm']-15)<.0001 and gap['minimumAtS']==2
        builds = []
        for i in (1,2):
            copy=EVIDENCE/'rebuilt'/f'{route}-{i}.glb'
            assert copy.read_bytes()==final.read_bytes() and check(copy)==read(EVIDENCE/'measurements'/f'{route}-rebuild-{i}.json')==result
            builds.append(sha(copy))
            if route=='ontokin':
                assert (EVIDENCE/'rebuilt'/f'ontokin-{i}-native.glb').read_bytes()==(src/'build/native.glb').read_bytes()
        shots=[s for s in frames['shots'] if s['route']==route]
        assert [s['time'] for s in shots]==[0,1,2]
        for s in shots:
            assert s['sha']==sha(final) and s['meshCount']==7 and s['duration']==2
            assert s['eye']==[.46,.90,.96] and s['target']==[.19,.014,.09] and s['registration']=='identity'
            assert (EVIDENCE/'playback'/s['file']).is_file()
        out['routes'][route]={'formalAttempts':1,'sealedGlbSha256':sha(final),'cleanBuildSha256':builds,
            'gaps':result['gaps'],'parts':len(result['parts']),
            'segments':result['trajectory']['certifiedIntervals'],'worldSpacePairs':result['clearance']['certifiedNonoverlapPairs'],
            'cameraFrames':[s['file'] for s in shots],
            'maxWorldPositionErrorMm':max(v['maxWorldPositionErrorMm'] for v in result['parts'].values())}
    native = HERE/'deliveries/ontokin/build'
    verify_native(native/'native.glb',native/'starter.glb',read(native/'export-diff.json'))
    out['ontokinMeshNamesChanged']=7
    out['ontokinBinaryChunkUnchanged']=True
    return out

if __name__=='__main__':
    print(json.dumps(main(),indent=2))
