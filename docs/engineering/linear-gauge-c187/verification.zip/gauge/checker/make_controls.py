#!/usr/bin/env python3
"""Build deterministic fixtures directly from the brief, without importing the evaluator."""
import argparse
import itertools
import json
import struct
from pathlib import Path

import numpy as np

# Positive and negative controls, with the part of the checker each fault must reach.
CASES = {
    "good": None,
    "good_split_travel": None,
    "good_design_rounding": None,
    "good_face_fans": None,
    "unequal_sibling_travel": "unequal moving travel",
    "lateral_motion": "travel must follow positive X only",
    "stationary_drift": "fixed body drifts",
    "renamed_sibling": "mesh node and mesh must share the specified ID",
    "renamed_mesh_only": "mesh node and mesh must share the specified ID",
    "grown_right_shoe": "right_shoe: world bounds error",
    "wrong_travel": "left_carriage: world trajectory error",
    "moved_stop": "right_stop: world bounds error",
    "nonlinear_endpoints_correct": "left_carriage: world trajectory error",
    "short_speed_spike": "left_carriage: segment velocity error",
    "wrong_color_one_face": "right_shoe: material RGB error",
    "missing_face": "left_shoe: incomplete or overlapping cuboid face",
    "double_triangle_hole": "left_shoe: incomplete or overlapping cuboid face",
    "reversed_face": "left_shoe: inward or degenerate triangle",
    "interior_triangle": "left_shoe: triangle off cuboid faces",
    "stop_moves_with_correct_endpoints": "right_stop: world trajectory error",
    "rotating_parent": "time-varying rotation outside",
    "scale_returns_to_one": "time-varying scale is outside",
    "step_interpolation": "unsupported interpolation",
    "cubic_interpolation": "unsupported interpolation",
    "incorrect_right_ancestor": "right_shoe: world trajectory error",
    "contact_penetration": "base / left_carriage: interior overlap",
    "wrong_duration": "clip does not span",
    "duplicate_target": "unsupported or duplicate animation target",
    "hidden_extra_mesh": "unreachable node outside the default scene",
    "misleading_metadata": "right_shoe: world bounds error",
}


def build(spec, fault):
    data = bytearray()
    d = {"asset": {"version": "2.0", "generator": "Independent C187 specimen generator"},
         "scene": 0, "scenes": [{"nodes": [0]}], "nodes": [], "meshes": [],
         "materials": [], "accessors": [], "bufferViews": [], "buffers": [],
         "animations": [{"channels": [], "samplers": []}]}
    anim = d["animations"][0]

    def access(values, kind, scalar=5126, interleaved=False, bounds=True):
        dtype = {5126: "<f4", 5123: "<u2"}[scalar]
        arr = np.array(values, dtype=dtype)
        if kind == "SCALAR":
            arr = arr.reshape(-1, 1)
        while len(data) % 4:
            data.append(0)
        start = len(data)
        if interleaved:
            for row in arr:
                data.extend(b"\0"*4 + row.tobytes())
        else:
            data.extend(arr.tobytes())
        view = {"buffer": 0, "byteOffset": start, "byteLength": len(data)-start}
        ac = {"bufferView": len(d["bufferViews"]), "componentType": scalar, "count": len(arr), "type": kind}
        if interleaved:
            view["byteStride"] = 4 + arr.shape[1]*arr.dtype.itemsize
            ac["byteOffset"] = 4
        if bounds:
            ac.update({"min": arr.min(0).tolist(), "max": arr.max(0).tolist()})
        d["bufferViews"].append(view)
        d["accessors"].append(ac)
        return len(d["accessors"])-1

    def track(node, path, times, values, interpolation="LINEAR"):
        sampler = {"input": access(times, "SCALAR"), "output": access(values, "VEC4" if path == "rotation" else "VEC3"),
                   "interpolation": interpolation}
        anim["channels"].append({"target": {"node": node, "path": path}, "sampler": len(anim["samplers"])})
        anim["samplers"].append(sampler)

    def node(**props):
        idx = len(d["nodes"])
        d["nodes"].append(props)
        return idx

    def attach(parent, child):
        d["nodes"][parent].setdefault("children", []).append(child)

    basis = np.array([[0., 0., 1.], [0., 1., 0.], [-1., 0., 0.]])
    origin = np.array([.025, -.032, .011])
    m = np.eye(4)
    m[:3, :3], m[:3, 3] = basis, origin
    root = node(name="Registration", matrix=m.T.flatten().tolist())
    sub, slide, node_ids, local_centres = {}, {}, {}, {}
    duration = 1.98 if fault == "wrong_duration" else float(spec["motion"]["durationS"])
    distance = .290 if fault == "wrong_travel" else float(spec["motion"]["travelMm"][0])/1000
    if fault == "good_design_rounding":
        distance -= .00008  # 299.92 mm constant travel remains within the design tolerance.
    delta = basis.T @ [distance, 0, .00002 if fault == "lateral_motion" else 0]
    for lane in ("left", "right"):
        # Different unsynchronized key grids must still yield the same world motion.
        sub[lane] = node(name=lane+"_group")
        attach(root, sub[lane])
        slide[lane] = node(name=lane+"_actuator")
        attach(sub[lane], slide[lane])
        fraction = .6 if fault == "good_split_travel" else 1.
        if fraction < 1:
            track(sub[lane], "translation", [0, .35*duration, duration],
                  [0*delta, .35*(1-fraction)*delta, (1-fraction)*delta])
        t = np.array([0, .5, .501, 1.] if lane == "left" else [0, .25, .8, 1.])
        u = t.copy()
        if lane == "left" and fault == "nonlinear_endpoints_correct":
            u[1] = .52
        if lane == "left" and fault == "short_speed_spike":
            u[1] += .0003
        interpolation = "STEP" if lane == "left" and fault == "step_interpolation" else "LINEAR"
        values = u[:, None]*fraction*delta
        if lane == "right" and fault == "unequal_sibling_travel":
            values = u[:, None]*fraction*(delta+basis.T @ [.00001, 0, 0])
        if lane == "left" and fault == "cubic_interpolation":
            interpolation = "CUBICSPLINE"
            values = np.array([val for pose in values for val in (0*delta, pose, 0*delta)])
        track(slide[lane], "translation", t*duration, values, interpolation)
        if lane == "left" and fault == "rotating_parent":
            track(sub[lane], "rotation", [0, 1, 2], [[0, 0, 0, 1], [0, .6, 0, .8], [0, 0, 0, 1]])
        if lane == "left" and fault == "scale_returns_to_one":
            track(sub[lane], "scale", [0, 1, 2], [[1, 1, 1], [1, 1.05, 1], [1, 1, 1]])
    # Identical rotations, including antipodal signs, and constant scale are admissible.
    track(root+1, "scale", [0, duration], [[1, 1, 1], [1, 1, 1]])
    if fault == "scale_returns_to_one":
        # Avoid an unrelated duplicate target in that specimen.
        anim["channels"].pop()
    if fault != "rotating_parent":
        track(sub["left"], "rotation", [0, duration], [[0, 0, 0, 1], [0, 0, 0, -1]])

    face_quads = []
    corners = np.array(list(itertools.product([-1, 1], repeat=3)))
    corner_index = {tuple(c): i for i, c in enumerate(corners)}
    for axis in range(3):
        for side in (-1, 1):
            quad = []
            for x, y in ((-1,-1), (1,-1), (1,1), (-1,1)):
                where = np.zeros(3, dtype=int)
                where[axis], where[(axis+1)%3], where[(axis+2)%3] = side, x, y
                quad.append(corner_index[tuple(where)])
            face_quads.append(quad if side == 1 else list(reversed(quad)))

    for part in spec["parts"]:
        name = part["id"]
        lo, hi = np.array(part["worldBoundsAt0Mm"], dtype=float)/1000
        if name == "right_shoe" and fault in ("grown_right_shoe", "misleading_metadata"):
            hi[0] += .01
        if name == "right_stop" and fault == "moved_stop":
            lo[0], hi[0] = lo[0]+.002, hi[0]+.002
        if name == "left_carriage" and fault == "contact_penetration":
            lo[1] -= .0001
        center = (hi+lo)/2
        span = np.abs(basis.T @ (hi-lo))/2
        local_centres[name] = basis.T @ (center-origin)
        prims = []
        color = {"pbrMetallicRoughness": {"baseColorFactor": part["baseColorLinearRGB"]+[1.]}}
        material = len(d["materials"])
        d["materials"].append(color)
        verts = corners*span
        if fault == "good_face_fans":
            verts = np.vstack((verts, [verts[q].mean(0) for q in face_quads]))
        indexed = name != "base"
        pos = access(verts, "VEC3", interleaved=True) if indexed else None
        for k, quad in enumerate(face_quads):
            a, b, c, e = quad
            ind = [a,b,c,a,c,e]
            if fault == "good_face_fans":
                center_id = 8+k
                ind = [a,b,center_id, b,c,center_id, c,e,center_id, e,a,center_id]
            if name == "left_shoe" and k == 0:
                if fault == "missing_face":
                    continue
                if fault == "double_triangle_hole":
                    ind = [a,b,c,a,b,c]
                if fault == "reversed_face":
                    ind = [a,c,b,a,c,e]
                if fault == "interior_triangle":
                    ind += [0,3,5]
            mat = material
            if name == "right_shoe" and k == 5 and fault == "wrong_color_one_face":
                mat = len(d["materials"])
                d["materials"].append({"pbrMetallicRoughness": {"baseColorFactor": [.89,.6,.18,1]}})
            if indexed:
                prims.append({"attributes": {"POSITION": pos}, "indices": access(ind, "SCALAR", 5123), "material": mat})
            else:
                prims.append({"attributes": {"POSITION": access(verts[ind], "VEC3")}, "material": mat})
        if name == "right_shoe" and fault == "misleading_metadata":
            d["accessors"][pos]["min"] = [-.04,-.025,-.05]
            d["accessors"][pos]["max"] = [.04,.025,.05]
        mesh_name = name+"_copy" if name == "right_shoe" and fault == "renamed_mesh_only" else name
        d["meshes"].append({"name": mesh_name, "primitives": prims})
        node_name = "unknown_shoe" if name == "right_shoe" and fault == "renamed_sibling" else name
        idx = node_ids[name] = node(name=node_name, mesh=len(d["meshes"])-1)
        if name.endswith("_shoe"):
            lane = name.split("_")[0]
            parent_name = lane+"_carriage"
            parent = node_ids[parent_name]
            translation = local_centres[name]-local_centres[parent_name]
            if lane == "right":
                d["nodes"][idx]["scale"] = [-1, 1, 1]
                if fault == "incorrect_right_ancestor":
                    parent, translation = root, local_centres[name]
        else:
            parent = slide[name.split("_")[0]] if name.endswith("_carriage") else root
            translation = local_centres[name]
        d["nodes"][idx]["translation"] = translation.tolist()
        attach(parent, idx)
        if name == "base" and fault == "stationary_drift":
            track(idx, "translation", [0, duration], [translation, translation+basis.T @ [.00001,0,0]])
        if name == "right_stop" and fault == "stop_moves_with_correct_endpoints":
            track(idx, "translation", [0,1,2], [translation, translation+.02*delta, translation])
    if fault == "duplicate_target":
        anim["channels"].append(dict(anim["channels"][0]))
    if fault == "hidden_extra_mesh":
        node(name="hidden", mesh=0)
    d["buffers"].append({"byteLength": len(data)})
    while len(data)%4:
        data.append(0)
    blob = json.dumps(d, separators=(",", ":")).encode()
    blob += b" "*(-len(blob)%4)
    return (struct.pack("<4sII", b"glTF", 2, 28+len(blob)+len(data))+
            struct.pack("<I4s", len(blob), b"JSON")+blob+
            struct.pack("<I4s", len(data), b"BIN\0")+data)


if __name__ == "__main__":
    cmd = argparse.ArgumentParser(description=__doc__)
    cmd.add_argument("output_dir", type=Path)
    cmd.add_argument("--design", type=Path, default=Path(__file__).with_name("assembly.json"))
    args = cmd.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    design = json.loads(args.design.read_text())
    for case in CASES:
        (args.output_dir/(case+".glb")).write_bytes(build(design, case))
