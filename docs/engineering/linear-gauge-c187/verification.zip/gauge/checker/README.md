# C187 independent two-carriage gauge checker

The checker reads the standalone GLB and the frozen numeric design. It does not import either authoring system. Only the generic binary and scene reader was adapted from C186's `benchmark/evaluator/neutral_glb.py`. The world-space surface, trajectory, collision and gap tests and the specimen generator are specific to this fixture. The authoring brief and design are included byte-for-byte.

## Run

Run these commands from this directory with Python 3.9+ and NumPy. The checker writes JSON and returns exit status 0 on acceptance and 1 on rejection. A rejection records its first failing gate and the measurements completed before it. Full glTF schema conformance is a separate question.

```sh
sha256sum -c SHA256SUMS
python qualify.py --out /tmp/c187-qualification.json
python check.py controls/good.glb --out /tmp/c187-good.json
python check.py /path/to/submitted.glb --out /tmp/c187-candidate.json
```

The qualification runner checks the frozen GLBs, expected outcomes and reasons, and regenerates every control in memory to verify its bytes. To regenerate the files explicitly, use `python make_controls.py /tmp/c187-controls`. The full frozen outcomes are in `qualification.json`. The known-good full acceptance measurements are in `known-good.json`. `input-hashes.json` identifies the incoming ZIP and source task files.

## Admitted glTF

- One glTF 2.0 JSON chunk, one embedded binary buffer, one scene and one animation spanning exactly 0 to 2 seconds. All nodes belong to the rooted scene. Each of the seven mesh nodes and its mesh carry the exact requested ID. Extra meshes, duplicate part IDs, skins, morphs, extension payloads, images, textures and vertex colors are outside the profile.
- Static affine node matrices or static translation/rotation/scale bases may occur anywhere in the ancestry. Animated nodes use TRS, not matrices. The checker accepts nonsingular part world bases, including reflections. Local translations may be animated on any number of nested ancestors. All tracks use glTF LINEAR interpolation with increasing float32 times and clamped endpoints. Constant rotations and scales can be keyed. Quaternions may change their sign without changing their orientation. Time-varying local rotation or scale, STEP and CUBICSPLINE are rejected even when a particular clip might yield equivalent poses.
- Mesh primitives use indexed or non-indexed TRIANGLES, float32 positions and unsigned scalar indices. Supported accessor reads respect byte offsets and strides, and exclude sparse and normalized data. Every primitive must use an opaque, solid material. Its linear base color is checked on every channel against that part's specified RGB, within 0.005. Bounds and animation come from the binary values and indices. Accessor min/max, names and extras do not certify the geometry or travel.

## Geometric and temporal proof

At the first animation pose, each referenced vertex is transformed through the complete node ancestry into glTF world coordinates. The measured bounds must agree with every design face within 0.2 mm. Each triangle must belong to exactly one of the six measured axis-aligned cuboid faces. The face-plane tolerance is 0.0001 mm. The checker projects the triangle onto that face's unit rectangle, verifies its outward winding with the glTF determinant parity rule, and clips each potentially overlapping pair of triangles. It bounds both multiplicity and uncovered face area to two parts per million of that face. These thresholds account for floating-point coordinates. A duplicated triangle cannot replace a missing one with the same area. The signed shell volume must also agree with the product of the measured dimensions to ten parts per million. A surface split into multiple primitives or triangles with non-corner vertices is admissible.

With time-invariant ancestor linear bases, every world transform's linear basis is constant and its translation is affine on each interval of the union of all channel keys. Each vertex therefore has the same piecewise-affine displacement as its own node. At every key boundary, interval midpoint, quarter-clip time and endpoint the checker verifies world positions and displacement against the design to 0.2 mm. An affine error reaches its component extrema at the interval boundaries. Endpoint sampling alone across the entire clip would not suffice.

Each segment's velocity must stay within 0.025 mm/s per component of its part's measured whole-clip mean. Moving parts must have strictly positive X speed and no more than 0.001 mm of transverse displacement. Fixed-body displacement is bounded by 0.001 mm. Every pair of moving bodies must agree to 0.001 mm in displacement and 0.025 mm/s in velocity. The latter allowance covers the amplification of encoded float32 error when differencing short intervals. These tolerances are explicit measurement limits of this profile. The nominal translation is 300 mm in 2 seconds. A constant 299.92 mm translation passes the design's 0.2 mm position allowance.

All 21 pairs of measured boxes undergo a swept interval test. Interior overlap requires all six opposing face inequalities to hold at once. The checker intersects their linear time windows and permits a numerical contact allowance of 0.001 mm. For each matching shoe and stop, positive Y and Z overlap is checked at the union of key times. Overlap length is concave on each interval, so its minimum occurs at a boundary. The X gap is affine on each interval. Its derivative must be negative throughout the clip, and its smallest boundary value must occur at exactly 2 seconds. The initial and minimum gaps must match 315 and 15 mm within 0.5 mm.

## Qualification and scope

Four independently generated positives cover nested transforms, reflection, antipodal constant quaternions, multiple key grids, split ancestor travel, nominal tolerance and four-triangle face fans. The baseline uses indexed, interleaved mesh data as well as non-indexed triangles. Twenty-six negatives cover the five prescribed mutations and additional ID, topology, color, fixed/moving trajectory, interpolation, contact and scene failures. A short speed spike stays inside the 0.2 mm pose tolerance yet violates the rate check. A duplicate triangle counterfeits a face's area and bounds. Three direct swept-solver controls cover a crossing between disjoint endpoints, sliding face contact, and incompatible axis-overlap windows.

The checker certifies the exported geometry, clip and gap within these limits. Editable-source sharing, build reproducibility, exporter naming effects and visual playback require separate inspection.
