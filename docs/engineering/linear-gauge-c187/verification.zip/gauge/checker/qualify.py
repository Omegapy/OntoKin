#!/usr/bin/env python3
"""Check every frozen specimen, regenerate it in memory, and test swept overlap."""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from check import check, swept_overlap
from make_controls import build, CASES


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--controls", type=Path, default=Path(__file__).with_name("controls"))
    parser.add_argument("--design", type=Path, default=Path(__file__).with_name("assembly.json"))
    parser.add_argument("--out", type=Path)
    args = parser.parse_args()
    design = json.loads(args.design.read_text())
    cases = []
    for name, expected_reason in CASES.items():
        path = args.controls/(name+".glb")
        actual = path.read_bytes()
        r = check(path, args.design)
        matched = r["pass"] == (expected_reason is None) and (expected_reason is None or expected_reason in r.get("reason", ""))
        extra = {}
        if expected_reason is None and r["pass"]:
            extra["measuredGaps"] = r["gaps"]
            mm = 15.08 if name == "good_design_rounding" else 15.
            matched &= all(abs(g["minimumMm"] - mm) < .0001 and g["minimumAtS"] == 2 for g in r["gaps"].values())
        reproduces = actual == build(design, name)
        cases.append({"case": name, "expectedPass": expected_reason is None, "observedPass": r["pass"],
                      "reason": r.get("reason"), "reproducesBytes": reproduces,
                      "sha256": hashlib.sha256(actual).hexdigest(), "verified": bool(matched and reproduces), **extra})

    a = np.array([[0., 0., 0.], [1., 1., 1.]])
    b = a+[4,0,0]
    # These cases stress the analytic interval solver independently of the endpoint bounds gate.
    # The crossing boxes have separated endpoints and briefly share an interior.
    crossed = swept_overlap(a, a+[5,0,0], b, b+[-5,0,0])
    contact = swept_overlap(a, a+[5,0,0], b+[0,1,0], b+[-5,1,0])
    skew = swept_overlap(a, a+[10,0,0], a+[4,-7,0], a+[4,3,0])
    unit = {"crossingInteriorWitnessFraction": crossed,
            "crossingInteriorFound": crossed is not None and .3 < crossed < .5,
            "slidingFaceContactAllowed": contact is None,
            "disjointAxisOverlapWindowsAllowed": skew is None}
    frozen_names = {p.stem for p in args.controls.glob("*.glb")}
    ok = all(c["verified"] for c in cases) and frozen_names == set(CASES)
    ok &= all(v for k, v in unit.items() if k != "crossingInteriorWitnessFraction")
    result = {"pass": bool(ok), "positiveCount": sum(x is None for x in CASES.values()),
              "negativeCount": sum(x is not None for x in CASES.values()), "cases": cases, "sweptSolver": unit}
    output = json.dumps(result, indent=2, allow_nan=False)+"\n"
    if args.out:
        args.out.write_text(output)
    else:
        print(output, end="")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
