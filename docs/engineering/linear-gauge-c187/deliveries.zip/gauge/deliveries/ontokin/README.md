# Two-carriage linear gauge

Open `build/starter.glb` for the standalone animated assembly in metres. The editable OntoKin program is `main.ok`. Its part origins sit at their minimum XYZ corners. Positions and dimensions in the source use millimetres. The assembly travels along world +X with +Y up.

## Rebuild

From the staged OntoKin authoring arm, run the following command with a fresh output directory.

```sh
/dev/shm/ontokin-c187/restored/venv/bin/python -IB delivery/build.py tools/runtime rebuilt
```

For a relocated package, the equivalent invocation from the directory containing `main.ok` is `python3.12 -IB build.py /path/to/pinned/runtime /path/to/new/output`. The compiler is OntoKin reference 0.4.0, language 0.22, profile torque-0.1. The pinned source digest is `3e6ef2df6a7e8837050abb949075bff9b65f6a4aa4a9f1587850d7ddd59bce56`.

## Edit a shoe

Both `left_shoe` and `right_shoe` instantiate `class Shoe`. This class builds one cuboid from its public `length_x`, `height_y`, `width_z` and `finish` parameters. Change a class default to change both shoes. For an edit to just one shoe, assign the parameter inside its named `object` block in `scene Slide`. For example, placing `length_x = 95[mm];` inside the `left_shoe` block shortens its +X end by 5 mm. A disposable rebuild of this example changed only the left shoe's bounds. The submitted source uses the original 100 mm length for both shoes.

## Clearance

| Shoe | Initial gap | Minimum gap | Time of minimum |
| --- | ---: | ---: | ---: |
| Left | 315 mm | 15 mm | 2.000 s |
| Right | 315 mm | 15 mm | 2.000 s |

Each stop starts at X = 495 mm. Each shoe's forward face starts at X = 180 mm and travels at 150 mm/s, so its gap is 315 − 150t mm. Shoe and stop overlap by 40 mm in Y and 80 mm in Z. Measurements from the delivered vertices and animation gave 15.000008 mm for each minimum. All 25 keys and their 24 midpoints matched the source bounds within 0.000023 mm. Every rotation was the identity, and the gap decreased throughout each linear key interval. Each mesh has eight geometric corners and twelve triangles, with two incident triangles per geometric edge.

## Export record

The runtime emits the requested node IDs and gives every extruded mesh the name `extrusion`. The build writes the untouched export to `build/native.glb`, then copies the seven node IDs to their matching mesh names in `build/starter.glb`. The individual before/after values, JSON pointers and SHA-256 digests are in `build/export-diff.json`. Reversing those seven fields reproduced the native JSON on comparison. Both files contain the same 11,552-byte BIN chunk (SHA-256 `dac056d1748a9faacbdb309c7397ac79547f908059555fa2a5316894db6d38db`). `build/export.json` is the native exporter's report.

The author used the coordinator's staged runtime, its extrusion and export examples, and a local GLB reader for independent checks. The first native compile succeeded. A transient shell connection interrupted three verification commands before they launched. Rerunning them succeeded. No external design assistance was used.
