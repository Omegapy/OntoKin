"""Compile main.ok and copy each occurrence's stable ID into its glTF mesh name."""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys


def label_meshes(native):
    _, _, total = struct.unpack_from("<4sII", native)
    size, kind = struct.unpack_from("<I4s", native, 12)
    if total != len(native) or kind != b"JSON":
        raise ValueError("Expected an embedded GLB with a JSON chunk.")
    document = json.loads(native[20:20 + size])
    changes = []
    used = set()
    for node in document["nodes"]:
        if "mesh" not in node:
            continue
        idx = node["mesh"]
        if idx in used:
            raise ValueError("One mesh is referenced by multiple occurrence IDs.")
        used.add(idx)
        mesh = document["meshes"][idx]
        if mesh.get("name") != node["name"]:
            changes.append({"path": f"/meshes/{idx}/name", "before": mesh.get("name"),
                            "after": node["name"]})
            mesh["name"] = node["name"]
    data = json.dumps(document, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    data += b" " * (-len(data) % 4)
    tail = native[20 + size:]
    output = struct.pack("<4sIIII", b"glTF", 2, 20 + len(data) + len(tail),
                         len(data), 0x4e4f534a) + data + tail
    bin_size, bin_kind = struct.unpack_from("<I4s", tail)
    if bin_kind != b"BIN\x00" or len(tail) != 8 + bin_size:
        raise ValueError("Expected one BIN chunk after JSON.")
    digest = lambda b: hashlib.sha256(b).hexdigest()
    diff = {"native_sha256": digest(native), "final_sha256": digest(output),
            "bin_byte_length": bin_size, "bin_sha256": digest(tail[8:]),
            "json_fields_changed": changes}
    return output, diff


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkout", type=Path, help="pinned OntoKin source root")
    parser.add_argument("output", type=Path, help="new output directory")
    args = parser.parse_args()
    sys.path.insert(0, str(args.checkout.resolve()))
    from ontokin.budget_runtime import execute_torque_export
    from ontokin.execution_budget import HostPolicy
    from ontokin.scene import ExportOptions
    from ontokin.texture_bundle import load_texture_bundle

    entry = Path(__file__).with_name("main.ok")
    bundle = load_texture_bundle({
        "schema_version": "ontokin.bundle/0.2",
        "entry": {"filename": entry.name, "source": entry.read_text(encoding="utf-8")},
        "modules": [], "assets": [],
    })
    args.output.mkdir(parents=True, exist_ok=False)
    result = execute_torque_export(
        bundle, policy=HostPolicy(max_operations=1_000_000, max_elapsed_ms=80_000),
        caller_caps={"max_operations": 1_000_000, "max_elapsed_ms": 80_000},
        options=ExportOptions(end="2", fps=12, helpers=False),
    )
    (args.output / "export.json").write_text(json.dumps(result.report, indent=2) + "\n")
    if result.data is None:
        raise SystemExit("Export failed. See export.json.")
    (args.output / "native.glb").write_bytes(result.data)
    output, diff = label_meshes(result.data)
    (args.output / "starter.glb").write_bytes(output)
    (args.output / "export-diff.json").write_text(json.dumps(diff, indent=2) + "\n")


if __name__ == "__main__":
    main()
