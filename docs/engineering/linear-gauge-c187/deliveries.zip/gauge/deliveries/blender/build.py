"""Two-carriage linear gauge. Run with Blender 4.5.3 LTS. See README.md."""
from pathlib import Path
import sys

import bpy
from mathutils import Vector


# Public dimensions use the output frame: X along the slide, Y up, Z across lanes.
# Each cuboid is anchored at its minimum X, minimum Y and centre Z.
# Geometry dimensions are (length X, height Y, width Z), in millimetres.
SIZE_MM = {
    "base": (730, 80, 600),
    "carriage": (200, 40, 80),
    "shoe": (100, 50, 80),
    "stop": (30, 40, 120),
}
COLOR_LINEAR = {
    "base": (0.21, 0.26, 0.30),
    "carriage": (0.17, 0.50, 0.54),
    "shoe": (0.84, 0.60, 0.18),
    "stop": (0.61, 0.25, 0.19),
}
LANE_Z_MM = {"left": -160, "right": 160}
# Optional full XYZ size, keyed by the part ID, for an individual instance.
INSTANCE_SIZE_MM = {}
DURATION_S = 2
TRAVEL_MM = 300
FPS = 24


def blender_point(x, y, z):
    """Convert output-frame millimetres to Blender's Z-up metres."""
    return (x / 1000, -z / 1000, y / 1000)


def make_part(scene, materials, part_id, kind, anchor_mm, parent=None):
    length, height, width = INSTANCE_SIZE_MM.get(part_id, SIZE_MM[kind])
    half_width = width / 2
    # Vertex order is defined in Blender's right-handed frame.
    vertices = [
        blender_point(x, y, z)
        for y in (0, height)
        for z in (half_width, -half_width)
        for x in (0, length)
    ]
    faces = [
        (0, 2, 3, 1), (4, 5, 7, 6),
        (0, 1, 5, 4), (2, 6, 7, 3),
        (0, 4, 6, 2), (1, 3, 7, 5),
    ]
    mesh = bpy.data.meshes.new(part_id)
    mesh.from_pydata(vertices, [], faces)
    mesh.update()
    part = bpy.data.objects.new(part_id, mesh)
    scene.collection.objects.link(part)
    part.parent = parent
    part.location = blender_point(*anchor_mm)
    mesh.materials.append(materials[kind])
    return part


def animate_carriage(carriage, scene):
    start_x = carriage.location.x
    carriage.keyframe_insert(data_path="location", index=0, frame=0)
    carriage.location.x = start_x + TRAVEL_MM / 1000
    carriage.keyframe_insert(data_path="location", index=0, frame=scene.frame_end)
    action = carriage.animation_data.action
    action.name = carriage.name + "_travel"
    for curve in action.fcurves:
        for key in curve.keyframe_points:
            key.interpolation = "LINEAR"


def build(output):
    if bpy.app.version != (4, 5, 3):
        raise RuntimeError(f"Expected Blender 4.5.3, found {bpy.app.version_string}")
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.context.preferences.filepaths.save_version = 0
    scene = bpy.context.scene
    scene.name = "Two-carriage linear gauge"
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.length_unit = "MILLIMETERS"
    scene.render.fps = FPS
    scene.frame_start = 0
    scene.frame_end = FPS * DURATION_S

    materials = {}
    for kind, rgb in COLOR_LINEAR.items():
        mat = bpy.data.materials.new(kind + "_material")
        mat.diffuse_color = (*rgb, 1)
        mat.use_nodes = True
        shader = mat.node_tree.nodes.get("Principled BSDF")
        shader.inputs["Base Color"].default_value = (*rgb, 1)
        shader.inputs["Roughness"].default_value = 0.65
        materials[kind] = mat

    make_part(scene, materials, "base", "base", (-160, 0, 0))
    for lane, lane_z in LANE_Z_MM.items():
        carriage = make_part(scene, materials, lane + "_carriage", "carriage",
                             (-100, 80, lane_z))
        # Relative to the carriage anchor. The shoe inherits carriage motion.
        make_part(scene, materials, lane + "_shoe", "shoe", (180, 40, 0),
                  parent=carriage)
        make_part(scene, materials, lane + "_stop", "stop", (495, 130, lane_z))
        animate_carriage(carriage, scene)

    scene.frame_set(0)
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type == "VIEW_3D":
                view = area.spaces.active
                view.shading.color_type = "MATERIAL"
                view.overlay.show_floor = False
                view.overlay.show_axis_x = False
                view.overlay.show_axis_y = False
                view.region_3d.view_perspective = "ORTHO"
                view.region_3d.view_rotation = Vector((0.65, 1.3, -0.95)).to_track_quat("-Z", "Y")
                view.region_3d.view_location = (0.205, 0, 0.085)
                view.region_3d.view_distance = 1.35

    output.mkdir(parents=True, exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=str(output / "gauge.blend"))
    result = bpy.ops.export_scene.gltf(
        filepath=str(output / "gauge.glb"), export_format="GLB",
        export_yup=True, export_animations=True, export_animation_mode="SCENE",
        export_anim_scene_split_object=False,
        export_frame_range=True, export_force_sampling=True,
        export_texcoords=False, export_normals=True, export_skins=False,
        export_morph=False, export_cameras=False, export_lights=False,
    )
    if "FINISHED" not in result:
        raise RuntimeError(f"glTF export failed: {result!r}")


if __name__ == "__main__":
    args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if len(args) != 1:
        raise SystemExit("Pass the output directory after --")
    build(Path(args[0]).resolve())
