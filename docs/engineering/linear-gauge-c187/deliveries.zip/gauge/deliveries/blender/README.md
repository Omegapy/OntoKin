# Two-carriage linear gauge

Open `gauge.blend` to edit the seven parts or play frames 0 through 48 at 24 fps. The standalone `gauge.glb` stores both carriage tracks in one two-second animation. Each shoe is a child of its carriage.

## Rebuild

Run this command from the directory containing `build.py`, with Blender 4.5.3 LTS on the executable search path. It writes a fresh native project and GLB into `rebuilt/`.

```sh
blender -b -t 2 --factory-startup --python-exit-code 1 --python build.py -- rebuilt
```

The exact executable used in this run was `/workspace/scratch/e7fbfa81c224/replay-work/blender-4.5.3-linux-x64/blender`. The build requires only that distribution and its bundled glTF exporter.

## Edit one shoe

`SIZE_MM["shoe"]` in `build.py` defines both shoes as 100 × 50 × 80 mm in output X, Y, Z order. Each uses the same cuboid construction, with its origin at minimum X, minimum Y and centre Z. The lane name determines the part ID. To vary one part, set `INSTANCE_SIZE_MM` to a dictionary containing the desired full size under `"left_shoe"` or `"right_shoe"`, then rebuild. Parts without an override use their shared size. Each part has its own named mesh in the native scene so it also supports direct editing.

Source dimensions use millimetres in the glTF frame, where +Y points up. The script converts those dimensions to Blender's Z-up metre coordinates. The native glTF exporter restores Y-up metre coordinates.

## Clearance and checks

| Shoe / matching stop | Gap at 0 s | Minimum gap | Time of minimum |
| --- | ---: | ---: | ---: |
| Left | 315.000 mm | 15.000 mm | 2.000 s |
| Right | 315.000 mm | 15.000 mm | 2.000 s |

The stop's near face is at X = 495 mm. The matching shoe's front face moves from 180 mm to 480 mm at 150 mm/s. Their Y extents overlap by 40 mm and their Z extents overlap by 80 mm throughout. Each gap therefore decreases linearly.

A separate Python reader decoded the GLB vertex positions, triangle indices, colors and animation accessors. It applied parent translations and checked all exported sample times, plus an intermediate time of 0.271 s. Every mesh had eight distinct geometric corners and twelve outward-facing triangles with paired edges. The maximum world-bound error was 0.000045 mm and the maximum linear color channel error was below 0.000000027. A second clean build reproduced the GLB byte for byte.

## Export record

The native Blender glTF exporter wrote the delivered GLB directly. Node and mesh names already matched all seven specified IDs. The GLB SHA-256 is `b54bb8269167819909a9cf8a9698dc29549aad448326788c765ea38518880cd1`.

Two local export trials preceded submission. The first exposed the exporter's default of splitting scene animation by object. The second exposed Bézier easing on the native keys, with a 28.86 mm worst-case bound error at intermediate times. The submitted source explicitly combines scene tracks and sets both keys of each carriage to linear interpolation. The coordinator supplied the brief, design table and executable. The author created the source and performed the local checks independently.
