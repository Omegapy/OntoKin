"""Lay out the twelve captures made by the C187 camera."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parents[1]
shots = root / "evidence/playback"
page = Image.new("RGB", (1320, 1240), "#14232d")
draw = ImageDraw.Draw(page)

def label(x, y, text, size, color="#eef5f4", bold=False):
    font = ImageFont.truetype("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf", size)
    draw.text((x, y), text, font=font, fill=color)

label(32, 18, "ONTOKIN   /   C189", 18, "#afdcce", True)
label(30, 48, "Does the shoe follow the carriage?", 40, bold=True)
label(32, 109, "The left lane is at the top of each frame. The right carriage travels at 150 mm/s in every row.", 22)
columns = [32, 463, 894]
for x, t in zip(columns, [0, 1, 2]):
    label(x, 158, f"{t}.000 s", 23, "#afdcce", True)
for i, (speed, route, name) in enumerate([
    (125, "blender", "Blender / Python"), (125, "ontokin", "OntoKin"),
    (100, "blender", "Blender / Python"), (100, "ontokin", "OntoKin")
]):
    top = 207 + i * 252
    label(32, top, f"{name}    ·    left feed {speed} mm/s", 19, bold=True)
    label(780, top, f"Final clearance    left {315-2*speed} mm    /    right 15 mm", 18, "#afdcce")
    for t, x in enumerate(columns):
        with Image.open(shots / f"feed-{speed}/{route}-{t}.png") as im:
            page.paste(im.convert("RGB").resize((391,223), Image.Resampling.LANCZOS), (x,top+26))
page.save(shots / "comparison.png", optimize=True)
