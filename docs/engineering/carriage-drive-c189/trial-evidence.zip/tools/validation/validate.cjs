const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const [moduleDir, destination, group = 'formal'] = process.argv.slice(2);
const root = path.resolve(__dirname, '../..');
const validator = require(path.resolve(moduleDir));
async function validate() {
  let base;
  let names;
  if (group === 'formal') {
    base = 'drive/deliveries';
    names = [125, 100].flatMap(feed => [
      'blender/feed-' + feed + '.glb',
      'ontokin/feed-' + feed + '/build/native.glb',
      'ontokin/feed-' + feed + '/build/assembly.glb'
    ]);
  } else if (group === 'private-110') {
    base = 'drive/audit/receipts/private-110';
    names = ['blender-final.glb', 'ontokin-raw.glb', 'ontokin-final.glb'];
  } else {
    throw new Error('Unknown validation group: ' + group);
  }
  const receipts = {};
  for (const name of names) {
    const bytes = fs.readFileSync(path.join(root, base, name));
    const report = await validator.validateBytes(new Uint8Array(bytes), {uri:name, writeTimestamp:false});
    receipts[name] = {sha256:crypto.createHash('sha256').update(bytes).digest('hex'), report};
    if (report.issues.numErrors || report.issues.numWarnings) process.exitCode = 1;
  }
  fs.writeFileSync(destination, JSON.stringify(receipts, null, 2) + '\n');
}
validate().catch(e => { console.error(e); process.exitCode = 1; });
