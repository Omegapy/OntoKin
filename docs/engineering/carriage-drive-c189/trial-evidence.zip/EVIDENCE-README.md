# C189 trial evidence

Two native designs drove an attached shoe at three speeds and retained the right lane's original feed. The study's repository README provides the results and links to the comparison image.

Use CPython 3.12.14 and NumPy 2.3.5. From the extracted root, run the two commands in Bash.

```sh
python3.12 -IB drive/replay.py > /tmp/c189-results.json
cmp evidence/results.json /tmp/c189-results.json
```

The `drive/audit/README.md` gives full native rebuild and perturbation commands. The native runtime is included under `tools/native`. For Blender use 4.5.3 LTS. To repeat the six formal Khronos validations, extract the included validator npm tarball and run `node tools/validation/validate.cjs /path/to/package /tmp/validation.json`. Compare this with `evidence/validation/khronos.json`. Pass `private-110` as the final argument for the three additional validations.

Serve the extracted root on loopback and open `gauge/viewer/` to inspect the GLBs from the C187 camera. All twelve captures and the contact sheet are under `evidence/playback/`. The C190 coordinator starts with `NEXT-TASK.md`. Its participant brief and stop positions are under `next/`.
