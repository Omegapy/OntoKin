"""Execute sealed source builds and isolated single-control perturbations. Never writes to deliveries."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import shutil
import subprocess


def main():
    p = argparse.ArgumentParser(description=__doc__)
    for name in ('blender','python','runtime','blender-arm','ontokin-arm','c188','work'):
        p.add_argument('--'+name,type=lambda x:Path(x).resolve(),required=True)
    a = p.parse_args()
    a.work.mkdir(parents=True,exist_ok=False)
    t = a.work/'tmp'
    t.mkdir()
    env = dict(os.environ,TMPDIR=str(t),TEMP=str(t),TMP=str(t),PYTHONDONTWRITEBYTECODE='1')
    def run(argv, out, name):
        with (out/(name+'.log')).open('w') as log:
            result = subprocess.run(list(map(str,argv)),cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f'{name} failed in {out} (exit {result.returncode}). See its log.')
    def blender(source,script,*args):
        return [a.blender,'-b','-t','2',source,'--python-exit-code','1','--python',script,'--',*args]
    probe = Path(__file__).with_name('probe_blender.py').resolve()
    def do_blender():
        arm=a.blender_arm
        for trial in (1,2):
            out=a.work/f'blender-{trial}'
            out.mkdir()
            run(blender(arm/'c188/gauge.blend',arm/'build.py',arm/'settings/feed-125.json',
                        arm/'settings/feed-100.json',out/'built'),out,'clean-build')
            for speed in (125,100,110):
                source=arm/f'feed-{125 if speed==110 else speed}.blend'
                private_copy=out/f'seed-for-{speed}.blend'
                shutil.copyfile(source,private_copy)
                run(blender(private_copy,probe,out/f'native-{speed}.json',
                            '110' if speed==110 else 'unchanged',out/f'reopened-{speed}.glb'),out,f'reopen-{speed}')
        run(blender(a.c188/'blender/gauge.blend',probe,a.work/'blender-c188.json','unchanged','-'),a.work,'blender-c188')
    def do_ontokin():
        arm=a.ontokin_arm
        for trial in (1,2):
            out=a.work/f'ontokin-{trial}'
            out.mkdir()
            for speed in (125,100,110):
                source=arm/f'feed-{125 if speed==110 else speed}/main.ok'
                if speed==110:
                    original=source.read_bytes()
                    old,new=b'feed_speed = 125[mm/s];',b'feed_speed = 110[mm/s];'
                    assert original.count(old)==1
                    source=out/'private-110.ok'
                    source.write_bytes(original.replace(old,new))
                run([a.python,'-IB',arm/'build.py',a.runtime,source,out/f'feed-{speed}'],out,f'compile-{speed}')
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=[pool.submit(do_blender),pool.submit(do_ontokin)]
        for result in results:
            result.result()
    print('Both clean rebuilds and both native perturbations complete for each arm.')


if __name__=='__main__':
    main()
