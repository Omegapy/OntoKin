"""Inspect a reopened native scene and, if requested, export it with one control edit."""
import hashlib
import json
import sys
from pathlib import Path

import bpy


def vec(data):
    return [float(x) for x in data]


def digest(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True).encode()).hexdigest()


def native_description(scene):
    scene.frame_set(0)
    summary = {}
    for obj in sorted(scene.objects, key=lambda x: x.name):
        anim = obj.animation_data
        action = anim.action if anim else None
        drivers = []
        for curve in anim.drivers if anim else ():
            drivers.append({"path": curve.data_path, "index": curve.array_index,
                            "expression": curve.driver.expression,
                            "variables": [{"type": v.type, "name": v.name,
                                           "target_id": v.targets[0].id.name,
                                           "target_path": v.targets[0].data_path} for v in curve.driver.variables]})
        mesh = obj.data
        shape = {"vertices": [vec(v.co) for v in mesh.vertices],
                 "polygons": [list(p.vertices) for p in mesh.polygons]}
        mat, = mesh.materials
        material = {"name": mat.name, "rgba": vec(mat.diffuse_color),
                    "shader_rgba": vec(mat.node_tree.nodes['Principled BSDF'].inputs['Base Color'].default_value),
                    "roughness": mat.node_tree.nodes['Principled BSDF'].inputs['Roughness'].default_value}
        summary[obj.name] = {"type": obj.type, "parent": obj.parent.name if obj.parent else None,
                             "properties": {k:obj[k] for k in obj.keys()},
                             "local_transform_at_start": [vec(row) for row in obj.matrix_local],
                             "action": action.name if action else None, "drivers": drivers,
                             "nla_count": len(anim.nla_tracks) if anim else 0,
                             "constraint_count": len(obj.constraints), "has_animation_data": anim is not None,
                             "has_rigid_body": obj.rigid_body is not None,
                             "rigid_body_constraint": obj.rigid_body_constraint is not None,
                             "mesh_name": mesh.name, "shape_sha256": digest(shape), "material": material}
    return {"range_frames": [scene.frame_start, scene.frame_end], "fps": scene.render.fps,
            "fps_base": scene.render.fps_base, "has_rigid_body_world": scene.rigidbody_world is not None,
            "objects": summary}


def evaluated_motion(scene, left_speed):
    lanes = {}
    for lane, feed in (("left", left_speed), ("right", 150)):
        carriage = scene.objects[f'{lane}_carriage']
        shoe = scene.objects[f'{lane}_shoe']
        assert shoe.parent == carriage and shoe.animation_data is None
        origins, relative = [], []
        for f in range(49):
            scene.frame_set(f)
            graph = bpy.context.evaluated_depsgraph_get()
            carrier = carriage.evaluated_get(graph).matrix_world
            child = shoe.evaluated_get(graph).matrix_world
            origins.append([vec(carrier.translation), vec(child.translation)])
            relative.append([vec(row) for row in carrier.inverted() @ child])
        drift = max(abs(v - relative[0][j][k]) for m in relative for j, row in enumerate(m)
                    for k, v in enumerate(row))
        residual_mm = max(abs(1000*(p[k] - origins[0][i][k]) - (feed*f/24 if k == 0 else 0))
                          for f, pair in enumerate(origins) for i, p in enumerate(pair) for k in range(3))
        assert residual_mm < .001 and drift < 1e-6
        lanes[lane] = {"parent":carriage.name,"child":shoe.name, "offset_carriage_frame_blender_m":
                        [relative[0][i][3] for i in range(3)],"checked_integer_frames":49,
                        "max_relative_matrix_element_drift":drift,
                        "max_absolute_translation_error_mm":residual_mm,
                        "travel_x_mm_at_2s":{name:1000*(origins[-1][i][0] - origins[0][i][0])
                                              for i,name in enumerate((carriage.name, shoe.name))}}
    scene.frame_set(0)
    return lanes


def main():
    report, requested, target = sys.argv[sys.argv.index('--') + 1:]
    scene = bpy.context.scene
    assert bpy.app.version == (4, 5, 3) and bpy.app.build_hash == b'67807e1800cc'
    source = Path(bpy.data.filepath)
    before = native_description(scene)
    obj = scene.objects['left_carriage']
    seed = 'speed_mm_s' not in obj
    if requested != 'unchanged':
        assert not seed and obj['speed_mm_s'] == 125
        obj['speed_mm_s'] = float(requested)
        obj.update_tag()
        scene.frame_set(0)
    speed = 150 if seed else obj['speed_mm_s']
    after = native_description(scene)
    if requested != 'unchanged':
        expected = json.loads(json.dumps(before))
        expected['objects']['left_carriage']['properties']['speed_mm_s'] = speed
        assert expected == after
    if not seed:
        for lane,s in [('left',speed),('right',150)]:
            carrier = after['objects'][f'{lane}_carriage']
            shoe = after['objects'][f'{lane}_shoe']
            assert carrier['properties']['speed_mm_s'] == s and carrier['action'] is None
            drv, = carrier['drivers']
            var, = drv['variables']
            assert drv['path']=='location' and drv['index']==0 and var['target_id']==f'{lane}_carriage'
            assert var['target_path']=='["speed_mm_s"]' and var['type']=='SINGLE_PROP'
            assert shoe['parent']==f'{lane}_carriage' and not shoe['has_animation_data']
    assert not after['has_rigid_body_world'] and all(not v['has_rigid_body'] and
            not v['rigid_body_constraint'] and not v['constraint_count'] for v in after['objects'].values())
    motion = evaluated_motion(scene, speed)
    if target != '-':
        result = bpy.ops.export_scene.gltf(filepath=str(Path(target).resolve()), export_format='GLB',
                export_yup=True,export_animations=True,export_animation_mode='SCENE',
                export_anim_scene_split_object=False,export_frame_range=True,export_force_sampling=True,
                export_texcoords=False,export_normals=True,export_skins=False,export_morph=False,
                export_cameras=False,export_lights=False)
        assert 'FINISHED' in result
    document = {"source_basename":source.name,"source_sha256":hashlib.sha256(source.read_bytes()).hexdigest(),
                "blender_version":bpy.app.version_string,"blender_build":bpy.app.build_hash.decode(),
                "intentional_edit":None if requested=='unchanged' else {"path":"left_carriage[\"speed_mm_s\"]", "before":125,"after":speed},
                "native":after, "evaluated_motion":motion}
    Path(report).write_text(json.dumps(document, indent=2)+'\n')


main()
