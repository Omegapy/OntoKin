"""Verify replays, derive independent field records, save source-control and GLB receipts."""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent))
from glb_audit import inspect_glb, load, variant_diff


def hashed(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def js(p):
    return json.loads(p.read_text())


def write(p,data):
    p.write_text(json.dumps(data,indent=2)+'\n')


def changes(a,b,keys=()):
    if isinstance(a,dict) and isinstance(b,dict):
        for k in sorted(set(a)|set(b)):
            if k in a and k in b:
                yield from changes(a[k],b[k],keys+(k,))
            else:
                yield {'path':list(keys+(k,)),'before':a.get(k),'after':b.get(k)}
    elif a!=b:
        yield {'path':list(keys),'before':a,'after':b}


def diff(path,a,b,names):
    path.write_text(''.join(difflib.unified_diff(a.read_text().splitlines(True),b.read_text().splitlines(True),*names)))


def file_manifest(root,unprefixed=None):
    manifest={}
    path=unprefixed or root/'SHA256SUMS'
    for row in path.read_text().splitlines():
        value,name=row.split(maxsplit=1)
        if unprefixed:
            assert name.startswith('starter/')
            name=name[len('starter/'):]
        assert hashed(root/name)==value, name
        manifest[name]=value
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    assert actual==set(manifest)|({'SHA256SUMS'} if not unprefixed else set())
    return manifest


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for key in ('blender-arm','ontokin-arm','work','c188','output'):
        parser.add_argument('--'+key,required=True,type=lambda x:Path(x).resolve())
    a=parser.parse_args()
    a.output.mkdir(parents=True,exist_ok=False)
    out=a.output
    private=out/'private-110'; private.mkdir()
    evidence={'deliveries':{},'starters':{}}
    starter_blender=a.c188/'blender'
    expected={p.relative_to(starter_blender).as_posix():hashed(p) for p in starter_blender.rglob('*') if p.is_file()}
    nested=a.blender_arm/'c188'
    assert expected=={p.relative_to(nested).as_posix():hashed(p) for p in nested.rglob('*') if p.is_file()}
    evidence['starters']['blender']={'files':expected,'verified_against':'sealed nested c188/ directory'}
    evidence['starters']['ontokin']={'files':file_manifest(a.c188/'ontokin',a.ontokin_arm/'starter.sha256'),
                                      'verified_against':'sealed starter.sha256'}
    for route,arm in [('blender',a.blender_arm),('ontokin',a.ontokin_arm)]:
        evidence['deliveries'][route]={'sealed_manifest_sha256':hashed(arm/'SHA256SUMS'),'files':file_manifest(arm)}
    write(out/'provenance.json',evidence)
    diff(out/'ontokin-c188-to-c189.diff',a.c188/'ontokin/main.ok',a.ontokin_arm/'feed-125/main.ok',
         ('repair/deliveries/ontokin/main.ok','drive/deliveries/ontokin/feed-125/main.ok'))
    diff(out/'ontokin-c188-builder-to-c189.diff',a.c188/'ontokin/build.py',a.ontokin_arm/'build.py',
         ('repair/deliveries/ontokin/build.py','drive/deliveries/ontokin/build.py'))
    old=js(a.work/'blender-c188.json')['native']
    baseline=js(a.work/'blender-1/native-125.json')['native']
    delta=list(changes(old,baseline))
    assert all(row['path'][:2] in (['objects','left_carriage'],['objects','right_carriage']) and
               row['path'][2] in ('drivers','action','properties') for row in delta)
    write(out/'blender-c188-to-c189.json',delta)
    formal={}; paths={}
    for route,arm in [('blender',a.blender_arm),('ontokin',a.ontokin_arm)]:
        rows={}; native={}; paths[route]={}
        for speed in (125,100,110):
            case=f'feed-{speed}'
            a_files=[]; d_files=[]; other=[]
            for trial in (1,2):
                top=a.work/f'{route}-{trial}'
                if route=='blender':
                    raw=top/f'reopened-{speed}.glb'; final=raw
                    other.append(js(top/f'native-{speed}.json'))
                    if speed!=110:
                        clean=top/'built'/f'{case}.glb'; sealed=arm/f'{case}.glb'
                        assert clean.read_bytes()==raw.read_bytes()==sealed.read_bytes()
                else:
                    raw=top/case/'native.glb'; final=top/case/'assembly.glb'
                    if speed!=110:
                        pairs=[(raw,arm/case/'build/native.glb'),(final,arm/case/'build/assembly.glb'),
                               (top/case/'export-diff.json',arm/case/'build/export-diff.json')]
                        assert all(x.read_bytes()==y.read_bytes() for x,y in pairs)
                    r=js(top/case/'export.json')
                    source=arm/case/'main.ok' if speed!=110 else top/'private-110.ok'
                    assert r['outcome']=='valid' and r['source_revision']=='sha256:'+hashed(source)
                    assert r['validation']['status']=='passed' and not r['source_diagnostics']
                    assert r['source_code_sha256']=='3e6ef2df6a7e8837050abb949075bff9b65f6a4aa4a9f1587850d7ddd59bce56'
                    _,doc,_=load(raw); extras=doc['extras']['ontokin']
                    nodes={n['name']:n['extras']['ontokin'] for n in doc['nodes']}
                    assert len(extras['follows'])==2 and extras['joints']==[]
                    for lane,v,offset in [('left',speed,0.15),('right',150,0.18)]:
                        shoe=nodes[f'{lane}_shoe']; carriage=nodes[f'{lane}_carriage']
                        rel,=[f for f in extras['follows'] if f['path']==lane+'_mount']
                        assert (rel['parent_frame'],rel['child_object'],rel['offset_position_m'],rel['offset_rotation_wxyz'])==(
                            lane+'_carriage.frame',lane+'_shoe',[offset,.04,0],[1,0,0,0])
                        assert shoe['authored_motion']=='prescribed' and shoe['physical']=={'kind':'no_body'}
                        assert shoe['collision']=='disabled' and carriage['collision']=='disabled'
                        assert carriage['authored_motion']=='dynamic' and carriage['physical']['kind']=='sphere_body'
                        assert carriage['physical']['mass']==1.0 and carriage['physical']['radius']==.02
                        assert carriage['properties']['feed_speed']['value']==v/1000
                    other.append({'source_sha256':hashed(source),'runtime_source_digest':r['source_code_sha256'],
                                  'runtime_version':r['version'],'validation_status':r['validation']['status'],
                                  'language_version':r['language_version'],'source_profile':r['profile'],
                                  'native_follows':extras['follows'],'node_physics':{key:{k:value[k] for k in
                                    ['physical','authored_motion','collision']} for key,value in nodes.items()},
                                  'hierarchy':r['representation']['hierarchy'],'solver_embedded':r['torque_profile']['live_solver_embedded']})
                a_files.append(raw); d_files.append(final)
            assert a_files[0].read_bytes()==a_files[1].read_bytes() and d_files[0].read_bytes()==d_files[1].read_bytes()
            assert other[0]==other[1]; native[case]=other[0]
            rows[case]={'sealed_case':speed!=110,'trials':2,'clean_raw_byte_equal':True,'clean_final_byte_equal':True,
                        'clean_matches_sealed_raw_and_final':True if speed!=110 else None,
                        'export':inspect_glb(a_files[0],d_files[0],speed,route)}
            paths[route][speed]=d_files[0]
            if route=='blender' and speed!=110:
                blends=[(a.work/f'blender-{i}'/'built'/f'{case}.blend') for i in [1,2]]
                rows[case]['editable_blend_artifacts']={'sealed_sha256':hashed(arm/f'{case}.blend'),
                    'reruns_sha256':[hashed(x) for x in blends],'reruns_identical':blends[0].read_bytes()==blends[1].read_bytes(),
                    'both_reopened_sealed_glbs_match_paired_clean_builds':True}
            if speed==110:
                shutil.copyfile(d_files[0],private/f'{route}-final.glb')
                if route=='ontokin':
                    shutil.copyfile(a_files[0],private/'ontokin-raw.glb')
        if route=='blender':
            for s in [100,110]:
                n=native[f'feed-{s}']['native']; delta=list(changes(baseline,n))
                assert delta==[{'path':['objects','left_carriage','properties','speed_mm_s'],'before':125.,'after':s}]
            write(out/'blender-native.json',native)
            diff(out/'blender-settings.diff',arm/'settings/feed-125.json',arm/'settings/feed-100.json',('feed-125.json','feed-100.json'))
        else:
            a125=arm/'feed-125/main.ok'; private_ok=a.work/'ontokin-1/private-110.ok'
            for s,path in [(100,arm/'feed-100/main.ok'),(110,private_ok)]:
                before=a125.read_bytes(); old=b'feed_speed = 125[mm/s];'; assert before.count(old)==1
                assert before.replace(old,f'feed_speed = {s}[mm/s];'.encode())==path.read_bytes()
                diff(out/f'ontokin-125-to-{s}.diff',a125,path,('feed-125/main.ok',f'feed-{s}/main.ok'))
            shutil.copyfile(private_ok,private/'main.ok')
            write(out/'ontokin-native.json',native)
        formal[route]=rows
        for speed in (100,110):
            write(out/f'{route}-125-to-{speed}-glb.json',variant_diff(paths[route][125],paths[route][speed],route))
    write(out/'source-audit.json',formal)
    print('Source, perturbation, clean raw/final replay and edit-scope audits passed for both routes.')


if __name__=='__main__':
    main()
