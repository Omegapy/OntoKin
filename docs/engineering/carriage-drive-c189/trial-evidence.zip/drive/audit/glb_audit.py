"""Coordinator's read-only GLB measurements and field audit for the C189 linear clips."""
import collections
import hashlib
import json
import struct
from pathlib import Path


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    data = Path(path).read_bytes()
    magic, version, total, size, kind = struct.unpack_from('<4s3I4s', data)
    assert (magic, version, total, kind) == (b'glTF', 2, len(data), b'JSON')
    bin_size, kind = struct.unpack_from('<I4s', data, 20 + size)
    binary = data[28 + size:]
    assert kind == b'BIN\0' and bin_size == len(binary)
    return data, json.loads(data[20:20 + size]), binary


def fields(a, b, path=''):
    """Leaf changes under a stable document structure. Unexpected structural edits fail."""
    if isinstance(a, dict) and isinstance(b, dict):
        assert a.keys() == b.keys(), ('JSON object keys differ', path)
        for key in sorted(a):
            token = key.replace('~', '~0').replace('/', '~1')
            yield from fields(a[key], b[key], f'{path}/{token}')
    elif isinstance(a, list) and isinstance(b, list):
        assert len(a) == len(b), ('JSON array length differs', path)
        for i, (x, y) in enumerate(zip(a, b)):
            yield from fields(x, y, f'{path}/{i}')
    elif a != b or type(a) is not type(b):
        yield {'path': path, 'before': a, 'after': b}


def accessor(doc, binary, idx):
    a = doc['accessors'][idx]
    assert a['componentType'] == 5126 and 'sparse' not in a
    size = {'SCALAR': 1, 'VEC3': 3, 'VEC4': 4}[a['type']]
    fmt = struct.Struct('<' + 'f' * size)
    v = doc['bufferViews'][a['bufferView']]
    assert v['buffer'] == 0
    start = v.get('byteOffset', 0) + a.get('byteOffset', 0)
    stride = v.get('byteStride', fmt.size)
    return [fmt.unpack_from(binary, start + i * stride) for i in range(a['count'])]


def read_motion(doc, binary, left_speed):
    nodes = doc['nodes']
    ids = [n['name'] for n in nodes]
    lanes = ('left', 'right')
    names = {'base'} | {f'{side}_{kind}' for side in lanes for kind in ('carriage', 'shoe', 'stop')}
    assert set(ids) == names and len(ids) == len(names)
    parents = {c: i for i, n in enumerate(nodes) for c in n.get('children', [])}
    roots = doc['scenes'][doc['scene']]['nodes']
    assert set(roots) == set(range(len(nodes))) - set(parents)
    for n in nodes:
        assert ('matrix' not in n and n.get('rotation', [0, 0, 0, 1]) == [0, 0, 0, 1]
                and n.get('scale', [1, 1, 1]) == [1, 1, 1])
    clip, = doc['animations']
    poses = {}
    common = None
    for ch in clip['channels']:
        sampler = clip['samplers'][ch['sampler']]
        assert sampler.get('interpolation', 'LINEAR') == 'LINEAR'
        times = [t for t, in accessor(doc, binary, sampler['input'])]
        if common is None:
            common = times
        assert common == times and times == sorted(set(times)) and (times[0], times[-1]) == (0, 2)
        target = ch['target']
        values = accessor(doc, binary, sampler['output'])
        assert len(values) == len(times)
        if target['path'] == 'rotation':
            assert all(q == (0, 0, 0, 1) for q in values)
        else:
            assert target['path'] == 'translation' and target['node'] not in poses
            poses[target['node']] = values
    def offsets(idx, k):
        node = nodes[idx]
        xyz = list(poses[idx][k] if idx in poses else node.get('translation', [0, 0, 0]))
        if idx in parents:
            xyz = [a + b for a, b in zip(xyz, offsets(parents[idx], k))]
        return xyz
    corners = {}
    for i, n in enumerate(nodes):
        vertices = [v for p in doc['meshes'][n['mesh']]['primitives']
                    for v in accessor(doc, binary, p['attributes']['POSITION'])]
        local = [[op(dim) for dim in zip(*vertices)] for op in (min, max)]
        corners[n['name']] = [[[1000 * (a + b) for a, b in zip(extreme, offsets(i, k))]
                               for extreme in local] for k in range(len(common))]
    result = {}
    for side, speed in zip(lanes, (left_speed, 150)):
        shoe, carriage, stop = (corners[f'{side}_{p}'] for p in ('shoe', 'carriage', 'stop'))
        gaps = []
        drift = 0
        max_error = 0
        for k, time in enumerate(common):
            for part in (shoe, carriage, stop, corners['base']):
                target_speed = speed if part is shoe or part is carriage else 0
                for a in range(3):
                    for bound in (0, 1):
                        delta = part[k][bound][a] - part[0][bound][a]
                        max_error = max(max_error, abs(delta - (target_speed * time if a == 0 else 0)))
            for a in (1, 2):
                assert min(shoe[k][1][a], stop[k][1][a]) > max(shoe[k][0][a], stop[k][0][a])
            gaps.append(stop[k][0][0] - shoe[k][1][0])
            for a in range(3):
                delta = (shoe[k][0][a] - carriage[k][0][a]) - (shoe[0][0][a] - carriage[0][0][a])
                drift = max(drift, abs(delta))
        assert max_error < .0001 and drift < .0001
        assert all(b < a for a, b in zip(gaps, gaps[1:]))
        minimum = min(gaps)
        when = common[gaps.index(minimum)]
        assert abs(gaps[0] - 315) < .0001 and abs(minimum - (315 - 2 * speed)) < .0001 and when == 2
        result[side] = {'expected_speed_mm_s': speed, 'key_times_checked': len(common),
                        'measured_carriage_speed_mm_s': (carriage[-1][0][0] - carriage[0][0][0]) / when,
                        'measured_shoe_speed_mm_s': (shoe[-1][0][0] - shoe[0][0][0]) / when,
                        'initial_gap_mm': gaps[0], 'minimum_gap_mm': minimum, 'minimum_time_s': when,
                        'max_world_displacement_error_mm': max_error, 'max_relative_drift_mm': drift}
    return {'scene_roots': [ids[i] for i in roots], 'parents': {ids[c]: ids[p] for c, p in parents.items()},
            'linear_translation_targets': [ids[i] for i in sorted(poses)], 'lanes': result}


def inspect_glb(raw_path, final_path, left_speed, route):
    raw, a, ab = load(raw_path)
    final, b, bb = load(final_path)
    changes = list(fields(a, b))
    assert ab == bb
    if route == 'blender':
        assert raw == final and not changes
    else:
        assert route == 'ontokin'
        assert sorted((x['path'], x['before'], x['after']) for x in changes) == sorted(
            (f"/meshes/{n['mesh']}/name", 'extrusion', n['name']) for n in b['nodes'])
    return {'raw_sha256': sha(raw), 'final_sha256': sha(final), 'files_byte_equal': raw == final,
            'bin_byte_equal': ab == bb, 'raw_bin_sha256': sha(ab), 'final_bin_sha256': sha(bb),
            'bin_bytes': len(ab), 'raw_to_final_json_changes': changes, 'motion': read_motion(b, bb, left_speed)}


def variant_diff(before, after, route):
    old, a, ab = load(before)
    new, b, bb = load(after)
    changes = list(fields(a, b))
    assert len(ab) == len(bb) and a['bufferViews'] == b['bufferViews']
    deltas = {k for k, (x, y) in enumerate(zip(ab, bb)) if x != y}
    covered = set()
    outputs = []
    targets = {'left_carriage'} if route == 'blender' else {'left_carriage', 'left_shoe'}
    clip, = a['animations']
    for ch in clip['channels']:
        t = ch['target']
        node = a['nodes'][t['node']]['name']
        if node not in targets or t['path'] != 'translation':
            continue
        acc = clip['samplers'][ch['sampler']]['output']
        accessor_a = a['accessors'][acc]
        view = accessor_a['bufferView']
        meta = a['bufferViews'][view]
        start = meta.get('byteOffset', 0) + accessor_a.get('byteOffset', 0)
        stride = meta.get('byteStride', 12)
        assert accessor_a['type'] == 'VEC3' and accessor_a['componentType'] == 5126
        changed_keys = []
        for k in range(1, accessor_a['count']):
            offset = start + k * stride
            differing = deltas.intersection(range(offset, offset + 4))
            if differing:
                covered.update(differing)
                changed_keys.append(k)
        assert changed_keys == list(range(1, accessor_a['count']))
        outputs.append({'node': node, 'path': 'translation', 'component': 'X', 'accessor': acc,
                        'bufferView': view, 'changed_key_indices_inclusive': [changed_keys[0], changed_keys[-1]]})
    assert covered == deltas and {record['node'] for record in outputs} == targets
    categories = collections.Counter()
    for ch in changes:
        p = ch['path']
        if p.startswith('/extras/ontokin/reach_quantization/interval_certificates/'):
            categories['native interval error and speed bounds'] += 1
        elif p.endswith('/properties/feed_speed/value'):
            assert p == f"/nodes/{next(i for i, node in enumerate(a['nodes']) if node['name'] == 'left_carriage')}/extras/ontokin/properties/feed_speed/value"
            categories['native left carriage feed'] += 1
        elif p.endswith(('/source_revision', '/program_revision', '/entry_revision', '/program/revision')) and '/extras/ontokin/' in p:
            categories['source and program revision identities'] += 1
        else:
            raise ValueError(f'Unexpected between-speed JSON field {p}')
    assert route in ('blender', 'ontokin')
    assert not changes if route == 'blender' else changes
    return {'before_sha256': sha(old), 'after_sha256': sha(new), 'different_bin_bytes': len(deltas),
            'all_changed_bin_bytes_accounted_for': True, 'changed_animation_outputs': outputs,
            'changed_json_fields_count': len(changes), 'changed_json_categories': dict(categories),
            'changed_json_paths': [change['path'] for change in changes]}
