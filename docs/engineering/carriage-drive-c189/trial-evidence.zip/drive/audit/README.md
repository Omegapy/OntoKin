# C189 independent source audit

At 125 and 100 mm/s, two fresh builds per route reproduced all four final GLBs and their raw native exports byte for byte. At an unsubmitted 110 mm/s, one scalar change on a private copy of each native design produced a 220 mm left travel and a 95 mm minimum left clearance. The right lane traveled 300 mm and reached a 15 mm minimum. Both minima occurred at 2 s. Both private exports reproduced in two independent processes per route.

| Left feed (mm/s) | Blender left minimum (mm) | OntoKin left minimum (mm) | Blender right minimum (mm) | OntoKin right minimum (mm) |
| ---: | ---: | ---: | ---: | ---: |
| 125 | 64.999990 | 64.999998 | 14.999993 | 15.000008 |
| 100 | 114.999995 | 115.000010 | 14.999993 | 15.000008 |
| 110, coordinator edit | 94.999999 | 94.999999 | 14.999993 | 15.000008 |

## What moved the shoes

**Blender.** The C188 `.blend` already parented each shoe to its carriage. The new build replaces the two carriage keyframe actions with native X-location drivers. Each driver reads its own object's `speed_mm_s` value. The scene audit checked the parent identity, local matrix, action, driver targets, geometry, material and physics status of all seven objects. Under those checks, the sealed 125 and 100 designs differed only in the left feed. Independent reopens of each sealed scene regenerated its GLB. To test 110, the coordinator copied the sealed 125 scene, changed `left_carriage["speed_mm_s"]`, notified Blender of that edit with `update_tag()` and exported directly. The native objects retained their original relative transforms across all 49 integer frames. Both native shoe origins sit 180 mm forward and 40 mm above their carriage origins in output axes. The repaired left mesh extends 30 mm farther backward than the original shoe. The delivered GLB retains both parent relationships and stores two carriage translation channels. No object has a rigid body and the scene has no rigid-body world.

**OntoKin.** C188 gave each carriage and shoe its own velocity and sphere body. In C189 the carriage class reads its `feed_speed` parameter as initial X velocity, defaults to 150 mm/s, and retains the original 20 mm radius, 1 kg sphere with collision disabled. The left carriage overrides the default. The shoes are prescribed, collision-disabled `no_body()` occurrences. Each native `follow` names the matching carriage frame, shoe and rigid offset. Its evaluator composes the moving parent frame and fixed offset in `ontokin/evaluator.py` (the `follow` branch in `instance`). The compiled scene reports both relations. Relative to the native origins, the left offset is (150, 40, 0) mm and the right offset is (180, 40, 0) mm. Both routes put the same shoe surfaces at the same starting positions. The private OntoKin source differs from the 125 source by one numeric literal. Its export records the evaluated poses at 25 keys per part. The seven exported scene roots carry baked world tracks, including separate translation tracks for each carriage and shoe. These tracks have two native lane drives behind them. The shoe supplies no contact shape, inertia or reaction load. The task measured clearance between visible surfaces over the clip.

## Which bytes changed

The Blender exporter wrote the final GLBs directly. The OntoKin adapter changed seven JSON mesh names, copying each stable occurrence ID into its mesh name. Each raw and final BIN chunk matched byte for byte. The JSON pointer, old value and new value of each adapter edit are in `receipts/source-audit.json`.

Changing the submitted speed from 125 to 100 changed 154 bytes in Blender's left-carriage X output and 143 bytes in the OntoKin left-carriage and left-shoe X outputs. All other binary bytes matched across settings. Blender's glTF JSON remained identical across speeds. OntoKin's glTF JSON also records the changed native speed, source/program identities and interval certificates. For each variant pair, `receipts/*-glb.json` lists all changed JSON paths, changed buffer views and affected key ranges. The direct native source edits appear in the `.diff` files.

The separately saved Blender `.blend` rebuilds differed in their binary representation. The sealed projects have verified checksums, and fresh reopens and clean builds agreed on every GLB byte. The project-file digest differences are preserved in `receipts/source-audit.json`. OntoKin's native validation reports also contain runtime elapsed time. The replay checks the reports' source/runtime identity, diagnostic status and following semantics. It checks the raw GLB, final GLB and mesh-name adapter record byte for byte.

## Reproduce

Start in the extracted handoff root. Set `PY` to the pinned CPython 3.12.14 interpreter and `BLENDER` to the Blender 4.5.3 executable (build `67807e1800cc`). The handoff includes the pinned runtime under `tools/native/`. The native compiler's implementation digest is `3e6ef2df6a7e8837050abb949075bff9b65f6a4aa4a9f1587850d7ddd59bce56`. `WORK` and `RESULTS` must be new directories. Run from Bash with the restored tools. Use the audit script from its actual location if viewing it as a copy under repository evidence.

```sh
KIT=$PWD
AUDIT="$KIT/drive/audit"
RUNTIME="$KIT/tools/native"
WORK=$(mktemp -d)/builds
RESULTS=$(mktemp -d)/receipts
COMMON=(--blender-arm "$KIT/drive/deliveries/blender" --ontokin-arm "$KIT/drive/deliveries/ontokin" --c188 "$KIT/drive/baselines" --work "$WORK")
"$PY" -IB "$AUDIT/build_replays.py" "${COMMON[@]}" --blender "$BLENDER" --python "$PY" --runtime "$RUNTIME"
"$PY" -IB "$AUDIT/assess_replays.py" "${COMMON[@]}" --output "$RESULTS"
```

`receipts/provenance.json` verifies the complete sealed manifests and each supplied C188 source and export. `probe_blender.py` performs native inspection and direct export. `glb_audit.py` reads both raw and final GLB chunks and reconstructs world transforms using their actual hierarchy. For this clip all rotations are identity, all scales are one and translations are linear on common key intervals. Checking every endpoint bounds drift within each interval. Strictly decreasing gaps make the final key the global minimum. The readback confirms overlap of the opposing surfaces on the other two axes. The private diagnostic outputs and edited OntoKin source are under `receipts/private-110/`.
