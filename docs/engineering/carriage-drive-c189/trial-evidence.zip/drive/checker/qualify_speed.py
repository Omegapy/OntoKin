#!/usr/bin/env python3
"""Rebuild the synthetic controls and require each to reach its specified check."""
import argparse
import hashlib
import json
from pathlib import Path
import tempfile

import numpy as np

from measure_speed import HERE, measure, swept_overlap
from specimens import specimen

FAULTS = {"good": None, "fan-positive": None,
          "shoe-keeps-150": "left_shoe: world trajectory error",
          "right-also-slows": "right_carriage: world trajectory error",
          "wrong-mid-speed": "left_carriage: world trajectory error",
          "short-spike": "left_carriage: intermediate segment velocity error",
          "small-slip": "left: shoe offset varies",
          "subtolerance-stop": "right_stop: C188 solid or color changed",
          "missing-face": "left_shoe: incomplete or overlapping cuboid face"}


def run(controls, save):
    controls.mkdir(parents=True, exist_ok=True)
    cases = []
    for speed in (125, 100):
        for mode, expected in FAULTS.items():
            case_id = f"feed-{speed}"
            data = specimen(speed, mode)
            file = controls / f"{case_id}-{mode}.glb"
            file.write_bytes(data)
            r = measure(HERE / "baselines/synthetic.glb", file, case_id)
            reason = r.get("reason")
            if expected is None:
                correct = r["pass"] and r["clearance"]["certifiedNonoverlapPairs"] == 21
            else:
                correct = not r["pass"] and expected in (reason or "")
            record = {"file": file.name, "sha256": hashlib.sha256(data).hexdigest(),
                      "expectedPass": expected is None, "observedPass": r["pass"],
                      "expectedDiagnostic": expected, "observedDiagnostic": reason, "verified": correct}
            if r["pass"]:
                record["gaps"] = r["gaps"]
                record["sweptPairs"] = r["clearance"]["certifiedNonoverlapPairs"]
            if save:
                (HERE / "receipts" / f"{case_id}-{mode}.json").write_text(json.dumps(r, indent=2) + "\n")
            cases.append(record)
    # Both endpoints are clear. Only the first swept test intersects internally.
    small = np.array([[0., 0., 0.], [1., 1., 1.]])
    far = small + [7, 0, 0]
    sweep = {}
    for name, delta, collision in (("crosses-between-keys", [10, 0, 0], True),
                                   ("separated-in-z", [10, 0, 0], False),
                                   ("endpoint-face-contact", [6, 0, 0], False)):
        target = far + ([0, 0, 2] if name == "separated-in-z" else [0, 0, 0])
        u = swept_overlap(small, small+delta, target, target)
        sweep[name] = {"witnessFraction": u, "verified": (u is not None) == collision}
    return {"version": "C189.1", "pass": all(c["verified"] for c in cases + list(sweep.values())),
            "controls": cases, "sweptSlabControls": sweep}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--seal-controls", action="store_true")
    args = p.parse_args()
    with tempfile.TemporaryDirectory() as temp:
        controls = HERE / "controls" if args.seal_controls else Path(temp)
        result = run(controls, args.seal_controls)
        if not args.seal_controls:
            for c in result["controls"]:
                if (controls / c["file"]).read_bytes() != (HERE / "controls" / c["file"]).read_bytes():
                    raise ValueError("sealed control differs from regeneration: " + c["file"])
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    raise SystemExit(0 if result["pass"] else 1)
