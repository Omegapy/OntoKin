"""Build analytic GLB controls without invoking the C189 evaluator or either authoring route."""
import json
from pathlib import Path
import struct
import sys

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "reference/c188/frozen"))
from make_controls import build


def specimen(speed, fault):
    spec = json.loads((HERE / "reference/c188/assembly.json").read_text())
    if fault == "subtolerance-stop":
        stop = next(p for p in spec["parts"] if p["id"] == "right_stop")
        for corner in stop["worldBoundsAt0Mm"]:
            corner[0] += 0.05
    modes = {"wrong-mid-speed": "nonlinear_endpoints_correct", "short-spike": "short_speed_spike",
             "missing-face": "missing_face", "fan-positive": "good_face_fans"}
    fixture = build(spec, modes.get(fault, "good"))
    size, = struct.unpack_from("<I", fixture, 12)
    doc = json.loads(fixture[20:20+size])
    blob = bytearray(fixture[28+size:])
    anim = doc["animations"][0]
    node_ids = {n["name"]: i for i, n in enumerate(doc["nodes"])}

    def get_array(idx):
        a = doc["accessors"][idx]
        v = doc["bufferViews"][a["bufferView"]]
        return np.frombuffer(blob, dtype="<f4", offset=v["byteOffset"], count=a["count"] * 3).reshape(-1, 3)

    def add_output(values):
        data = np.array(values, dtype="<f4")
        view = len(doc["bufferViews"])
        doc["bufferViews"].append({"buffer": 0, "byteOffset": len(blob), "byteLength": data.nbytes})
        blob.extend(data.tobytes())
        idx = len(doc["accessors"])
        doc["accessors"].append({"bufferView": view, "componentType": 5126, "count": len(data),
                                 "type": "VEC3", "min": data.min(0).tolist(), "max": data.max(0).tolist()})
        return idx

    # The independent C187 generator maps local +Z to world +X and gives each
    # actuator its own input accessor. Multiply its displacements by the feed ratio.
    for lane in ("left", "right"):
        target = node_ids[lane+"_actuator"]
        ch = next(c for c in anim["channels"] if c["target"]["node"] == target)
        sampler = anim["samplers"][ch["sampler"]]
        feed = speed if lane == "left" or fault == "right-also-slows" else 150
        idx = sampler["output"]
        array = get_array(idx)
        array[:] *= feed / 150
        doc["accessors"][idx].update(min=array.min(0).tolist(), max=array.max(0).tolist())
        del array  # no live memoryview during a later append

    if fault in ("shoe-keeps-150", "small-slip"):
        shoe = node_ids["left_shoe"]
        pos = np.array(doc["nodes"][shoe]["translation"])
        extra = (150-speed)*2/1000 if fault == "shoe-keeps-150" else .00001
        out = add_output([pos, pos + [0, 0, extra]])
        one_segment = next(c for c in anim["channels"] if c["target"]["path"] == "scale")
        time_input = anim["samplers"][one_segment["sampler"]]["input"]
        anim["channels"].append({"target": {"node": shoe, "path": "translation"}, "sampler": len(anim["samplers"])})
        anim["samplers"].append({"input": time_input, "output": out, "interpolation": "LINEAR"})
    doc["buffers"][0]["byteLength"] = len(blob)
    header = json.dumps(doc, separators=(",", ":")).encode()
    header += b" " * (-len(header) % 4)
    return (struct.pack("<4sII", b"glTF", 2, 28+len(header)+len(blob)) +
            struct.pack("<I4s", len(header), b"JSON") + header +
            struct.pack("<I4s", len(blob), b"BIN\0") + blob)
