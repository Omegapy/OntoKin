#!/usr/bin/env python3
"""C189.1. Measure a delivered speed variant against its accepted C188 solid geometry."""
import argparse
import itertools
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "reference/c188"))
from measure import DESIGN as BASE_DESIGN, digest, fields
from check import CONTACT_MM, RATE_MM_S, certify_shell, check, swept_overlap
from gltf import Scene, require

DESIGN = HERE / "assembly.json"
WORLD_ROUNDOFF_MM = 0.0001
COLOR_ROUNDOFF = 1e-7


def world_start(scene, worlds, name):
    node, local, colors = scene.parts[name]
    matrices = worlds[node]
    basis = matrices[0, :3, :3]
    require(np.isfinite(matrices).all() and np.linalg.det(basis) != 0 and
            np.all(matrices[:, :3, :3] == basis), f"{name}: invalid or varying basis")
    triangles = 1000 * (local @ basis.T + matrices[0, :3, 3])
    bounds = np.stack([triangles.min((0, 1)), triangles.max((0, 1))])
    displacement = 1000 * (matrices[:, :3, 3] - matrices[0, :3, 3])
    return triangles, bounds, displacement, colors, int(np.sign(np.linalg.det(basis)))


def evaluate(baseline, candidate, case_id, result):
    rule = json.loads(DESIGN.read_text())
    case = next(c for c in rule["motion"]["cases"] if c["id"] == case_id)
    dimension = {p["id"]: p for p in rule["parts"]}
    ids = set(dimension)
    tolerances = rule["tolerances"]
    duration = rule["motion"]["durationS"]
    baseline_check = check(baseline, BASE_DESIGN)
    require(baseline_check["pass"], "invalid C188 baseline: " + baseline_check.get("reason", ""))
    old, new = Scene(baseline, ids), Scene(candidate, ids)
    times = np.union1d(old.knots, new.knots)
    require(times[0] == 0 and times[-1] == duration, "incorrect clip duration")
    old_world = old.transforms(times)[0]
    world = new.transforms(times)[0]
    # Candidate velocities are measured on its own actual segments. Union knots are used
    # only for comparing against the older encoding, avoiding artificial near-zero segments.
    knots = new.knots
    key = np.searchsorted(times, knots)
    result["trajectory"] = {"knotsS": knots.tolist(), "unionKnotCount": len(times),
                            "certifiedIntervals": len(knots) - 1, "lanes": {}}
    boxes, speeds = {}, {}
    for name, spec in dimension.items():
        _, initial, old_motion, old_colors, _ = world_start(old, old_world, name)
        tris, start, disp, color, parity = world_start(new, world, name)
        record = result["parts"][name] = {"boundsAt0Mm": start.tolist()}
        design_error = float(np.max(np.abs(start - spec["worldBoundsAt0Mm"])))
        require(design_error <= tolerances["boundsAndWorldPositionsMm"], f"{name}: initial bounds")
        require(np.max(np.abs(color - spec["baseColorLinearRGB"])) <= tolerances["colorMaxChannelError"],
                f"{name}: design color")
        record.update(certify_shell(name, tris, start, parity))
        palette = np.unique(old_colors, axis=0)
        require(len(palette) == 1, f"{name}: expected a solid C188 reference material")
        bound_diff = float(np.max(np.abs(start - initial)))
        color_diff = float(np.max(np.abs(color - palette[0])))
        orig_fields, new_fields = fields(old, name), fields(new, name)
        record.update({"maxFaceDeltaFromC188Mm": bound_diff, "maxRGBDeltaFromC188": color_diff,
                       "exactC188FieldMatches": {k: v == new_fields[k] for k, v in orig_fields.items()}})
        require(bound_diff <= WORLD_ROUNDOFF_MM and color_diff <= COLOR_ROUNDOFF,
                f"{name}: C188 solid or color changed")
        target = np.zeros(3)
        moving = spec["motion"] == "translate"
        if moving:
            target[0] = case[name.split("_")[0] + "SpeedMmPerS"]
        move = disp[key]
        velocity = np.diff(move, axis=0) / np.diff(knots)[:, None]
        error = float(np.max(np.abs(move - knots[:, None] * target)))
        nominal_rate_error = float(np.max(np.abs(velocity - target)))
        rate_variation = float(np.max(np.abs(velocity - move[-1] / duration)))
        absolute = start + move[:, None, :]
        absolute_error = float(np.max(np.abs(absolute - (np.array(spec["worldBoundsAt0Mm"])
                                                     + knots[:, None, None] * target))))
        record.update({"boundsAt2Mm": absolute[-1].tolist(), "displacementMm": move[-1].tolist(),
                       "maxDisplacementErrorMm": error, "maxWorldPositionErrorMm": absolute_error,
                       "maxComponentVelocityErrorMmPerS": nominal_rate_error,
                       "maxDeviationFromMeanSpeedMmPerS": rate_variation,
                       "velocityMinMmPerS": velocity.min(0).tolist(),
                       "velocityMaxMmPerS": velocity.max(0).tolist()})
        require(max(error, absolute_error) <= tolerances["boundsAndWorldPositionsMm"],
                f"{name}: world trajectory error")
        require(rate_variation <= RATE_MM_S, f"{name}: intermediate segment velocity error")
        if moving:
            require(np.all(velocity[:, 0] > 0) and np.max(np.abs(move[:, 1:])) <= CONTACT_MM,
                    f"{name}: travel outside positive X")
        else:
            require(np.max(np.abs(move)) <= CONTACT_MM, f"{name}: fixed body drifts")
        if not (moving and name.startswith("left_")):
            delta = float(np.max(np.abs(disp - old_motion)))
            record["maxMotionDifferenceFromC188Mm"] = delta
            require(delta <= WORLD_ROUNDOFF_MM, f"{name}: C188 preserved trajectory changed")
        boxes[name], speeds[name] = absolute, velocity
    for lane in ("left", "right"):
        shoe, car = lane + "_shoe", lane + "_carriage"
        relative = boxes[shoe].mean(1) - boxes[car].mean(1)
        differences = float(np.max(np.abs(relative - relative[0])))
        rate_delta = float(np.max(np.abs(speeds[shoe] - speeds[car])))
        result["trajectory"]["lanes"][lane] = {
            "shoeCenterMinusCarriageCenterAt0Mm": relative[0].tolist(),
            "maxChangeInOffsetMm": differences, "maxRelativeSpeedMmPerS": rate_delta}
        require(differences <= CONTACT_MM and rate_delta <= RATE_MM_S, f"{lane}: shoe offset varies")
    pairs = list(itertools.combinations(boxes, 2))
    for a, b in pairs:
        for j, (t0, t1) in enumerate(zip(knots, knots[1:])):
            witness = swept_overlap(boxes[a][j], boxes[a][j+1], boxes[b][j], boxes[b][j+1])
            require(witness is None, f"{a} / {b}: interior overlap on [{t0}, {t1}]")
    result["clearance"] = {"certifiedNonoverlapPairs": len(pairs), "pairs": pairs,
                           "allowedNumericalContactMm": CONTACT_MM}
    for lane in ("left", "right"):
        stop, shoe = boxes[lane + "_stop"], boxes[lane + "_shoe"]
        gap = stop[:, 0, 0] - shoe[:, 1, 0]
        overlap = np.minimum(stop[:, 1, 1:], shoe[:, 1, 1:]) - np.maximum(stop[:, 0, 1:], shoe[:, 0, 1:])
        require(np.all(overlap > 0) and np.all(np.diff(gap) < 0), f"{lane}: gap or facing overlap")
        j = int(np.argmin(gap))
        g = rule["gap"]
        result["gaps"][lane] = {"startMm": float(gap[0]), "endMm": float(gap[-1]),
                                "minimumMm": float(gap[j]), "minimumAtS": float(knots[j]),
                                "minYZFaceOverlapMm": overlap.min(0).tolist()}
        require(abs(gap[0] - g["bothInitialMm"]) <= tolerances["minimumGapMm"] and
                abs(gap[j] - case[lane + "MinimumGapMm"]) <= tolerances["minimumGapMm"]
                and knots[j] == g["minimumTimeS"], f"{lane}: gap magnitude or minimum time")


def measure(baseline, candidate, case_id):
    result = {"version": "C189.1", "case": case_id, "designSha256": digest(DESIGN),
              "baselineSha256": digest(baseline), "candidateSha256": digest(candidate),
              "pass": False, "parts": {}, "gaps": {}}
    try:
        evaluate(baseline, candidate, case_id, result)
        result["pass"] = True
    except (ValueError, OSError, KeyError, IndexError, TypeError, ArithmeticError) as error:
        result["reason"] = str(error)
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("route", choices=("blender", "ontokin"))
    p.add_argument("case", choices=("feed-125", "feed-100"))
    p.add_argument("candidate", type=Path)
    p.add_argument("--out", required=True, type=Path)
    args = p.parse_args()
    result = measure(HERE / "baselines" / (args.route + ".glb"), args.candidate, args.case)
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False) + "\n")
    raise SystemExit(0 if result["pass"] else 1)
