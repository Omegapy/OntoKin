# C189 two-speed gauge checker

The checker decodes the submitted binary glTF file and compares its seven labeled solids with the accepted C188 export from the same route. Use the delivered GLB with the specified node and mesh identifiers. Validate any raw native export and audit any naming-only normalization separately. Native motion authority requires source inspection and a fresh build after perturbing the drive setting.

Run the commands below from this directory using Python 3 with NumPy. The sealed original run used NumPy 2.3.5.

```sh
sha256sum -c SHA256SUMS
python3 qualify_speed.py --out /tmp/c189-qualification.json
cmp qualification.json /tmp/c189-qualification.json
python3 measure_speed.py blender feed-125 /path/to/candidate.glb --out /tmp/c189-blender-125.json
python3 measure_speed.py ontokin feed-100 /path/to/candidate.glb --out /tmp/c189-ontokin-100.json
```

Use either route with either feed. A failed measurement exits with code 1 and records the first failed condition. The synthetic controls come from an independent GLB generator. Qualification regenerates each control, compares it byte for byte with the sealed specimen, and checks its expected result and diagnostic. Four positives span two speeds and two valid tessellations. Fourteen negatives cover a shoe that retains the old speed, a right lane that slows, correct endpoints with wrong intermediate speeds, a short velocity spike, small relative slip, a shifted stop, and a missing face. Three direct swept-slab controls include a collision between clear endpoints.

## What the checker measures

The preserved C187 decoder admits linear translation in any fixed affine ancestor basis, constant scale and constant rotation. It rejects time-varying orientation, scale and unsupported interpolations. This makes vertex trajectories affine on each interval between consecutive animation keys. Absolute errors and relative offsets have their maximum component error at a knot.

* Certify every initial shell using the preserved C187 triangulated-face coverage, winding and volume routine. Check every primitive’s solid color. Compare the six world faces and color of each certified solid to its C188 reference, with the C188 cross-file roundoffs of 0.0001 mm and 0.0000001 per color component.
* Check the nominal position and relative displacement at every union key of the candidate clip, using the 0.2 mm design tolerance. Report all component velocity extrema and error against the nominal speed. Enforce constant feed within the inherited 0.025 mm/s segment-to-mean tolerance, positive X travel, and 0.001 mm off-axis/contact tolerance. At constant feed, the 0.2 mm displacement tolerance over 2 s permits at most 0.1 mm/s mean-speed error. Compare the fixed objects and both right-lane motions with C188 at the union of the baseline and candidate keys.
* For each lane, measure the shoe center relative to the carriage center throughout. Allow at most 0.001 mm of relative drift and 0.025 mm/s of relative velocity. Report mesh, material, ancestral pose and animation field equality as observations. An author may change the native implementation of the motion relationship.
* Use the preserved swept slab intersection routine on all 21 unordered pairs on every candidate interval. Contact to 0.001 mm is allowed. Measure the matching stop face minus the shoe face in X, require positive overlap in Y and Z and strictly decreasing clearance throughout, then check the initial and minimum gap within 0.5 mm and the minimum time exactly.

The frozen modules under `reference/c188` are copied byte for byte from the C188 handoff. The original acceptance baseline and the new synthetic references serve different purposes. The synthetic reference is C188’s independently generated rear-extension specimen. The two native references are the C188 delivered Blender and OntoKin GLBs.
