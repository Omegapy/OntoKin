#!/usr/bin/env python3
"""Reproduce the C189 independent measurements and verify the recorded native and browser evidence."""
import hashlib
import json
from pathlib import Path
import struct
import sys
import tempfile

DRIVE = Path(__file__).resolve().parent
ROOT = DRIVE.parent
EVIDENCE = ROOT / "evidence"
CHECKER = DRIVE / "checker"
AUDIT = DRIVE / "audit"
ROUTES = ("blender", "ontokin")
FEEDS = (125, 100)


def read(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(test, message):
    if not test:
        raise ValueError(message)


def verify_files(folder, mapping):
    for name, digest in mapping.items():
        require(sha(folder / name) == digest, f"File digest mismatch: {folder.name}/{name}")


def manifest(path):
    pairs = [row.split(maxsplit=1) for row in path.read_text().splitlines()]
    result = {name: digest for digest, name in pairs}
    require(len(result) == len(pairs), f"Duplicate entry in {path}")
    return result


def final_glb(route, feed):
    name = f"feed-{feed}.glb" if route == "blender" else f"feed-{feed}/build/assembly.glb"
    return DRIVE / "deliveries" / route / name


def verify_inputs():
    dispatch = read(EVIDENCE / "dispatch.json")
    c188 = read(EVIDENCE / "c188-replayed.json")
    require(c188["pass"] and dispatch["c188ReplayMatched"] and
            sha(EVIDENCE / "c188-replayed.json") == dispatch["c188ReplaySha256"], "C188 replay receipt")
    verify_files(DRIVE, dispatch["commonBriefSha256"])
    require((DRIVE / "assembly.json").read_bytes() == (CHECKER / "assembly.json").read_bytes(),
            "checker and participant designs differ")
    verify_files(CHECKER, manifest(CHECKER / "SHA256SUMS"))
    verify_files(AUDIT, manifest(AUDIT / "SHA256SUMS"))
    runtime = read(EVIDENCE / "runtime.json")
    verify_files(ROOT / "tools/native", runtime["files"])
    hashes = {}
    for route in ROUTES:
        state = dispatch["routes"][route]
        folder = DRIVE / "deliveries" / route
        seals = read(EVIDENCE / "seals" / (route + ".json"))
        require(sha(folder / "SHA256SUMS") == state["authorSealSha256"] == seals["SHA256SUMS"],
                f"{route}: author seal")
        require({k:v for k,v in seals.items() if k != "SHA256SUMS"} == manifest(folder / "SHA256SUMS"),
                f"{route}: coordinator and author seals differ")
        verify_files(folder, seals)
        verify_files(DRIVE / "baselines" / route, state["starter"])
        base = "gauge.glb" if route == "blender" else "build/repaired.glb"
        require(sha(CHECKER / "baselines" / (route + ".glb")) == state["starter"][base] ==
                c188["routes"][route]["submittedSha256"], f"{route}: wrong C188 baseline")
        hashes[route] = state["authorSealSha256"]
    return {"dispatchSha256": sha(EVIDENCE / "dispatch.json"), "c188ReplaySha256": dispatch["c188ReplaySha256"],
            "sealedDeliveries": hashes, "nativeRuntimeFileCount": len(runtime["files"]),
            "runtimeManifestSha256": sha(EVIDENCE / "runtime.json"),
            "checkerManifestSha256": sha(CHECKER / "SHA256SUMS"),
            "sourceAuditManifestSha256": sha(AUDIT / "SHA256SUMS")}


def replay_checker(scratch):
    sys.path.insert(0, str(CHECKER))
    from qualify_speed import run
    from measure_speed import measure

    qualify = run(scratch, False)
    require(qualify["pass"] and qualify == read(CHECKER / "qualification.json"), "qualification differs")
    for c in qualify["controls"]:
        require((scratch / c["file"]).read_bytes() == (CHECKER / "controls" / c["file"]).read_bytes(),
                f"control bytes differ: {c['file']}")
    cases = {}
    for route in ROUTES:
        for feed in FEEDS:
            case = f"feed-{feed}"
            result = measure(CHECKER / "baselines" / (route + ".glb"), final_glb(route, feed), case)
            data = (json.dumps(result, indent=2, allow_nan=False) + "\n").encode()
            key = f"{route}-{case}"
            require(result["pass"] and data == (EVIDENCE / "formal" / (key + ".json")).read_bytes(),
                    f"{key}: independent receipt differs")
            cases[key] = {"glbSha256": result["candidateSha256"], "solids": len(result["parts"]),
                          "sweptPairs": result["clearance"]["certifiedNonoverlapPairs"],
                          "affineIntervals": result["trajectory"]["certifiedIntervals"],
                          "gaps": {lane: {k: g[k] for k in ("startMm", "minimumMm", "minimumAtS")}
                                   for lane, g in result["gaps"].items()}}
    return {"positiveControls": sum(c["expectedPass"] for c in qualify["controls"]),
            "negativeControls": sum(not c["expectedPass"] for c in qualify["controls"]),
            "directSweptControls": len(qualify["sweptSlabControls"]), "formalExports": cases}


def verify_playback():
    result = {}
    for feed in FEEDS:
        folder = EVIDENCE / "playback" / f"feed-{feed}"
        receipt = read(folder / "frames.json")
        shots = receipt["shots"]
        expected = {(route, t) for route in ROUTES for t in (0, 1, 2)}
        require(not receipt["errors"] and len(shots) == 6 and
                {(s["route"], s["time"]) for s in shots} == expected, "incomplete playback")
        frame_hashes = {}
        for shot in shots:
            route, t = shot["route"], shot["time"]
            name = f"{route}-{t}.png"
            require(shot["file"] == name and shot["sha"] == sha(final_glb(route, feed)) and
                    shot["duration"] == 2 and shot["meshCount"] == 7 and shot["backend"] == "WebGL2" and
                    shot["registration"] == "identity" and shot["three"] == "186" and
                    shot["eye"] == [.46, .9, .96] and shot["target"] == [.19, .014, .09] and
                    shot["fov"] == 34 and shot["size"] == [720, 410], f"{name}: viewer state")
            png = folder / name
            head = png.read_bytes()[:24]
            require(head[:8] == b"\x89PNG\r\n\x1a\n" and struct.unpack(">II", head[16:24]) == (720, 411),
                    f"{name}: invalid capture")
            frame_hashes[name] = sha(png)
        result[f"feed-{feed}"] = {"browser": receipt["browser"], "traceSha256": sha(folder / "frames.json"),
                                  "viewerSizePx": [720, 410], "elementCaptureSizePx": [720, 411],
                                  "captureSha256": frame_hashes}
    return result


def verify_validator_receipts():
    paths = {final_glb(r, s).relative_to(DRIVE / "deliveries").as_posix() for r in ROUTES for s in FEEDS}
    paths |= {f"ontokin/feed-{s}/build/native.glb" for s in FEEDS}
    groups = (("formal", "khronos.json", DRIVE / "deliveries", paths),
              ("control110", "perturbation.json", AUDIT / "receipts/private-110",
               {"blender-final.glb", "ontokin-raw.glb", "ontokin-final.glb"}))
    result = {}
    for label, name, root, expected in groups:
        path = EVIDENCE / "validation" / name
        reports = read(path)
        require(set(reports) == expected, f"{label}: validator coverage")
        for asset, item in reports.items():
            report = item["report"]
            require(sha(root / asset) == item["sha256"] and report["uri"] == asset and
                    report["validatorVersion"] == "2.0.0-dev.3.10", "validator GLB/version mismatch")
            issues = report["issues"]
            require(all(issues[k] == 0 for k in ("numErrors", "numWarnings", "numInfos", "numHints")) and
                    issues["messages"] == [] and not issues["truncated"], f"{asset}: validation issue")
        result[label] = {"files": len(reports), "zeroErrorsWarningsInfosAndHints": True,
                         "receiptSha256": sha(path)}
    return result


def verify_native_audit():
    sys.path.insert(0, str(AUDIT))
    from glb_audit import inspect_glb

    receipts = AUDIT / "receipts"
    audit = read(receipts / "source-audit.json")
    result = {}
    for route in ROUTES:
        native = read(receipts / f"{route}-native.json")
        formal_builds = 0
        for speed in (*FEEDS, 110):
            case = f"feed-{speed}"
            record = audit[route][case]
            formal = speed in FEEDS
            require(record["sealed_case"] == formal and record["trials"] == 2 and
                    record["clean_raw_byte_equal"] and record["clean_final_byte_equal"],
                    f"{route} {case}: native rebuild")
            if formal:
                require(record["clean_matches_sealed_raw_and_final"] is True, f"{route} {case}: sealed rebuild")
                raw = final = final_glb(route, speed)
                if route == "ontokin":
                    raw = final.with_name("native.glb")
                formal_builds += record["trials"]
            else:
                folder = receipts / "private-110"
                raw = final = folder / f"{route}-final.glb"
                if route == "ontokin":
                    raw = folder / "ontokin-raw.glb"
            fresh = inspect_glb(raw, final, speed, route)
            require(fresh == record["export"], f"{route} {case}: decoded raw/final audit differs")
            for lane in ("left", "right"):
                if route == "blender":
                    objects = native[case]["native"]["objects"]
                    shoe, car = objects[lane+"_shoe"], objects[lane+"_carriage"]
                    require(shoe["parent"] == lane+"_carriage" and not shoe["drivers"] and not shoe["action"]
                            and car["properties"]["speed_mm_s"] == (speed if lane=="left" else 150),
                            f"{route} {case}: native object parent and drive")
                else:
                    mount = next(f for f in native[case]["native_follows"] if f["path"] == lane+"_mount")
                    require(mount["child_object"] == lane+"_shoe" and mount["parent_frame"] == lane+"_carriage.frame",
                            f"{route} {case}: native follow")
        control = audit[route]["feed-110"]["export"]["motion"]["lanes"]
        result[route] = {"formalRebuildsMatched": formal_builds, "independent110BuildsMatched": 2,
                         "nativeFollowing": "parented to carriage" if route == "blender" else "native follow relation",
                         "control110": {side:{k:control[side][k] for k in
                                      ("measured_carriage_speed_mm_s","measured_shoe_speed_mm_s",
                                       "minimum_gap_mm","minimum_time_s")} for side in ("left","right")}}
    return result


def main():
    require(__debug__, "Use the regular Python interpreter with assertions enabled")
    inputs = verify_inputs()
    with tempfile.TemporaryDirectory() as temp:
        numeric = replay_checker(Path(temp))
    return {"checkpoint": "C189", "pass": True, "inputs": inputs, "measurements": numeric,
            "recordedNativeRebuildsAndRecheckedExports": verify_native_audit(),
            "recordedValidation": verify_validator_receipts(), "recordedPlayback": verify_playback()}


if __name__ == "__main__":
    print(json.dumps(main(), indent=2, sort_keys=True, allow_nan=False))
