# C189 OntoKin carriage drive

Open `feed-125/build/assembly.glb` or `feed-100/build/assembly.glb` for the two recorded settings. Edit the corresponding `main.ok` to change the native design.

In `scene Slide`, the technician edits `left_carriage.feed_speed`. The Carriage class uses that speed as the X component of its initial world velocity. The right carriage inherits the class default of 150 mm/s. The two sources differ by one numeric literal, as recorded in `settings.diff`.

The native `follow left_mount` relation sets the left shoe's pose from `left_carriage.frame` plus a fixed offset of (150, 40, 0) mm. The right mount uses (180, 40, 0) mm in its carriage frame. Each shoe uses `motion = prescribed` and `physical = no_body()`. The original shoe geometry remains a closed extrusion. The edit removes the C188 shoes’ independent dynamic sphere proxies, world placements and velocities. The two carriages retain theirs. These are rigid spatial followers with no mass or force feedback. Each final GLB stores the evaluated world tracks on seven root nodes, so further speed edits belong in the native source.

## Measured clearance

| Left feed (mm/s) | Right feed (mm/s) | Left travel (mm) | Right travel (mm) | Left minimum (mm) | Right minimum (mm) | Time of both minima (s) |
| ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 125 | 150 | 250.000007 | 300.000004 | 64.999998 | 15.000008 | 2.000 |
| 100 | 150 | 200.000003 | 300.000004 | 115.000010 | 15.000008 | 2.000 |

Both initial clearances are 315 mm to the precision of the brief. The reader checks all 25 keys of each GLB against the supplied part bounds, colors and motion. It computes each gap from the stop's minimum X and the shoe's maximum X after checking overlap on the other axes. Rotations are identity. All tracks share the same 24 linear intervals. Gaps decrease on every interval, and relative shoe offsets vary by at most 0.000015 mm at the endpoints, which also bounds their drift inside the intervals. Each case includes its full-precision `measurements.json`.

## Clean rebuild

Run from the directory containing this README. Use CPython 3.12.14 and the pinned OntoKin 0.4.0 reference for language 0.22, profile torque-0.1. The build creates new output directories. The runtime source digest is `3e6ef2df6a7e8837050abb949075bff9b65f6a4aa4a9f1587850d7ddd59bce56`.

```sh
PY=/workspace/scratch/e7fbfa81c224/replay-work/job/venv/bin/python
OK_RUNTIME=/dev/shm/c189/tools/runtime
mkdir -p ../tmp
export TMPDIR="$PWD/../tmp"
OUT=$(mktemp -d "$TMPDIR/rebuild.XXXXXX")
for CASE in feed-125 feed-100
do
    "$PY" -IB build.py "$OK_RUNTIME" "$CASE/main.ok" "$OUT/$CASE"
    "$PY" -IB measure.py "$OUT/$CASE/assembly.glb" "$CASE" assembly.json
    cmp "$CASE/build/native.glb" "$OUT/$CASE/native.glb"
    cmp "$CASE/build/assembly.glb" "$OUT/$CASE/assembly.glb"
done
```

For each case, `build/native.glb` is the exact reference export, and `build/export.json` is its native validation report. The C188 naming adapter changes seven mesh names from `extrusion` to their occurrence IDs. Each `build/export-diff.json` lists the exact JSON pointers and old and new values. Applying those changes to the native JSON reproduced the final JSON exactly. The 11,552-byte binary chunk is identical before and after naming in each case. Across settings, only the two left translation buffer views differ. The same comparison against the original C188 GLB gave the same result for each case. See `binary-comparison.json`.

## Trials and assistance

Formal submission 1. The original source and the exported C188 starter remained intact. From the entrant directory, `sha256sum -c submission/starter.sha256` verifies all nine original files.

The first authored source used one carriage speed and one native follow per lane. The first export for each setting passed native validation and local measurements, with no source retries. Both were rebuilt from fresh output directories. The native GLB, final GLB and naming record reproduced byte for byte. Native reports include elapsed execution time. No synchronized independent-shoe variant was used.

The coordinator supplied the public brief, assembly table, C188 package, pinned runtime and Python interpreter. The OntoKin entrant inspected the supplied native catalog, parser, validator and torque specification, adapted the C188 builder and measurement script, and ran the builds and checks independently. No other entrant, private evaluation data, external source or additional author contributed.
