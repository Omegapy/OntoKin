"""Measure the two lane clearances from the delivered GLB's vertices and animation."""
import json
from pathlib import Path
import struct
import sys


def measure(path, case_id, assembly_path):
    specification = json.loads(Path(assembly_path).read_text())
    case, = (c for c in specification["motion"]["cases"] if c["id"] == case_id)
    data = Path(path).read_bytes()
    json_length = struct.unpack_from("<I", data, 12)[0]
    doc = json.loads(data[20:20 + json_length])
    binary = data[28 + json_length:]

    def values(index):
        acc = doc["accessors"][index]
        view = doc["bufferViews"][acc["bufferView"]]
        assert acc["componentType"] == 5126 and view["buffer"] == 0
        fmt = struct.Struct("<" + {"SCALAR": "f", "VEC3": "3f", "VEC4": "4f"}[acc["type"]])
        start = view.get("byteOffset", 0) + acc.get("byteOffset", 0)
        stride = view.get("byteStride", fmt.size)
        return [fmt.unpack_from(binary, start + i * stride) for i in range(acc["count"])]

    anim, = doc["animations"]
    tracks = {}
    for channel in anim["channels"]:
        target = channel["target"]
        sample = anim["samplers"][channel["sampler"]]
        assert sample.get("interpolation", "LINEAR") == "LINEAR"
        tracks[target["node"], target["path"]] = (
            [t[0] for t in values(sample["input"])], values(sample["output"]))

    world = {}
    roots = doc["scenes"][doc["scene"]]["nodes"]
    for i in roots:
        node = doc["nodes"][i]
        assert not any(k in node for k in ("matrix", "children", "scale"))
        times, translations = tracks[i, "translation"]
        assert times == sorted(set(times)) and times[0] == 0 and times[-1] == 2
        rot_times, rotations = tracks[i, "rotation"]
        assert rot_times == times and set(rotations) == {(0., 0., 0., 1.)}
        vertices = [p for prim in doc["meshes"][node["mesh"]]["primitives"]
                    for p in values(prim["attributes"]["POSITION"])]
        corners = [tuple(map(fn, zip(*vertices))) for fn in (min, max)]
        world[node["name"]] = {
            t: [[1000 * (local + offset) for local, offset in zip(corner, translation)]
                for corner in corners] for t, translation in zip(times, translations)}

    def close(a, b, tolerance=0.2):
        if abs(a - b) > tolerance:
            raise ValueError(f"Expected {b}, observed {a}, tolerance {tolerance}.")

    expected_parts = {p["id"]: p for p in specification["parts"]}
    assert world.keys() == expected_parts.keys() and len(roots) == len(world) == 7
    for i in roots:
        node = doc["nodes"][i]
        name = node["name"]
        mesh = doc["meshes"][node["mesh"]]
        assert mesh["name"] == name
        expected = expected_parts[name]
        for primitive in mesh["primitives"]:
            rgb = doc["materials"][primitive["material"]]["pbrMetallicRoughness"]["baseColorFactor"][:3]
            for actual, wanted in zip(rgb, expected["baseColorLinearRGB"]):
                close(actual, wanted, specification["tolerances"]["colorMaxChannelError"])
        speed = 0 if expected["motion"] == "fixed" else case[name.split("_")[0] + "SpeedMmPerS"]
        for t, corners in world[name].items():
            for corner, original in zip(corners, expected["worldBoundsAt0Mm"]):
                for axis, (actual, start) in enumerate(zip(corner, original)):
                    close(actual, start + (speed * t if axis == 0 else 0))
    lanes = {}
    for lane in ("left", "right"):
        shoe, stop = world[lane + "_shoe"], world[lane + "_stop"]
        assert shoe.keys() == stop.keys()
        gaps = {}
        for time in shoe:
            lo, hi = shoe[time]
            stop_lo, stop_hi = stop[time]
            assert all(min(hi[a], stop_hi[a]) > max(lo[a], stop_lo[a]) for a in (1, 2))
            gaps[time] = stop_lo[0] - hi[0]
        assert all(a > b for a, b in zip(gaps.values(), list(gaps.values())[1:]))
        carriage = world[lane + "_carriage"]
        assert carriage.keys() == shoe.keys()
        relative = [shoe[0][0][axis] - carriage[0][0][axis] for axis in range(3)]
        drift = max(abs(corners[0][axis] - carriage[t][0][axis] - relative[axis])
                    for t, corners in shoe.items() for axis in range(3))
        close(drift, 0, 0.2)
        minimum = min(gaps, key=gaps.get)
        close(gaps[minimum], case[lane + "MinimumGapMm"], specification["tolerances"]["minimumGapMm"])
        assert minimum == specification["gap"]["minimumTimeS"]
        lanes[lane] = {"initial_gap_mm": gaps[0], "minimum_gap_mm": gaps[minimum],
                       "time_of_minimum_s": minimum, "keys": len(gaps),
                       "initial_shoe_bounds_mm": shoe[0], "shoe_offset_from_carriage_mm": relative,
                       "max_relative_offset_drift_mm": drift,
                       "carriage_travel_mm": carriage[2][0][0] - carriage[0][0][0],
                       "shoe_travel_mm": shoe[2][0][0] - shoe[0][0][0]}
    return lanes


if __name__ == "__main__":
    print(json.dumps(measure(*sys.argv[1:]), indent=2))
