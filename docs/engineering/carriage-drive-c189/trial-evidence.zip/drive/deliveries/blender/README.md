# C189 Blender submission

Open `feed-125.blend` in Blender 4.5.3 LTS. Select `left_carriage` and open **Object Properties → Custom Properties → speed_mm_s**. This value controls the left lane in millimetres per second. The second editable file, `feed-100.blend`, captures the scene after changing this one setting to 100. Play frames 0–48 at 24 frames per second. Both corresponding GLBs are direct native exports.

Each carriage has one native driver on its X location. The driver reads the carriage's own speed and evaluates the initial X position plus elapsed time times speed. Each shoe is an object child of its carriage, with a fixed local offset of (180, 40, 0) mm in glTF axes. The shoes have no animation data. The right carriage has its own 150 mm/s drive. There are zero synchronized independently animated shoes.

The source is the accepted C188 scene in `c188/gauge.blend`. The supplied C188 files in `c188/` are exact copies of the starter. C189 replaces the two former carriage actions with the native drivers. It uses the geometry and materials already stored in C188.

## Clean build and native control check

Run from this directory with Blender 4.5.3 LTS on the executable search path. The trial used build `67807e1800cc`.

```sh
mkdir -p work/tmp
export TMPDIR="$PWD/work/tmp"
blender -b -t 2 c188/gauge.blend --python-exit-code 1 --python build.py -- \
  settings/feed-125.json settings/feed-100.json work/rebuilt
python3 measure.py work/rebuilt/feed-125.glb
python3 measure.py work/rebuilt/feed-100.glb
cmp feed-125.glb work/rebuilt/feed-125.glb
cmp feed-100.glb work/rebuilt/feed-100.glb
blender -b -t 2 feed-125.blend --python-exit-code 1 --python verify-control.py -- \
  feed-100.glb work/from-native.glb
```

The last command reopens the native 125 mm/s file, checks both driver targets and both parent relationships, sets the left feed to 100, tags the object for reevaluation and exports. It compares the result against the delivered 100 mm/s GLB byte for byte.

## Measurements

| Left setting (mm/s) | Lane | Initial gap (mm) | Minimum gap (mm) | Time of minimum (s) |
| ---: | --- | ---: | ---: | ---: |
| 125 | Left | 314.999998 | 64.999990 | 2.000000 |
| 125 | Right | 314.999998 | 14.999993 | 2.000000 |
| 100 | Left | 314.999998 | 114.999995 | 2.000000 |
| 100 | Right | 314.999998 | 14.999993 | 2.000000 |

`measure.py` reads the shoe vertices, world translations and stop vertices from each GLB. At all 49 key times it confirms transverse overlap and computes the stop's minimum X minus the shoe's maximum X. Translation is linear between keys, so the minimum covers the whole clip.

## Changes between the two settings

`settings.diff` shows the one-line input change. In the native scene, the only edited design property is `left_carriage["speed_mm_s"]`. The resulting GLBs have identical JSON. The binary changes occupy 48 X samples in the left carriage's translation track. The native exporter wrote both delivered GLBs directly. `post-export.json` gives the raw file hashes and field-level change record.

## Trials and assistance

1. Built the 125 mm/s and 100 mm/s variants separately from C188. Both native exports produced the specified clearances.
2. Tested a direct property edit after reopening the 125 mm/s native file. The first check failed. Assignment from Python without an update notification kept the previous sampled speed. Added `carriage.update_tag()` after assignment. The retry produced the 100 mm/s GLB byte for byte.
3. Built both delivered variants sequentially in one scene. The second export followed a single change to the left feed. Repeated this paired build in an empty directory and compared both GLBs byte for byte. Repeated the native reopen-and-edit check on the delivered baseline. All three comparisons passed.

Local diagnostic failures: one. Failed native case exports: zero. First formal submission. The coordinator supplied the public brief, dimensions, accepted C188 files and executable path. The entrant used the supplied measurement script and authored the drive controls, native verification and documentation. No cross-route files or external assistance were used.
