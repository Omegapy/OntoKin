"""Change one property in a reopened 125 mm/s scene, re-export and compare."""
from pathlib import Path
import runpy
import sys

import bpy

case_100, output = (Path(arg).resolve() for arg in sys.argv[sys.argv.index("--") + 1:])
scene = bpy.context.scene
assert len(scene.objects) == 7
for side, speed in (("left", 125.0), ("right", 150.0)):
    carriage = scene.objects[side + "_carriage"]
    shoe = scene.objects[side + "_shoe"]
    assert carriage["speed_mm_s"] == speed
    assert shoe.animation_data is None and shoe.parent == carriage
    assert carriage.animation_data.action is None
    drive, = carriage.animation_data.drivers
    assert drive.data_path == "location" and drive.array_index == 0
    variable, = drive.driver.variables
    assert variable.targets[0].id == carriage
    assert variable.targets[0].data_path == '["speed_mm_s"]'

scene.objects["left_carriage"]["speed_mm_s"] = 100.0
scene.objects["left_carriage"].update_tag()
scene.frame_set(0)
export_scene = runpy.run_path(str(Path(__file__).with_name("build.py")))["export_scene"]
export_scene(output)
assert output.read_bytes() == case_100.read_bytes()
print("PASS. One left-carriage speed edit in the reopened native file reproduced the 100 mm/s GLB byte for byte.")
