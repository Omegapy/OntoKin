"""Apply native carriage feed controls to the accepted C188 Blender scene."""
import json
from pathlib import Path
import sys

import bpy


def add_drive(carriage, feed_mm_s, scene):
    """Drive local X in metres from the carriage object's own feed in mm/s."""
    start_x = carriage.location.x
    carriage.animation_data_clear()
    carriage["speed_mm_s"] = float(feed_mm_s)
    carriage.id_properties_ui("speed_mm_s").update(
        description="Carriage feed along +X, in millimetres per second",
        soft_min=0.0, soft_max=300.0, precision=1,
    )
    curve = carriage.driver_add("location", 0)
    driver = curve.driver
    variable = driver.variables.new()
    variable.name = "speed"
    variable.type = "SINGLE_PROP"
    variable.targets[0].id = carriage
    variable.targets[0].data_path = '["speed_mm_s"]'
    # The source uses a two-second clip beginning at frame zero and 24 fps.
    frame_rate = scene.render.fps / scene.render.fps_base
    driver.expression = f"{start_x:.9g} + frame * speed / {1000 * frame_rate:.9g}"


def build(first, second, output):
    if bpy.app.version != (4, 5, 3):
        raise RuntimeError(f"Expected Blender 4.5.3, found {bpy.app.version_string}")
    first_feed = json.loads(first.read_text())["left_speed_mm_s"]
    scene = bpy.context.scene
    assert (scene.frame_start, scene.frame_end, scene.render.fps) == (0, 48, 24)
    scene.frame_set(0)
    for lane, feed in (("left", first_feed), ("right", 150)):
        carriage = scene.objects[lane + "_carriage"]
        assert scene.objects[lane + "_shoe"].parent == carriage
        add_drive(carriage, feed, scene)

    # Remove the old, now-unlinked C188 keyframe actions from the saved file.
    for action in list(bpy.data.actions):
        if action.users == 0:
            bpy.data.actions.remove(action)

    scene.frame_set(0)
    output.mkdir(parents=True, exist_ok=True)
    bpy.context.preferences.filepaths.save_version = 0
    save_variant(output / first.stem)

    # One design input changes. Tag the ID so Blender reevaluates a scripted edit.
    carriage = scene.objects["left_carriage"]
    carriage["speed_mm_s"] = float(json.loads(second.read_text())["left_speed_mm_s"])
    carriage.update_tag()
    scene.frame_set(0)
    save_variant(output / second.stem)


def save_variant(stem):
    bpy.ops.wm.save_as_mainfile(filepath=str(stem.with_suffix(".blend")))
    export_scene(stem.with_suffix(".glb"))


def export_scene(path):
    result = bpy.ops.export_scene.gltf(
        filepath=str(path), export_format="GLB",
        export_yup=True, export_animations=True, export_animation_mode="SCENE",
        export_anim_scene_split_object=False,
        export_frame_range=True, export_force_sampling=True,
        export_texcoords=False, export_normals=True, export_skins=False,
        export_morph=False, export_cameras=False, export_lights=False,
    )
    if "FINISHED" not in result:
        raise RuntimeError(f"glTF export failed: {result!r}")


if __name__ == "__main__":
    first, second, output = sys.argv[sys.argv.index("--") + 1:]
    build(Path(first).resolve(), Path(second).resolve(), Path(output).resolve())
