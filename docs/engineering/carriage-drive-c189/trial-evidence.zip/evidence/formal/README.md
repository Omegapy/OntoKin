# C189 formal export measurements

All four sealed submissions passed C189.1. Each keeps the seven C188 starting solids and colors. Both lanes start with 315.000 mm clearance. The gap decreases throughout each two-second clip.

| Route | Left feed (mm/s) | Left minimum (mm) | Right minimum (mm) | Time (s) | Intervals checked | Swept pairs |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Blender/Python | 125 | 65.000 | 15.000 | 2.000 | 48 | 21 |
| Blender/Python | 100 | 115.000 | 15.000 | 2.000 | 48 | 21 |
| OntoKin | 125 | 65.000 | 15.000 | 2.000 | 24 | 21 |
| OntoKin | 100 | 115.000 | 15.000 | 2.000 | 24 | 21 |

Measured right carriage and shoe speeds rounded to 150.000 mm/s on all four exports. The largest measured change in shoe-to-carriage offset across either lane was 0.000015 mm. Both routes preserved the exact decoded mesh attributes and indices and all seven initial world bounds. Blender’s right moving tracks differed from C188 by at most 0.000030 mm in world displacement. OntoKin’s corresponding difference was zero. Its seven material records differ from C188 only in the source revision recorded under `extras.ontokin.program_revision`.

The individual receipts contain the measured speed extrema, world faces, gaps, field comparisons, swept pairs and file hashes. Motion traces describe the delivered animation. Crediting a native relationship also requires the source audit and drive perturbation.
