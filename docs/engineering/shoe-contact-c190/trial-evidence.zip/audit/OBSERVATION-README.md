# Complete observations for accepted and rejected exports

`observe.py` is a read-only companion to the frozen C190-R2.1 evaluator. It
continues collecting geometry, motion and clearance observations after a
contact acceptance failure. It does not modify the evaluator or relax its
limits. The report embeds the frozen acceptance result and hash separately.

```sh
python -IB observe.py blender /path/to/final.glb \
  --stop-mm 380 --out complete-observation.json
```

Use `ontokin` for that route and `355` or `367.5` for the other stop settings.
The adjacent `../checker` directory supplies the pinned decoder, reference
geometry and acceptance code. CPython 3.12.14 and NumPy 2.3.5 are the execution
versions used here.

The command exits **0 when observations are complete**, including for a rejected
candidate. It exits 2 when the restricted GLB decoder or usable part transforms
prevent a complete observation. Read `frozenAcceptance.pass` to determine the
actual playback acceptance outcome.

Every usable part receives initial/final bounds, preserved geometry/color
errors, surface certification, all segment velocities and pre/post-impact
velocity summaries. Both lanes receive full knot-by-knot gap measurements,
first near-contact and exact zero-gap crossings, maximum penetration, attachment
offset drift and relative speed. All 20 unrelated pairs receive continuous
swept checks, with witnesses retained for every intersecting interval. Native
solver causality and timestep are not inferred from the GLB.

The two supplied control receipts demonstrate the intended distinction. The
good 380 mm control passes and produces complete observations. The pass-through
control fails the frozen penetration limit but still reports approximately
50 mm of left-shoe penetration, a 15 mm final right gap, unchanged attachment
offsets, continuing left speed and all 20 unrelated pair results. These are
analytic control observations, not participant or native solver results.

The observer was authored and self-checked without reading participant files.
All frozen evaluator member hashes were rechecked afterward and remained
unchanged. No new checker qualification or acceptance version was introduced.
