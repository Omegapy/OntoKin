#!/usr/bin/env python3
"""Independently replay the sealed OntoKin C190 delivery and edit one stop setting."""
import argparse
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+"\n")


def decode(path):
    raw = Path(path).read_bytes()
    assert struct.unpack_from("<4sII", raw) == (b"glTF", 2, len(raw))
    size, kind = struct.unpack_from("<I4s", raw, 12)
    assert kind == b"JSON"
    doc = json.loads(raw[20:20+size])
    binary_size, kind = struct.unpack_from("<I4s", raw, 20+size)
    assert kind == b"BIN\0" and 28+size+binary_size == len(raw)
    return doc, raw[28+size:]


def differences(a, b, prefix=""):
    if type(a) is not type(b):
        return [{"path": prefix, "before": a, "after": b}]
    if isinstance(a, dict):
        if set(a) != set(b):
            return [{"path": prefix, "before": a, "after": b}]
        return [v for k in a for v in differences(a[k], b[k], prefix+"/"+k)]
    if isinstance(a, list):
        if len(a) != len(b):
            return [{"path": prefix, "before": a, "after": b}]
        return [v for j in range(len(a)) for v in differences(a[j], b[j], prefix+"/"+str(j))]
    return [] if a == b else [{"path": prefix, "before": a, "after": b}]


def adapter_audit(directory):
    raw, blob = decode(directory/"native.glb")
    final, final_blob = decode(directory/"assembly.glb")
    changes = differences(raw, final)
    nodes = {node["mesh"]: node["name"] for node in raw["nodes"] if "mesh" in node}
    expected = [{"path": f"/meshes/{i}/name", "before": "extrusion", "after": nodes[i]}
                for i in range(7)]
    assert changes == expected and blob == final_blob
    return {"rawSha256": digest(directory/"native.glb"), "finalSha256": digest(directory/"assembly.glb"),
            "exactJsonChanges": changes, "exactlySevenNamingChanges": True,
            "binaryUnchanged": True, "binaryBytes": len(blob),
            "binarySha256": hashlib.sha256(blob).hexdigest()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, default=ROOT/"tools/native")
    parser.add_argument("--delivery", type=Path, default=ROOT/"deliveries/ontokin")
    parser.add_argument("--out", required=True, type=Path, help="New output directory")
    args = parser.parse_args()
    output, runtime, delivery = args.out.resolve(), args.runtime.resolve(), args.delivery.resolve()
    output.mkdir(parents=True, exist_ok=False)
    (output/"commands").mkdir()
    commands = []

    def run(label, argv, expected=0):
        started = datetime.now(timezone.utc).isoformat()
        proc = subprocess.run(argv, capture_output=True, text=True, check=False)
        ended = datetime.now(timezone.utc).isoformat()
        (output/"commands"/(label+".stdout.txt")).write_text(proc.stdout)
        (output/"commands"/(label+".stderr.txt")).write_text(proc.stderr)
        commands.append({"label": label, "argv": argv, "startedAtUtc": started, "finishedAtUtc": ended,
                         "returncode": proc.returncode, "expectedReturncode": expected})
        write(output/"commands.json", commands)
        assert proc.returncode == expected, f"{label}: expected {expected}, got {proc.returncode}: {proc.stderr}"
        print(f"{label}: expected exit {proc.returncode}", flush=True)
        return proc.stdout

    # Verify the actual sealed input before using its scripts.
    manifest = delivery/"SHA256SUMS"
    checked = 0
    for line in manifest.read_text().splitlines():
        if not line.strip():
            continue
        expected, name = line.split(None, 1)
        name = name.lstrip(" *")
        assert digest(delivery/name) == expected, f"Sealed input changed: {name}"
        checked += 1
    input_receipt = {"deliveryManifestSha256": digest(manifest), "filesVerified": checked,
                     "builderSha256": digest(delivery/"build.py"),
                     "fullRebuilderSha256": digest(delivery/"rebuild.py"),
                     "comparatorSha256": digest(delivery/"compare_rebuilds.py"),
                     "pythonVersion": sys.version}
    write(output/"input-verification.json", input_receipt)
    for suffix in ("a", "b"):
        run("formal-rebuild-"+suffix, [sys.executable, "-IB", str(delivery/"rebuild.py"),
                                      str(runtime), str(output/("formal-"+suffix))])
    compared = run("formal-compare", [sys.executable, "-IB", str(delivery/"compare_rebuilds.py"),
                                      str(delivery/"build"), str(output/"formal-a"), str(output/"formal-b")])
    write(output/"formal-comparison.json", json.loads(compared))

    source380 = (delivery/"stop-380/main.ok").read_text()
    source355 = (delivery/"stop-355/main.ok").read_text()
    needle = "vec3(380[mm], 130[mm], -220[mm])"
    assert source380.count(needle) == 1
    assert source355 == source380.replace(needle, "vec3(355[mm], 130[mm], -220[mm])")
    source367 = source380.replace(needle, "vec3(367.5[mm], 130[mm], -220[mm])")
    third = output/"third-stop"
    third.mkdir()
    source = third/"main.ok"
    source.write_text(source367)
    (third/"settings.diff").write_text("".join(difflib.unified_diff(
        source380.splitlines(keepends=True), source367.splitlines(keepends=True),
        fromfile="delivery/stop-380/main.ok", tofile="third-stop/main.ok")))
    for suffix in ("a", "b"):
        run("third-stop-build-"+suffix, [sys.executable, "-IB", str(delivery/"build.py"),
                                        str(runtime), str(source), str(third/("build-"+suffix))])
    third_matches = []
    for name in ("native.glb", "assembly.glb", "native-state.json", "export-diff.json"):
        a, b = third/"build-a"/name, third/"build-b"/name
        assert a.read_bytes() == b.read_bytes(), f"Third-stop mismatch: {name}"
        third_matches.append({"path": name, "sha256": digest(a)})
    write(third/"rebuild-comparison.json", {"byteIdenticalFiles": third_matches,
        "variableFieldsNotCompared": ["elapsed execution time", "inspection elapsed time"]})

    # Query the third source at its actual event neighborhood as a separate
    # native request. Keep the entrant's builder and its returned records intact.
    sys.path.insert(0, str(runtime))
    from ontokin.construction import compile_construction
    from ontokin.evaluator import evaluate
    from ontokin.execution_budget import HostPolicy, SharedExecutionBudget, admit_entry_budget
    from ontokin.profile_capabilities import TORQUE_PROFILE
    from ontokin.program_runtime import _support
    from ontokin.texture_bundle import load_texture_bundle
    bundle = load_texture_bundle({"schema_version": "ontokin.bundle/0.2",
        "entry": {"filename": "main.ok", "source": source367}, "modules": [], "assets": []})
    ledger = SharedExecutionBudget(HostPolicy(max_operations=1_000_000, max_elapsed_ms=80_000),
                                  {"max_operations": 1_000_000, "max_elapsed_ms": 80_000})
    admit_entry_budget(bundle.entry, ledger, profile=TORQUE_PROFILE)
    ledger.stage = "construction"
    compiler = compile_construction(bundle, execution_budget=ledger)
    _support(compiler)
    ledger.stage = "evaluation"
    times = ["0", "1.499", "1.5", "1.501", "2"]
    native = evaluate(compiler.model, times, check=ledger.tick, work=compiler.reach_work)
    write(third/"independent-native-state.json", native)
    write(third/"independent-native-request.json", {"sourceSha256": digest(source),
        "sourceRevision": bundle.entry.revision, "programRevision": bundle.program_revision,
        "sampleTimesSeconds": times, "nativeMethod": native["numerical_method"],
        "nativeIntegrationTimestepSeconds": None, "executionBudget": ledger.report(status="valid")})
    assert native["physical_assumptions"]["collision"] == "disabled"
    assert native["physical_assumptions"]["contact_response"] == "unavailable"
    assert native["boundary_times_seconds"] == ["0"]
    for sample in native["samples"]:
        for name in ("left_carriage", "left_shoe"):
            assert sample["objects"][name]["velocity_m_per_s"] == [.125, 0., 0.]
        for name in ("right_carriage", "right_shoe"):
            assert sample["objects"][name]["velocity_m_per_s"] == [.15, 0., 0.]
    state = native["samples"][0]["objects"]
    source_audit = {
        "formalSourceDiffOnlyStopLiteral": True, "thirdSourceDiffOnlyStopLiteral": True,
        "source380Sha256": digest(delivery/"stop-380/main.ok"),
        "source355Sha256": digest(delivery/"stop-355/main.ok"), "source367Point5Sha256": digest(source),
        "thirdStopNativeBoundaryTimesSeconds": native["boundary_times_seconds"],
        "nativeContactResponse": native["physical_assumptions"]["contact_response"],
        "nativeCollision": native["physical_assumptions"]["collision"],
        "nativeMethod": native["numerical_method"], "nativeIntegrationTimestepSeconds": None,
        "objects": {name: {key: obj[key] for key in ("physical", "own_mass_kg", "owned_aggregate_mass_kg",
            "position_m", "motion", "collision", "pose_authority", "velocity_m_per_s")}
                    for name, obj in state.items()},
        "sourceInspection": "Visible extrusions are separate from physical sphere proxy; no solver contact, event, clamp or stop command is added"}
    write(output/"native-source-audit.json", source_audit)

    observed = []
    adaptations = []
    for name, stop, directory in (("stop-380", 380., output/"formal-a/stop-380"),
                                   ("stop-355", 355., output/"formal-a/stop-355"),
                                   ("stop-367.5", 367.5, third/"build-a")):
        adaptations.append({"case": name, **adapter_audit(directory)})
        acceptance_path = output/(name+"-acceptance.json")
        observation_path = output/(name+"-observation.json")
        run(name+"-acceptance", [sys.executable, "-IB", str(ROOT/"checker/measure_contact.py"), "ontokin",
             str(directory/"assembly.glb"), "--stop-mm", str(stop), "--out", str(acceptance_path)], expected=1)
        run(name+"-observation", [sys.executable, "-IB", str(ROOT/"audit/observe.py"), "ontokin",
             str(directory/"assembly.glb"), "--stop-mm", str(stop), "--out", str(observation_path)])
        acceptance = json.loads(acceptance_path.read_text())
        observation = json.loads(observation_path.read_text())
        assert not acceptance["pass"] and "maximum penetration" in acceptance["reason"]
        assert observation["observationComplete"]
        assert observation["unrelatedPairSummary"]["nonoverlapPairs"] == 20
        observed.append({"case": name, "stopNearFaceMm": stop, "playbackPass": False,
            "failureReason": acceptance["reason"], "left": observation["gaps"]["left"],
            "right": observation["gaps"]["right"], "lanes": observation["lanes"],
            "leftCarriagePostImpactVelocity": observation["parts"]["left_carriage"]["postIdealImpactVelocity"],
            "leftCarriageSettledPoseErrorMm": observation["parts"]["left_carriage"]["maximumSettledContactPoseErrorMm"],
            "unrelatedPairs": observation["unrelatedPairSummary"], "trajectory": observation["trajectory"]})
    write(output/"adapter-audit.json", adaptations)
    # Verify that the extra independent inspection also preserved every pinned
    # runtime byte, not only the subprocesses' before/after records.
    manifest_text = (output/"formal-a/runtime-before.sha256").read_text()
    rows = []
    for path in sorted(runtime.rglob("*")):
        rel = path.relative_to(runtime)
        if path.is_file() and ".git" not in rel.parts and "__pycache__" not in rel.parts and path.suffix != ".pyc":
            rows.append(digest(path)+"  "+rel.as_posix())
    assert "\n".join(rows)+"\n" == manifest_text
    report = {"auditVersion": "C190-R2-ontokin-audit-1", "outcome": "unsupported contact independently reproduced",
        "completedAtUtc": datetime.now(timezone.utc).isoformat(), "formalCaseBuilds": 4,
        "thirdStopBuilds": 2, "expectedDiagnosticProbeExecutions": 4,
        "formalStableFilesMatchedAgainstSealAndBothRebuilds": len(json.loads(compared)["byte_identical_files"]),
        "thirdStableFilesMatched": len(third_matches), "nativeContactSuccess": False,
        "timedStopOrClampingUsed": False, "namingOnlyAdaptationVerifiedCases": 3,
        "runtimeUnchanged": True, "runtimeFilesVerified": len(rows),
        "runtimeManifestSha256": hashlib.sha256(manifest_text.encode()).hexdigest(),
        "checkerFreezeSha256": digest(ROOT/"checker/FREEZE.json"), "observedCases": observed,
        "limits": ["No full product regression run: runtime unchanged", "Recorded playback is distinct from native solver causality",
                   "Near-face overshoot is not a contact manifold penetration estimate"]}
    write(output/"summary.json", report)
    print(json.dumps({"outcome": report["outcome"], "formalBuilds": 4, "thirdBuilds": 2,
                      "formalStableFilesMatched": report["formalStableFilesMatchedAgainstSealAndBothRebuilds"],
                      "runtimeUnchanged": True, "leftOvershootMm": [x["left"]["maximumPenetrationPastNearFaceMm"] for x in observed]}), flush=True)


if __name__ == "__main__":
    main()
