# Independent native audit of the C190 OntoKin delivery

The audit reproduced the sealed route's disclosed negative result. Moving the
stop changes geometry, but the left shoe and carriage continue at 125 mm/s.
The runtime has no active contact response. No collision-induced halt is claimed.

These are fresh coordinator verification records, separate from the entrant's
own rebuilds. The audit used CPython 3.12.14 and the unchanged packaged runtime
whose source identity is
`3e6ef2df6a7e8837050abb949075bff9b65f6a4aa4a9f1587850d7ddd59bce56`.
The actual commands and outcomes are in
[commands.json](../../evidence/ontokin-audit/commands.json), with full stdout and
stderr retained for each process. See [summary.json](../../evidence/ontokin-audit/summary.json).

## Rebuild and independent edit

Both formal cases were rebuilt twice into fresh output directories. The sealed
delivery and both rebuild directories matched byte for byte for all 14 stable
files selected by the entrant's comparator, including four raw/final GLBs,
native states, measurements, naming records, capability records and runtime
manifests. Both minimal rejection probes reproduced their complete stable
diagnostic projections in both rebuilds. Wall-clock and elapsed-budget fields
were explicitly excluded from byte comparison.

The coordinator independently copied the sealed 380 mm source and changed its
single left-stop X literal to **367.5 mm**. The actual
[source](../../evidence/ontokin-audit/third-stop/main.ok) and
[one-setting diff](../../evidence/ontokin-audit/third-stop/settings.diff) are
preserved. Two builds through the unchanged sealed builder reproduced the raw
GLB, final GLB, native state and adapter record exactly.

An additional independent native inspection sampled the third source at
0, 1.499, 1.5, 1.501 and 2 seconds. Left carriage and shoe velocity remained
exactly `(0.125, 0, 0)` m/s in every native sample; both right objects remained
at `(0.15, 0, 0)` m/s. The engine reported collision disabled, contact response
unavailable and only time zero in its event-boundary list. Its method is
analytical trajectories with a rational event clock and binary64 spatial
calculations; there is no fixed integration timestep. The exported 60 Hz
recording is a separate sampling setting.

## Independent exported observations

| Left stop near face | First zero-gap crossing | Final signed left gap | Final right gap | Left speed after crossing |
| ---: | ---: | ---: | ---: | ---: |
| 380 mm | 1.600000024 s | −50.000012 mm | 15.000008 mm | 125 mm/s |
| 355 mm | 1.399999976 s | −75.000018 mm | 15.000008 mm | 125 mm/s |
| 367.5 mm | 1.500000119 s | −62.500000 mm | 15.000008 mm | 125 mm/s |

All three exports fail the frozen C190-R2.1 contact acceptance criterion. Each
has 121 keys and 120 intervals over two seconds; the longest stored interval is
0.016666770 s. Left shoe-to-carriage offset drift is at most 0.00001863 mm.
All 20 unrelated solid pairs remain clear throughout every piecewise-linear
interval, under the inherited numerical contact tolerance.

Negative signed gap measures the shoe's advancement past the stop's near face.
It is an exported geometric observation, not a native contact-manifold
penetration estimate. The full observations continue after acceptance fails,
so the independent right lane and unrelated pairs remain inspectable:

- [380 mm observation](../../evidence/ontokin-audit/stop-380-observation.json)
- [355 mm observation](../../evidence/ontokin-audit/stop-355-observation.json)
- [367.5 mm observation](../../evidence/ontokin-audit/stop-367.5-observation.json)

## Native causal interpretation

The inspected source and freshly evaluated native state agree:

| Element | Actual representation and consequence |
| --- | --- |
| Left shoe | Extruded visible geometry with `no_body()`; it is not a collision shape. |
| Left carriage | Owns one 1 kg sphere of radius 20 mm at its origin. That sphere does not match the shoe's contact face. |
| Attachment | `follow` gives the prescribed massless shoe one spatial pose authority. Its catalog explicitly excludes ownership and force transfer. |
| Stops | Prescribed massless objects with fixed poses, not immovable solver colliders. |
| Contact | Collision is disabled and response unavailable. No contact impulse or force is transferred to the carriage. |

The minimal `collision = enabled` probe reproduces `OKL-E-NAME` in binding:
`Unknown name 'enabled' in this lexical scope.` This is a rejected unsupported
value, not a collision solver failure. The independent runtime catalog states
that disabled is the only collision mode. Giving the followed shoe mass
reproduces `OKL-E-PHYSICAL-DOMAIN` in elaboration:
`A follow relation may control only a massless child with no_body().`

No event, timed stop, clamp or edited animation track was introduced. The
coordinator's third edit changed only stop placement. This distinguishes an
unsupported native contact capability from a superficially successful animation.

## Export adaptation and integrity

Independent decoding compared raw and final GLB documents for all three cases.
Exactly seven JSON fields changed: `/meshes/0/name` through `/meshes/6/name`, each
from `extrusion` to the corresponding occurrence ID. Every other JSON value and
the complete **30,752-byte BIN chunk** remained identical. The independent
[adapter audit](../../evidence/ontokin-audit/adapter-audit.json) contains all
patches and hashes.

All 209 pinned runtime files remained unchanged through both formal rebuilds,
the two third-stop builds and the extra native inspection. The manifest hash
remains `937c5ec626aee8dbe7668010143d0825c6559226ccad2cc7d9164cf54f6db24e`.
No runtime or sealed delivery file was modified. This audit did not rerun the
full product regression suite because it made no product-code change.

## Reproduce

From the handoff root, select a new output directory:

```sh
python -IB audit/ontokin/replay.py --out /absolute/path/to/new-audit
```

The script defaults to the adjacent packaged runtime, sealed delivery, frozen
checker and observation companion. `--runtime` and `--delivery` can override
those paths explicitly. It verifies the delivery seal first, records all invoked
commands, performs the builds and independent edit, and preserves complete
results under the chosen output directory. Expected contact-acceptance failures
exit 1 and are recorded as expected failures; they do not become collision passes.
