#!/usr/bin/env python3
"""Observe an entire C190 export even when its frozen acceptance check fails early."""
import argparse
import itertools
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
CHECKER = HERE.parent / "checker"
sys.path.insert(0, str(CHECKER))
from measure_contact import (CONTACT_MM, POSITION_MM, TIME_ROUNDOFF_S, VERSION,
                             Scene, certify_shell, digest, first_threshold,
                             measure, motion_knots, swept_overlap, world_start)


def velocity_summary(values):
    return {"intervals": len(values),
            "minMmPerS": values.min(0).tolist() if len(values) else None,
            "maxMmPerS": values.max(0).tolist() if len(values) else None}


def observe(route, candidate, stop_mm):
    baseline = CHECKER / "baselines" / (route+".glb")
    acceptance = measure(baseline, candidate, stop_mm)
    result = {
        "version": "C190-R2-observation-1",
        "purpose": "Read-only observation; does not change or replace frozen acceptance",
        "observationOnly": True, "nativeSolverCausalityEstablished": False,
        "nativeTimestep": "Not inferable from GLB; inspect separate native records",
        "route": route, "candidateSha256": digest(candidate),
        "baselineSha256": digest(baseline), "stopNearFaceMm": stop_mm,
        "frozenAcceptance": {"version": VERSION, "pass": acceptance["pass"],
                             "reason": acceptance.get("reason"),
                             "freezeSha256": digest(CHECKER / "FREEZE.json")},
        "parts": {}, "lanes": {}, "gaps": {}, "unrelatedPairs": []}
    design = json.loads((CHECKER / "assembly.json").read_text())
    dimensions = {p["id"]: p for p in design["parts"]}
    try:
        scene = Scene(candidate, set(dimensions))
        old = Scene(baseline, set(dimensions))
    except (ValueError, OSError, KeyError, IndexError, TypeError, ArithmeticError) as error:
        result["observationComplete"] = False
        result["decodeFailure"] = str(error)
        return result
    knots = scene.knots
    delta = np.diff(knots)
    world, _ = scene.transforms(knots)
    prior, _ = old.transforms(np.array([0., 2.]))
    ideal = (stop_mm-180)/125
    result["trajectory"] = {"durationS": float(knots[-1]-knots[0]),
                            "knotsS": knots.tolist(), "intervalCount": len(delta),
                            "minimumIntervalS": float(delta.min()),
                            "maximumIntervalS": float(delta.max()), "idealContactS": ideal}
    boxes, moves, speeds = {}, {}, {}
    for name, spec in dimensions.items():
        record = result["parts"][name] = {}
        try:
            triangles, initial, disp, color, parity = world_start(scene, world, name)
            _, before, _, old_color, _ = world_start(old, prior, name)
        except (ValueError, OSError, KeyError, IndexError, TypeError, ArithmeticError) as error:
            record["observationFailure"] = str(error)
            continue
        expected = np.array(spec["worldBoundsAt0Mm"], dtype=float)
        if name == "left_stop":
            expected[:, 0] += stop_mm-495
            before[:, 0] += stop_mm-495
        try:
            record["surface"] = {"certified": True, **certify_shell(name, triangles, initial, parity)}
        except ValueError as error:
            record["surface"] = {"certified": False, "reason": str(error)}
        velocity = np.diff(disp, axis=0)/delta[:, None]
        nominal = np.array([125 if name.startswith("left_") else 150, 0., 0.])
        if spec["motion"] == "fixed":
            nominal[:] = 0
        record.update({"boundsAt0Mm": initial.tolist(), "boundsAt2Mm": (initial+disp[-1]).tolist(),
                       "maxInitialDesignErrorMm": float(np.max(np.abs(initial-expected))),
                       "maxPreservedFaceErrorMm": float(np.max(np.abs(initial-before))),
                       "maxPreservedColorError": float(np.max(np.abs(color-np.unique(old_color, axis=0)[0]))),
                       "displacementAt2Mm": disp[-1].tolist(),
                       "maximumTransverseDisplacementMm": float(np.max(np.abs(disp[:, 1:]))),
                       "maximumDisplacementMm": float(np.max(np.abs(disp))),
                       "allVelocity": velocity_summary(velocity),
                       "preIdealImpactVelocity": velocity_summary(velocity[knots[1:] <= ideal+TIME_ROUNDOFF_S]),
                       "postIdealImpactVelocity": velocity_summary(velocity[knots[:-1] >= ideal-TIME_ROUNDOFF_S]),
                       "velocitySegmentsMmPerS": velocity.tolist()})
        if spec["motion"] == "translate":
            relevant = motion_knots(scene, name)
            relevant_delta = np.diff(relevant)
            at = max(0, min(len(relevant_delta)-1, int(np.searchsorted(relevant, ideal, side="right")-1)))
            event = np.flatnonzero(abs(relevant-ideal) <= TIME_ROUNDOFF_S)
            allowance = float(relevant_delta[at])
            if len(event) and 0 < event[0] < len(relevant)-1:
                j = int(event[0])
                allowance = float(max(relevant_delta[j-1], relevant_delta[j]))
            settle = min(2., ideal+allowance)
            record["sampling"] = {"relevantKnotsS": relevant.tolist(),
                                  "maxRelevantIntervalS": float(relevant_delta.max()),
                                  "impactAllowanceS": allowance, "settlingBoundaryS": settle}
            record["settledVelocity"] = velocity_summary(velocity[knots[:-1] >= settle-TIME_ROUNDOFF_S])
            if name.startswith("left_"):
                probes = np.unique(np.r_[settle, knots[knots >= settle]])
                post, _ = scene.transforms(probes)
                node = scene.parts[name][0]
                post_disp = 1000*(post[node][:, :3, 3]-world[node][0, :3, 3])
                target = np.array([stop_mm-180, 0., 0.])
                record["maximumSettledContactPoseErrorMm"] = float(np.max(np.abs(post_disp-target)))
            else:
                record["maximumNominalMotionErrorMm"] = float(np.max(np.abs(disp-knots[:, None]*nominal)))
        boxes[name], moves[name], speeds[name] = initial+disp[:, None, :], disp, velocity

    for lane in ("left", "right"):
        shoe, car, stop = lane+"_shoe", lane+"_carriage", lane+"_stop"
        if not all(name in boxes for name in (shoe, car, stop)):
            result["lanes"][lane] = {"observationFailure": "missing usable part transforms"}
            continue
        offset = boxes[shoe].mean(1)-boxes[car].mean(1)
        result["lanes"][lane] = {"initialShoeCenterMinusCarriageCenterMm": offset[0].tolist(),
                                  "maximumOffsetDriftMm": float(np.max(np.abs(offset-offset[0]))),
                                  "maximumRelativeSpeedMmPerS": float(np.max(np.abs(speeds[shoe]-speeds[car])))}
        gap = boxes[stop][:, 0, 0]-boxes[shoe][:, 1, 0]
        overlap = np.minimum(boxes[stop][:, 1, 1:], boxes[shoe][:, 1, 1:])-np.maximum(boxes[stop][:, 0, 1:], boxes[shoe][:, 0, 1:])
        negative = int(gap.argmin())
        positive = int(gap.argmax())
        result["gaps"][lane] = {
            "startMm": float(gap[0]), "endMm": float(gap[-1]),
            "minimumMm": float(gap[negative]), "minimumAtS": float(knots[negative]),
            "maximumMm": float(gap[positive]), "maximumAtS": float(knots[positive]),
            "gapAtEachKnotMm": gap.tolist(), "minimumTransverseOverlapMm": overlap.min(0).tolist(),
            "firstWithinPoint5MmS": first_threshold(knots, gap, POSITION_MM),
            "firstZeroGapS": first_threshold(knots, gap, 0.),
            "maximumPenetrationPastNearFaceMm": max(0., float(-gap.min())),
            "penetrationCertification": "Exact endpoint extrema of the affine signed face gap on every interval"}

    expected_pair = {"left_shoe", "left_stop"}
    for a, b in itertools.combinations(boxes, 2):
        if {a, b} == expected_pair:
            continue
        witnesses = []
        for j, (t0, t1) in enumerate(zip(knots, knots[1:])):
            fraction = swept_overlap(boxes[a][j], boxes[a][j+1], boxes[b][j], boxes[b][j+1])
            if fraction is not None:
                witnesses.append({"intervalIndex": j, "intervalStartS": float(t0), "intervalEndS": float(t1),
                                  "witnessFraction": fraction, "witnessTimeS": float(t0+fraction*(t1-t0))})
        result["unrelatedPairs"].append({"pair": [a, b], "certifiedIntervals": len(delta),
                                           "nonoverlap": not witnesses, "overlapWitnesses": witnesses})
    result["unrelatedPairSummary"] = {
        "pairsObserved": len(result["unrelatedPairs"]), "expectedPairs": 20,
        "nonoverlapPairs": sum(x["nonoverlap"] for x in result["unrelatedPairs"]),
        "overlappingPairs": sum(not x["nonoverlap"] for x in result["unrelatedPairs"]),
        "numericalContactToleranceMm": CONTACT_MM}
    result["observationComplete"] = len(boxes) == len(dimensions) and len(result["unrelatedPairs"]) == 20
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("route", choices=("blender", "ontokin", "synthetic"))
    parser.add_argument("glb", type=Path)
    parser.add_argument("--stop-mm", type=float, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    report = observe(args.route, args.glb, args.stop_mm)
    args.out.write_text(json.dumps(report, indent=2, allow_nan=False)+"\n")
    print(json.dumps({"observationComplete": report["observationComplete"],
                      "acceptancePass": report["frozenAcceptance"]["pass"],
                      "acceptanceReason": report["frozenAcceptance"]["reason"],
                      "rightFinalGapMm": report.get("gaps", {}).get("right", {}).get("endMm"),
                      "leftMaxPenetrationMm": report.get("gaps", {}).get("left", {}).get("maximumPenetrationPastNearFaceMm"),
                      "unrelatedPairs": report.get("unrelatedPairSummary")}))
    raise SystemExit(0 if report["observationComplete"] else 2)
