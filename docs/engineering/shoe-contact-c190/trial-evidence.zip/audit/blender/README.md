# Independent native audit of Blender submission 2

The independent audit reproduced the sealed Blender delivery and its native
collision response. It also verified the final playback projection separately.
The raw Bullet result retains small solver rotations and fails the frozen
translation-only export profile; the disclosed final projection passes that
unchanged profile. No acceptance tolerance was relaxed.

The audit used Blender **4.5.3 LTS**, build **67807e1800cc**, and CPython 3.12.14
with NumPy 2.3.5 for independent export measurements. Full results are in
[summary.json](../../evidence/blender-audit/summary.json); every invoked argument
vector, return code and timestamp is in
[commands.json](../../evidence/blender-audit/commands.json). The executable hash
was checked before and after the audit and remained unchanged.

## Fresh builds and independent stop edit

The 380 and 355 mm cases were each rebuilt twice from the sealed C189 source
through the sealed C190 builder. All **20 stable-file comparisons** matched the
seal byte for byte: raw GLB, final GLB, native transforms, native trace and native
summary for each case and repeat. Native `.blend` serialization is not claimed
byte-identical; its editable behavior was exercised directly instead.

The coordinator created a JSON setting containing only
`left_stop_near_face_mm: 367.5`. Each of two fresh Blender processes reopened the
sealed 380 mm native scene and changed its `near_face_mm` property using the
sealed replay script. It reconstructed no geometry or constraints. Both
replays matched all five stable output files exactly. The setting, diff,
edited scenes, native records, raw GLBs and final GLBs are preserved under
[third-stop](../../evidence/blender-audit/third-stop).

| Stop near face | Final playback zero-gap crossing | Final left gap | Maximum final near-face penetration | Final right gap |
| ---: | ---: | ---: | ---: | ---: |
| 380 mm | 1.600002983 s | 0.000000931 mm | 0.007583760 mm | 14.999968 mm |
| 355 mm | 1.400002935 s | 0.000000931 mm | 0.007583760 mm | 14.999968 mm |
| 367.5 mm | 1.499999888 s | 0.000000931 mm | 0.007583760 mm | 14.999968 mm |

All three final exports pass the frozen C190-R2.1 checker. Their shoe offsets
are constant, and all 20 unrelated solid pairs are continuously clear through
the clip. The raw exports in all three settings retain the explicit rejection
`time-varying rotation outside translation-only profile`.

## Native causal control

Two additional fresh processes reopened the same sealed 380 mm native scene.
The first inspected and ran it unchanged. The second removed **only the left
shoe's rigid-body component**, preserving its visible mesh, parent and starting
pose. The compound parent retained its carriage-shaped collision child, mass
and motor. The complete configuration difference contains only that component
and its removal from the rigid-body collection.

| Native measurement | Shoe collision shape present | Shoe collision shape removed |
| --- | ---: | ---: |
| Left carriage final travel | 200.000003 mm | 250.000000 mm |
| Left final geometric gap | 0.000030 mm | −49.999982 mm |
| Left sampled velocity after the ideal event | Brief correction, then halt | 124.998093–125.001669 mm/s |
| Right carriage final travel | 300.000012 mm | 300.000012 mm |
| Right final geometric gap | 14.999986 mm | 14.999986 mm |

Every recorded right-carriage, right-shoe and right-stop transform and bound was
bit-identical between the two native runs. The base and left stop were also
bit-identical. Thus removing the shoe's collision component removed the left
halt while preserving the other lane's motion. This is direct native evidence
for the contact mechanism, rather than an inference from the final animation.

The unchanged native control first reached the 0.01 mm geometric contact band
at 1.6 s. Its maximum sampled near-face penetration was 0.007004 mm. Native
finite-difference velocity includes a short post-impact correction ranging from
−1.730919 to 1.505613 mm/s; the raw result is not represented as mathematically
motionless immediately at impact. The prescribed 0.5 mm settled-position
criterion remains the acceptance rule.

The configuration snapshots and source inspection show two independent native
MOTOR constraints, each reading its own carriage's speed property. Each carriage
is an active COMPOUND with a configured mass of 1 kg; the shoe BOX is one of its
collision children. The GENERIC guide leaves X translation unbounded and locks
the other translations and rotations. The fixed stops are passive bodies.
The carriage-shaped child is below the stop's vertical range, while the shoe
overlaps that range. There is no carriage transform action or transform driver,
no X position limit and no time-dependent stop command.

The world uses 240 recorded frames per second, 10 native substeps per frame,
100 solver iterations and a time scale of one. Its nominal timestep is
1/2400 s. These observations come from evaluated native matrices and derived
gaps/velocities. The audit does not claim Bullet contact manifolds or normal
impulses, which these `bpy` records do not expose. See
[causal-control.json](../../evidence/blender-audit/causal-control.json).

## Exact raw-to-final projection audit

An independent decoder compared all JSON fields and logical accessor elements,
then measured every vertex at all 481 recorded states. It also applied the
native matrices directly to the corresponding geometry. Across all three cases:

- The sole semantic JSON edit removes the left-carriage rotation channel.
- Exactly three transverse translation values change in the left-carriage
  track. All carriage X samples remain identical to the native export.
- Meshes, geometry accessor values, materials, node hierarchy, animation input
  times and shoe-local transforms remain unchanged.
- The unused rotation sampler, accessor and bytes remain in the container and
  have no active channel. They are not rewritten as invented solver samples.

| Stop | Maximum recorded raw-to-final vertex change | Maximum native-record-to-final vertex change | Continuous raw-playback bound |
| ---: | ---: | ---: | ---: |
| 380 mm | 0.054198649 mm | 0.054194154 mm | 0.056595176 mm |
| 355 mm | 0.054198904 mm | 0.054194253 mm | 0.056595369 mm |
| 367.5 mm | 0.054199488 mm | 0.054194480 mm | 0.056595812 mm |

The continuous bound covers each of the 480 raw GLB interpolation intervals.
Identical linear X tracks cancel. Endpoint norms bound the removed transverse
translation. The rotation triangle inequality bounds interpolated orientation
by the smaller endpoint orientation angle plus the arc between endpoints;
`2 r sin(angle/2)` then bounds every carriage/shoe vertex's rotational movement.
The largest bound is below the supplied 0.2 mm geometry tolerance.

This bound applies to raw GLB LINEAR/SLERP playback versus final playback. It
does not describe unknown native substep poses. All 481 recorded native poses
were measured directly. Full field changes, changed values, per-part maxima,
input hashes and continuous bounds are in the three `*-raw-final.json` records.

## Reproduce

From the handoff root, choose a new output directory:

```sh
python -IB audit/blender/replay.py \
  --blender /absolute/path/to/blender-4.5.3-linux-x64/blender \
  --out /absolute/path/to/new-blender-audit
```

The script verifies the delivery seal, performs four formal builds, performs
two saved-scene stop edits, measures raw and final exports, and runs the two
independent native collision-component controls. `--delivery` can override the
adjacent packaged delivery path. The sealed sources and native scenes remain
unchanged. No product runtime was edited and no full product regression was
rerun by this audit. Structural GLB validation and visual review are separate
coordinator evidence.
