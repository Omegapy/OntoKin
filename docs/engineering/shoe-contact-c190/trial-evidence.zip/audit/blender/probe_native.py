"""Independent saved-scene inspection and collision-shape ablation inside Blender."""
import argparse
import csv
import hashlib
import json
from pathlib import Path
import sys

import bpy
from mathutils import Vector

PARTS = ('base', 'left_carriage', 'left_shoe', 'left_stop',
         'right_carriage', 'right_shoe', 'right_stop')


def drivers(data):
    if data.animation_data is None:
        return []
    return [{"dataPath": f.data_path, "arrayIndex": f.array_index,
             "expression": f.driver.expression, "type": f.driver.type,
             "variables": [{"name": v.name, "type": v.type,
                 "targets": [{"id": t.id.name if t.id else None, "dataPath": t.data_path} for t in v.targets]}
                 for v in f.driver.variables]} for f in data.animation_data.drivers]


def body(obj):
    rb = obj.rigid_body
    if rb is None:
        return None
    names = ('type', 'collision_shape', 'mass', 'kinematic', 'friction', 'restitution',
             'linear_damping', 'angular_damping', 'use_margin', 'collision_margin', 'use_deactivation')
    return {name: getattr(rb, name) for name in names}


def capture_config(scene):
    objects = {}
    for obj in sorted(scene.objects, key=lambda x: x.name):
        data = {"type": obj.type, "parent": obj.parent.name if obj.parent else None,
                "hideRender": obj.hide_render, "location": list(obj.location),
                "rotationEuler": list(obj.rotation_euler), "scale": list(obj.scale),
                "matrixParentInverse": [list(v) for v in obj.matrix_parent_inverse],
                "drivers": drivers(obj), "action": obj.animation_data.action.name
                    if obj.animation_data and obj.animation_data.action else None,
                "rigidBody": body(obj),
                "customProperties": {k: v for k, v in obj.items()
                                     if isinstance(v, (str, int, float, bool))}}
        if obj.type == 'MESH':
            vertices = [list(v.co) for v in obj.data.vertices]
            data["mesh"] = {"name": obj.data.name, "vertexCount": len(vertices),
                "verticesSha256": hashlib.sha256(json.dumps(vertices, separators=(',', ':')).encode()).hexdigest(),
                "localBounds": [[min(v[a] for v in vertices) for a in range(3)],
                                [max(v[a] for v in vertices) for a in range(3)]]}
        if obj.rigid_body_constraint:
            joint = obj.rigid_body_constraint
            names = ['type', 'disable_collisions', 'use_override_solver_iterations', 'solver_iterations',
                     'use_motor_lin', 'motor_lin_target_velocity', 'motor_lin_max_impulse']
            for axis in 'xyz':
                names += ['use_limit_lin_'+axis, 'limit_lin_'+axis+'_lower', 'limit_lin_'+axis+'_upper',
                          'use_limit_ang_'+axis, 'limit_ang_'+axis+'_lower', 'limit_ang_'+axis+'_upper']
            data['constraint'] = {name: getattr(joint, name) for name in names}
            data['constraint'].update(object1=joint.object1.name if joint.object1 else None,
                                       object2=joint.object2.name if joint.object2 else None)
        objects[obj.name] = data
    w = scene.rigidbody_world
    return {'objects': objects, 'world': {
        'frameStart': scene.frame_start, 'frameEnd': scene.frame_end,
        'fps': scene.render.fps, 'fpsBase': scene.render.fps_base, 'gravity': list(scene.gravity),
        'timeScale': w.time_scale, 'substepsPerFrame': w.substeps_per_frame,
        'solverIterations': w.solver_iterations, 'useSplitImpulse': w.use_split_impulse,
        'cacheIsBaked': w.point_cache.is_baked,
        'bodyCollection': sorted(o.name for o in w.collection.objects),
        'constraintCollection': sorted(o.name for o in w.constraints.objects)}}


def gltf(p):
    return [1000*p.x, 1000*p.z, -1000*p.y]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--remove-left-shoe-collider', action='store_true')
    args = parser.parse_args(sys.argv[sys.argv.index('--')+1:])
    output = args.out.resolve()
    output.mkdir(parents=True, exist_ok=False)
    assert bpy.app.version == (4, 5, 3)
    scene = bpy.context.scene
    scene.frame_set(0)
    bpy.context.view_layer.update()
    before = capture_config(scene)
    assert not before['world']['cacheIsBaked']
    for lane in ('left', 'right'):
        parent = scene.objects[lane+'_carriage']
        shoe = scene.objects[lane+'_shoe']
        assert parent.rigid_body.type == 'ACTIVE' and parent.rigid_body.collision_shape == 'COMPOUND'
        assert parent.rigid_body.mass == 1
        assert shoe.parent == parent and shoe.rigid_body.collision_shape == 'BOX'
        assert parent.animation_data is None and shoe.animation_data is None
        assert not scene.objects['_'+lane+'_generic'].rigid_body_constraint.use_limit_lin_x
        motor = scene.objects['_'+lane+'_motor']
        assert motor.rigid_body_constraint.object2 == parent
        drive, = motor.animation_data.drivers
        variable, = drive.driver.variables
        assert variable.targets[0].id == parent
        assert variable.targets[0].data_path == '["speed_mm_s"]'
        assert drive.driver.expression == '-speed_mm_s / 1000.0'
    removed = None
    if args.remove_left_shoe_collider:
        shoe = scene.objects['left_shoe']
        old_mesh, old_parent, old_matrix = shoe.data, shoe.parent, shoe.matrix_world.copy()
        bpy.ops.object.select_all(action='DESELECT')
        shoe.select_set(True)
        bpy.context.view_layer.objects.active = shoe
        bpy.ops.rigidbody.object_remove()
        assert shoe.rigid_body is None and shoe.data == old_mesh and shoe.parent == old_parent
        assert shoe.matrix_world == old_matrix
        removed = 'Removed only left_shoe rigid-body component; preserved visible mesh, parent and pose'
    after = capture_config(scene)
    (output/'configuration-before.json').write_text(json.dumps(before, indent=2)+'\n')
    (output/'configuration-after.json').write_text(json.dumps(after, indent=2)+'\n')
    bpy.context.preferences.filepaths.save_version = 0
    bpy.ops.wm.save_as_mainfile(filepath=str(output/'audited-scene.blend'))
    fps = scene.render.fps/scene.render.fps_base
    rows, samples = [], []
    initial, previous = {}, {}
    for frame in range(scene.frame_start, scene.frame_end+1):
        scene.frame_set(frame)
        graph = bpy.context.evaluated_depsgraph_get()
        record = {'frame': frame, 'timeS': frame/fps, 'parts': {}}
        row = {'frame': frame, 'timeS': frame/fps}
        for name in PARTS:
            obj = scene.objects[name]
            matrix = obj.evaluated_get(graph).matrix_world.copy()
            points = [gltf(matrix @ Vector(corner)) for corner in obj.bound_box]
            bounds = [[min(v[a] for v in points) for a in range(3)],
                      [max(v[a] for v in points) for a in range(3)]]
            record['parts'][name] = {'matrixBlenderM': [list(v) for v in matrix], 'boundsGltfMm': bounds}
        for lane in ('left', 'right'):
            x = record['parts'][lane+'_carriage']['matrixBlenderM'][0][3]*1000
            if frame == scene.frame_start:
                initial[lane] = x
            gap = record['parts'][lane+'_stop']['boundsGltfMm'][0][0]-record['parts'][lane+'_shoe']['boundsGltfMm'][1][0]
            row[lane+'TravelMm'] = x-initial[lane]
            row[lane+'GapMm'] = gap
            row[lane+'VelocityMmPerS'] = None if lane not in previous else (x-previous[lane])*fps
            previous[lane] = x
        rows.append(row)
        samples.append(record)
    with (output/'trace.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (output/'transforms.json').write_text(json.dumps(samples, separators=(',', ':'))+'\n')
    near = scene.objects['left_stop']['near_face_mm']
    ideal = (near-180)/125
    summary = {'nativeVersion': bpy.app.version_string, 'nativeBuild': bpy.app.build_hash.decode(),
               'ablation': args.remove_left_shoe_collider, 'mutation': removed,
               'samples': len(rows), 'captureFps': fps, 'idealContactS': ideal,
               'nearFaceMm': near, 'nativeNominalTimestepS': 1/(fps*scene.rigidbody_world.substeps_per_frame),
               'contactEvidence': 'Solver-evaluated poses; no Bullet manifold or impulse API used', 'lanes': {}}
    for lane in ('left', 'right'):
        pre = [row[lane+'VelocityMmPerS'] for row in rows[1:] if row['timeS'] <= ideal]
        post = [row[lane+'VelocityMmPerS'] for row in rows[1:] if row['timeS'] > ideal]
        summary['lanes'][lane] = {'finalTravelMm': rows[-1][lane+'TravelMm'],
            'finalGapMm': rows[-1][lane+'GapMm'], 'minimumGapMm': min(row[lane+'GapMm'] for row in rows),
            'firstWithinPoint01MmSampleS': next((row['timeS'] for row in rows if abs(row[lane+'GapMm']) <= .01), None),
            'preIdealContactVelocityRangeMmPerS': [min(pre), max(pre)],
            'postIdealContactVelocityRangeMmPerS': [min(post), max(post)]}
    (output/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
    print('INDEPENDENT_NATIVE_AUDIT', json.dumps(summary))


if __name__ == '__main__':
    main()
