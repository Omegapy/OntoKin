#!/usr/bin/env python3
"""Independent native rebuild, stop-edit, projection and collider-ablation audit."""
import argparse
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path.insert(0, str(HERE))
from glb_difference import compare, fields


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            h.update(block)
    return h.hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--blender', type=Path, required=True)
    parser.add_argument('--delivery', type=Path, default=ROOT/'deliveries/blender')
    parser.add_argument('--out', type=Path, required=True, help='New output directory')
    args = parser.parse_args()
    blender, delivery, output = args.blender.resolve(), args.delivery.resolve(), args.out.resolve()
    output.mkdir(parents=True, exist_ok=False)
    (output/'commands').mkdir()
    commands = []

    def run(label, argv, expected=(0,)):
        started = datetime.now(timezone.utc).isoformat()
        proc = subprocess.run(argv, capture_output=True, text=True, check=False)
        ended = datetime.now(timezone.utc).isoformat()
        (output/'commands'/(label+'.stdout.txt')).write_text(proc.stdout)
        (output/'commands'/(label+'.stderr.txt')).write_text(proc.stderr)
        commands.append({'label': label, 'argv': argv, 'startedAtUtc': started, 'finishedAtUtc': ended,
                         'returncode': proc.returncode, 'allowedReturncodes': list(expected)})
        write(output/'commands.json', commands)
        assert proc.returncode in expected, f'{label}: unexpected exit {proc.returncode}: {proc.stderr}'
        print(f'{label}: observed exit {proc.returncode}', flush=True)
        return proc.stdout

    input_checks = []
    for line in (delivery/'SHA256SUMS').read_text().splitlines():
        if not line.strip():
            continue
        expected, name = line.split(None, 1)
        name = name.lstrip(' *')
        assert digest(delivery/name) == expected, 'Sealed input changed: '+name
        input_checks.append(name)
    binary_before = digest(blender)
    write(output/'input-verification.json', {'deliveryManifestSha256': digest(delivery/'SHA256SUMS'),
        'filesVerified': len(input_checks), 'builderSha256': digest(delivery/'build.py'),
        'nativeReplaySha256': digest(delivery/'replay.py'), 'blenderExecutableSha256': binary_before,
        'pythonVersion': sys.version, 'checkerFreezeSha256': digest(ROOT/'checker/FREEZE.json')})
    version = run('native-version', [str(blender), '--version'])
    assert 'Blender 4.5.3 LTS' in version
    formal_matches = []
    for repeat in ('a', 'b'):
        for case in ('stop-380', 'stop-355'):
            dest = output/('formal-'+repeat)/case
            run('build-'+case+'-'+repeat, [str(blender), '-b', '-t', '2', '--python-exit-code', '1',
                '--python', str(delivery/'build.py'), '--', str(delivery/'settings'/(case+'.json')), str(dest)])
            for name in ('raw.glb', 'final.glb', 'native-transforms.json', 'native-trace.csv', 'native-summary.json'):
                assert (delivery/case/name).read_bytes() == (dest/name).read_bytes(), f'Formal rebuild mismatch: {case}/{name}/{repeat}'
                formal_matches.append({'repeat': repeat, 'case': case, 'file': name, 'sha256': digest(dest/name)})
    write(output/'formal-comparison.json', {'matchedAgainstSeal': formal_matches,
        'nativeSceneBytesNotCompared': 'Blend serialization contains path/session details; native saved-scene behavior is exercised separately'})

    settings380 = json.loads((delivery/'settings/stop-380.json').read_text())
    settings355 = json.loads((delivery/'settings/stop-355.json').read_text())
    assert set(settings380) == {'left_stop_near_face_mm'}
    assert set(settings355) == {'left_stop_near_face_mm'}
    assert settings380['left_stop_near_face_mm'] == 380 and settings355['left_stop_near_face_mm'] == 355
    third = output/'third-stop'
    third.mkdir()
    settings = third/'settings.json'
    write(settings, {'left_stop_near_face_mm': 367.5})
    (third/'settings.diff').write_text(''.join(difflib.unified_diff(
        (delivery/'settings/stop-380.json').read_text().splitlines(keepends=True),
        settings.read_text().splitlines(keepends=True), fromfile='sealed/settings/stop-380.json', tofile='third-stop/settings.json')))
    for repeat in ('a', 'b'):
        run('third-stop-replay-'+repeat, [str(blender), '-b', '-t', '2', str(delivery/'stop-380/scene.blend'),
            '--python-exit-code', '1', '--python', str(delivery/'replay.py'), '--', str(settings), str(third/('replay-'+repeat))])
    third_matches = []
    for name in ('raw.glb', 'final.glb', 'native-transforms.json', 'native-trace.csv', 'native-summary.json'):
        a, b = third/'replay-a'/name, third/'replay-b'/name
        assert a.read_bytes() == b.read_bytes(), 'Third-stop rebuild mismatch: '+name
        third_matches.append({'file': name, 'sha256': digest(a)})
    write(third/'rebuild-comparison.json', {'identicalFiles': third_matches,
        'nativeOperation': 'Reopen sealed 380 mm scene and change only near_face_mm; no geometry/constraint reconstruction'})

    observations, projections = [], []
    for case, stop, folder in (('stop-380', 380, output/'formal-a/stop-380'),
                                ('stop-355', 355, output/'formal-a/stop-355'),
                                ('stop-367.5', 367.5, third/'replay-a')):
        projection = compare(folder/'raw.glb', folder/'final.glb', folder/'native-transforms.json')
        write(output/(case+'-raw-final.json'), projection)
        assert projection['staticMeshesIdentical'] and projection['materialsIdentical'] and projection['geometryAccessorValuesIdentical']
        projections.append({'case': case, 'maximumRecordedVertexDistanceMm': projection['maximumRecordedVertexDistanceMm'],
            'maximumNativeSampleToFinalVertexDistanceMm': projection['maximumNativeSampleToFinalVertexDistanceMm'],
            'maximumContinuousRawToFinalVertexDeviationBoundMm': projection['maximumContinuousRawToFinalVertexDeviationBoundMm'],
            'jsonFieldChanges': len(projection['jsonFieldChanges']),
            'changedAnimationChannels': projection['changedAnimationChannels'],
            'geometryAccessorValuesIdentical': True, 'betweenKeyGeometryDeviationCertified': projection['betweenKeyGeometryDeviationCertified']})
        for form in ('raw', 'final'):
            path = output/(case+'-'+form+'-acceptance.json')
            run(case+'-'+form+'-acceptance', [sys.executable, '-IB', str(ROOT/'checker/measure_contact.py'),
                'blender', str(folder/(form+'.glb')), '--stop-mm', str(stop), '--out', str(path)], expected=(0, 1))
        observe_path = output/(case+'-observation.json')
        run(case+'-observation', [sys.executable, '-IB', str(ROOT/'audit/observe.py'), 'blender', str(folder/'final.glb'),
                                '--stop-mm', str(stop), '--out', str(observe_path)])
        acceptance = json.loads((output/(case+'-final-acceptance.json')).read_text())
        observation = json.loads(observe_path.read_text())
        assert acceptance['pass'], 'Frozen final acceptance failed: '+case+': '+str(acceptance.get('reason'))
        assert observation['observationComplete']
        observations.append({'case': case, 'frozenFinalPass': acceptance['pass'],
            'rawAcceptance': json.loads((output/(case+'-raw-acceptance.json')).read_text()),
            'leftGap': observation['gaps']['left'], 'rightGap': observation['gaps']['right'],
            'lanes': observation['lanes'], 'unrelatedPairs': observation['unrelatedPairSummary'],
            'trajectory': observation['trajectory']})

    control = output/'native-control'
    control.mkdir()
    for variant in ('baseline', 'removed-left-shoe-collider'):
        argv = [str(blender), '-b', '-t', '2', str(delivery/'stop-380/scene.blend'),
            '--python-exit-code', '1', '--python', str(HERE/'probe_native.py'), '--', '--out', str(control/variant)]
        if variant != 'baseline':
            argv.append('--remove-left-shoe-collider')
        run('causal-control-'+variant, argv)
    base, removed = control/'baseline', control/'removed-left-shoe-collider'
    original_config = json.loads((base/'configuration-before.json').read_text())
    assert original_config == json.loads((removed/'configuration-before.json').read_text())
    changes = fields(original_config, json.loads((removed/'configuration-after.json').read_text()))
    assert all(c['path'] in ('/objects/left_shoe/rigidBody', '/world/bodyCollection') for c in changes), changes
    a = json.loads((base/'summary.json').read_text())
    b = json.loads((removed/'summary.json').read_text())
    assert abs(a['lanes']['left']['finalTravelMm']-200) <= .5
    assert abs(b['lanes']['left']['finalTravelMm']-250) <= .2
    native_a = json.loads((base/'transforms.json').read_text())
    native_b = json.loads((removed/'transforms.json').read_text())
    unchanged = ('base', 'left_stop', 'right_carriage', 'right_shoe', 'right_stop')
    per_part = {name: all(x['parts'][name] == y['parts'][name] for x, y in zip(native_a, native_b)) for name in unchanged}
    right_difference = max(abs(x['parts'][name]['boundsGltfMm'][side][axis]-y['parts'][name]['boundsGltfMm'][side][axis])
        for x, y in zip(native_a, native_b) for name in ('right_carriage', 'right_shoe', 'right_stop')
        for side in (0, 1) for axis in range(3))
    assert right_difference <= .0001
    causal = {'initialConfigurationsIdentical': True, 'configurationChanges': changes,
        'collisionShapeRemovedOnly': True, 'unchangedNativePartsBitIdentical': per_part,
        'maximumRightLaneBoundsDifferenceMm': right_difference, 'baseline': a, 'ablated': b,
        'interpretation': 'With the native shoe BOX shape present the carriage halts; removing only that collision component leaves the mesh/attachment intact and the carriage continues. Right-lane response is unchanged.',
        'contactManifoldsOrImpulsesClaimed': False}
    write(output/'causal-control.json', causal)
    assert digest(blender) == binary_before
    report = {'auditVersion': 'C190-R2-blender-audit-1', 'completedAtUtc': datetime.now(timezone.utc).isoformat(),
        'formalBuilds': 4, 'formalStableComparisons': len(formal_matches), 'independentThirdStopReplays': 2,
        'thirdStopStableComparisons': len(third_matches), 'colliderControlRuns': 2,
        'pinnedExecutableUnchanged': True, 'blenderExecutableSha256': binary_before,
        'projectionAudits': projections, 'observedCases': observations,
        'nativeColliderControlPassed': True, 'rightLaneNativeBoundsDifferenceMm': right_difference,
        'limits': ['Raw native solver motion and final projected playback remain separate artifacts',
                   'Continuous projection bound covers interpolated raw GLB playback; native unrecorded substep poses are not covered',
                   'No Bullet manifold or normal-impulse API is exposed by the audit',
                   'Full product regression not rerun: product runtime unchanged']}
    write(output/'summary.json', report)
    print(json.dumps({'formalBuilds': 4, 'thirdStopReplays': 2, 'nativeColliderControlPassed': True,
        'rightLaneNativeBoundsDifferenceMm': right_difference,
        'maximumRecordedProjectionDeviationMm': max(x['maximumRecordedVertexDistanceMm'] for x in projections)}), flush=True)


if __name__ == '__main__':
    main()
