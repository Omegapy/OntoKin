"""Replay sealed C190 numerical and receiving-format evidence, without native rebuilds."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

ROOT = Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(command):
    result = subprocess.run(command, cwd=ROOT, text=True, capture_output=True)
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}): {command}\n{result.stdout}\n{result.stderr}")
    return result.stdout


def main():
    freeze = json.loads((ROOT / 'checker/FREEZE.json').read_text())
    for name, expected in freeze['files'].items():
        assert digest(ROOT / 'checker' / name) == expected, name
    runtime = json.loads((ROOT / 'evidence/runtime.json').read_text())
    for name, expected in runtime['files'].items():
        assert digest(ROOT / 'tools/native' / name) == expected, name
    seals = {}
    for directory in ['deliveries/blender', 'deliveries/ontokin', 'submissions/blender-1']:
        base = ROOT / directory
        lines = (base / 'SHA256SUMS').read_text().splitlines()
        for line in lines:
            expected, name = line.split('  ', 1)
            assert digest(base / name) == expected, directory + '/' + name
        seals[directory] = len(lines)
    sys.path.insert(0, str(ROOT / 'checker'))
    sys.path.insert(0, str(ROOT / 'audit'))
    from measure_contact import measure
    from observe import observe
    published = json.loads((ROOT / 'evidence/results.json').read_text())
    observed = []
    for case in published['cases']:
        candidate = ROOT / case['finalPath']
        assert digest(candidate) == case['finalSha256']
        result = measure(ROOT / 'checker/baselines' / (case['route'] + '.glb'), candidate, case['stopNearFaceMm'])
        assert result['pass'] == case['playbackPass'], case
        if not result['pass']:
            assert result['reason'] == 'left: maximum penetration exceeds 0.5 mm'
        full = observe(case['route'], candidate, case['stopNearFaceMm'])
        assert full['observationComplete']
        assert full['gaps']['left']['endMm'] == case['leftFinalSignedGapMm']
        assert full['gaps']['right']['endMm'] == case['rightFinalGapMm']
        assert full['unrelatedPairSummary']['nonoverlapPairs'] == 20
        observed.append({'route': case['route'], 'stopMm': case['stopNearFaceMm'],
                         'playbackPass': result['pass'], 'expectedOutcomeReproduced': True})
    with tempfile.TemporaryDirectory(prefix='c190-replay-') as tmp:
        work = Path(tmp)
        run([sys.executable, '-IB', str(ROOT/'checker/qualify.py'), '--out', str(work/'qualification.json')])
        assert (work/'qualification.json').read_bytes() == (ROOT/'checker/qualification.json').read_bytes()
        validator = work/'validator'
        validator.mkdir()
        with tarfile.open(ROOT/'tools/validation/gltf-validator-2.0.0-dev.3.10.tgz') as archive:
            archive.extractall(validator, filter='data')
        paths = [case[key] for case in published['cases'] for key in ['rawPath', 'finalPath']]
        (work/'files.json').write_text(json.dumps(paths))
        run(['node', str(ROOT/'audit/validate_glbs.cjs'), str(validator/'package'), str(ROOT),
             str(work/'files.json'), str(work/'validation.json')])
        validation = json.loads((work/'validation.json').read_text())
        for name, entry in validation.items():
            issues = entry['report']['issues']
            assert issues['numErrors'] == issues['numWarnings'] == 0, name
            expected_info = 1 if 'blender' in name and name.endswith('/final.glb') else 0
            assert issues['numInfos'] == expected_info and issues['numHints'] == 0, name
        run(['node', '--loader', str(ROOT/'audit/three_loader.mjs'), str(ROOT/'audit/three_readback.mjs'),
             str(ROOT), str(ROOT/'evidence/playback/all-files.json'), str(work/'three.json')])
        assert (work/'three.json').read_bytes() == (ROOT/'evidence/playback/three-all.json').read_bytes()
    print(json.dumps({'checkpoint': 'C190-R2', 'pass': True, 'checkerFilesVerified': len(freeze['files']),
                      'runtimeFilesVerified': len(runtime['files']), 'sealedDeliveries': seals,
                      'trajectoryControls': 45, 'sweptControls': 3, 'cases': observed,
                      'khronosFiles': 12, 'threeClips': 6, 'threePoses': 18,
                      'nativeBuildsRerunByThisCommand': False,
                      'scope': 'Fresh numerical, structural and Three.js replay; native audit drivers are separate'},
                     indent=2) + '\n', end='')


if __name__ == '__main__':
    main()
