# C190-R2.1 contact playback evaluator

This independently reconstructed evaluator replaces unavailable experiment files
from the interrupted C190 session. Its identity is **C190-R2.1**. It does not
claim the lost evaluator's hashes or control counts. The coordinator preserves
the original metadata separately.

The evaluator was developed and qualified without reading either C190 entrant's
directory or submission. `FREEZE.json` records the actual freeze time, exact
file hashes and qualification counts. The inherited GLB decoder, rectangular
surface proof and swept-slab intersection routine are unmodified copies of the
C187/C188 evaluator shipped in C189. The route baselines are the accepted C189
125 mm/s exports. The synthetic baseline comes from the C189 independent
control package.

## What a pass means

A pass certifies visible geometry and piecewise-linear playback in the supplied
GLB. It is **not proof of native contact simulation**. A timed clamp can satisfy
these numerical checks. The coordinator must inspect the native collider,
mass owner, attachment, solver response, editable stop control and fresh builds
separately before awarding collision credit.

The test preserves seven semantic node/mesh IDs, complete outward cuboid
surfaces, material colors and initial geometry. Only the left stop may move
from its baseline location; its thickness remains 30 mm. All motion has a fixed
orientation/scale and follows X. The stationary solids remain fixed. Shoes
retain their carriage offsets within 0.001 mm and relative speed within
0.025 mm/s. The right lane keeps its 150 mm/s motion and finishes with a
15 ± 0.5 mm gap.

The left shoe starts at X = 180 mm and approaches at 125 mm/s. Formal stop
faces at 380 and 355 mm imply ideal contact at 1.6 and 1.4 s. The independent
367.5 mm setting implies 1.5 s. The initial speed tolerance is 0.025 mm/s.
One event sample interval is allowed for impact timing and settling. From that
settling boundary through 2 s, the left carriage and shoe must remain within
0.5 mm of the contact pose. Post-contact velocity extrema are reported; no
extra speed tolerance is silently added to the specified positional criterion.

`firstWithinToleranceS` is the exact first interpolated entry into a 0.5 mm
face-gap band. `firstZeroGapS` separately reports exact geometric contact when
the export crosses zero gap. Small residual separation is admissible under the
task's positional tolerance. Neither timestamp is a native collision event.
Maximum penetration past the stop's near face is bounded by 0.5 mm over every
linear interval: an affine face gap reaches its extrema at interval endpoints.

Cadence is measured from translation tracks on each left part's actual ancestor
chain, rather than unrelated animation channels. Either all relevant intervals
must be at most 1/24 s, or an explicit impact key must have adjacent intervals
of at most 1/24 s. The impact interval defines the one-sample allowance. Float32
time encoding receives only a 0.0000003 s roundoff allowance. Native timestep
is separate evidence supplied by each author and audited by the coordinator.

The expected shoe/stop pair receives the contact rule. Each of the other 20
solid pairs receives a continuous swept-slab nonoverlap check on every exported
linear interval, with the inherited 0.001 mm numerical contact tolerance.

## Qualified controls

The independent generator imports no evaluator or entrant code. It constructs
analytic trajectories on the inherited synthetic geometry. All three stop
positions receive positive uniform-cadence and face-fan controls, plus a positive
explicit-impact-key control with fine cadence around impact and sparse samples
elsewhere. A hard-coded 1.6 s stop passes only the 380 mm setting and fails the
two moved-stop settings.

Negative controls include a moving stop, straight pass-through, a shoe stopping
without its carriage, both lanes stopping, post-impact penetration, an early
stop, incorrect initial speed, unresolved impact cadence, a small shoe slip,
a missing face and a renamed solid. Three separate slab controls check an
intersection only between keys, separation in Z and admissible endpoint contact.
`qualification.json` records all 45 trajectory-control outcomes (10 positive,
35 negative) and all three slab outcomes.

## Run

Use the handoff's CPython 3.12.14 and NumPy 2.3.5. No absolute runtime paths are
embedded in this package.

```sh
python -IB qualify.py --out qualification-replay.json
python -IB measure_contact.py blender /path/to/final.glb \
  --stop-mm 380 --out blender-stop-380.json
python -IB measure_contact.py ontokin /path/to/final.glb \
  --stop-mm 355 --out ontokin-stop-355.json
python -IB measure_contact.py blender /path/to/third-stop.glb \
  --stop-mm 367.5 --out blender-stop-367.5.json
```

The measurement command exits 0 for a playback pass and 1 for a measured
failure. Qualification regenerates all controls into a temporary directory and
requires their bytes to match the sealed controls. `--seal-controls` is only
for producing a new evaluator version before its freeze; do not use it to
overwrite this version's evidence after seeing submissions.
