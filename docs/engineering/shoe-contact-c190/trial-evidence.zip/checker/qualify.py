#!/usr/bin/env python3
"""Regenerate independent controls, verify acceptance/diagnostics and swept slab witnesses."""
import argparse
import hashlib
import json
import sys
import tempfile
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from measure_contact import HERE, VERSION, measure, swept_overlap
from specimens import specimen

FAULTS = {"good": None, "fan-positive": None, "event-local-positive": None,
          "pass-through": "maximum penetration", "moving-stop": "fixed body drifts",
          "shoe-only-stops": "shoe offset varies", "both-lanes-stop": "independent right trajectory",
          "penetration-after-contact": "maximum penetration", "stops-early": "no contact",
          "wrong-pre-speed": "pre-contact speed", "sparse": "insufficient impact cadence",
          "small-slip": "shoe offset varies", "missing-face": "incomplete or overlapping cuboid face",
          "renamed-shoe": "mesh node and mesh must share"}


def run(destination, seal=False):
    destination.mkdir(parents=True, exist_ok=True)
    cases = []
    for stop in (380, 355, 367.5):
        variants = dict(FAULTS)
        variants["hardcoded-1.6"] = None if stop == 380 else "maximum penetration"
        for fault, expected in variants.items():
            filename = f"stop-{stop:g}-{fault}.glb"
            path = destination / filename
            data = specimen(stop, fault)
            path.write_bytes(data)
            report = measure(HERE / "baselines/synthetic.glb", path, stop)
            good = ((report["pass"] and report["clearance"]["certifiedUnrelatedNonoverlapPairs"] == 20)
                    if expected is None else (not report["pass"] and expected in report.get("reason", "")))
            cases.append({"file": filename, "sha256": hashlib.sha256(data).hexdigest(),
                          "expectedPass": expected is None, "observedPass": report["pass"],
                          "expectedDiagnostic": expected, "observedDiagnostic": report.get("reason"),
                          "verified": good})
            if seal:
                (HERE / "receipts" / filename.replace(".glb", ".json")).write_text(json.dumps(report, indent=2)+"\n")
    a = np.array([[0., 0., 0.], [1., 1., 1.]])
    b = a + [7, 0, 0]
    slab = []
    for name, target, delta, collision in (("crosses-between-keys", b, [10,0,0], True),
                                           ("separated-in-z", b+[0,0,2], [10,0,0], False),
                                           ("endpoint-contact", b, [6,0,0], False)):
        witness = swept_overlap(a, a+delta, target, target)
        slab.append({"name": name, "witnessFraction": witness, "expectedCollision": collision,
                     "verified": (witness is not None) == collision})
    return {"version": VERSION, "pass": all(c["verified"] for c in cases+slab),
            "controls": cases, "sweptSlabControls": slab,
            "nativeCausalityScope": "No synthetic playback is solver evidence"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path)
    parser.add_argument("--seal-controls", action="store_true")
    args = parser.parse_args()
    with tempfile.TemporaryDirectory() as temp:
        path = HERE / "controls" if args.seal_controls else Path(temp)
        result = run(path, args.seal_controls)
        if not args.seal_controls:
            for control in result["controls"]:
                require_match = (path/control["file"]).read_bytes() == (HERE/"controls"/control["file"]).read_bytes()
                if not require_match:
                    raise ValueError("sealed control byte mismatch: "+control["file"])
    args.out.write_text(json.dumps(result, indent=2, allow_nan=False)+"\n")
    print(json.dumps({"version": result["version"], "pass": result["pass"],
                      "controls": len(result["controls"]),
                      "failures": [c for c in result["controls"] if not c["verified"]]}))
    raise SystemExit(0 if result["pass"] else 1)
