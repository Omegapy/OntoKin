#!/usr/bin/env python3
"""C190-R2.1: certify exported translation/contact playback, not native solver causality."""
import argparse
import hashlib
import itertools
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "reference"))
from gltf import Scene, require
from check import CONTACT_MM, RATE_MM_S, certify_shell, swept_overlap

VERSION = "C190-R2.1"
FACE_ROUNDOFF_MM = 0.0001
POSITION_MM = 0.5
TIME_ROUNDOFF_S = 3e-7
CADENCE_S = 1 / 24


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def world_start(scene, world, name):
    node, local, colors = scene.parts[name]
    matrices = world[node]
    basis = matrices[0, :3, :3]
    require(np.isfinite(matrices).all() and np.linalg.det(basis) != 0 and
            np.all(matrices[:, :3, :3] == basis), f"{name}: invalid or varying basis")
    triangles = 1000 * (local @ basis.T + matrices[0, :3, 3])
    bounds = np.stack([triangles.min((0, 1)), triangles.max((0, 1))])
    disp = 1000 * (matrices[:, :3, 3] - matrices[0, :3, 3])
    return triangles, bounds, disp, colors, int(np.sign(np.linalg.det(basis)))


def first_threshold(knots, values, limit):
    """Exact first crossing for a piecewise-linear scalar, including a constant contact."""
    if values[0] <= limit:
        return float(knots[0])
    for j in range(len(knots)-1):
        if values[j+1] <= limit:
            u = (values[j] - limit) / (values[j] - values[j+1])
            return float(knots[j] + u * (knots[j+1]-knots[j]))
    return None


def motion_knots(scene, name):
    """Only translation tracks that actually contribute to this part's world pose."""
    node = scene.parts[name][0]
    values = [0.0, 2.0]
    while node is not None:
        if (node, "translation") in scene.tracks:
            values.extend(scene.tracks[node, "translation"][0])
        node = scene.parent[node]
    return np.unique(values)


def evaluate(baseline, candidate, stop_mm, result):
    design = json.loads((HERE / "assembly.json").read_text())
    dims = {p["id"]: p for p in design["parts"]}
    ids = set(dims)
    require(np.isfinite(stop_mm) and 180 < stop_mm < 430, "stop outside the 2 s probe range")
    ideal = (stop_mm - 180) / 125
    old, scene = Scene(baseline, ids), Scene(candidate, ids)
    knots = scene.knots
    intervals = np.diff(knots)
    require(knots[0] == 0 and knots[-1] == 2, "incorrect clip duration")
    world, _ = scene.transforms(knots)
    old_world, _ = old.transforms(np.array([0.0, 2.0]))
    result["trajectory"] = {"knotsS": knots.tolist(), "certifiedIntervals": len(intervals),
                            "maxSceneIntervalS": float(intervals.max()), "lanes": {}}
    boxes, moves, velocities = {}, {}, {}
    for name, part in dims.items():
        tris, initial, disp, colors, parity = world_start(scene, world, name)
        _, reference, _, ref_colors, _ = world_start(old, old_world, name)
        expected = np.array(part["worldBoundsAt0Mm"], dtype=float)
        shift = np.zeros((2, 3))
        if name == "left_stop":
            shift[:, 0] = stop_mm - 495
        expected += shift
        reference += shift
        record = result["parts"][name] = {"boundsAt0Mm": initial.tolist()}
        require(np.max(np.abs(initial-expected)) <= design["tolerances"]["boundsAndWorldPositionsMm"],
                f"{name}: initial design bounds")
        require(np.max(np.abs(colors-part["baseColorLinearRGB"])) <= design["tolerances"]["colorMaxChannelError"],
                f"{name}: design color")
        record.update(certify_shell(name, tris, initial, parity))
        palette = np.unique(ref_colors, axis=0)
        require(len(palette) == 1, f"{name}: baseline solid material")
        bound_error = float(np.max(np.abs(initial-reference)))
        color_error = float(np.max(np.abs(colors-palette[0])))
        record.update({"maxPreservedFaceErrorMm": bound_error, "maxPreservedRGBError": color_error})
        require(bound_error <= FACE_ROUNDOFF_MM and color_error <= 1e-7,
                f"{name}: preserved C189 solid or color changed")
        velocity = np.diff(disp, axis=0) / intervals[:, None]
        record.update({"displacementAt2Mm": disp[-1].tolist(),
                       "velocityMinMmPerS": velocity.min(0).tolist(),
                       "velocityMaxMmPerS": velocity.max(0).tolist()})
        if part["motion"] == "fixed":
            require(np.max(np.abs(disp)) <= CONTACT_MM, f"{name}: fixed body drifts")
        else:
            require(np.max(np.abs(disp[:, 1:])) <= CONTACT_MM, f"{name}: travel outside X axis")
            if name.startswith("right_"):
                nominal = knots[:, None] * [150., 0., 0.]
                require(np.max(np.abs(disp-nominal)) <= 0.2, f"{name}: independent right trajectory")
                require(np.max(np.abs(velocity-[150., 0., 0.])) <= RATE_MM_S,
                        f"{name}: independent right speed")
        boxes[name] = initial + disp[:, None, :]
        moves[name], velocities[name] = disp, velocity

    # A fixed offset is stronger than merely similar terminal positions.
    for lane in ("left", "right"):
        shoe, car = lane+"_shoe", lane+"_carriage"
        offset = boxes[shoe].mean(1)-boxes[car].mean(1)
        error = float(np.max(np.abs(offset-offset[0])))
        rate_error = float(np.max(np.abs(velocities[shoe]-velocities[car])))
        result["trajectory"]["lanes"][lane] = {
            "initialShoeToCarriageOffsetMm": offset[0].tolist(),
            "maxOffsetDriftMm": error, "maxRelativeSpeedMmPerS": rate_error}
        require(error <= CONTACT_MM and rate_error <= RATE_MM_S, f"{lane}: shoe offset varies")

    for lane in ("left", "right"):
        stop, shoe = boxes[lane+"_stop"], boxes[lane+"_shoe"]
        gap = stop[:, 0, 0] - shoe[:, 1, 0]
        overlap = np.minimum(stop[:, 1, 1:], shoe[:, 1, 1:])-np.maximum(stop[:, 0, 1:], shoe[:, 0, 1:])
        require(np.all(overlap > 0), f"{lane}: absent transverse face overlap")
        result["gaps"][lane] = {"startMm": float(gap[0]), "endMm": float(gap[-1]),
                                "minimumMm": float(gap.min()), "minimumAtS": float(knots[gap.argmin()]),
                                "minTransverseOverlapMm": overlap.min(0).tolist()}
        if lane == "right":
            require(abs(gap[-1]-15) <= POSITION_MM, "right: final clearance")
            continue
        contact = first_threshold(knots, gap, POSITION_MM)
        geometric_contact = first_threshold(knots, gap, 0.0)
        penetration = max(0.0, float(-gap.min()))
        result["contact"] = {"idealTimeS": ideal, "firstWithinToleranceS": contact,
                             "firstZeroGapS": geometric_contact,
                             "contactToleranceMm": POSITION_MM,
                             "maxPenetrationPastNearFaceMm": penetration,
                             "penetrationCertification": "Affine gap extremum occurs at an interval endpoint",
                             "nativeSolverCausalityEstablished": False}
        require(penetration <= POSITION_MM, "left: maximum penetration exceeds 0.5 mm")
        require(contact is not None, "left: no contact within 0.5 mm")

    cadences = {}
    for name in ("left_carriage", "left_shoe"):
        local = motion_knots(scene, name)
        step = np.diff(local)
        uniform = float(step.max()) <= CADENCE_S + TIME_ROUNDOFF_S
        event_keys = np.flatnonzero(abs(local-ideal) <= TIME_ROUNDOFF_S)
        event_grid = False
        if len(event_keys):
            j = int(event_keys[0])
            event_grid = bool(0 < j < len(local)-1 and max(step[j-1], step[j]) <= CADENCE_S + TIME_ROUNDOFF_S)
        require(uniform or event_grid, f"{name}: insufficient impact cadence")
        before = np.searchsorted(local, ideal, side="right")-1
        before = max(0, min(before, len(step)-1))
        # The interval containing the impact, or the larger adjacent event interval,
        # defines the permitted one-sample timing/settling allowance.
        dt = float(step[before])
        if len(event_keys):
            j = int(event_keys[0])
            dt = float(max(step[j-1], step[j]))
        require(abs(contact-ideal) <= dt+TIME_ROUNDOFF_S, "left: first contact timing")
        cadences[name] = {"motionKnotsS": local.tolist(), "maxIntervalS": float(step.max()),
                          "fullClipCadencePass": uniform, "explicitImpactLocalCadencePass": event_grid,
                          "impactAllowanceS": dt}
        before_mask = knots[1:] <= ideal - dt + TIME_ROUNDOFF_S
        require(np.any(before_mask), f"{name}: no initial speed interval")
        pre_speed = velocities[name][before_mask]
        require(np.max(np.abs(pre_speed-[125., 0., 0.])) <= RATE_MM_S, f"{name}: pre-contact speed")
        # Probe the exact settling boundary as well as all later knots. Every
        # intervening position is affine, so endpoint bounds certify all times.
        settle = min(2.0, ideal + dt)
        probes = np.unique(np.r_[settle, knots[knots >= settle]])
        after_world, _ = scene.transforms(probes)
        _, _, after_disp, _, _ = world_start(scene, after_world, name)
        # world_start above references its first probe; use the true clip start.
        node = scene.parts[name][0]
        after_disp = 1000*(after_world[node][:, :3, 3]-world[node][0, :3, 3])
        target = np.array([stop_mm-180, 0., 0.])
        residual = float(np.max(np.abs(after_disp-target)))
        require(residual <= POSITION_MM, f"{name}: post-contact pose exceeds 0.5 mm")
        post_mask = knots[:-1] >= settle-TIME_ROUNDOFF_S
        post_speed = velocities[name][post_mask]
        cadences[name].update({"preContactSpeedMinMmPerS": pre_speed.min(0).tolist(),
                              "preContactSpeedMaxMmPerS": pre_speed.max(0).tolist(),
                              "settlingBoundaryS": settle, "maxPostContactPoseErrorMm": residual,
                              "postContactSpeedMinMmPerS": post_speed.min(0).tolist() if len(post_speed) else None,
                              "postContactSpeedMaxMmPerS": post_speed.max(0).tolist() if len(post_speed) else None})
    result["contact"]["sampling"] = cadences

    pairs = [p for p in itertools.combinations(boxes, 2)
             if set(p) != {"left_shoe", "left_stop"}]
    for a, b in pairs:
        for j, (t0, t1) in enumerate(zip(knots, knots[1:])):
            witness = swept_overlap(boxes[a][j], boxes[a][j+1], boxes[b][j], boxes[b][j+1])
            require(witness is None, f"{a} / {b}: interior overlap on [{t0}, {t1}]")
    result["clearance"] = {"certifiedUnrelatedNonoverlapPairs": len(pairs),
                           "pairs": pairs, "intervalsPerPair": len(intervals),
                           "allowedNumericalContactMm": CONTACT_MM}


def measure(baseline, candidate, stop_mm):
    result = {"version": VERSION, "stopNearFaceMm": stop_mm,
              "candidateSha256": digest(candidate), "baselineSha256": digest(baseline),
              "designSha256": digest(HERE / "assembly.json"), "pass": False,
              "scope": "Exported geometry and playback only; native causality requires separate audit",
              "parts": {}, "gaps": {}}
    try:
        evaluate(baseline, candidate, stop_mm, result)
        result["pass"] = True
    except (ValueError, OSError, KeyError, IndexError, TypeError, ArithmeticError) as error:
        result["reason"] = str(error)
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("route", choices=("blender", "ontokin", "synthetic"))
    p.add_argument("candidate", type=Path)
    p.add_argument("--stop-mm", required=True, type=float)
    p.add_argument("--out", required=True, type=Path)
    a = p.parse_args()
    r = measure(HERE / "baselines" / (a.route+".glb"), a.candidate, a.stop_mm)
    a.out.write_text(json.dumps(r, indent=2, allow_nan=False)+"\n")
    raise SystemExit(0 if r["pass"] else 1)
