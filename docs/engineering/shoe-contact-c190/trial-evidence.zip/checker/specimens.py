"""Independent analytic C190-R2 controls; imports no evaluator or participant source."""
import json
import struct
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "reference"))
from make_controls import build


def specimen(stop_mm, fault):
    spec = json.loads((HERE / "reference/assembly.json").read_text())
    for part in spec["parts"]:
        if part["id"] == "left_stop":
            for corner in part["worldBoundsAt0Mm"]:
                corner[0] += stop_mm-495
    modes = {"fan-positive": "good_face_fans", "missing-face": "missing_face",
             "renamed-shoe": "renamed_sibling"}
    raw = build(spec, modes.get(fault, "good"))
    size, = struct.unpack_from("<I", raw, 12)
    doc = json.loads(raw[20:20+size])
    blob = bytearray(raw[28+size:])
    doc["asset"]["generator"] = "Independent analytic C190-R2 control generator"
    doc["animations"] = [{"channels": [], "samplers": []}]
    anim = doc["animations"][0]
    node_ids = {n["name"]: i for i, n in enumerate(doc["nodes"])}
    tc = (stop_mm-180)/125
    times = np.linspace(0, 2, 81)
    if fault == "sparse":
        times = np.array([0, tc, 2])
    if fault == "event-local-positive":
        times = np.array([0, tc-.025, tc, tc+.025, 2])

    def access(values, kind):
        arr = np.array(values, dtype="<f4")
        if kind == "SCALAR":
            arr = arr.reshape(-1, 1)
        while len(blob) % 4:
            blob.append(0)
        view = len(doc["bufferViews"])
        doc["bufferViews"].append({"buffer": 0, "byteOffset": len(blob), "byteLength": arr.nbytes})
        blob.extend(arr.tobytes())
        idx = len(doc["accessors"])
        doc["accessors"].append({"bufferView": view, "componentType": 5126, "type": kind,
                                 "count": len(arr), "min": arr.min(0).tolist(), "max": arr.max(0).tolist()})
        return idx

    def track(name, values):
        anim["channels"].append({"target": {"node": node_ids[name], "path": "translation"},
                                  "sampler": len(anim["samplers"])})
        anim["samplers"].append({"input": access(times, "SCALAR"),
                                 "output": access(values, "VEC3"), "interpolation": "LINEAR"})

    left = .125*np.minimum(times, tc)
    if fault in ("pass-through", "shoe-only-stops"):
        left = .125*times
    elif fault == "hardcoded-1.6":
        left = .125*np.minimum(times, 1.6)
    elif fault == "penetration-after-contact":
        left += .001*np.maximum(0, times-tc)/(2-tc)
    elif fault == "stops-early":
        left = np.minimum(left, .125*tc-.001)
    elif fault == "wrong-pre-speed":
        left += .0001*np.sin(2*np.pi*times/tc)*(times < tc)
    right = .150*times
    if fault == "both-lanes-stop":
        right = .150*np.minimum(times, tc)
    track("left_actuator", np.stack([0*left, 0*left, left], axis=1))
    track("right_actuator", np.stack([0*right, 0*right, right], axis=1))
    if fault in ("shoe-only-stops", "small-slip"):
        pos = np.array(doc["nodes"][node_ids["left_shoe"]]["translation"])
        drift = -.125*np.maximum(0, times-tc) if fault == "shoe-only-stops" else .00001*times/2
        track("left_shoe", pos+np.stack([0*drift, 0*drift, drift], axis=1))
    if fault == "moving-stop":
        pos = np.array(doc["nodes"][node_ids["left_stop"]]["translation"])
        drift = .005*np.sin(np.pi*times/2)
        track("left_stop", pos+np.stack([0*drift, 0*drift, drift], axis=1))
    doc["buffers"][0]["byteLength"] = len(blob)
    header = json.dumps(doc, separators=(",", ":")).encode()
    header += b" "*(-len(header)%4)
    return (struct.pack("<4sII", b"glTF", 2, 28+len(header)+len(blob))+
            struct.pack("<I4s", len(header), b"JSON")+header+
            struct.pack("<I4s", len(blob), b"BIN\0")+blob)
