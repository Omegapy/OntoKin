"""Compare stable evidence from two or more independent rebuild directories."""
import hashlib
import json
from pathlib import Path
import sys


def main():
    roots = [Path(value) for value in sys.argv[1:]]
    if len(roots) < 2:
        raise SystemExit("Usage: python3.12 -IB compare_rebuilds.py BUILD_A BUILD_B [BUILD_C]")
    paths = ["native-capabilities.json", "between-case-comparison.json", "runtime-before.sha256", "runtime-after.sha256"]
    paths += [f"{case}/{name}" for case in ["stop-380", "stop-355"]
              for name in ["native.glb", "assembly.glb", "native-state.json", "measurements.json", "export-diff.json"]]
    checked = []
    for relative in paths:
        expected = (roots[0] / relative).read_bytes()
        for root in roots[1:]:
            assert (root / relative).read_bytes() == expected, f"Mismatch: {root / relative}"
        checked.append({"path": relative, "sha256": hashlib.sha256(expected).hexdigest()})
    for name in ["collision-enabled", "mass-bearing-follower"]:
        reports = [json.loads((root / "probes" / name / "export.json").read_text()) for root in roots]
        stable = ["outcome", "achieved_level", "diagnostics", "implementation_identity", "source_revision", "program_revision"]
        projections = [{key: report[key] for key in stable} for report in reports]
        assert all(value == projections[0] for value in projections[1:]), f"Diagnostic mismatch: {name}"
    print(json.dumps({"outcome": "identical stable native and delivered evidence",
        "directories_compared": [str(root) for root in roots], "byte_identical_files": checked,
        "diagnostic_projections_identical": ["collision-enabled", "mass-bearing-follower"],
        "variable_fields_not_compared": ["wall-clock execution time", "execution budget elapsed_ms", "absolute rebuild paths"]}, indent=2))


if __name__ == "__main__":
    main()
