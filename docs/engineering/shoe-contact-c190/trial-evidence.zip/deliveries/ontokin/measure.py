"""Read the delivered GLB and test the disclosed contact-free C190 result.

Checks seven visible solids, original dimensions/materials, rigid following,
recording cadence, both lane velocities, and geometric passage through the stop.
It does not infer solver contact from a geometric crossing.
"""
import json
from pathlib import Path
import struct
import sys


def decode(path):
    data = Path(path).read_bytes()
    length = struct.unpack_from("<I", data, 12)[0]
    doc = json.loads(data[20:20 + length])
    binary = data[28 + length:]

    def values(index):
        acc = doc["accessors"][index]
        view = doc["bufferViews"][acc["bufferView"]]
        assert acc["componentType"] == 5126 and view["buffer"] == 0
        fmt = struct.Struct("<" + {"SCALAR": "f", "VEC3": "3f", "VEC4": "4f"}[acc["type"]])
        start = view.get("byteOffset", 0) + acc.get("byteOffset", 0)
        stride = view.get("byteStride", fmt.size)
        return [fmt.unpack_from(binary, start + i * stride) for i in range(acc["count"])]

    anim, = doc["animations"]
    tracks = {}
    for channel in anim["channels"]:
        target = channel["target"]
        sampler = anim["samplers"][channel["sampler"]]
        assert sampler.get("interpolation", "LINEAR") == "LINEAR"
        tracks[target["node"], target["path"]] = (
            [t[0] for t in values(sampler["input"])], values(sampler["output"]))
    return doc, binary, values, tracks


def close(actual, expected, tolerance=0.2):
    if abs(actual - expected) > tolerance:
        raise AssertionError(f"Expected {expected}, observed {actual}, tolerance {tolerance}.")


def measure(path, case_id, assembly_path, cases_path, native_state_path):
    spec = json.loads(Path(assembly_path).read_text())
    cases = json.loads(Path(cases_path).read_text())
    case, = (c for c in cases["cases"] if c["id"] == case_id)
    doc, binary, values, tracks = decode(path)
    roots = doc["scenes"][doc["scene"]]["nodes"]
    expected = {p["id"]: p for p in spec["parts"]}
    expected["left_stop"]["worldBoundsAt0Mm"][0][0] = case["leftStopNearFaceMm"]
    expected["left_stop"]["worldBoundsAt0Mm"][1][0] = case["leftStopNearFaceMm"] + 30
    world = {}
    maximum_bounds_error = 0.0
    maximum_color_error = 0.0
    for i in roots:
        node = doc["nodes"][i]
        assert not any(k in node for k in ("matrix", "children", "scale"))
        name = node["name"]
        mesh = doc["meshes"][node["mesh"]]
        assert mesh["name"] == name
        times, translations = tracks[i, "translation"]
        assert times == sorted(set(times)) and times[0] == 0 and times[-1] == 2
        assert len(times) == 121
        for j, t in enumerate(times):
            close(t, j / 60, 0.0000002)
        rot_times, rotations = tracks[i, "rotation"]
        assert rot_times == times and set(rotations) == {(0., 0., 0., 1.)}
        vertices = [p for prim in mesh["primitives"] for p in values(prim["attributes"]["POSITION"])]
        corners = [tuple(map(fn, zip(*vertices))) for fn in (min, max)]
        world[name] = {t: [[1000 * (local + offset) for local, offset in zip(corner, translation)]
                           for corner in corners] for t, translation in zip(times, translations)}
        part = expected[name]
        for primitive in mesh["primitives"]:
            rgb = doc["materials"][primitive["material"]]["pbrMetallicRoughness"]["baseColorFactor"][:3]
            for actual, wanted in zip(rgb, part["baseColorLinearRGB"]):
                close(actual, wanted, spec["tolerances"]["colorMaxChannelError"])
                maximum_color_error = max(maximum_color_error, abs(actual - wanted))
        speed = 0 if part["motion"] == "fixed" else cases[name.split("_")[0] + "SpeedMmPerS"]
        for t, current in world[name].items():
            for corner, initial in zip(current, part["worldBoundsAt0Mm"]):
                for axis, (actual, start) in enumerate(zip(corner, initial)):
                    wanted = start + (speed * t if axis == 0 else 0)
                    close(actual, wanted)
                    maximum_bounds_error = max(maximum_bounds_error, abs(actual - wanted))
    assert world.keys() == expected.keys() and len(roots) == 7

    lanes = {}
    gap_tracks = {}
    for lane in ["left", "right"]:
        shoe, stop, carriage = (world[lane + "_" + name] for name in ["shoe", "stop", "carriage"])
        assert shoe.keys() == stop.keys() == carriage.keys()
        gaps = {}
        for time in shoe:
            lo, hi = shoe[time]
            slo, shi = stop[time]
            assert all(min(hi[a], shi[a]) > max(lo[a], slo[a]) for a in (1, 2))
            gaps[time] = slo[0] - hi[0]
        assert all(a > b for a, b in zip(gaps.values(), list(gaps.values())[1:]))
        offset = [shoe[0][0][axis] - carriage[0][0][axis] for axis in range(3)]
        drift = max(abs(shoe[t][0][axis] - carriage[t][0][axis] - offset[axis])
                    for t in shoe for axis in range(3))
        close(drift, 0, 0.2)
        expected_travel = cases[lane + "SpeedMmPerS"] * 2
        travel = carriage[2][0][0] - carriage[0][0][0]
        close(travel, expected_travel)
        crossing = None
        pairs = list(gaps.items())
        for (ta, ga), (tb, gb) in zip(pairs, pairs[1:]):
            if ga >= 0 and gb <= 0:
                crossing = ta + ga * (tb - ta) / (ga - gb)
                break
        final_overlap = max(0, min(shoe[2][1][0], stop[2][1][0]) - max(shoe[2][0][0], stop[2][0][0]))
        lanes[lane] = {
            "initial_gap_mm": gaps[0], "final_signed_leading_face_gap_mm": gaps[2],
            "minimum_signed_leading_face_gap_mm": min(gaps.values()),
            "first_geometric_face_crossing_s": crossing,
            "geometric_crossing_is_solver_contact": False,
            "final_x_overlap_mm": final_overlap,
            "carriage_travel_mm": travel,
            "shoe_travel_mm": shoe[2][0][0] - shoe[0][0][0],
            "shoe_offset_from_carriage_mm": offset, "maximum_attachment_drift_mm": drift,
            "initial_shoe_bounds_mm": shoe[0], "final_shoe_bounds_mm": shoe[2],
            "stop_bounds_mm": stop[0], "rotation": "identity at every retained key",
        }
        gap_tracks[lane] = gaps
    close(lanes["left"]["first_geometric_face_crossing_s"], case["idealContactS"], 0.000001)
    close(lanes["left"]["final_signed_leading_face_gap_mm"], case["leftStopNearFaceMm"] - 430)
    close(lanes["right"]["final_signed_leading_face_gap_mm"], 15)
    assert lanes["left"]["final_x_overlap_mm"] > 29.99
    assert lanes["right"]["first_geometric_face_crossing_s"] is None

    native = json.loads(Path(native_state_path).read_text())
    assert native["physical_assumptions"]["contact_response"] == "unavailable"
    assert native["physical_assumptions"]["collision"] == "disabled"
    observations = []
    for sample in native["samples"]:
        objects = sample["objects"]
        assert set(objects) == set(expected)
        assert sample["actions"] == {} and sample["joints"] == {}
        for lane, speed in [("left", 0.125), ("right", 0.15)]:
            body, shoe = objects[lane + "_carriage"], objects[lane + "_shoe"]
            close(body["velocity_m_per_s"][0], speed, 1e-12)
            close(shoe["velocity_m_per_s"][0], speed, 1e-12)
            assert body["physical"]["kind"] == "sphere_body" and body["own_mass_kg"] == 1
            assert shoe["physical"]["kind"] == "no_body" and shoe["own_mass_kg"] == 0
        observations.append({"time_seconds": sample["time_seconds"],
            "left_carriage_velocity_mm_per_s": [v * 1000 for v in objects["left_carriage"]["velocity_m_per_s"]],
            "left_shoe_velocity_mm_per_s": [v * 1000 for v in objects["left_shoe"]["velocity_m_per_s"]],
            "right_carriage_velocity_mm_per_s": [v * 1000 for v in objects["right_carriage"]["velocity_m_per_s"]],
            "left_shoe_pose_authority": objects["left_shoe"]["pose_authority"],
            "left_carriage_own_mass_kg": objects["left_carriage"]["own_mass_kg"],
            "left_shoe_own_mass_kg": objects["left_shoe"]["own_mass_kg"]})
    return {"case": case_id, "outcome": "native contact-free pass-through; requested stop unsupported",
        "visible_ids": list(world), "maximum_bounds_error_mm": maximum_bounds_error,
        "maximum_color_channel_error": maximum_color_error,
        "recording": {"fps": 60, "keys": 121, "duration_seconds": 2, "interpolation": "LINEAR",
                      "nominal_sample_interval_seconds": 1 / 60},
        "native_numerical_method": native["numerical_method"], "native_timestep_seconds": None,
        "native_boundary_times_seconds": native["boundary_times_seconds"],
        "native_physical_assumptions": native["physical_assumptions"],
        "lanes": lanes, "native_observations": observations,
        "gap_samples": [{"time_seconds": t, "left_gap_mm": gap_tracks["left"][t],
                         "right_gap_mm": gap_tracks["right"][t]} for t in gap_tracks["left"]]}


if __name__ == "__main__":
    print(json.dumps(measure(*sys.argv[1:]), indent=2, allow_nan=False))
