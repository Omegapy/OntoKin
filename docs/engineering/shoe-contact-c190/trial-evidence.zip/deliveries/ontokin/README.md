# C190 OntoKin recovery replication

**Result: the pinned native profile cannot solve contact at the shoe.** Both supplied cases are actual native exports of the disclosed contact-free motion. The left shoe passes into the stop and continues at 125 mm/s. The right lane continues independently at 150 mm/s. This package does not claim a collision-induced stop.

This is newly produced recovery evidence, not recovered original C190 evidence. The coordinator reported that the earlier result artifacts could not be recovered and authorized this replication. Tool readiness was recorded at **2026-11-10 00:13:13 UTC**. [recovery-receipt.json](recovery-receipt.json) records the scope, interpreter, deadline and assistance.

## Open and edit

The editable native sources are [stop-380/main.ok](stop-380/main.ok) and [stop-355/main.ok](stop-355/main.ok). Their only difference is the left stop's X placement, 380 mm versus 355 mm. Both are derived from the supplied C189 `feed-125` source; all other source text is unchanged. [settings.diff](settings.diff) records the one-literal change.

| Case | Raw native export | Final export with occurrence mesh names |
| --- | --- | --- |
| Stop at 380 mm | [native.glb](build/stop-380/native.glb) | [assembly.glb](build/stop-380/assembly.glb) |
| Stop at 355 mm | [native.glb](build/stop-355/native.glb) | [assembly.glb](build/stop-355/assembly.glb) |

Each build starts from its own time-zero state and runs for two seconds. The raw GLB is the exact byte array returned by the pinned runtime. The final adapter changes seven JSON mesh names from `extrusion` to the existing occurrence IDs. It changes no node, transform, material, vertex, timestamp or animation value. Each `export-diff.json` gives the seven JSON pointers and confirms that the entire 30,752-byte binary chunk is unchanged.

The seven visible IDs remain `base`, `left_carriage`, `left_shoe`, `left_stop`, `right_carriage`, `right_shoe` and `right_stop`. Initial bounds, dimensions, linear RGB colors, identities and the original rigid follow relationships are checked against [assembly.json](assembly.json), with only the required left-stop location substituted. The largest bounds discrepancy at any recorded key is **0.00002265 mm**, below the supplied 0.2 mm tolerance. The left stop remains 30 mm thick. The right stop's near face remains 495 mm.

## What the native run did

| Measurement | Stop at 380 mm | Stop at 355 mm |
| --- | ---: | ---: |
| Initial left leading-face gap | 200 mm | 175 mm |
| Ideal contact time from the brief | 1.600 s | 1.400 s |
| Geometric face crossing measured from GLB | 1.600000024 s | 1.399999976 s |
| Left carriage travel at 2 s | 250.000007 mm | 250.000007 mm |
| Left shoe travel at 2 s | 250.000011 mm | 250.000011 mm |
| Left signed leading-face gap at 2 s | −50.000012 mm | −75.000018 mm |
| Left shoe/stop X overlap at 2 s | 29.999999 mm | 29.999999 mm |
| Right carriage travel at 2 s | 300.000004 mm | 300.000004 mm |
| Right leading-face clearance at 2 s | 15.000008 mm | 15.000008 mm |

A negative signed gap means the shoe's leading face has passed the stop's near face. It is not a solver penetration estimate or a contact manifold. The positive Y and Z overlap and final X overlap establish actual geometric intersection of the displayed solids.

The native state inspections retain samples at 0, 1, 1.399, 1.4, 1.401, 1.599, 1.6, 1.601 and 2 seconds. Every sampled left carriage and shoe velocity remains `(125, 0, 0)` mm/s, including after both geometric crossings. The right carriage remains at `(150, 0, 0)` mm/s. The native engine reports `collision: disabled` and `contact_response: unavailable`. Its boundary-time list contains only `0`; there is no authored event at either ideal contact time.

Complete evidence is in each case's `native-state.json`, `inspection-request.json`, `export.json` and `measurements.json`. [between-case-comparison.json](build/between-case-comparison.json) confirms that every moving-part animation track is identical across settings. Only the left stop's translation track and its corresponding binary buffer view differ.

## Causal chain and the missing capability

| Required link | Actual native representation |
| --- | --- |
| Shape at the contact face | `left_shoe` is a closed extruded visible solid, initially spanning X = 50–180 mm. It has `physical = no_body()` and collision disabled. It is not a collision shape. |
| Owner of moving mass | `left_carriage` owns 1 kg through `sphere_body(20[mm], 1[kg])`. The sphere's center is the carriage's native origin, initially `(−100, 80, −200)` mm. This inherited sphere does not match the visible shoe's leading face. |
| Attachment | `follow left_mount` derives the shoe's pose from `left_carriage.frame` plus `(150, 40, 0)` mm. The right offset is `(180, 40, 0)` mm. The native catalog defines `follow` as one-way massless spatial following with no ownership or force transfer. |
| Fixed stop | Each stop keeps its authored world pose. It is a massless object with default prescribed motion and no actions; it is not an immovable physical collider. |
| Solver response | There is no contact response, collision pair, contact impulse, restitution or friction solve in this profile. Contact cannot propagate back through `follow` to the carriage. |

The shoes stay rigidly fixed relative to their carriages in the output: the largest measured left offset drift is 0.00001863 mm, attributable to binary32 output rounding. This spatial relationship does not establish a load-bearing rigid-body attachment.

Zero gravity and zero Y/Z initial velocities preserve X-only translation. The source does not declare a dynamically constrained slider or friction model. No restitution value can be set because no contact solve exists. These are the closest inherited C189 behaviors the pinned profile actually supports.

[native-capabilities.json](build/native-capabilities.json) captures the runtime's own catalog entries for collision mode, body model and following. The torque catalog explicitly lists contacts as unsupported. Its source specification also excludes contact, collision, compound inertia, general rigid-body dynamics and live engine physics.

## Preserved rejection probes

Two minimal native sources were executed through the same builder and pinned runtime:

| Probe | Exact native diagnostic |
| --- | --- |
| [collision-enabled.ok](probes/collision-enabled.ok) | `OKL-E-NAME`, binding phase: `Unknown name 'enabled' in this lexical scope.` |
| [mass-bearing-follower.ok](probes/mass-bearing-follower.ok) | `OKL-E-PHYSICAL-DOMAIN`, elaboration phase: `A follow relation may control only a massless child with no_body().` |

The collision probe demonstrates that `enabled` is not a legal collision-mode value. Its diagnostic is a binding rejection, not a solver failure after contact. The runtime catalog independently states that `disabled` is the only supported collision mode. The second probe establishes that the inherited follow relation cannot carry a physical shoe body.

Both raw diagnostic envelopes are preserved under `build/probes/`, including source/program hashes, source spans, native implementation identity, phase and blocked levels. They produced no GLB. There is no contact record to supply: the runtime reports contact response as unavailable, rather than an enabled solver observing zero contacts.

## Recording cadence and native timestep

The export requests **60 Hz**, producing **121 common keys** over 0–2 seconds. The nominal recording interval is 1/60 s. Both ideal contact times coincide with requested sample positions; stored binary32 timestamps have the small rounding differences shown above. All translations use linear interpolation and all rotations remain identity.

**There is no fixed native integration timestep.** The engine describes its method as `analytical trajectories; rational event clock; binary64 spatial calculations`. The 60 Hz setting controls GLB recording samples, not physics integration. The separate native inspections use the exact decimal times listed above. Increasing recording cadence does not add a contact solver.

## Portable rebuild

Use CPython 3.12.14 and the supplied immutable native checkout. No third-party Python package is required. From this submission directory, give each run a fresh output directory:

```sh
PYTHON=/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12
NATIVE=/workspace/scratch/eb7f3f78ef8f/c189/tools/native
"$PYTHON" -IB rebuild.py "$NATIVE" /absolute/path/to/rebuild-a
"$PYTHON" -IB rebuild.py "$NATIVE" /absolute/path/to/rebuild-b
"$PYTHON" -IB compare_rebuilds.py build /absolute/path/to/rebuild-a /absolute/path/to/rebuild-b
```

`rebuild.py` executes both case exports, both expected rejections, native state inspections and measurements. It records every invoked argument vector, start/end time, source hash, return code and native outcome in `attempts.json`. It also hashes the pinned runtime before and after the run. `compare_rebuilds.py` checks byte identity of the raw/final GLBs, native states, measurements, naming records, capability records, case comparison and runtime manifests. It compares the stable portions of the rejection envelopes separately. Execution times and absolute output paths are expected to differ.

The actual entrant command was:

```sh
/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 -IB submission/rebuild.py /workspace/scratch/eb7f3f78ef8f/c189/tools/native submission/build
```

It ran from the entrant directory, one level above this README. The four subprocess commands are preserved verbatim in [attempts.json](build/attempts.json). There was one build per case and one execution per minimal probe, with no source retry. Each successful build also makes a separate native state-inspection request. Thus the four build jobs contain two successful export requests, two native inspection requests and two expected rejected export requests. This is **formal submission 1**, not four submissions.

The runtime reports OntoKin reference 0.4.0, language 0.22, profile `torque-0.1`, with native source-code identity `3e6ef2df6a7e8837050abb949075bff9b65f6a4aa4a9f1587850d7ddd59bce56`. The before/after manifest covers 209 files and is unchanged; its SHA-256 is `937c5ec626aee8dbe7668010143d0825c6559226ccad2cc7d9164cf54f6db24e`. Cache files and Git metadata are excluded explicitly. Python ran with `-B`, so it did not write bytecode into the pinned runtime.

## Scope of the result

This replication demonstrates editable geometry, preserved IDs/materials, one native motion authority per lane, rigid spatial following, independent right-lane motion, a one-setting stop edit, verified raw export and recorded geometric pass-through. It does **not** demonstrate collision detection/response, a shoe collider attached to carriage mass, force feedback, a physical guide constraint or a collision-induced halt. No timed stop, impulse, position clamp, limit or edited motion track was used to imitate the requested result.
