"""Rebuild both C190 cases and reproduce expected native rejections.

Usage: python3.12 -IB rebuild.py /path/to/pinned/native /new/output/directory
All output stays under the specified output directory. Runtime bytes are read only.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shlex
import subprocess
import sys


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def runtime_manifest(root):
    rows = []
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if path.is_file() and ".git" not in rel.parts and "__pycache__" not in rel.parts and path.suffix != ".pyc":
            rows.append(hashlib.sha256(path.read_bytes()).hexdigest() + "  " + rel.as_posix())
    return "\n".join(rows) + "\n"


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runtime", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    runtime = args.runtime.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    before = runtime_manifest(runtime)
    (output / "runtime-before.sha256").write_text(before)
    sys.path.insert(0, str(runtime))
    sys.path.insert(0, str(root))
    from ontokin.agent import implementation_identity
    from ontokin.agent_catalog import catalog
    from ontokin.torque_agent_catalog import torque_interface
    from measure import measure, decode
    native_catalog = catalog()
    relevant = {"CollisionMode", "BodyModel", "sphere_body", "Object.collision", "follow", "disabled"}
    write_json(output / "native-capabilities.json", {
        "implementation_identity": implementation_identity(),
        "torque_interface": torque_interface(),
        "core_catalog_selected_items": [v for v in native_catalog["items"] if v["name"] in relevant],
    })
    attempts = []
    cases = ["stop-380", "stop-355"]
    jobs = [(case, root / case / "main.ok", output / case, 0) for case in cases]
    jobs += [(name, root / "probes" / (name + ".ok"), output / "probes" / name, 2)
             for name in ["collision-enabled", "mass-bearing-follower"]]
    expected_codes = {"collision-enabled": "OKL-E-NAME", "mass-bearing-follower": "OKL-E-PHYSICAL-DOMAIN"}
    try:
        for name, source, destination, expected_returncode in jobs:
            command = [sys.executable, "-IB", str(root / "build.py"), str(runtime), str(source), str(destination)]
            started = utc()
            process = subprocess.run(command, text=True, capture_output=True, check=False)
            finished = utc()
            destination.mkdir(parents=True, exist_ok=True)
            (destination / "stdout.txt").write_text(process.stdout)
            (destination / "stderr.txt").write_text(process.stderr)
            report_path = destination / "export.json"
            report = json.loads(report_path.read_text()) if report_path.exists() else {}
            attempt = {"order": len(attempts) + 1, "job": name, "started_utc": started,
                "finished_utc": finished, "command_argv": command, "shell_command": shlex.join(command),
                "source_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
                "returncode": process.returncode, "expected_returncode": expected_returncode,
                "native_outcome": report.get("outcome"),
                "native_diagnostics": report.get("diagnostics", []),
                "native_achieved_level": report.get("achieved_level")}
            attempts.append(attempt)
            write_json(output / "attempts.json", attempts)
            print(f"{name}: exit {process.returncode}; native outcome {report.get('outcome')}", flush=True)
            assert process.returncode == expected_returncode, process.stderr
            if expected_returncode == 0:
                measured = measure(destination / "assembly.glb", name, root / "assembly.json",
                    root / "cases.json", destination / "native-state.json")
                write_json(destination / "measurements.json", measured)
            else:
                assert report["diagnostics"][0]["code"] == expected_codes[name], report
                assert not (destination / "native.glb").exists()

        documents = [decode(output / case / "assembly.glb") for case in cases]
        doc_a, bin_a, _, tracks_a = documents[0]
        doc_b, bin_b, _, tracks_b = documents[1]
        changed_tracks = []
        for key in tracks_a:
            if tracks_a[key] != tracks_b[key]:
                changed_tracks.append({"node": doc_a["nodes"][key[0]]["name"], "path": key[1]})
        assert changed_tracks == [{"node": "left_stop", "path": "translation"}]
        changed_views = []
        assert len(doc_a["bufferViews"]) == len(doc_b["bufferViews"])
        for i, (va, vb) in enumerate(zip(doc_a["bufferViews"], doc_b["bufferViews"])):
            assert va == vb
            start, length = va.get("byteOffset", 0), va["byteLength"]
            if bin_a[start:start + length] != bin_b[start:start + length]:
                changed_views.append(i)
        write_json(output / "between-case-comparison.json", {
            "changed_animation_tracks": changed_tracks, "changed_binary_buffer_views": changed_views,
            "all_moving_part_tracks_identical": True, "right_lane_independent_of_left_stop_setting": True,
            "interpretation": "Only the left stop moved; moving trajectories did not respond to contact geometry."})
        write_json(output / "rebuild-summary.json", {
            "outcome": "expected unsupported-contact result reproduced",
            "evidence_kind": "C190 recovery replication",
            "python_version": sys.version, "cases": cases, "build_attempts": len(attempts),
            "formal_submission_number": 1, "recording_fps": 60, "recording_keys_per_case": 121,
            "native_timestep_seconds": None,
            "native_method": "analytical trajectories; rational event clock; binary64 spatial calculations",
            "native_contact_response": "unavailable", "native_collision": "disabled",
            "contact_success_claimed": False, "rejections_expected": expected_codes,
            "finished_utc": utc()})
    finally:
        after = runtime_manifest(runtime)
        (output / "runtime-after.sha256").write_text(after)
        write_json(output / "runtime-integrity.json", {
            "unchanged": before == after, "files_hashed": len(before.splitlines()),
            "manifest_sha256": hashlib.sha256(before.encode()).hexdigest(),
            "exclusions": [".git directory", "__pycache__ directories", "*.pyc files"]})
        assert before == after, "Pinned runtime bytes changed."
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
