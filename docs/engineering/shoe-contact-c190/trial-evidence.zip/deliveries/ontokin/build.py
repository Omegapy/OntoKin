"""Export one immutable OntoKin source and record native state without physics edits.

The only GLB adaptation changes mesh names to existing occurrence IDs.
This file supplies no contact algorithm, timed stop, position clamp or motion track.
"""
import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def label_meshes(native):
    magic, version, total = struct.unpack_from("<4sII", native)
    size, kind = struct.unpack_from("<I4s", native, 12)
    if magic != b"glTF" or version != 2 or total != len(native) or kind != b"JSON":
        raise ValueError("Expected an embedded GLB with a JSON chunk.")
    document = json.loads(native[20:20 + size])
    changes = []
    used = set()
    for node in document["nodes"]:
        if "mesh" not in node:
            continue
        idx = node["mesh"]
        if idx in used:
            raise ValueError("One mesh is referenced by multiple occurrence IDs.")
        used.add(idx)
        mesh = document["meshes"][idx]
        if mesh.get("name") != node["name"]:
            changes.append({"path": f"/meshes/{idx}/name", "before": mesh.get("name"),
                            "after": node["name"]})
            mesh["name"] = node["name"]
    data = json.dumps(document, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    data += b" " * (-len(data) % 4)
    tail = native[20 + size:]
    output = struct.pack("<4sIIII", b"glTF", 2, 20 + len(data) + len(tail),
                         len(data), 0x4e4f534a) + data + tail
    bin_size, bin_kind = struct.unpack_from("<I4s", tail)
    if bin_kind != b"BIN\x00" or len(tail) != 8 + bin_size:
        raise ValueError("Expected one BIN chunk after JSON.")
    digest = lambda b: hashlib.sha256(b).hexdigest()
    diff = {"native_sha256": digest(native), "final_sha256": digest(output),
            "bin_byte_length": bin_size, "bin_sha256": digest(tail[8:]),
            "binary_chunk_unchanged": True, "json_fields_changed": changes}
    return output, diff


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runtime", type=Path)
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path, help="Must not already exist")
    args = parser.parse_args()
    sys.path.insert(0, str(args.runtime.resolve()))
    from ontokin.budget_runtime import execute_torque_export
    from ontokin.construction import compile_construction
    from ontokin.evaluator import evaluate
    from ontokin.execution_budget import HostPolicy, SharedExecutionBudget, admit_entry_budget
    from ontokin.profile_capabilities import TORQUE_PROFILE
    from ontokin.program_runtime import _support
    from ontokin.scene import ExportOptions
    from ontokin.texture_bundle import load_texture_bundle

    source = args.source.read_text(encoding="utf-8")
    bundle = load_texture_bundle({
        "schema_version": "ontokin.bundle/0.2",
        "entry": {"filename": "main.ok", "source": source},
        "modules": [], "assets": [],
    })
    args.output.mkdir(parents=True, exist_ok=False)
    policy = HostPolicy(max_operations=1_000_000, max_elapsed_ms=80_000)
    caps = {"max_operations": 1_000_000, "max_elapsed_ms": 80_000}
    result = execute_torque_export(bundle, policy=policy, caller_caps=caps,
        options=ExportOptions(end="2", fps=60, helpers=False))
    write_json(args.output / "export.json", result.report)
    if result.data is None:
        print("Native export rejected this source; raw diagnostic is in export.json.")
        return 2
    (args.output / "native.glb").write_bytes(result.data)
    final, diff = label_meshes(result.data)
    (args.output / "assembly.glb").write_bytes(final)
    write_json(args.output / "export-diff.json", diff)

    # A second native request inspects the same source around both ideal contact
    # times. Neither request introduces an event at those times.
    ledger = SharedExecutionBudget(policy, caps)
    admit_entry_budget(bundle.entry, ledger, profile=TORQUE_PROFILE)
    ledger.stage = "construction"
    compiler = compile_construction(bundle, execution_budget=ledger)
    _support(compiler)
    ledger.stage = "evaluation"
    sample_times = ["0", "1", "1.399", "1.4", "1.401", "1.599", "1.6", "1.601", "2"]
    state = evaluate(compiler.model, sample_times, check=ledger.tick, work=compiler.reach_work)
    write_json(args.output / "native-state.json", state)
    write_json(args.output / "inspection-request.json", {
        "entry_filename": "main.ok", "source_revision": bundle.entry.revision,
        "program_revision": bundle.program_revision, "sample_times_seconds": sample_times,
        "side": "after", "native_timestep_seconds": None,
        "native_method": state["numerical_method"],
        "export_sampling": {"fps": 60, "duration_seconds": 2, "helpers": False},
        "execution_budget": ledger.report(status="valid"),
    })
    print("Native export and native state inspection completed; contact response is unavailable.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
