import bpy, json, csv
from pathlib import Path
from mathutils import Matrix, Vector
ROOT=Path(__file__).resolve().parents[1]
bpy.ops.wm.open_mainfile(filepath=str(ROOT/'starter/feed-125.blend'))
scene=bpy.context.scene
scene.frame_set(0)
visible=list(scene.objects)
world={o.name:o.matrix_world.copy() for o in visible}
for o in visible:
    o.animation_data_clear()
    o.parent=None
    o.matrix_world=world[o.name]
for o in visible:
    center=sum((Vector(p) for p in o.bound_box),Vector())/8
    for v in o.data.vertices: v.co-=center
    o.matrix_world=o.matrix_world@Matrix.Translation(center)
for lane in ('left','right'):
    shoe=scene.objects[lane+'_shoe']; carriage=scene.objects[lane+'_carriage']; matrix=shoe.matrix_world.copy()
    shoe.parent=carriage; shoe.matrix_parent_inverse=Matrix.Identity(4); shoe.matrix_world=matrix
for a in list(bpy.data.actions):
    if a.users==0: bpy.data.actions.remove(a)
scene.frame_start=0; scene.frame_end=480; scene.render.fps=240; scene.render.fps_base=1
scene.gravity=(0,0,0)
scene.objects['left_stop'].location.x=.395

def rb(obj,kind,shape):
    bpy.ops.object.select_all(action='DESELECT'); obj.select_set(True); bpy.context.view_layer.objects.active=obj
    bpy.ops.rigidbody.object_add()
    r=obj.rigid_body; r.type=kind; r.collision_shape=shape; r.mass=1
    r.friction=0; r.restitution=0; r.linear_damping=0; r.angular_damping=0; r.use_margin=True; r.collision_margin=0; r.use_deactivation=False
    return r
for name in ('base','left_stop','right_stop'): rb(scene.objects[name],'PASSIVE','BOX')
for lane in ('left','right'):
    carriage=scene.objects[lane+'_carriage']; shoe=scene.objects[lane+'_shoe']
    rb(carriage,'ACTIVE','COMPOUND'); rb(shoe,'ACTIVE','BOX')
    proxy=bpy.data.objects.new('_'+lane+'_carriage_collision',carriage.data.copy()); scene.collection.objects.link(proxy)
    proxy.parent=carriage; proxy.matrix_parent_inverse=Matrix.Identity(4); proxy.location=(0,0,0); proxy.hide_render=True; proxy.display_type='WIRE'
    rb(proxy,'ACTIVE','BOX')
    for kind in ('GENERIC','MOTOR'):
        joint=bpy.data.objects.new('_'+lane+'_'+kind.lower(),None); scene.collection.objects.link(joint); joint.location=carriage.location
        bpy.ops.object.select_all(action='DESELECT'); joint.select_set(True); bpy.context.view_layer.objects.active=joint; bpy.ops.rigidbody.constraint_add()
        c=joint.rigid_body_constraint; c.type=kind; c.object1=scene.objects['base']; c.object2=carriage; c.disable_collisions=True
        c.use_override_solver_iterations=True; c.solver_iterations=100
        if kind=='GENERIC':
            c.use_limit_lin_x=False
            for axis in ('y','z'):
                setattr(c,'use_limit_lin_'+axis,True); setattr(c,'limit_lin_'+axis+'_lower',0); setattr(c,'limit_lin_'+axis+'_upper',0)
            for axis in ('x','y','z'):
                setattr(c,'use_limit_ang_'+axis,True); setattr(c,'limit_ang_'+axis+'_lower',0); setattr(c,'limit_ang_'+axis+'_upper',0)
        else:
            c.use_motor_lin=True; c.motor_lin_target_velocity=-.125 if lane=='left' else -.15; c.motor_lin_max_impulse=100000
world=scene.rigidbody_world; world.substeps_per_frame=10; world.solver_iterations=100; world.use_split_impulse=True; world.point_cache.frame_start=0; world.point_cache.frame_end=480
for f in range(0,481):
    scene.frame_set(f); dg=bpy.context.evaluated_depsgraph_get()
    if f%24==0 or f in (1,2,3):
        print('PROBE', f,[(n,tuple(scene.objects[n].evaluated_get(dg).matrix_world.translation)) for n in ('left_carriage','left_shoe','right_carriage')])
bpy.context.preferences.filepaths.save_version=0
scene.frame_set(0)
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'work/probe.blend'))
