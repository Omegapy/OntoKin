"""Measure every exported sample, including tiny native-solver rotations.

Usage: python3 measure.py final.glb [native-transforms.json]
No Blender or third-party Python package is required.
"""
import json
import math
from pathlib import Path
import struct
import sys

PARTS = {'base', 'left_carriage', 'left_shoe', 'left_stop', 'right_carriage', 'right_shoe', 'right_stop'}


def product(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(4)) for j in range(4)] for i in range(4)]


def local_matrix(node, values):
    if 'matrix' in node:
        assert not values
        return [[node['matrix'][j * 4 + i] for j in range(4)] for i in range(4)]
    t = values.get('translation', node.get('translation', [0, 0, 0]))
    s = values.get('scale', node.get('scale', [1, 1, 1]))
    x, y, z, w = values.get('rotation', node.get('rotation', [0, 0, 0, 1]))
    rotation = [[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)],
                [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)],
                [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]]
    return [[rotation[i][j] * s[j] for j in range(3)] + [t[i]] for i in range(3)] + [[0, 0, 0, 1]]


def measure(path, native_path=None):
    data = path.read_bytes()
    magic, version, total = struct.unpack_from('<4sII', data)
    assert (magic, version, total) == (b'glTF', 2, len(data))
    offset, model, payload = 12, None, None
    while offset < len(data):
        size, kind = struct.unpack_from('<II', data, offset)
        chunk = data[offset + 8:offset + 8 + size]
        if kind == 0x4E4F534A:
            model = json.loads(chunk)
        elif kind == 0x004E4942:
            payload = chunk
        offset += 8 + size
    assert model and payload

    def floats(index):
        accessor = model['accessors'][index]
        assert accessor['componentType'] == 5126
        count = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}[accessor['type']]
        layout = struct.Struct('<' + 'f' * count)
        view = model['bufferViews'][accessor['bufferView']]
        start = view.get('byteOffset', 0) + accessor.get('byteOffset', 0)
        stride = view.get('byteStride', layout.size)
        return [layout.unpack_from(payload, start + i * stride) for i in range(accessor['count'])]

    nodes = model['nodes']
    named = {node['name']: i for i, node in enumerate(nodes)}
    assert set(named) == PARTS, set(named)
    assert len(model['meshes']) == 7
    parents = {child: i for i, node in enumerate(nodes) for child in node.get('children', [])}
    for lane in ('left', 'right'):
        assert parents[named[lane + '_shoe']] == named[lane + '_carriage']
    animation, = model['animations']
    tracks = {}
    times = None
    for channel in animation['channels']:
        sampler = animation['samplers'][channel['sampler']]
        assert sampler['interpolation'] == 'LINEAR'
        track_times = [v[0] for v in floats(sampler['input'])]
        assert times is None or times == track_times
        times = track_times
        target = channel['target']
        assert not nodes[target['node']]['name'].endswith('_shoe'), 'Shoes must follow their parents'
        tracks[(target['node'], target['path'])] = floats(sampler['output'])
    assert len(times) == 481 and abs(times[0]) < 1e-8 and abs(times[-1] - 2) < 1e-8
    vertices = {}
    colors = {}
    for name, index in named.items():
        primitive, = model['meshes'][nodes[index]['mesh']]['primitives']
        vertices[index] = floats(primitive['attributes']['POSITION'])
        colors[name] = model['materials'][primitive['material']]['pbrMetallicRoughness']['baseColorFactor'][:3]
    samples = []
    for sample_index, time in enumerate(times):
        matrices = {}
        def world(index):
            if index not in matrices:
                values = {field: values[sample_index] for (i, field), values in tracks.items() if i == index}
                matrix = local_matrix(nodes[index], values)
                matrices[index] = product(world(parents[index]), matrix) if index in parents else matrix
            return matrices[index]
        bounds = {}
        for name, index in named.items():
            matrix = world(index)
            points = [[1000 * (sum(matrix[a][k] * vertex[k] for k in range(3)) + matrix[a][3]) for a in range(3)] for vertex in vertices[index]]
            bounds[name] = [[min(p[a] for p in points) for a in range(3)], [max(p[a] for p in points) for a in range(3)]]
        samples.append(bounds)
    result = {'file': path.name, 'visible_solids': sorted(named), 'samples': len(times), 'duration_s': times[-1] - times[0],
              'sample_interval_s': 1 / 240, 'initial_bounds_mm': samples[0], 'linear_rgb': colors, 'lanes': {}}
    for lane in ('left', 'right'):
        gaps = []
        travels = []
        initial = samples[0][lane + '_carriage'][0][0]
        for sample in samples:
            shoe, stop = sample[lane + '_shoe'], sample[lane + '_stop']
            assert all(min(shoe[1][a], stop[1][a]) > max(shoe[0][a], stop[0][a]) for a in (1, 2))
            gaps.append(stop[0][0] - shoe[1][0])
            travels.append(sample[lane + '_carriage'][0][0] - initial)
        contact = [i for i, gap in enumerate(gaps) if abs(gap) <= .01]
        speed = 125 if lane == 'left' else 150
        ideal_travel = [min(speed * t, gaps[0]) for t in times]
        result['lanes'][lane] = {
            'initial_gap_mm': gaps[0], 'minimum_gap_mm': min(gaps), 'final_gap_mm': gaps[-1],
            'final_travel_mm': travels[-1], 'first_contact_sample_s': times[contact[0]] if contact else None,
            'max_deviation_from_ideal_travel_mm': max(abs(x - y) for x, y in zip(travels, ideal_travel)),
        }
    if native_path:
        native = json.loads(native_path.read_text())
        assert len(native) == len(samples)
        result['max_glb_vs_native_bounds_error_mm'] = max(
            abs(native[i]['bounds_gltf_mm'][name][side][axis] - samples[i][name][side][axis])
            for i in range(len(samples)) for name in named for side in (0, 1) for axis in range(3))
        assert result['max_glb_vs_native_bounds_error_mm'] < .2
    return result


if __name__ == '__main__':
    print(json.dumps(measure(Path(sys.argv[1]), Path(sys.argv[2]) if len(sys.argv) > 2 else None), indent=2))
