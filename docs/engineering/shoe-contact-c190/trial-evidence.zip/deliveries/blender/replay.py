"""Replay a delivered native scene, optionally changing only its stop setting.

  blender -b stop-380/scene.blend --python-exit-code 1 --python replay.py -- settings/stop-355.json output
This does not call configure() or rebuild geometry/physics. It operates on the
saved native scene. The output includes a copy of the edited native scene.
"""
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import sys
import bpy

api = runpy.run_path(str(Path(__file__).resolve().with_name('build.py')))
settings_name, output_name = sys.argv[sys.argv.index('--') + 1:]
settings = json.loads(Path(settings_name).read_text())
assert set(settings) == {'left_stop_near_face_mm'}
output = Path(output_name).resolve()
output.mkdir(parents=True, exist_ok=True)
scene = bpy.context.scene
assert bpy.app.version == (4, 5, 3)
assert (scene.frame_start, scene.frame_end, scene.render.fps) == (0, 480, 240)
for lane in ('left', 'right'):
    carriage = scene.objects[lane + '_carriage']
    shoe = scene.objects[lane + '_shoe']
    assert carriage.rigid_body.type == 'ACTIVE'
    assert carriage.rigid_body.collision_shape == 'COMPOUND'
    assert carriage.animation_data is None
    assert shoe.parent == carriage and shoe.rigid_body.collision_shape == 'BOX'
    assert shoe.animation_data is None
    joint = scene.objects['_' + lane + '_motor']
    assert joint.rigid_body_constraint.object2 == carriage
    assert not scene.objects['_' + lane + '_generic'].rigid_body_constraint.use_limit_lin_x
    drive, = joint.animation_data.drivers
    variable, = drive.driver.variables
    assert variable.targets[0].id == carriage
    assert variable.targets[0].data_path == '["speed_mm_s"]'

# No saved baked physics cache: this property is the only design input changed.
assert not scene.rigidbody_world.point_cache.is_baked
scene.frame_set(0)
stop = scene.objects['left_stop']
stop['near_face_mm'] = float(settings['left_stop_near_face_mm'])
stop.update_tag()
scene.frame_set(0)
bpy.context.view_layer.update()
bpy.context.preferences.filepaths.save_version = 0
bpy.ops.wm.save_as_mainfile(filepath=str(output / 'scene.blend'))
rows, transforms = api['capture'](scene)
summary = api['summarize'](rows, scene)
api['write_capture'](output, rows, transforms, summary)
api['export_scene'](scene, output / 'raw.glb')
mapping = runpy.run_path(str(Path(__file__).resolve().with_name('map_playback.py')))['map_playback']
mapping(output / 'raw.glb', output / 'final.glb', output / 'post-export.json', output / 'native-transforms.json')
print('REPLAY_NATIVE_SUMMARY', json.dumps(summary))
print('REPLAY_GLB_SHA256', hashlib.sha256((output / 'raw.glb').read_bytes()).hexdigest())
