"""C190: native Bullet compound-body contact, built from the C189 Blender source.

Run with pinned Blender 4.5.3 LTS:
  blender -b -t 2 --python-exit-code 1 --python build.py -- settings/stop-380.json output
No elapsed-time or travel-distance branch controls carriage motion.
"""
import csv
import hashlib
import json
import runpy
from pathlib import Path
import shutil
import sys

import bpy
from mathutils import Matrix, Vector

PARTS = ('base', 'left_carriage', 'left_shoe', 'left_stop',
         'right_carriage', 'right_shoe', 'right_stop')
FPS = 240
DURATION_S = 2
SUBSTEPS = 10
ITERATIONS = 100
FEEDS_MM_S = {'left': 125.0, 'right': 150.0}


def selected(obj):
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj


def add_body(obj, body_type, shape):
    selected(obj)
    bpy.ops.rigidbody.object_add()
    body = obj.rigid_body
    body.type = body_type
    body.collision_shape = shape
    body.mass = 1.0
    body.friction = 0.0
    body.restitution = 0.0
    body.linear_damping = 0.0
    body.angular_damping = 0.0
    body.use_margin = True
    body.collision_margin = 0.0
    body.use_deactivation = False
    return body


def add_constraint(scene, lane, kind):
    carriage = scene.objects[lane + '_carriage']
    obj = bpy.data.objects.new('_' + lane + '_' + kind.lower(), None)
    scene.collection.objects.link(obj)
    obj.location = carriage.location
    obj.empty_display_size = 0.04
    obj.hide_render = True
    selected(obj)
    bpy.ops.rigidbody.constraint_add()
    joint = obj.rigid_body_constraint
    joint.type = kind
    joint.object1 = scene.objects['base']
    joint.object2 = carriage
    joint.disable_collisions = True
    joint.use_override_solver_iterations = True
    joint.solver_iterations = ITERATIONS
    if kind == 'GENERIC':
        # X is unbounded. Other translations and every rotation are locked.
        joint.use_limit_lin_x = False
        for axis in ('y', 'z'):
            setattr(joint, 'use_limit_lin_' + axis, True)
            setattr(joint, 'limit_lin_' + axis + '_lower', 0.0)
            setattr(joint, 'limit_lin_' + axis + '_upper', 0.0)
        for axis in ('x', 'y', 'z'):
            setattr(joint, 'use_limit_ang_' + axis, True)
            setattr(joint, 'limit_ang_' + axis + '_lower', 0.0)
            setattr(joint, 'limit_ang_' + axis + '_upper', 0.0)
    else:
        joint.use_motor_lin = True
        # In Blender's object1=base/object2=carriage convention, negative
        # relative motor velocity drives the carriage along world +X.
        joint.motor_lin_target_velocity = -FEEDS_MM_S[lane] / 1000.0
        joint.motor_lin_max_impulse = 100000.0
        drive = joint.driver_add('motor_lin_target_velocity').driver
        variable = drive.variables.new()
        variable.name = 'speed_mm_s'
        variable.type = 'SINGLE_PROP'
        variable.targets[0].id = carriage
        variable.targets[0].data_path = '["speed_mm_s"]'
        drive.expression = '-speed_mm_s / 1000.0'
    return obj


def center_mesh_origin(obj):
    """Center BOX collision shapes without changing any visible world vertex."""
    center = sum((Vector(corner) for corner in obj.bound_box), Vector()) / 8
    for vertex in obj.data.vertices:
        vertex.co -= center
    obj.matrix_world = obj.matrix_world @ Matrix.Translation(center)


def configure(stop_face_mm, source):
    if bpy.app.version != (4, 5, 3):
        raise RuntimeError('Requires Blender 4.5.3 LTS; found ' + bpy.app.version_string)
    bpy.ops.wm.open_mainfile(filepath=str(source))
    scene = bpy.context.scene
    scene.frame_set(0)
    visible = [scene.objects[name] for name in PARTS]
    initial_world = {obj.name: obj.matrix_world.copy() for obj in visible}
    for obj in visible:
        obj.animation_data_clear()
        obj.parent = None
        obj.matrix_world = initial_world[obj.name]
    for obj in visible:
        center_mesh_origin(obj)
    for lane in FEEDS_MM_S:
        carriage = scene.objects[lane + '_carriage']
        shoe = scene.objects[lane + '_shoe']
        matrix = shoe.matrix_world.copy()
        shoe.parent = carriage
        shoe.matrix_parent_inverse = Matrix.Identity(4)
        shoe.matrix_world = matrix
        carriage['speed_mm_s'] = FEEDS_MM_S[lane]
        carriage['motion_authority'] = 'Native Bullet MOTOR constraint; no transform animation'
        carriage['mass_owner'] = 'This carriage owns its compound body, including the shoe'
        shoe['attachment'] = 'Direct compound collision child of ' + carriage.name
    for action in list(bpy.data.actions):
        if action.users == 0:
            bpy.data.actions.remove(action)

    scene.frame_start = 0
    scene.frame_end = FPS * DURATION_S
    scene.render.fps = FPS
    scene.render.fps_base = 1.0
    scene.gravity = (0.0, 0.0, 0.0)
    stop = scene.objects['left_stop']
    stop['near_face_mm'] = float(stop_face_mm)
    stop.id_properties_ui('near_face_mm').update(
        description='Only case setting: world-X near face of the 30 mm thick fixed stop',
        soft_min=200.0, soft_max=495.0, precision=3)
    driver = stop.driver_add('location', 0).driver
    variable = driver.variables.new()
    variable.name = 'near_face_mm'
    variable.type = 'SINGLE_PROP'
    variable.targets[0].id = stop
    variable.targets[0].data_path = '["near_face_mm"]'
    driver.expression = '(near_face_mm + 15.0) / 1000.0'
    stop.update_tag()
    scene.frame_set(0)

    for name in ('base', 'left_stop', 'right_stop'):
        add_body(scene.objects[name], 'PASSIVE', 'BOX')
    for lane in FEEDS_MM_S:
        carriage = scene.objects[lane + '_carriage']
        shoe = scene.objects[lane + '_shoe']
        add_body(carriage, 'ACTIVE', 'COMPOUND')
        add_body(shoe, 'ACTIVE', 'BOX')
        # COMPOUND uses direct rigid-body children. Its own visible mesh is
        # represented by this hidden collision-only child; the shoe is itself
        # the other child. No duplicate shoe trajectory or hidden stop exists.
        proxy = bpy.data.objects.new('_' + lane + '_carriage_collision', carriage.data.copy())
        scene.collection.objects.link(proxy)
        proxy.parent = carriage
        proxy.matrix_parent_inverse = Matrix.Identity(4)
        proxy.location = (0.0, 0.0, 0.0)
        proxy.hide_render = True
        proxy.display_type = 'WIRE'
        proxy['role'] = 'Collision-only copy of the visible carriage box'
        add_body(proxy, 'ACTIVE', 'BOX')
        add_constraint(scene, lane, 'GENERIC')
        add_constraint(scene, lane, 'MOTOR')

    world = scene.rigidbody_world
    world.time_scale = 1.0
    world.substeps_per_frame = SUBSTEPS
    world.solver_iterations = ITERATIONS
    world.use_split_impulse = True
    world.point_cache.frame_start = 0
    world.point_cache.frame_end = FPS * DURATION_S
    # Leave the native default memory cache unchanged. Explicitly assigning
    # use_disk_cache=False crashes this pinned build during fresh setup.
    scene['C190_solver'] = 'Blender native Bullet rigid-body world'
    scene['C190_timestep_s'] = 1 / (FPS * SUBSTEPS)
    scene['C190_sample_s'] = 1 / FPS
    scene['C190_no_timed_stop'] = True
    scene.frame_set(0)
    return scene


def gltf_point(p):
    return [1000.0 * p.x, 1000.0 * p.z, -1000.0 * p.y]


def world_bounds(obj, depsgraph):
    evaluated = obj.evaluated_get(depsgraph)
    points = [gltf_point(evaluated.matrix_world @ Vector(corner)) for corner in obj.bound_box]
    return [[min(point[a] for point in points) for a in range(3)],
            [max(point[a] for point in points) for a in range(3)]]


def capture(scene):
    """Read solver-evaluated transforms; velocities and gap flags are derived."""
    rows, transforms = [], []
    initial_x = {}
    previous_x = {}
    for frame in range(scene.frame_start, scene.frame_end + 1):
        scene.frame_set(frame)
        depsgraph = bpy.context.evaluated_depsgraph_get()
        bounds = {name: world_bounds(scene.objects[name], depsgraph) for name in PARTS}
        row = {'frame': frame, 'time_s': frame / FPS}
        matrices = {}
        for name in PARTS:
            obj = scene.objects[name]
            matrix = obj.evaluated_get(depsgraph).matrix_world.copy()
            matrices[name] = [list(v) for v in matrix]
        for lane in FEEDS_MM_S:
            x = matrices[lane + '_carriage'][0][3] * 1000
            if frame == scene.frame_start:
                initial_x[lane] = x
            shoe = bounds[lane + '_shoe']
            stop = bounds[lane + '_stop']
            row[lane + '_carriage_travel_mm'] = x - initial_x[lane]
            row[lane + '_shoe_front_x_mm'] = shoe[1][0]
            row[lane + '_stop_near_x_mm'] = stop[0][0]
            row[lane + '_gap_mm'] = stop[0][0] - shoe[1][0]
            row[lane + '_vx_fd_mm_s'] = None if frame == scene.frame_start else (x - previous_x[lane]) * FPS
            row[lane + '_geometric_contact_0p01mm'] = abs(row[lane + '_gap_mm']) <= 0.01
            previous_x[lane] = x
        rows.append(row)
        transforms.append({'frame': frame, 'time_s': frame / FPS,
                           'matrices_blender_m': matrices, 'bounds_gltf_mm': bounds})
    return rows, transforms


def summarize(rows, scene):
    summary = {
        'blender_version': bpy.app.version_string,
        'blender_build_hash': bpy.app.build_hash.decode(),
        'solver': 'Native Bullet through Blender RigidBodyWorld',
        'duration_s': DURATION_S, 'capture_fps': FPS,
        'native_substeps_per_frame': SUBSTEPS,
        'nominal_solver_timestep_s': 1 / (FPS * SUBSTEPS),
        'solver_iterations': ITERATIONS,
        'contact_record_type': 'Native evaluated poses; geometric gap/contact flags and finite-difference velocities derived from those poses. bpy does not expose Bullet manifolds/impulses.',
        'motion_driver': 'Constant native motor target velocity with unbounded X guide; no time/travel stop clamp',
        'left_stop_setting_mm': scene.objects['left_stop']['near_face_mm'],
        'lanes': {},
    }
    for lane in FEEDS_MM_S:
        contact = [r for r in rows if r[lane + '_geometric_contact_0p01mm']]
        first = contact[0]['time_s'] if contact else None
        before = [r[lane + '_vx_fd_mm_s'] for r in rows[1:]
                  if first is None or r['time_s'] <= first]
        after = [r[lane + '_vx_fd_mm_s'] for r in rows[1:]
                 if first is not None and r['time_s'] > first]
        summary['lanes'][lane] = {
            'mass_kg': scene.objects[lane + '_carriage'].rigid_body.mass,
            'final_travel_mm': rows[-1][lane + '_carriage_travel_mm'],
            'final_gap_mm': rows[-1][lane + '_gap_mm'],
            'minimum_gap_mm': min(r[lane + '_gap_mm'] for r in rows),
            'first_geometric_contact_sample_s': first,
            'precontact_vx_range_mm_s': [min(before), max(before)] if before else None,
            'postcontact_max_abs_vx_mm_s': max(map(abs, after)) if after else None,
        }
    return summary


def export_scene(scene, target):
    scene.frame_set(0)
    bpy.ops.object.select_all(action='DESELECT')
    for name in PARTS:
        scene.objects[name].select_set(True)
    bpy.context.view_layer.objects.active = scene.objects['left_carriage']
    result = bpy.ops.export_scene.gltf(
        filepath=str(target), export_format='GLB',
        use_selection=True, export_yup=True, export_animations=True,
        export_animation_mode='SCENE', export_anim_scene_split_object=False,
        export_frame_range=True, export_frame_step=1, export_force_sampling=True,
        export_bake_animation=True, export_optimize_animation_size=False,
        export_texcoords=False, export_normals=True, export_skins=False,
        export_morph=False, export_cameras=False, export_lights=False,
        export_extras=False,
    )
    if 'FINISHED' not in result:
        raise RuntimeError('GLB export failed: ' + repr(result))


def write_capture(output, rows, transforms, summary):
    with (output / 'native-trace.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (output / 'native-transforms.json').write_text(json.dumps(transforms, indent=2) + '\n')
    (output / 'native-summary.json').write_text(json.dumps(summary, indent=2) + '\n')


def build(settings, output):
    config = json.loads(settings.read_text())
    if set(config) != {'left_stop_near_face_mm'}:
        raise ValueError('The only case input must be left_stop_near_face_mm')
    source = Path(__file__).resolve().parent / 'source/c189-feed-125.blend'
    output.mkdir(parents=True, exist_ok=True)
    scene = configure(float(config['left_stop_near_face_mm']), source)
    bpy.context.preferences.filepaths.save_version = 0
    # Save the editable native rig before simulation, with no baked motion.
    bpy.ops.wm.save_as_mainfile(filepath=str(output / 'scene.blend'))
    rows, transforms = capture(scene)
    summary = summarize(rows, scene)
    write_capture(output, rows, transforms, summary)
    export_scene(scene, output / 'raw.glb')
    # Playback-only guide projection. Native physics and raw export are unchanged.
    mapping = runpy.run_path(str(Path(__file__).resolve().with_name('map_playback.py')))['map_playback']
    mapping(output / 'raw.glb', output / 'final.glb', output / 'post-export.json', output / 'native-transforms.json')
    print('C190_NATIVE_SUMMARY', json.dumps(summary))


if __name__ == '__main__':
    settings_arg, output_arg = sys.argv[sys.argv.index('--') + 1:]
    build(Path(settings_arg).resolve(), Path(output_arg).resolve())
