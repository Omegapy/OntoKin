# C190 Blender: native contact at the attached shoe

This is a new recovery replication, not a reconstruction of an unavailable previous C190 result. The delivered native scenes use Blender 4.5.3 LTS, build `67807e1800cc`, and Blender's native Bullet rigid-body solver. No engine or runtime code was changed.

Both cases stop the left carriage through collision at its attached shoe. The right lane continues at 150 mm/s through the full two seconds. The second case changes one input: the near face of the left stop from 380 to 355 mm. `settings.diff` shows that complete input difference.

## Results

| Measurement | Stop at 380 mm | Stop at 355 mm |
|---|---:|---:|
| First sampled geometric contact | 1.600000 s | 1.400000 s |
| Final left carriage travel | 200.000003 mm | 174.999997 mm |
| Final left shoe–stop gap | 0.000030 mm | 0.000000 mm |
| Maximum sampled penetration | 0.007004 mm | 0.007004 mm |
| Final right carriage travel | 300.000012 mm | 300.000012 mm |
| Final right shoe–stop gap | 14.999986 mm | 14.999986 mm |

The complete native matrices of the right carriage, right shoe, right stop and base are bit-identical between the two case runs. Reopening the delivered 380 mm native scene and changing its one stop property to 355 mm reproduces the delivered 355 mm raw GLB byte for byte.

At all 481 samples, the largest difference between GLB bounds and native evaluated bounds is 0.000030 mm. Initial visible bounds differ from the public specification by at most 0.000023 mm. Material color channel error is at most 0.000000027. The GLBs contain exactly the original seven named visible solids; each shoe is a child of its carriage and has no separate animation channel.

## Native causal chain

Each visible carriage is the mass owner of one active `COMPOUND` rigid body with a mass of 1 kg. Its two direct collision children are the visible shoe (`BOX`) and a hidden collision-only box that matches the visible carriage. The compound parent uses those child shapes as one rigid body. The shoe has no independent physical trajectory or mass authority. Its rigid relative placement follows the carriage.

Each lane has an independent native `MOTOR` constraint against the fixed base. The motor target is driven by that carriage's `speed_mm_s` property: 125 on the left and 150 on the right. The sign of Blender's relative motor convention makes the actual target property negative for positive world-X travel. The maximum motor impulse property is 100000, sufficient to reach the requested speed in the first sampled interval. This is a feed-controlled demonstration, not a calibrated actuator-force model.

A separate `GENERIC` constraint locks translation along Blender Y/Z and all three rotations. X translation is unbounded: there is no enabled X position limit. Gravity, friction, restitution, and linear/angular damping are zero. The base and both stops are passive fixed bodies. The carriage cannot reach the stop vertically: the stop starts at 130 mm height while the carriage ends at 120 mm. The shoe spans 120–170 mm, so its leading face is the colliding shape.

The native solver blocks that compound body's motion when its shoe reaches the left stop. The motor continues to request its fixed feed, so the stopping response is a contact constraint against a running motor. The right lane has its own motor and separate body and does not share the contact response. Neither carriage has a transform action or transform driver. No code branches on elapsed time or travel to stop a carriage. The only scene-position driver places the fixed left stop from `near_face_mm`.

The original mesh origins were centered for reliable native BOX collision shapes; all world vertices, IDs, colors, dimensions and initial visible poses were preserved. The left shoe remains 130 mm long. The additional two collision proxies are hidden from rendering, and the four constraint helpers are non-mesh objects. None is exported.

## Open, edit and replay

Open `stop-380/scene.blend` or `stop-355/scene.blend` with the pinned Blender version. The scene is saved at frame zero before simulation and contains the editable native solver rig, not baked carriage keyframes. Play sequentially from frame 0 to frame 480. The scene rate is 240 frames per second, representing exactly two seconds.

To change the case, select `left_stop`, open **Object Properties → Custom Properties**, and edit `near_face_mm`. Replay from the initial state. For a reproducible programmatic edit, use `replay.py`: it opens no starter file, rebuilds no geometry or constraints, changes only that native property, and simulates the saved scene. It calls `update_tag()` after assigning the custom property so Blender reevaluates the driver.

From this directory:

```sh
BLENDER=/path/to/blender-4.5.3-linux-x64/blender
mkdir -p rebuilt/tmp
export TMPDIR="$PWD/rebuilt/tmp"
"$BLENDER" -b -t 2 --python-exit-code 1 --python build.py -- settings/stop-380.json rebuilt/stop-380
"$BLENDER" -b -t 2 --python-exit-code 1 --python build.py -- settings/stop-355.json rebuilt/stop-355
"$BLENDER" -b -t 2 stop-380/scene.blend --python-exit-code 1 --python replay.py -- settings/stop-355.json rebuilt/replay-355
python3 measure.py rebuilt/stop-355/raw.glb rebuilt/stop-355/native-transforms.json
cmp stop-355/raw.glb rebuilt/replay-355/raw.glb
```

`commands.sh` includes the complete portable rebuild and native-reopen comparison workflow. `commands-actual.txt` records the actual native invocations, including failed intermediate attempts. `source/c189-feed-125.blend` is an unchanged copy of the supplied C189 source. `build.py` reads that source and uses the same implementation for either setting. `replay.py` instead operates on the delivered native scene itself. For an additional stop position, create a JSON file containing only `left_stop_near_face_mm` and pass it to either script.

## Evidence and numerical limits

The native world uses 10 substeps per 1/240-second scene frame and 100 solver iterations. With time scale 1, the nominal solver step is 1/2400 second, or 0.416667 ms. Capture and export are every 1/240 second, or 4.166667 ms. The files therefore contain 481 sampled states, including both endpoints. Substep contact times and impulses are not exposed by these Python records.

For each case:

- `scene.blend` is the native editable solver scene.
- `raw.glb` is the direct Blender glTF exporter output. `final.glb` is an unmodified byte copy; `post-export.json` records their identical hashes and an empty change list.
- `native-transforms.json` records evaluated native world matrices and derived world bounds of all seven parts at every sample.
- `native-trace.csv` records those poses as travel and face/gap values, with finite-difference X velocities. `contact-window.csv` is an unedited subset around contact.
- `native-summary.json` records native configuration and summary measurements. `glb-measurements.json` is obtained by reading the exported GLB, including its small rotation track.

These are solver-evaluated transform records, not a fabricated contact-event log. The contact flags are geometric: absolute shoe–stop gap no greater than 0.01 mm. Velocities are finite differences of native evaluated carriage positions. Blender's `bpy` interface does not expose Bullet contact manifolds or normal impulses, so no direct manifold or force claim is made.

The left feed before contact is 124.9981–125.0017 mm/s at sampled precision. The right feed is 149.9963–150.0034 mm/s. Finite solver convergence produces a brief correction after impact: maximum left X deviation from the ideal halt is 0.007588 mm, maximum backward correction is 0.007585 mm, maximum off-axis displacement is 0.001811 mm, and maximum rotation is 0.015817 degrees. Maximum post-contact finite-difference speed is 1.731 mm/s for one short correction interval; the body is stationary by 25 ms after first contact. Restitution is exactly zero, but the sampled numerical correction is not mathematically zero motion. All these spatial errors are far below the 0.5 mm halt tolerance. They are retained in the native GLB export, not flattened or corrected afterward.

The GLB represents the sampled result of a native collision solve. It does not contain a portable Bullet simulation or a contact solver; moving a stop in a GLB viewer cannot recompute motion. Changing the native `.blend` setting and replaying does recompute collision timing and stopping position.

## Attempts and provenance

Timed work began at 2026-11-10 00:14:34 UTC after the coordinator provided the pinned tool. Untimed setup was limited to reading this route's public brief and starter sources and planning the native design. No other route or evaluator implementation was inspected. No prior C190 source or evidence was available for reuse. This is formal submission 1; `attempts.json` lists all nine native simulation/build/replay invocations before submission.

The first internal probe exposed a reversed motor sign and a startup ramp with a low motor impulse. The second fixed those settings and demonstrated native contact. Two build attempts then triggered the same pinned-runtime segmentation fault by explicitly assigning `point_cache.use_disk_cache = False` while setting up a fresh world. The final code leaves that native default unchanged; no runtime patch was made. Both crash records are preserved in `logs/`. A legacy C189 measurement script also rejected the solver's small rotation channel because it assumed translation-only tracks; the delivered C190 `measure.py` handles translation, rotation and scale. Final builds and saved-scene replays succeeded, with byte-identical GLB comparisons.

`validation.json` records geometry, material, attachment, guide error and replay checks. `runtime.json` records the pinned version/build, coordinator-verified archive hash and source hash. The archive of intermediate attempt sources and original native logs preserves the observed failures. `SHA256SUMS` seals the submission files.
