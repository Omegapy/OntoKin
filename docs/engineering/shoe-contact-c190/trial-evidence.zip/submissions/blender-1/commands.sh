#!/usr/bin/env bash
# Portable rebuild and saved-scene verification. Run from this delivery directory.
# Set BLENDER to the pinned Blender 4.5.3 LTS executable, build 67807e1800cc.
set -euo pipefail
BLENDER="${BLENDER:-blender}"
mkdir -p rebuilt/tmp
export TMPDIR="$PWD/rebuilt/tmp"
"$BLENDER" -b -t 2 --python-exit-code 1 --python build.py -- settings/stop-380.json rebuilt/stop-380
"$BLENDER" -b -t 2 --python-exit-code 1 --python build.py -- settings/stop-355.json rebuilt/stop-355
python3 measure.py rebuilt/stop-380/raw.glb rebuilt/stop-380/native-transforms.json
python3 measure.py rebuilt/stop-355/raw.glb rebuilt/stop-355/native-transforms.json
cmp stop-380/raw.glb rebuilt/stop-380/raw.glb
cmp stop-355/raw.glb rebuilt/stop-355/raw.glb
"$BLENDER" -b -t 2 stop-380/scene.blend --python-exit-code 1 --python replay.py -- settings/stop-380.json rebuilt/replay-380
"$BLENDER" -b -t 2 stop-380/scene.blend --python-exit-code 1 --python replay.py -- settings/stop-355.json rebuilt/replay-355
cmp stop-380/raw.glb rebuilt/replay-380/raw.glb
cmp stop-355/raw.glb rebuilt/replay-355/raw.glb
