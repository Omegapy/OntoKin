"""Controlled source pose arithmetic for the explicitly adopted reach profile.

Private rotations are projective 96-bit dyadic quaternions. Composition never
feeds an exposed binary64 quaternion back into the chain. Homogeneous rotation
is a proper rotation even when the private quaternion is not exactly unit.
No host trigonometric function, float square root or preparation oracle is used.
The uniform derivation is in docs/engineering/reach-numeric-kernel.md.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
from fractions import Fraction as F
from hashlib import sha256
from pathlib import Path

from .reach_numeric import (
    MAX_OPERAND_BITS, PRECISIONS, DyadicContext, ReachAdmissionError, ReachExecutionWork,
    compare, exact, float_bits, rational, round_binary64, round_dyadic,
    sqrt_rational_binary64,
)

METHOD = "ontokin.source-pose-projective-dyadic/0.2"
BITS = 96
RHO = F(1,1 << 97)
VECTOR_ERROR = F(1,1 << 96)
PRODUCT_ERROR = F(1,1 << 91)
TRIG_ERROR = F(1,1 << 80)
AXIS_ERROR = F(1,1 << 74)
EXPOSED_ROTATION_ERROR = F(1,1 << 50)
ARGUMENT_ERROR = F(1,1 << 86)
_HORNER_TERMS = 13
MAX_RECORDING_ROTATION_STEPS = 10000
ZERO = (F(0),F(0),F(0))
UNIT = (F(1),F(0),F(0),F(0))
_GRID_SCALE = 1 << BITS
_FINITE_FIELDS = (("position",3),("orientation",4),("velocity",3),("omega",3))
_FINITE_PROOF_BUSY = object()


@dataclass(frozen=True)
class RotationValue:
    components: tuple[F,F,F,F]
    error_rad: F = F(0)
    # Only materialized event anchors preserve an already exposed quaternion.
    frozen_projection: tuple[float,float,float,float] | None = None


@dataclass(frozen=True)
class _PoseFinitenessProof:
    owner: object
    cap: int
    fields: tuple


@dataclass
class _PoseFinitenessFamily:
    """One completed record shared by already-retained translated poses."""
    owner: object
    proof: _PoseFinitenessProof | None = None


@dataclass(frozen=True)
class _IntegerAxisFactors:
    diagonal: int
    cross: int
    denominator: int
    squares: tuple[int,int]
    vector: tuple[F,F,F] | None = None
    result: tuple[F,F,F] | None = None
    projection: tuple[float,float,float,float] | None = None


class _FractionPlanarFallback(Exception):
    """A changed live cap requires the original Fraction path."""


@dataclass(frozen=True)
class SpinPlan:
    scaled_omega: tuple[F,F,F]
    maximum: F
    norm_bounds: tuple[F,F]
    pi_bounds: tuple[F,F]
    max_elapsed_s: F
    precision_bits: int
    argument_error_rad: F


@dataclass(frozen=True)
class SourceNumericBasis:
    name: str
    version: str
    implementation: str
    method: str
    derivation: str
    inputs: tuple[tuple[str,str],...]

    def as_dict(self):
        return {"name":self.name,"version":self.version,
                "implementation":self.implementation,"method":self.method,
                "derivation":self.derivation}


@dataclass(frozen=True)
class PoseValue:
    exact_position: tuple[F,F,F]
    rotation: RotationValue
    exact_velocity: tuple[F,F,F]
    exact_omega: tuple[F,F,F]
    position_error_m: F
    _ops: ReachPoseOps = field(repr=False,compare=False)
    _projection: dict = field(default_factory=dict,repr=False,compare=False)
    _projection_domains: dict = field(default_factory=dict,repr=False,compare=False)
    # A completed proof belongs to this retained source pose. It contains only
    # immutable operand fingerprints, never computed public projection tuples.
    # replace() starts cold; a translated source occurrence may explicitly
    # carry the proof and must then match each unchanged field before reuse.
    _finite_proof: object = field(default=None,init=False,repr=False,compare=False)
    _finite_family: object = field(default=None,init=False,repr=False,compare=False)

    def __deepcopy__(self,memo):
        # Arithmetic state is immutable; the memoized projections do not alter
        # its value. In particular never copy a request callback/compiler.
        memo[id(self)]=self
        return self

    @property
    def position(self): return self._ops._expose(self,"position")

    @property
    def orientation(self): return self._ops._expose(self,"orientation")

    @property
    def velocity(self): return self._ops._expose(self,"velocity")

    @property
    def omega(self): return self._ops._expose(self,"omega")

    @property
    def angular_error_rad(self): return self.rotation.error_rad


@dataclass(frozen=True)
class RecordedTransform:
    """Actual p/q only; deliberately not a pose or a point-error certificate.

    The recording planner has separately validated the complete source phase.
    This value cannot supply derivative or position-error fields to full source
    composition, release anchors, or point-bound construction.
    """
    exact_position: tuple[F,F,F]
    rotation: RotationValue
    _ops: ReachPoseOps = field(repr=False,compare=False)
    _projection: dict = field(default_factory=dict,repr=False,compare=False)
    _projection_domains: dict = field(default_factory=dict,repr=False,compare=False)

    @property
    def position(self): return self._ops._expose(self,"position")

    @property
    def orientation(self): return self._ops._expose(self,"orientation")


class ReachPoseOps:
    """One request's deterministic pose helpers and auditable error bounds."""
    def __init__(self,work: ReachExecutionWork):
        self.work=work

    def _op(self,a,b,kind): return exact(a,b,kind,self.work)

    def _sum(self,values):
        result=F(0)
        for value in values: result=self._op(result,value,"add")
        return result

    def _vector(self,values,length=3):
        self.work.charge("pose_vector_domain")
        if not isinstance(values,(list,tuple)) or len(values)!=length:
            raise ReachAdmissionError("reach_numeric","A pose vector has the wrong dimension.")
        # Private Fraction tuples are already exact. Checking their bounded
        # representation does not require decoding each component again.
        if isinstance(values,tuple) and all(type(value) is F for value in values):
            self.work.guard(*values)
            return values
        return tuple(rational(value,self.work) for value in values)

    def _recording_vector(self,values,length=3):
        """Decode repeated fixed source vectors once in the shared work cache.

        Every call still admits the complete current vector and finite scalar
        types. Only the exact binary64-to-rational decoding is reused, and its
        proof is scoped to the unchanged live operand limit.
        """
        while True:
            cap=self.work.max_operand_bits
            self.work.charge("pose_vector_domain")
            if not isinstance(values,(list,tuple)) or len(values)!=length:
                raise ReachAdmissionError("reach_numeric","A pose vector has the wrong dimension.")
            if isinstance(values,tuple) and all(type(value) is F for value in values):
                self.work.guard(*values)
                if self.work.max_operand_bits==cap:
                    return values
                continue
            if any(type(value) not in (int,float,F) for value in values):
                return tuple(rational(value,self.work) for value in values)
            original=tuple(values)
            for value in original:
                if type(value) is float:
                    if float_bits(value) & 0x7FF0000000000000 == 0x7FF0000000000000:
                        raise ReachAdmissionError("reach_domain","A reach operand must be finite.")
                else:
                    self.work.guard(value)
            if self.work.max_operand_bits!=cap:
                continue
            key=(METHOD,"recording_vector",cap,tuple((type(value),value) for value in original))
            result=self.work.lookup(key)
            if self.work.max_operand_bits!=cap:
                continue
            if result is None:
                result=tuple(rational(value,self.work) for value in original)
                if self.work.max_operand_bits!=cap:
                    continue
                self.work.remember(key,result)
            self.work.guard(*result)
            if self.work.max_operand_bits==cap:
                return result

    def _rounded_vector(self,values):
        self.work.charge("pose_grid_check")
        values=tuple(values)
        self.work.guard(*values)
        on_grid=tuple(value.denominator.bit_length()<=BITS+1 and
                      value.denominator & (value.denominator-1)==0 for value in values)
        if all(on_grid):
            return values
        return tuple(value if ready else round_dyadic(value,BITS,work=self.work)
                     for value,ready in zip(values,on_grid))

    def _l1(self,values):
        self.work.charge("pose_norm_bound",len(values))
        return self._sum(abs(value) for value in values)

    def add(self,a,b):
        a,b=self._vector(a),self._vector(b)
        return self._add_exact_vectors(a,b)

    def _add_exact_vectors(self,a,b):
        """Add already validated private three-vectors without decoding again."""
        self.work.charge("pose_add_zero_check")
        if not any(a): return b
        if not any(b): return a
        return tuple(y if not x else x if not y else self._op(x,y,"add")
                     for x,y in zip(a,b))

    def scale(self,vector,factor):
        vector,factor=self._vector(vector),rational(factor,self.work)
        self.work.charge("pose_scale_identity_check")
        if not factor or not any(vector): return ZERO
        if factor==1: return vector
        return tuple(self._op(value,factor,"mul") for value in vector)

    def cross(self,a,b):
        a,b=self._vector(a),self._vector(b)
        self.work.charge("pose_cross_zero_check")
        if not any(a) or not any(b): return ZERO
        return tuple(self._op(self._op(a[j],b[k],"mul"),self._op(a[k],b[j],"mul"),"sub")
                     for j,k in ((1,2),(2,0),(0,1)))

    def affine(self,initial,rate,elapsed):
        return self.add(initial,self.scale(rate,rational(elapsed,self.work)))

    def recording_affine(self,initial,rate,elapsed):
        initial,rate=self._recording_vector(initial),self._recording_vector(rate)
        return self.affine(initial,rate,elapsed)

    def parabolic(self,initial,velocity,acceleration,elapsed):
        elapsed=rational(elapsed,self.work)
        half_square=self._op(self._op(elapsed,elapsed,"mul"),F(2),"div")
        return self.add(self.affine(initial,velocity,elapsed),self.scale(acceleration,half_square))

    def _rotation(self,value):
        if isinstance(value,RotationValue):
            self.work.charge("pose_rotation_reference")
            self.work.guard(*value.components,value.error_rad)
            return value
        values=self._vector(value,4)
        key=(METHOD,"constant_rotation",values,self.work.max_operand_bits)
        cached=self.work.lookup(key)
        if cached is not None: return cached
        result=self._rescale(values,F(0))
        self.work.remember(key,result)
        return result

    def _rescale(self,values,error):
        self.work.charge("quaternion_rescale",5)
        self.work.guard(*values,error)
        maximum=max(abs(value) for value in values)
        if not maximum:
            raise ReachAdmissionError("reach_numeric","A zero quaternion cannot represent a rotation.")
        # Exact power-of-two scaling leaves the represented rotation unchanged.
        exponent=maximum.numerator.bit_length()-maximum.denominator.bit_length()
        self.work.guard_bits(max(maximum.numerator.bit_length()+max(-exponent,0),
                                 maximum.denominator.bit_length()+max(exponent,0))+2)
        below=(maximum.numerator < maximum.denominator << exponent) if exponent>=0 else (
            maximum.numerator << -exponent < maximum.denominator)
        if below: exponent-=1
        shift=-exponent-1
        self.work.guard_bits(abs(shift)+2)
        if shift==0:
            result=self._rounded_vector(values)
        else:
            factor=F(1 << shift) if shift>=0 else F(1,1 << -shift)
            result=self._rounded_vector(self._op(value,factor,"mul") for value in values)
        self.work.charge("quaternion_sign",4)
        if next(value for value in result if value)<0: result=tuple(-value for value in result)
        return RotationValue(result,self._op(error,PRODUCT_ERROR,"add"))

    def multiply(self,a,b):
        original_a,original_b=a,b
        while True:
            cap=self.work.max_operand_bits
            a,b=self._rotation(original_a),self._rotation(original_b)
            if self.work.max_operand_bits!=cap:
                continue
            # Error allowances do not enter the Hamilton product or its grid
            # projection. Keep one immutable component result and one
            # replaceable allowance/result for these exact guarded operands.
            key=(METHOD,"rotation_product",a.components,b.components,cap)
            cached=self.work.lookup(key)
            if self.work.max_operand_bits!=cap:
                continue
            if cached is not None:
                self.work.charge("rotation_product_error_identity")
                if self.work.max_operand_bits!=cap:
                    continue
                if cached[:2]==(a.error_rad,b.error_rad): return cached[2]
                error=self._op(self._op(a.error_rad,b.error_rad,"add"),PRODUCT_ERROR,"add")
                result=RotationValue(cached[2].components,error)
            else:
                result=self._multiply_uncached(a,b)
            if self.work.max_operand_bits!=cap:
                continue
            self.work.remember(key,(a.error_rad,b.error_rad,result))
            if self.work.max_operand_bits==cap:
                return result

    def _power_two_scalar(self,value):
        self.work.charge("quaternion_scalar_scale_check")
        if type(value) is not F or not value:
            return False
        numerator,denominator=abs(value.numerator),value.denominator
        return not (numerator & (numerator-1) or denominator & (denominator-1))

    def _scaled_identity_product(self,components,error):
        # Multiplication by a signed power of two is exactly undone by the
        # ordinary scale/sign canonicalization. Reuse an already canonical
        # grid tuple, or apply that same rescale to the unmultiplied operand.
        self.work.charge("quaternion_identity_canonical_check")
        if (isinstance(components,tuple) and all(type(value) is F for value in components) and
                F(1,2)<=max(map(abs,components))<1 and next(value for value in components if value)>0):
            self.work.charge("quaternion_identity_grid_check",4)
            if all(value.denominator.bit_length()<=BITS+1 and
                   value.denominator & (value.denominator-1)==0 for value in components):
                return RotationValue(components,self._op(error,PRODUCT_ERROR,"add"))
        return self._rescale(components,error)

    def _multiply_uncached(self,a,b):
        aw,ax,ay,az=a.components; bw,bx,by,bz=b.components
        mul=lambda x,y:self._op(x,y,"mul")
        self.work.charge("quaternion_sparse_check")
        error=self._op(a.error_rad,b.error_rad,"add")
        # A signed power-of-two scalar disappears under the same exact
        # rescale/sign operation. Other scalar scales retain the full product.
        if not any((bx,by,bz)):
            if all(type(value) is F for value in a.components) and self._power_two_scalar(bw):
                return self._scaled_identity_product(a.components,error)
            return self._rescale(tuple(mul(value,bw) for value in a.components),error)
        if not any((ax,ay,az)):
            if all(type(value) is F for value in b.components) and self._power_two_scalar(aw):
                return self._scaled_identity_product(b.components,error)
            return self._rescale(tuple(mul(aw,value) for value in b.components),error)
        if not any((ax,ay,bx,by)):
            integer=self._integer_planar_product(a,b,error)
            if integer is not None:
                return integer
            return self._rescale((self._op(mul(aw,bw),mul(az,bz),"sub"),F(0),F(0),
                                  self._op(mul(aw,bz),mul(az,bw),"add")),error)
        # A shared X or Y axis has the same two-component Hamilton algebra
        # as Z. Only the existing small exact grid domain can omit the generic
        # zero products; wider/non-grid inputs and narrowed caps keep them.
        # Freeze the already read generic operands: a callback cannot replace
        # a private RotationValue between branch selection and integer work.
        components=(aw,ax,ay,az,bw,bx,by,bz)
        if (self.work.max_operand_bits==MAX_OPERAND_BITS and
                all(type(value) is F for value in components)):
            axis=(0 if not any((ay,az,by,bz)) else
                  1 if not any((ax,az,bx,bz)) else None)
            if axis is not None:
                integer=self._integer_planar_product(
                    RotationValue(components[:4]),RotationValue(components[4:]),error,axis=axis)
                if integer is not None:
                    return integer
        self.work.charge("quaternion_signed_terms",6)
        values=(self._sum((mul(aw,bw),-mul(ax,bx),-mul(ay,by),-mul(az,bz))),
                self._sum((mul(aw,bx),mul(ax,bw),mul(ay,bz),-mul(az,by))),
                self._sum((mul(aw,by),-mul(ax,bz),mul(ay,bw),mul(az,bx))),
                self._sum((mul(aw,bz),mul(ax,by),-mul(ay,bx),mul(az,bw))))
        return self._rescale(values,error)

    def _planar_step(self,kind):
        self.work.charge(kind)
        if self.work.max_operand_bits!=MAX_OPERAND_BITS:
            raise _FractionPlanarFallback

    def _planar_grid_domain(self,values,*,unit=False):
        # The selecting helper precharges one bounded domain check. These
        # values were also decoded and guarded by multiply/rotate already.
        if any(type(value) is not F for value in values):
            return False
        self.work.guard(*values)
        for value in values:
            denominator=value.denominator
            if denominator.bit_length()>BITS+1 or denominator & (denominator-1):
                return False
            if unit:
                if abs(value.numerator)>denominator:
                    return False
            elif value.numerator.bit_length()+BITS-(denominator.bit_length()-1)>256:
                return False
        return True

    def _planar_integer(self,value,exponent=BITS):
        shift=exponent-(value.denominator.bit_length()-1)
        if not value or not shift:
            return value.numerator
        return self._planar_operation(value.numerator,shift,"shift")

    def _planar_operation(self,left,right,operation):
        self._planar_step("planar_integer_"+operation)
        self.work.guard(left,right)
        a,b=left.bit_length(),right.bit_length()
        width=(a+b if operation=="mul" else
               a+right if operation=="shift" else max(a,b)+1)
        self.work.guard_bits(width)
        if operation=="mul": return left*right
        if operation=="shift": return left << right
        if operation=="sub": return left-right
        return left+right

    def _planar_quotient(self,numerator,denominator,*,as_fraction=False):
        self._planar_step("planar_integer_round")
        self.work.guard(numerator,denominator)
        self.work.guard_bits(max(numerator.bit_length(),denominator.bit_length())+1)
        quotient,remainder=divmod(numerator,denominator)
        rounded=quotient+int(2*remainder>denominator or
                             (2*remainder==denominator and quotient%2))
        if as_fraction:
            self.work.guard(rounded,_GRID_SCALE)
            return F(rounded,_GRID_SCALE)
        return rounded

    def _integer_planar_product(self,a,b,error,*,axis=2):
        """An exact scalar/Cartesian Hamilton product and original scale/grid."""
        if self.work.max_operand_bits!=MAX_OPERAND_BITS:
            return None
        try:
            self._planar_step("planar_integer_domain")
            if type(axis) is not int or not 0<=axis<3:
                return None
            first,last=(a.components[0],a.components[axis+1]),(b.components[0],b.components[axis+1])
            if not self._planar_grid_domain(first+last,unit=True):
                return None
            # Each operand may use its own common dyadic denominator. The
            # final projective normalization cancels both denominators.
            ea=max(value.denominator.bit_length()-1 for value in first)
            eb=max(value.denominator.bit_length()-1 for value in last)
            aw,az=(self._planar_integer(value,ea) for value in first)
            bw,bz=(self._planar_integer(value,eb) for value in last)
            op=self._planar_operation
            real=op(op(aw,bw,"mul"),op(az,bz,"mul"),"sub")
            imag=op(op(aw,bz,"mul"),op(az,bw,"mul"),"add")
            self._planar_step("planar_integer_scale")
            maximum=max(abs(real),abs(imag))
            if not maximum:
                return None
            shift=maximum.bit_length()-BITS
            if shift>0:
                denominator=op(1,shift,"shift")
                real,imag=(self._planar_quotient(value,denominator) for value in (real,imag))
            elif shift<0:
                real,imag=(op(value,-shift,"shift") for value in (real,imag))
            self._planar_step("planar_integer_sign")
            if real<0 or (not real and imag<0):
                real,imag=op(0,real,"sub"),op(0,imag,"sub")
            self.work.guard(real,imag,_GRID_SCALE)
            values=[F(real,_GRID_SCALE),ZERO[0],ZERO[0],ZERO[0]]
            values[axis+1]=F(imag,_GRID_SCALE)
            allowance=self._op(error,PRODUCT_ERROR,"add")
            if self.work.max_operand_bits!=MAX_OPERAND_BITS:
                return None
            return RotationValue(tuple(values),allowance)
        except _FractionPlanarFallback as error:
            if self.work.callback_error is error:
                raise
            return None

    def _integer_axis_rotate(self,q,vector,axis,factors):
        """Return the original rounded vector and one tagged factor record."""
        if (self.work.max_operand_bits!=MAX_OPERAND_BITS or
                (factors is not None and type(factors) is not _IntegerAxisFactors)):
            return None
        try:
            self._planar_step("planar_integer_domain")
            if (not self._planar_grid_domain((q[0],q[axis+1]),unit=True) or
                    not self._planar_grid_domain(vector)):
                return None
            op=self._planar_operation
            if factors is None:
                pair=(q[0],q[axis+1])
                exponent=max(value.denominator.bit_length()-1 for value in pair)
                w,z=(self._planar_integer(value,exponent) for value in pair)
                w2,z2=op(w,w,"mul"),op(z,z,"mul")
                denominator=op(w2,z2,"add")
                diagonal=op(w2,z2,"sub")
                cross=op(op(w,z,"mul"),1,"shift")
                factors=_IntegerAxisFactors(diagonal,cross,denominator,(w2,z2))
            self.work.guard(factors.diagonal,factors.cross,factors.denominator)
            first,second=(axis+1)%3,(axis+2)%3
            u,v=(self._planar_integer(vector[index]) for index in (first,second))
            c,s,d=factors.diagonal,factors.cross,factors.denominator
            if not v:
                out_u,out_v=op(c,u,"mul"),op(s,u,"mul")
            elif not u:
                out_u,out_v=op(0,op(s,v,"mul"),"sub"),op(c,v,"mul")
            else:
                out_u=op(op(c,u,"mul"),op(s,v,"mul"),"sub")
                out_v=op(op(s,u,"mul"),op(c,v,"mul"),"add")
            values=list(vector)
            values[first],values[second]=(self._planar_quotient(value,d,as_fraction=True)
                                         for value in (out_u,out_v))
            return tuple(values),factors
        except _FractionPlanarFallback as error:
            if self.work.callback_error is error:
                raise
            return None

    def inverse_rotation(self,value):
        value=self._rotation(value)
        self.work.charge("quaternion_conjugate",3)
        q=value.components
        return RotationValue((q[0],-q[1],-q[2],-q[3]),value.error_rad)

    def rotate(self,rotation,vector):
        original_rotation,original_vector=rotation,vector
        while True:
            cap=self.work.max_operand_bits
            rotation,vector=self._rotation(original_rotation),self._vector(original_vector)
            if self.work.max_operand_bits!=cap:
                continue
            result=self._rotate_guarded(rotation,vector)
            if self.work.max_operand_bits==cap:
                return result

    def _rotate_guarded(self,rotation,vector):
        q=rotation.components
        self.work.charge("rotation_sparse_check")
        if not any(vector): return ZERO
        if not any(q[1:]): return self._rounded_vector(vector)
        active=tuple(index for index,value in enumerate(q[1:]) if value)
        axis=(active[0] if len(active)==1 and all(type(value) is F for value in q) else None)
        if axis is not None:
            first,second=(axis+1)%3,(axis+2)%3
            # A vector on the sole quaternion axis is fixed exactly. It still
            # receives the same final grid projection as the full matrix path.
            if not vector[first] and not vector[second]:
                return self._rounded_vector(vector)
        result_key=(METHOD,"rotated_vector",q,vector,self.work.max_operand_bits)
        if axis is not None:
            cap=self.work.max_operand_bits
            key=(METHOD,"axis_rotation_factors",q,cap)
            factors=self.work.lookup(key)
            # A fixed-size factor record owns its last exact vector result and
            # projection as well. These quantities use the same q and domain;
            # separate one-use entries would only evict reusable phase laws.
            if (cap==MAX_OPERAND_BITS and self.work.max_operand_bits==cap and
                    type(factors) is _IntegerAxisFactors and factors.vector==vector):
                self.work.guard(*factors.result)
                return factors.result
            integer=self._integer_axis_rotate(q,vector,axis,factors)
            if integer is not None:
                result,integer_factors=integer
                if self.work.max_operand_bits==cap:
                    self.work.remember(key,replace(integer_factors,vector=vector,result=result))
                    if self.work.max_operand_bits==cap:
                        return result
            # A non-grid vector keeps the original rational factors. Replace
            # the same single entry; never retain two representations per q.
            if type(factors) is _IntegerAxisFactors or self.work.max_operand_bits!=cap:
                factors=None
            key=(METHOD,"axis_rotation_factors",q,self.work.max_operand_bits)
            result_key=(METHOD,"rotated_vector",q,vector,self.work.max_operand_bits)
            cached=self.work.lookup(result_key)
            if cached is not None: return cached
            if factors is None:
                w,z=q[0],q[axis+1]
                w2,z2=self._op(w,w,"mul"),self._op(z,z,"mul")
                denominator=self._op(w2,z2,"add")
                diagonal=self._op(self._op(w2,z2,"sub"),denominator,"div")
                cross=self._op(self._op(self._op(F(2),w,"mul"),z,"mul"),denominator,"div")
                factors=(diagonal,cross)
                self.work.remember(key,factors)
            diagonal,cross=factors
            u,v=vector[first],vector[second]
            if not v:
                out_u,out_v=self._op(diagonal,u,"mul"),self._op(cross,u,"mul")
            elif not u:
                self.work.charge("rotation_axis_sign")
                out_u,out_v=-self._op(cross,v,"mul"),self._op(diagonal,v,"mul")
            else:
                out_u=self._op(self._op(diagonal,u,"mul"),self._op(cross,v,"mul"),"sub")
                out_v=self._op(self._op(cross,u,"mul"),self._op(diagonal,v,"mul"),"add")
            values=list(vector)
            values[first],values[second]=out_u,out_v
            result=self._rounded_vector(values)
            self.work.remember(result_key,result)
            return result
        cached=self.work.lookup(result_key)
        if cached is not None: return cached
        key=(METHOD,"rotation_rows",q,self.work.max_operand_bits)
        rows=self.work.lookup(key)
        if rows is None:
            w,x,y,z=q; mul=lambda a,b:self._op(a,b,"mul")
            squares=tuple(mul(v,v) for v in q); denominator=self._sum(squares)
            two=F(2)
            diagonal=lambda i,j:self._op(denominator,mul(two,self._op(squares[i],squares[j],"add")),"sub")
            pair=lambda a,b,c,d,sign:mul(two,self._op(mul(a,b),mul(c,d),sign))
            numerators=((diagonal(2,3),pair(x,y,w,z,"sub"),pair(x,z,w,y,"add")),
                        (pair(x,y,w,z,"add"),diagonal(1,3),pair(y,z,w,x,"sub")),
                        (pair(x,z,w,y,"sub"),pair(y,z,w,x,"add"),diagonal(1,2)))
            rows=tuple(tuple(self._op(v,denominator,"div") for v in row) for row in numerators)
            self.work.remember(key,rows)
        self.work.charge("rotation_vector_support")
        support=tuple((index,value) for index,value in enumerate(vector) if value)
        result=self._rounded_vector(self._sum(self._op(row[index],value,"mul")
                                              for index,value in support if row[index]) for row in rows)
        self.work.remember(result_key,result)
        return result

    def _pi(self,precision):
        key=(METHOD,"pi",precision)
        cached=self.work.lookup(key)
        if cached is not None: return cached
        # Exact alternating sums have tighter enclosures than iterating rounded
        # interval powers. N is fixed by precision, and every recurrence is charged.
        count=(precision+15)//4
        def atan_inverse(denominator):
            z=F(1,denominator); square=self._op(z,z,"mul"); power=z; total=F(0)
            for k in range(count):
                self.work.charge("source_series_recurrence")
                term=self._op(power,F(2*k+1),"div")
                total=self._op(total,term,"add" if k%2==0 else "sub")
                power=self._op(power,square,"mul")
            tail=self._op(power,F(2*count+1),"div")
            other=self._op(total,tail,"add" if count%2==0 else "sub")
            return (total,other) if compare(total,other,self.work)<=0 else (other,total)
        a,b=atan_inverse(5),atan_inverse(239)
        lower=self._op(self._op(F(16),a[0],"mul"),self._op(F(4),b[1],"mul"),"sub")
        upper=self._op(self._op(F(16),a[1],"mul"),self._op(F(4),b[0],"mul"),"sub")
        context=DyadicContext(precision,self.work)
        low=context.point(lower).lo; high=context.point(upper).hi
        result=F(low,1 << precision),F(high,1 << precision)
        self.work.remember(key,result)
        return result

    def _coefficients(self):
        key=(METHOD,"horner_coefficients",_HORNER_TERMS)
        cached=self.work.lookup(key)
        if cached is not None: return cached
        factorials=[1]
        for k in range(1,2*_HORNER_TERMS):
            self.work.charge("source_factorial")
            self.work.guard_bits(factorials[-1].bit_length()+k.bit_length())
            factorials.append(factorials[-1]*k)
        self.work.charge("source_coefficients",2*_HORNER_TERMS)
        result=(tuple(F((-1)**k,factorials[2*k+1]) for k in range(_HORNER_TERMS)),
                tuple(F((-1)**k,factorials[2*k]) for k in range(_HORNER_TERMS)))
        self.work.remember(key,result)
        return result

    def _horner_sincos(self,value):
        self.work.charge("source_series_grid_guard")
        if type(value) is not F:
            raise ReachAdmissionError("reach_numeric","Source series requires an exact dyadic grid argument.")
        self.work.guard(value)
        denominator=value.denominator
        if (abs(value.numerator)>denominator or denominator.bit_length()>BITS+1 or
                denominator & (denominator-1)):
            raise ReachAdmissionError("reach_numeric","Source series argument is outside its proved grid and range.")
        sine_coefficients,cosine_coefficients=self._coefficients()
        packed=self._packed_horner_sincos(value,sine_coefficients,cosine_coefficients)
        if packed is not None:
            return packed
        return self._fraction_horner_sincos(value,sine_coefficients,cosine_coefficients)

    def _fraction_horner_sincos(self,value,sine_coefficients,cosine_coefficients):
        # Exact 13-term recurrences stay below 2,600 prospective operand bits
        # on this grid. Only the two final projections incur rounding error.
        square=self._op(value,value,"mul")
        sine,cosine=sine_coefficients[-1],cosine_coefficients[-1]
        for k in range(_HORNER_TERMS-2,-1,-1):
            self.work.charge("source_series_recurrence")
            sine=self._op(self._op(sine,square,"mul"),sine_coefficients[k],"add")
            cosine=self._op(self._op(cosine,square,"mul"),cosine_coefficients[k],"add")
        sine=round_dyadic(self._op(value,sine,"mul"),BITS,work=self.work)
        return sine,round_dyadic(cosine,BITS,work=self.work)

    def _packed_horner_sincos(self,value,sine_coefficients,cosine_coefficients):
        """Evaluate the same two rational polynomials in exact integer lanes.

        For x=n/d, both factorial-scaled Horner numerators are nonnegative
        on |x|<=1. A sufficiently wide base therefore separates them exactly,
        including intermediate subtractions. This replaces two rational
        multiply/add pairs with one integer multiply/subtract pair per step;
        neither polynomial nor the final dyadic rounding is approximated.
        """
        self.work.charge("source_horner_packing_domain")
        original_exponent=value.denominator.bit_length()-1
        degree=_HORNER_TERMS-1
        common=sine_coefficients[-1].denominator
        # A single exact grid layout serves every admitted argument under the
        # ordinary cap. Rebuilding tables for reduced binary64 denominators
        # wastes the recurrence savings. Smaller caps retain their own layout.
        full_digit_bits=common.bit_length()+2*BITS*degree+1
        full_width=max(2*full_digit_bits+2*BITS+4,
                       2*common.bit_length()+2*BITS*degree+BITS+BITS+16)
        exponent=BITS if full_width<=self.work.max_operand_bits else original_exponent
        scale_bits=2*exponent*degree
        digit_bits=common.bit_length()+scale_bits+1
        packed_width=2*digit_bits+2*exponent+4
        # Also dominate the old Fraction operations' unreduced cross-products,
        # final sine multiplication, and 96-bit rounding shifts. A lowered
        # request limit retains the original arithmetic and rejection domain.
        fraction_width=2*common.bit_length()+scale_bits+exponent+BITS+16
        width=max(packed_width,fraction_width)
        if width>self.work.max_operand_bits:
            return None
        self.work.guard_bits(width)
        key=(METHOD,"packed_horner",_HORNER_TERMS,exponent,digit_bits,
             self.work.max_operand_bits)
        table=self.work.lookup(key)
        if table is None:
            self.work.charge("source_horner_scale_shift",2)
            denominator=common << scale_bits
            base=1 << digit_bits
            coefficients=[]
            for k,(sine,cosine) in enumerate(zip(sine_coefficients,cosine_coefficients)):
                self.work.charge("source_horner_integer_coefficient",2)
                a,b=common//sine.denominator,common//cosine.denominator
                self.work.charge("source_horner_coefficient_pack",3)
                coefficients.append(((a << digit_bits)+b) << (2*exponent*(degree-k)))
            table=(denominator,base,tuple(coefficients))
            self.work.remember(key,table)
        denominator,base,coefficients=table
        self.work.guard(value,denominator,base,*coefficients)
        numerator=value.numerator
        if exponent!=original_exponent:
            self.work.guard_bits(numerator.bit_length()+exponent-original_exponent)
            self.work.charge("source_horner_grid_shift")
            numerator <<= exponent-original_exponent
        self.work.charge("source_horner_argument_square")
        numerator_square=numerator*numerator
        total=coefficients[-1]
        for coefficient in reversed(coefficients[:-1]):
            self.work.charge("source_series_recurrence")
            self.work.guard_bits(max(total.bit_length()+numerator_square.bit_length(),
                                     coefficient.bit_length())+1)
            self.work.charge("source_horner_integer_product")
            product=total*numerator_square
            self.work.charge("source_horner_integer_subtract")
            total=coefficient-product
        self.work.charge("source_horner_unpack")
        sine_numerator,cosine_numerator=divmod(total,base)
        self.work.charge("source_horner_fraction",2)
        sine,cosine=F(sine_numerator,denominator),F(cosine_numerator,denominator)
        sine=round_dyadic(self._op(value,sine,"mul"),BITS,work=self.work)
        return sine,round_dyadic(cosine,BITS,work=self.work)

    def _reduced_sincos(self,lower,upper,pi):
        pi_mid=self._op(self._op(pi[0],pi[1],"add"),F(2),"div")
        ratio=self._op(self._op(lower,upper,"add"),pi_mid,"div")
        k=round_dyadic(ratio,0,work=self.work).numerator
        self.work.charge("quadrant_preflight",3)
        self.work.guard(k)
        kl,kh=(self._op(F(k),v,"mul") for v in pi)
        if k<0: kl,kh=kh,kl
        lo=self._op(lower,self._op(kh,F(2),"div"),"sub")
        hi=self._op(upper,self._op(kl,F(2),"div"),"sub")
        middle=round_dyadic(self._op(self._op(lo,hi,"add"),F(2),"div"),BITS,work=self.work)
        error=max(self._op(middle,lo,"sub"),self._op(hi,middle,"sub"))
        if compare(error,ARGUMENT_ERROR,self.work)>0 or compare(abs(middle),F(1),self.work)>0:
            return None
        sine,cosine=self._horner_sincos(middle)
        self.work.charge("quadrant_restore",2)
        return ((sine,cosine),(cosine,-sine),(-sine,-cosine),(-cosine,sine))[k%4]

    def sincos(self,angle):
        angle=rational(angle,self.work)
        key=(METHOD,"sincos",angle)
        cached=self.work.lookup(key)
        if cached is not None: return cached
        if not angle: return F(0),F(1)
        if compare(abs(angle),F(1),self.work)<=0:
            middle=round_dyadic(angle,BITS,work=self.work)
            result=self._horner_sincos(middle)
        else:
            result=None
            for precision in PRECISIONS:
                result=self._reduced_sincos(angle,angle,self._pi(precision))
                if result is not None: break
            if result is None:
                raise ReachAdmissionError("reach_numeric","Finite source angle reduction could not be certified.")
        self.work.remember(key,result)
        return result

    def _scaled_axis(self,axis,precision=96):
        axis=self._vector(axis)
        key=(METHOD,"scaled_axis",axis,precision)
        cached=self.work.lookup(key)
        if cached is not None: return cached
        self.work.charge("axis_scale",3)
        maximum=max(abs(v) for v in axis)
        if not maximum:
            raise ReachAdmissionError("reach_numeric","A rotation axis must be nonzero.")
        scaled=tuple(self._op(v,maximum,"div") for v in axis)
        square=self._sum(self._op(v,v,"mul") for v in scaled)
        context=DyadicContext(precision,self.work)
        bounds=context.bounds(context.sqrt_point(square))
        result=scaled,maximum,bounds
        self.work.remember(key,result)
        return result

    def axis_rotation(self,axis,angle):
        angle=rational(angle,self.work)
        axis=self._vector(axis)
        key=(METHOD,"axis_rotation",axis,angle)
        cached=self.work.lookup(key)
        if cached is not None: return cached
        if not angle:
            # Still validate the axis; a zero axis does not become admissible.
            self._scaled_axis(axis)
            result=RotationValue(UNIT)
            self.work.remember(key,result)
            return result
        unit=self._normalized_axis(axis)
        sine,cosine=self.sincos(self._op(angle,F(2),"div"))
        values=(cosine,*(self._op(v,sine,"mul") for v in unit))
        result=self._rescale(values,AXIS_ERROR)
        self.work.remember(key,result)
        return result

    def _recording_cursor_key(self,kind,context,path,max_steps,*operands):
        """Identify one finite recording pass without another numerical cache."""
        self.work.charge("recording_rotation_cursor_domain")
        if (type(context) is not object or type(path) is not str or not path
                or type(max_steps) is not int
                or not 1<=max_steps<=MAX_RECORDING_ROTATION_STEPS):
            raise ReachAdmissionError("reach_domain","A recording rotation needs a fresh context and bounded path cursor.")
        self.work.guard(max_steps)
        return (METHOD,"recording_rotation_cursor",kind,context,path,max_steps,
                self.work.max_operand_bits,*operands)

    def recording_axis_rotation(self,axis,coordinate,*,context,path,max_steps):
        """Compose exact coordinate differences within one recorded phase.

        The ordinary source evaluator is unchanged. The export certificate
        separately includes the proved finite recurrence excess at endpoints.
        Eviction or the finite step ceiling starts again at the direct kernel.
        """
        original_axis,original_coordinate=axis,coordinate
        while True:
            cap=self.work.max_operand_bits
            coordinate=rational(original_coordinate,self.work)
            axis=self._recording_vector(original_axis)
            key=self._recording_cursor_key("axis",context,path,max_steps,axis)
            previous=self.work.lookup(key)
            if self.work.max_operand_bits!=cap:
                continue
            delta,increment=None,None
            if previous is None or previous[2]>=max_steps:
                result=self.axis_rotation(axis,coordinate)
                count=1
            else:
                last,rotation,count,old_delta,old_increment=previous
                self.work.charge("recording_rotation_cursor_guard")
                self.work.guard(last,*rotation.components,rotation.error_rad,count)
                delta=self._op(coordinate,last,"sub")
                if delta:
                    if delta==old_delta:
                        self.work.charge("recording_increment_reuse")
                        increment=old_increment
                        self.work.guard(*increment.components,increment.error_rad)
                    else:
                        increment=self.axis_rotation(axis,delta)
                    result=self._recording_product(increment,rotation)
                else:
                    result=rotation
                    # A repeated query does not evict the last useful step.
                    delta,increment=old_delta,old_increment
                self.work.charge("recording_rotation_step")
                count+=1
            if self.work.max_operand_bits!=cap:
                continue
            self.work.remember(key,(coordinate,result,count,delta,increment))
            if self.work.max_operand_bits==cap:
                return result

    def _recording_product(self,increment,rotation):
        """Keep one-use recurrence products out of the shared bounded cache.

        Both complete operands and the same Hamilton/grid/error operations
        remain checked. Only the completed product's cache bookkeeping is
        omitted; the owning cursor publishes its result after the step passes.
        A narrower arithmetic domain retains the ordinary multiplication path.
        """
        if self.work.max_operand_bits!=MAX_OPERAND_BITS:
            return self.multiply(increment,rotation)
        first,second=self._rotation(increment),self._rotation(rotation)
        return self._multiply_uncached(first,second)

    def recording_body_orientation(self,seed_builder,axis,rate,time,*,phase_start,
                                   phase_end,context,path,proof_token,max_steps,
                                   source_admission=None,source_records=0):
        """Advance one proved complete carrier orientation in body coordinates.

        The caller has freshly checked the immutable phase's chained source-law
        witnesses. A miss evaluates the ordinary PRIVATE complete orientation,
        with recording cursors disabled throughout its ancestry. Each warm step
        postmultiplies that orientation by the proved ideal Cartesian body
        increment. This recording-only approximation uses the existing finite
        endpoint allowance; it never changes a source coordinate or anchor.
        """
        source_failure=None
        def direct_seed():
            nonlocal source_failure
            try:
                return seed_builder()
            except ReachAdmissionError as error:
                source_failure=error
                raise
        def current_source():
            nonlocal source_failure
            try:
                return source_admission()
            except ReachAdmissionError as error:
                source_failure=error
                raise
        while True:
            cap=self.work.max_operand_bits
            try:
                return self._recording_body_orientation(
                    direct_seed if callable(seed_builder) else seed_builder,axis,rate,time,
                    phase_start=phase_start,phase_end=phase_end,context=context,
                    path=path,proof_token=proof_token,max_steps=max_steps,
                    source_admission=current_source if callable(source_admission) else source_admission,
                    source_records=source_records)
            except ReachAdmissionError as error:
                if (error is not source_failure and self.work.max_operand_bits!=cap
                        and error is not self.work.callback_error
                        and error.details.get("budget")=="numeric_operand_bits"):
                    continue
                raise

    def _recording_body_orientation(self,seed_builder,axis,rate,time,*,phase_start,
                                    phase_end,context,path,proof_token,max_steps,
                                    source_admission=None,source_records=0):
        original_rate,original_time=rate,time
        original_start,original_end=phase_start,phase_end
        while True:
            cap=self.work.max_operand_bits
            rate=rational(original_rate,self.work)
            time=rational(original_time,self.work)
            phase_start=rational(original_start,self.work)
            phase_end=rational(original_end,self.work)
            self.work.charge("recording_body_phase_guard")
            if (type(proof_token) is not object or not callable(seed_builder)
                    or (axis is not None and (type(axis) is not int or not 0<=axis<3))
                    or (axis is None and rate)
                    or type(source_records) is not int or source_records<0
                    or source_admission is not None and not callable(source_admission)
                    or source_admission is None and source_records):
                raise ReachAdmissionError("reach_domain","A carrier cursor needs a proved Cartesian body law.")
            if (compare(phase_start,time,self.work)>0
                    or compare(time,phase_end,self.work)>0):
                raise ReachAdmissionError("reach_domain","A carrier cursor lies outside its proved phase.")
            key=self._recording_cursor_key("body",context,path,max_steps,
                proof_token,phase_start,phase_end,axis,rate)
            previous=self.work.lookup(key)
            if self.work.max_operand_bits!=cap:
                continue
            delta,increment=None,None
            # Narrow domains retain every ordinary source-kernel preflight.
            # A cap change can never turn a wide-domain saved q into a proof
            # that those omitted preflights would have succeeded.
            if cap!=MAX_OPERAND_BITS or previous is None or previous[2]>=max_steps:
                self.work.charge("recording_body_direct_seed")
                result=seed_builder()
                if type(result) is not RotationValue:
                    raise ReachAdmissionError("reach_domain","A carrier cursor seed must be a private complete rotation.")
                result=self._rotation(result)
                count=1
            else:
                last,rotation,count,old_delta,old_increment=previous
                self.work.charge("recording_rotation_cursor_guard")
                self.work.guard(last,*rotation.components,rotation.error_rad,count)
                delta=self._op(time,last,"sub")
                if delta and rate:
                    if delta==old_delta:
                        self.work.charge("recording_body_increment_reuse")
                        increment=old_increment
                        self.work.guard(*increment.components,increment.error_rad)
                    else:
                        vector=tuple(F(int(index==axis)) for index in range(3))
                        increment=self.axis_rotation(vector,self._op(rate,delta,"mul"))
                    # Body angular velocity acts on the right. The ordinary
                    # root-spin cursor instead uses a world-space left factor.
                    result=self._recording_product(rotation,increment)
                else:
                    result=rotation
                    delta,increment=old_delta,old_increment
                self.work.charge("recording_rotation_step")
                count+=1
            if self.work.max_operand_bits!=cap:
                continue
            admitted=False
            def admit():
                nonlocal admitted
                if source_admission() is not True:
                    raise ReachAdmissionError("reach_domain","The current carrier source was not admitted.")
                admitted=True
                return True
            if source_admission is not None:
                self.work.charge("recording_angular_witness_guard",source_records)
                if self.work.max_operand_bits!=cap:
                    continue
            if cap==MAX_OPERAND_BITS:
                self.work.remember(key,(time,result,count,delta,increment),
                                   admission=admit if source_admission is not None else None)
            if self.work.max_operand_bits==cap:
                if source_admission is not None and not admitted:
                    admit()
                return result

    def _normalized_axis(self,axis):
        """The same immutable 96-bit axis reduction for every requested angle."""
        axis=self._vector(axis)
        key=(METHOD,"normalized_axis",axis)
        cached=self.work.lookup(key)
        if cached is not None: return cached
        scaled,_,norm=self._scaled_axis(axis)
        self.work.charge("pose_unit_axis_check")
        if norm==(F(1),F(1)):
            # A scaled vector has a component of magnitude one. A proved
            # exact unit norm therefore makes its other components zero;
            # division by one and grid rounding would preserve every bit.
            unit=scaled
        else:
            middle=self._op(self._op(norm[0],norm[1],"add"),F(2),"div")
            unit=self._rounded_vector(self._op(v,middle,"div") for v in scaled)
        self.work.remember(key,unit)
        return unit

    def spin_plan(self,omega,max_elapsed_s):
        omega=self._vector(omega); maximum_time=abs(rational(max_elapsed_s,self.work))
        key=(METHOD,"spin_plan",omega,maximum_time)
        cached=self.work.lookup(key)
        if cached is not None: return cached
        if not any(omega):
            result=SpinPlan(ZERO,F(0),(F(1),F(1)),(F(3),F(4)),maximum_time,96,F(0))
            self.work.remember(key,result); return result
        for precision in PRECISIONS:
            scaled,maximum,norm=self._scaled_axis(omega,precision)
            pi=self._pi(precision)
            extent=self._op(self._op(maximum,maximum_time,"mul"),norm[1],"mul")
            quotient=self._op(extent,pi[0],"div")
            self.work.charge("phase_quadrant_ceiling",3)
            kmax=quotient.numerator//quotient.denominator+2
            angular_width=self._op(self._op(maximum,maximum_time,"mul"),self._op(norm[1],norm[0],"sub"),"mul")
            pi_width=self._op(F(kmax),self._op(pi[1],pi[0],"sub"),"mul")
            error=self._op(self._op(self._op(angular_width,pi_width,"add"),F(4),"div"),RHO,"add")
            if compare(error,ARGUMENT_ERROR,self.work)<=0:
                result=SpinPlan(scaled,maximum,norm,pi,maximum_time,precision,error)
                self.work.remember(key,result); return result
        raise ReachAdmissionError("reach_numeric","Finite source spin phase reduction could not be certified.")

    def _checked_spin_plan(self,omega,elapsed,phase_plan):
        plan=phase_plan if phase_plan is not None else self.spin_plan(omega,abs(elapsed))
        if not isinstance(plan,SpinPlan) or compare(abs(elapsed),plan.max_elapsed_s,self.work)>0:
            raise ReachAdmissionError("reach_numeric","A source sample lies outside its proved spin phase.")
        supplied=self._vector(omega)
        reconstructed=tuple(self._op(v,plan.maximum,"mul") for v in plan.scaled_omega)
        self.work.charge("spin_plan_identity",3)
        if supplied!=reconstructed:
            raise ReachAdmissionError("reach_numeric","A spin plan belongs to different angular velocity.")
        return plan

    def spin_rotation(self,omega,elapsed,*,phase_plan=None):
        elapsed=rational(elapsed,self.work)
        plan=self._checked_spin_plan(omega,elapsed,phase_plan)
        if not plan.maximum or not elapsed: return RotationValue(UNIT)
        factor=self._op(self._op(plan.maximum,elapsed,"mul"),F(2),"div")
        lo,hi=(self._op(factor,v,"mul") for v in plan.norm_bounds)
        if elapsed<0: lo,hi=hi,lo
        pair=self._reduced_sincos(lo,hi,plan.pi_bounds)
        if pair is None:
            raise ReachAdmissionError("reach_numeric","A proved spin phase did not enclose its sample.")
        sine,cosine=pair
        self.work.charge("spin_unit_operand_guard")
        self.work.guard(*plan.scaled_omega,*plan.norm_bounds)
        unit_key=(METHOD,"spin_unit_axis",plan.scaled_omega,plan.norm_bounds,BITS)
        unit=self.work.lookup(unit_key)
        if unit is None:
            middle=self._op(self._op(plan.norm_bounds[0],plan.norm_bounds[1],"add"),F(2),"div")
            unit=tuple(round_dyadic(self._op(v,middle,"div"),BITS,work=self.work) for v in plan.scaled_omega)
            self.work.remember(unit_key,unit)
        return self._rescale((cosine,*(self._op(v,sine,"mul") for v in unit)),AXIS_ERROR)

    def advance_orientation(self,initial,omega,elapsed,*,phase_plan=None):
        initial=self._rotation(initial); elapsed=rational(elapsed,self.work)
        omega=self._vector(omega)
        self.work.charge("orientation_stationary",3)
        if not any(omega) or not elapsed: return initial
        return self.multiply(self.spin_rotation(omega,elapsed,phase_plan=phase_plan),initial)

    def recording_advance_orientation(self,initial,omega,elapsed,*,context,path,
                                      max_steps,phase_plan=None):
        """Record a fixed world angular velocity with bounded rotation steps."""
        original_initial,original_omega,original_elapsed=initial,omega,elapsed
        while True:
            cap=self.work.max_operand_bits
            initial=self._rotation(original_initial)
            elapsed=rational(original_elapsed,self.work)
            omega=self._recording_vector(original_omega)
            key=self._recording_cursor_key("spin",context,path,max_steps,initial,omega,phase_plan)
            self.work.charge("orientation_stationary",3)
            if self.work.max_operand_bits!=cap:
                continue
            if not any(omega) or not elapsed: return initial
            # Every warm request checks the current clock, velocity and plan.
            # A saved increment proves only the same exact delta and plan.
            plan=self._checked_spin_plan(omega,elapsed,phase_plan)
            previous=self.work.lookup(key)
            if self.work.max_operand_bits!=cap:
                continue
            delta,increment,increment_plan=None,None,plan
            if previous is not None and previous[2]<max_steps:
                last,rotation,count,old_delta,old_increment,old_plan=previous
                self.work.charge("recording_rotation_cursor_guard")
                self.work.guard(last,*rotation.components,rotation.error_rad,count)
                delta=self._op(elapsed,last,"sub")
                if compare(abs(delta),plan.max_elapsed_s,self.work)>0:
                    delta=None
            if delta is None:
                result=self.advance_orientation(initial,omega,elapsed,phase_plan=plan)
                count=1
            else:
                if delta:
                    if delta==old_delta and plan==old_plan:
                        self.work.charge("recording_spin_increment_reuse")
                        increment=old_increment
                        self.work.guard(*increment.components,increment.error_rad)
                    else:
                        increment=self.spin_rotation(omega,delta,phase_plan=plan)
                    result=self._recording_product(increment,rotation)
                else:
                    result=rotation
                    delta,increment=old_delta,old_increment
                    increment_plan=old_plan
                self.work.charge("recording_rotation_step")
                count+=1
            if self.work.max_operand_bits!=cap:
                continue
            self.work.remember(key,(elapsed,result,count,delta,increment,increment_plan))
            if self.work.max_operand_bits==cap:
                return result

    def identity(self):
        self.work.charge("pose_identity")
        return PoseValue(ZERO,RotationValue(UNIT),ZERO,ZERO,F(0),self)

    def make(self,position=ZERO,orientation=UNIT,velocity=ZERO,omega=ZERO):
        position,rotation=self._vector(position),self._rotation(orientation)
        velocity,omega=self._vector(velocity),self._vector(omega)
        self.work.charge("pose_stationary_check")
        stationary=not any(velocity) and not any(omega)
        key=(METHOD,"stationary_pose",position,rotation)
        if stationary:
            cached=self.work.lookup(key)
            if cached is not None: return cached
        result=PoseValue(position,rotation,velocity,omega,F(0),self)
        if stationary: self.work.remember(key,result)
        return result

    def constant_pose(self,pose):
        return self.make(pose.position,pose.rotation)

    def hinge_pose(self,axis,coordinate,exact_rate):
        axis=self._vector(axis)
        coordinate,exact_rate=rational(coordinate,self.work),rational(exact_rate,self.work)
        key=(METHOD,"hinge_pose",axis,coordinate,exact_rate)
        cached=self.work.lookup(key)
        if cached is not None:
            rotation,omega=cached
            return PoseValue(ZERO,rotation,ZERO,omega,F(0),self)
        result=self.make(orientation=self.axis_rotation(axis,coordinate),omega=self.scale(axis,exact_rate))
        self.work.remember(key,(result.rotation,result.exact_omega))
        return result

    def make_recording(self,position=ZERO,orientation=UNIT):
        """Construct only the validated transform used by recorded sampling."""
        return RecordedTransform(self._vector(position),self._rotation(orientation),self)

    def hinge_recording(self,axis,coordinate):
        """Keep the ordinary exact hinge rotation without unused zero rates."""
        return RecordedTransform(ZERO,self.axis_rotation(axis,coordinate),self)

    def compose_recording(self,parent,local):
        """Execute the unchanged p/q equations for an already validated phase.

        Spatial rates and the sampled position allowance never enter either
        equation. Whole-phase allowances are derived before this sampler runs;
        the distinct result type cannot be mistaken for those omitted values.
        Quaternion products retain their original exact error recurrence.
        """
        if not isinstance(parent,(PoseValue,RecordedTransform)) or not isinstance(local,(PoseValue,RecordedTransform)):
            raise TypeError("Recording composition requires private transform inputs")
        self.work.charge("recording_transform_operand_guard")
        positions=[]
        for value in (parent.exact_position,local.exact_position):
            if not (isinstance(value,tuple) and len(value)==3 and all(type(part) is F for part in value)):
                value=self._vector(value)
            self.work.guard(*value)
            positions.append(value)
        parent_position,local_position=positions
        # These guards ran through rotate/multiply before reuse was added and
        # must also precede a hit. The complete rotations include their error
        # recurrence and any materialized source projection, not just p/q bits.
        parent_rotation=self._rotation(parent.rotation)
        local_rotation=self._rotation(local.rotation)
        key=(METHOD,"recording_relative",self.work.max_operand_bits,
             parent_rotation,local_position,local_rotation)
        relative=self.work.lookup(key)
        if relative is None:
            offset=self.rotate(parent_rotation,local_position)
        else:
            offset,rotation=relative
        self.work.guard(*offset)
        position=self._rounded_vector(self._add_exact_vectors(parent_position,offset))
        if relative is None:
            rotation=self.multiply(parent_rotation,local_rotation)
            self.work.remember(key,(offset,rotation))
        return RecordedTransform(position,rotation,self)

    def compose_recording_fast(self,parent,local):
        """Compose recorded transforms, eliding actual identity products.

        This is a separately identified recording algorithm. The original
        source and direct-recording equations keep their projection sequence.
        An omitted quaternion projection introduces no product error, but both
        operands' existing angular allowances still belong to the result.
        """
        if not isinstance(parent,(PoseValue,RecordedTransform)) or not isinstance(local,(PoseValue,RecordedTransform)):
            raise TypeError("Recording composition requires private transform inputs")
        self.work.charge("recording_identity_operand_guard")
        # The fast path operates only on this request's immutable private
        # domain. Less ordinary input shapes and narrower arithmetic domains
        # retain the original checked composition and its preflights.
        if (parent._ops is not self or local._ops is not self or
                self.work.max_operand_bits != 32768):
            return self.compose_recording(parent,local)
        for value in (parent,local):
            if (not isinstance(value.exact_position,tuple) or len(value.exact_position)!=3 or
                    not all(type(part) is F for part in value.exact_position) or
                    type(value.rotation) is not RotationValue or
                    not isinstance(value.rotation.components,tuple) or len(value.rotation.components)!=4 or
                    not all(type(part) is F for part in value.rotation.components) or
                    type(value.rotation.error_rad) is not F):
                return self.compose_recording(parent,local)
            self.work.guard(*value.exact_position,*value.rotation.components,value.rotation.error_rad)
            if not any(value.rotation.components):
                raise ReachAdmissionError("reach_numeric","A zero quaternion cannot represent a rotation.")
        parent_rotation,local_rotation=parent.rotation,local.rotation
        parent_identity=not any(parent_rotation.components[1:])
        local_identity=not any(local_rotation.components[1:])
        if not parent_identity and not local_identity:
            return self._compose_recording_relative(parent,local)
        self.work.charge("recording_identity_composition")
        if not any(local.exact_position):
            position=self._rounded_vector(parent.exact_position)
        else:
            offset=(self._rounded_vector(local.exact_position) if parent_identity else
                    self.rotate(parent_rotation,local.exact_position))
            position=self._rounded_vector(self._add_exact_vectors(parent.exact_position,offset))
        unchanged=local_rotation if parent_identity else parent_rotation
        other=parent_rotation if parent_identity else local_rotation
        if not other.error_rad:
            rotation=unchanged
        else:
            error=self._op(unchanged.error_rad,other.error_rad,"add")
            rotation=RotationValue(unchanged.components,error,unchanged.frozen_projection)
        # A cancellation callback may also narrow the work domain during a
        # charged position operation. Re-establish the ordinary preflights in
        # that domain before an unprojected quaternion can leave this helper.
        if self.work.max_operand_bits != 32768:
            return self.compose_recording(parent,local)
        return RecordedTransform(position,rotation,self)

    def _compose_recording_relative(self,parent,local):
        """Compose the fully guarded operands of the recording fast path.

        The existing relative-result entry already retains the complete
        rotation product. A second product-cache entry stores identical work
        under another key and displaces reusable laws in a moving recording.
        """
        cap=self.work.max_operand_bits
        key=(METHOD,"recording_relative",cap,parent.rotation,local.exact_position,local.rotation)
        relative=self.work.lookup(key)
        if self.work.max_operand_bits!=cap:
            return self.compose_recording(parent,local)
        self.work.charge("recording_relative_translation")
        if not any(local.exact_position):
            offset=ZERO
            position=self._rounded_vector(parent.exact_position)
        else:
            offset=(self._rotate_guarded(parent.rotation,local.exact_position)
                    if relative is None else relative[0])
            self.work.guard(*offset)
            position=self._rounded_vector(self._add_exact_vectors(parent.exact_position,offset))
        if relative is None:
            rotation=self._multiply_uncached(parent.rotation,local.rotation)
            if self.work.max_operand_bits==cap:
                self.work.remember(key,(offset,rotation))
        else:
            rotation=relative[1]
            self.work.guard(*rotation.components,rotation.error_rad)
        if self.work.max_operand_bits!=cap:
            return self.compose_recording(parent,local)
        return RecordedTransform(position,rotation,self)

    def compose(self,parent,local):
        if not isinstance(parent,PoseValue) or not isinstance(local,PoseValue):
            raise TypeError("Controlled composition requires private PoseValue inputs")
        self.work.charge("composition_stationary_check")
        canonical_zero_rates=(parent.exact_velocity is ZERO and parent.exact_omega is ZERO and
                              local.exact_velocity is ZERO and local.exact_omega is ZERO)
        if not canonical_zero_rates:
            # Value equality alone cannot establish the private vector domain:
            # booleans compare equal to zero, and a short zero tuple has no
            # nonzero component. Validate these shapes/types before any cache
            # lookup or derivative shortcut can hide the ordinary rejection.
            self.work.charge("composition_rate_domains",4)
            for rates in (parent.exact_velocity,parent.exact_omega,
                          local.exact_velocity,local.exact_omega):
                if not (isinstance(rates,tuple) and len(rates)==3 and
                        all(type(value) is F for value in rates)):
                    self._vector(rates)
        stationary=canonical_zero_rates or not any((
            *parent.exact_velocity,*parent.exact_omega,*local.exact_velocity,*local.exact_omega))
        # A translated scene produces many one-use whole-pose entries. Keep
        # the bounded cache for shared local arithmetic instead of displacing
        # it with each object's distinct world translation.
        cache_stationary=stationary and not any(parent.exact_position)
        key=(METHOD,"stationary_composition",parent,local)
        if cache_stationary:
            cached=self.work.lookup(key)
            if cached is not None: return cached
        # Parent translation and position errors do not enter the rotation or
        # derivative arithmetic. Project each caller's position and retain its
        # own error calculation even when those common operations are reused.
        relative_key=(METHOD,"relative_composition",parent.rotation,
                      parent.exact_velocity,parent.exact_omega,local.exact_position,
                      local.rotation,local.exact_velocity,local.exact_omega)
        self.work.charge("composition_operand_guard")
        parent_position=parent.exact_position
        if not (isinstance(parent_position,tuple) and len(parent_position)==3 and
                all(type(value) is F for value in parent_position)):
            parent_position=self._vector(parent_position)
        self.work.guard(*parent_position,*parent.rotation.components,parent.rotation.error_rad,
            *parent.exact_velocity,*parent.exact_omega,parent.position_error_m,
            *local.exact_position,*local.rotation.components,local.rotation.error_rad,
            *local.exact_velocity,*local.exact_omega,local.position_error_m)
        relative=self.work.lookup(relative_key)
        offset=(self.rotate(parent.rotation,local.exact_position) if relative is None else relative[0])
        # The precharged fixed-size composition guard also covers the bounded
        # private offset retrieved or computed above. Both vector operands are
        # now checked; the generic add helper would decode/check them again.
        self.work.guard(*offset)
        position=self._rounded_vector(self._add_exact_vectors(parent_position,offset))
        if relative is None:
            if stationary:
                # The complete operand guard and earlier zero-value check
                # prove both spatial derivatives exactly zero, including every
                # grid projection. Equivalent private zero tuples need not have
                # the same Python object identity to establish that equation.
                velocity=omega=ZERO
            else:
                self.work.charge("composition_derivative_zero_check")
                if local.exact_velocity is ZERO:
                    if offset is ZERO or parent.exact_omega is ZERO:
                        linear=self._vector(parent.exact_velocity)
                    else:
                        linear=self.add(parent.exact_velocity,self.cross(parent.exact_omega,offset))
                else:
                    linear=self.add(self.add(parent.exact_velocity,self.cross(parent.exact_omega,offset)),
                                    self.rotate(parent.rotation,local.exact_velocity))
                angular=(self._vector(parent.exact_omega) if local.exact_omega is ZERO else
                         self.add(parent.exact_omega,self.rotate(parent.rotation,local.exact_omega)))
                # The omitted exact-zero terms cannot change the sum. Keep
                # the ordinary final grid: a parent's rate may be off-grid.
                velocity=self._rounded_vector(linear)
                omega=self._rounded_vector(angular)
            offset_error=self._op(self._l1(local.exact_position),parent.angular_error_rad,"mul")
            offset_allowance=self._sum((offset_error,VECTOR_ERROR,VECTOR_ERROR))
        else:
            _,rotation,velocity,omega,offset_allowance=relative
        parent_error,local_error=parent.position_error_m,local.position_error_m
        # The complete charged operand guard above covers these private
        # Fraction identities. Keep the actual allowance addition for every
        # caller, including when relative composition arithmetic is cached.
        if type(parent_error) is F and type(local_error) is F and not parent_error:
            inherited_error=local_error
        elif type(parent_error) is F and type(local_error) is F and not local_error:
            inherited_error=parent_error
        else:
            inherited_error=self._op(parent_error,local_error,"add")
        position_error=self._op(inherited_error,offset_allowance,"add")
        if relative is None:
            rotation=self.multiply(parent.rotation,local.rotation)
            self.work.remember(relative_key,(offset,rotation,velocity,omega,offset_allowance))
        result=PoseValue(position,rotation,velocity,omega,position_error,self)
        if cache_stationary: self.work.remember(key,result)
        return result

    def inverse_pose(self,pose):
        value=pose if isinstance(pose,PoseValue) else self.constant_pose(pose)
        key=(METHOD,"inverse_pose",value.exact_position,value.rotation,value.position_error_m)
        cached=self.work.lookup(key)
        if cached is not None: return cached
        rotation=self.inverse_rotation(value.rotation)
        self.work.charge("pose_position_negate",3)
        position=self.rotate(rotation,tuple(-x for x in value.exact_position))
        # This is a static frame inverse. Spatial derivatives are intentionally
        # zero; use relative_point for the measured moving-frame position.
        error=self._sum((value.position_error_m,
            self._op(self._l1(value.exact_position),value.angular_error_rad,"mul"),VECTOR_ERROR))
        result=PoseValue(position,rotation,ZERO,ZERO,error,self)
        self.work.remember(key,result)
        return result

    def relative_point(self,base,world_point):
        if not isinstance(base,PoseValue): raise TypeError("A private base pose is required")
        point=world_point.exact_position if isinstance(world_point,PoseValue) else self._vector(world_point)
        difference=tuple(self._op(a,b,"sub") for a,b in zip(point,base.exact_position))
        return self.rotate(self.inverse_rotation(base.rotation),difference)

    def ensure_finite(self,pose):
        """Prove unused public fields admissible without materializing tuples.

        This is only a finiteness check, never a source of public pose values.
        Small exact operands under the full width cap admit every operation of
        the original projection; every other case executes that projection.
        The proof and explicit intermediate widths are in the numeric note.
        """
        if (type(pose) is not PoseValue or pose._ops is not self or
                type(pose._projection) is not dict):
            pose.position,pose.orientation,pose.velocity,pose.omega
            return
        own=pose._finite_proof
        family=pose._finite_family
        if (own is _FINITE_PROOF_BUSY or
                own is not None and not self._valid_finite_proof(own) or
                family is not None and not self._valid_finite_family(family)):
            # An interrupted/reentrant or malformed private memo cannot supply
            # any proof. Preserve the original four ordered field checks.
            self._ensure_finite_fields(pose)
            return
        previous=own if own is not None else family.proof if family is not None else None
        retained=own
        object.__setattr__(pose,"_finite_proof",_FINITE_PROOF_BUSY)
        try:
            self.work.charge("pose_finiteness_proof")
            if (self.work.max_operand_bits!=MAX_OPERAND_BITS or
                    pose._finite_proof is not _FINITE_PROOF_BUSY or
                    pose._finite_family is not None and not self._valid_finite_family(pose._finite_family)):
                self._ensure_finite_fields(pose)
                return
            signature=self._finite_signature(pose)
            completed=[]
            if self._complete_finite_signature(signature):
                # The freshly read signature already proves all four private
                # fields in the full cap. Repeating each field's identical
                # shape/width predicate cannot strengthen this same proof.
                # No callback occurs between this bounded read and publication.
                completed=list(signature)
            for index,(name,length) in enumerate(() if completed else _FINITE_FIELDS):
                matched=(previous is not None and signature[index] is not None and
                         signature[index] is previous.fields[index])
                if previous is not None and (matched or name in pose._projection):
                    completed.append(signature[index] if matched else None)
                    continue
                proved=self._ensure_finite_field(pose,name,length)
                if (self.work.max_operand_bits!=MAX_OPERAND_BITS or
                        pose._finite_proof is not _FINITE_PROOF_BUSY or
                        pose._finite_family is not None and not self._valid_finite_family(pose._finite_family) or
                        any(current is not original for current, original in
                            zip(self._finite_signature(pose), signature))):
                    # A later callback may invalidate even an earlier reused
                    # field. Replay all original checks under the live domain.
                    self._ensure_finite_fields(pose)
                    return
                completed.append(signature[index] if proved else None)
            retained=_PoseFinitenessProof(self,MAX_OPERAND_BITS,tuple(completed))
            if self._valid_finite_family(pose._finite_family):
                # Sibling sites may have been built before their first check.
                # Publish only this completed immutable operand proof, never
                # a source pose, public tuple or partially proved field set.
                pose._finite_family.proof=retained
        finally:
            if pose._finite_proof is _FINITE_PROOF_BUSY:
                object.__setattr__(pose,"_finite_proof",retained)

    @staticmethod
    def _finite_payload(name,payload):
        if name=="orientation":
            if (type(payload) is not RotationValue or payload.frozen_projection is not None or
                    type(payload.error_rad) is not F):
                return None
            values=payload.components
            length=4
        else:
            values=payload
            length=3
        if (type(values) is not tuple or len(values)!=length or
                any(type(value) is not F for value in values) or
                any(max(value.numerator.bit_length(),value.denominator.bit_length())>512
                    for value in values)):
            return None
        if name=="orientation" and not any(values):
            return None
        return payload

    def _finite_signature(self,pose):
        return tuple(self._finite_payload(name,pose.rotation if name=="orientation" else
                     getattr(pose,"exact_"+name)) for name,_ in _FINITE_FIELDS)

    @staticmethod
    def _complete_finite_signature(signature):
        """The existing small-domain theorem holds for every current field."""
        return all(payload is not None for payload in signature)

    def _valid_finite_proof(self,proof):
        return (type(proof) is _PoseFinitenessProof and proof.owner is self and
                type(proof.cap) is int and proof.cap==MAX_OPERAND_BITS and
                type(proof.fields) is tuple and len(proof.fields)==len(_FINITE_FIELDS) and
                all(value is None or self._finite_payload(name,value) is not None
                    for (name,_),value in zip(_FINITE_FIELDS,proof.fields)))

    def _carry_finite_proof(self,source,target):
        """Carry completed immutable proof state; the next check matches fields."""
        if not (type(source) is PoseValue and type(target) is PoseValue and
                source._ops is self and target._ops is self):
            return
        proof=source._finite_proof
        if proof is not None and not self._valid_finite_proof(proof):
            return
        family=source._finite_family
        if family is None:
            family=_PoseFinitenessFamily(self,proof)
            object.__setattr__(source,"_finite_family",family)
        elif not self._valid_finite_family(family):
            return
        if proof is not None:
            object.__setattr__(target,"_finite_proof",source._finite_proof)
        object.__setattr__(target,"_finite_family",family)

    def _valid_finite_family(self,family):
        return (type(family) is _PoseFinitenessFamily and family.owner is self and
                (family.proof is None or self._valid_finite_proof(family.proof)))

    def _ensure_finite_fields(self,pose):
        for name,length in _FINITE_FIELDS:
            self._ensure_finite_field(pose,name,length)

    def _ensure_finite_field(self,pose,name,length):
        self.work.charge("pose_finiteness_field")
        # Preserve the existing finiteness check's treatment of an actual
        # projection. Such a tuple is never a proof of the private operands;
        # an actual _expose request retains its separate current-domain checks.
        if name in pose._projection:
            return False
        if self.work.max_operand_bits!=MAX_OPERAND_BITS:
            getattr(pose,name)
            return False
        if name=="orientation":
            rotation=pose.rotation
            if type(rotation) is not RotationValue or rotation.frozen_projection is not None:
                getattr(pose,name)
                return False
            values=rotation.components
        else:
            values=getattr(pose,"exact_"+name)
        if (type(values) is not tuple or len(values)!=length or
                any(type(value) is not F for value in values)):
            getattr(pose,name)
            return False
        self.work.guard(*values)
        small=all(max(value.numerator.bit_length(),value.denominator.bit_length())<=512
                  for value in values)
        if not small or (name=="orientation" and not any(values)):
            getattr(pose,name)
            return False
        return True

    def _unit_projection(self,rotation):
        while True:
            cap=self.work.max_operand_bits
            try:
                result=self._unit_projection_in_domain(rotation)
            except ReachAdmissionError as error:
                if (self.work.callback_error is error or self.work.max_operand_bits==cap or
                        error.details.get("budget")!="numeric_operand_bits"):
                    raise
                continue
            if self.work.max_operand_bits==cap:
                return result

    def _unit_projection_in_domain(self,rotation):
        if rotation.frozen_projection is not None:
            self.work.charge("frozen_quaternion_projection")
            self.work.guard(*rotation.components)
            return rotation.frozen_projection
        self.work.charge("quaternion_projection_operand_guard")
        self.work.guard(*rotation.components)
        active=tuple(index for index,value in enumerate(rotation.components[1:]) if value)
        if (self.work.max_operand_bits==MAX_OPERAND_BITS and len(active)==1 and
                all(type(value) is F for value in rotation.components)):
            cap=self.work.max_operand_bits
            key=(METHOD,"axis_rotation_factors",rotation.components,cap)
            factors=self.work.lookup(key)
            if type(factors) is _IntegerAxisFactors and self.work.max_operand_bits==cap:
                if factors.projection is not None:
                    return factors.projection
                # Homogeneous rotation has already formed these exact integer
                # squares and their sum. Their common dyadic denominator
                # cancels in every normalization ratio, without a new square,
                # norm sum, or approximate square root.
                self.work.guard(*factors.squares,factors.denominator)
                squares=[0,0,0,0]
                squares[0],squares[active[0]+1]=factors.squares
                result=[]
                for value,square in zip(rotation.components,squares):
                    if not value:
                        self.work.charge("known_zero_quaternion_projection")
                        result.append(0.0)
                        continue
                    ratio=self._op(F(square),F(factors.denominator),"div")
                    component=sqrt_rational_binary64(ratio,work=self.work)
                    self.work.charge("quaternion_projection_sign")
                    result.append(-component if value<0 and component else component)
                result=tuple(result)
                if self.work.max_operand_bits==cap:
                    self.work.remember(key,replace(factors,projection=result))
                return result
        # Error allowances and pose identity do not affect this projection.
        key=(METHOD,"unit_projection",rotation.components)
        cached=self.work.lookup(key)
        if cached is not None: return cached
        self.work.charge("quaternion_projection_support")
        # Exact zero terms do not change q dot q. Reuse each actual square in
        # its output ratio, and start the nonempty exact sum at its first term.
        squares=tuple(self._op(value,value,"mul") if value else F(0)
                      for value in rotation.components)
        nonzero=tuple(value for value in squares if value)
        if not nonzero:
            raise ZeroDivisionError("Exact zero divisor")
        denominator=nonzero[0]
        for value in nonzero[1:]: denominator=self._op(denominator,value,"add")
        result=[]
        for value,square in zip(rotation.components,squares):
            if not value:
                self.work.charge("known_zero_quaternion_projection")
                result.append(0.0)
                continue
            square=self._op(square,denominator,"div")
            component=sqrt_rational_binary64(square,work=self.work)
            self.work.charge("quaternion_projection_sign")
            result.append(-component if value<0 and component else component)
        result=tuple(result)
        self.work.remember(key,result)
        return result

    def _expose(self,pose,field_name):
        while True:
            cap=self.work.max_operand_bits
            self.work.charge("pose_projection_lookup")
            operand=(pose.rotation if field_name=="orientation" else
                     getattr(pose,"exact_"+field_name))
            domain=pose._projection_domains.get(field_name)
            if (self.work.max_operand_bits==cap and domain is not None and
                    domain[0]==cap and domain[1] is operand and field_name in pose._projection):
                return pose._projection[field_name]
            # The projection dict can outlive a callback-induced operand-cap
            # change, or be shared by dataclasses.replace. Re-establish the
            # original arithmetic proof before reusing another domain's bits.
            value=(self._unit_projection(pose.rotation) if field_name=="orientation" else
                   self._vector_projection(operand))
            if self.work.max_operand_bits!=cap:
                continue
            # Materialized source anchors may supply preexisting public bits,
            # including signed zero. Validate their exact operands above and
            # retain that intentional exposure rather than normalizing it.
            if (domain is None and field_name in pose._projection
                    and pose._projection[field_name]==value):
                value=pose._projection[field_name]
            pose._projection[field_name]=value
            pose._projection_domains[field_name]=(cap,operand)
            return value

    def _vector_projection(self,values):
        if values is ZERO:
            self.work.charge("known_zero_vector_projection")
            return (0.0,0.0,0.0)
        self.work.charge("vector_projection_operand_guard")
        self.work.guard(*values)
        self.work.charge("vector_projection_zero_check")
        if not any(values): return (0.0,0.0,0.0)
        key=(METHOD,"vector_projection",values)
        cached=self.work.lookup(key)
        if cached is not None: return cached
        result=tuple(round_binary64(value,work=self.work) for value in values)
        self.work.remember(key,result)
        return result

    def materialize(self,pose):
        """Freeze the actual exposed release anchor without normalization drift."""
        projections={name:getattr(pose,name) for name in ("position","orientation","velocity","omega")}
        values={name:self._vector(value,4 if name=="orientation" else 3) for name,value in projections.items()}
        # Importing the already exposed orientation defines the new anchor's
        # exact projective rotation; preserve its actual saved public bits.
        rotation=RotationValue(values["orientation"],
            self._op(pose.angular_error_rad,EXPOSED_ROTATION_ERROR,"add"),projections["orientation"])
        rounding=self._sum(abs(self._op(a,b,"sub")) for a,b in zip(values["position"],pose.exact_position))
        return PoseValue(values["position"],rotation,values["velocity"],values["omega"],
            self._op(pose.position_error_m,rounding,"add"),self,projections)

    def source_bounds(self,pose,*,maximum_position_m=None):
        """Point bounds including final floats; never a whole-phase certificate.

        A supplied uniform L1 extent bounds the final projection alone. The
        composed pose's position_error_m may still depend on this sample's
        offsets. Use uniform_source_bounds for an entire phase.
        """
        extent=self._l1(pose.exact_position) if maximum_position_m is None else rational(maximum_position_m,self.work)
        if compare(extent,F(0),self.work)<0:
            raise ReachAdmissionError("reach_numeric","A source position bound cannot be negative.")
        rounding=self._op(self._op(extent,F(1,1<<53),"mul"),F(3,1<<1075),"add")
        return {"method":METHOD,"position_m":self._op(pose.position_error_m,rounding,"add"),
                "rotation_rad":self._op(pose.angular_error_rad,EXPOSED_ROTATION_ERROR,"add"),
                "proper_rotation_defect":F(0),"uniform_extent_supplied":maximum_position_m is not None}


def uniform_source_bounds(*,max_position_l1_m,path_offset_l1_m,trig_count,
                          product_count,vector_round_count,coordinate_angle_error_rad,
                          anchor_position_error_m,anchor_rotation_error_rad,
                          radius_m=F(0),work):
    """Bound every source pose in a caller-identified continuous phase.

    The caller supplies whole-phase magnitudes, actual helper path counts and
    independently propagated anchor discrepancies. Counts are conservative
    maxima, not measured errors or merely the number of published samples.
    ``path_offset_l1_m`` sums all local offset extents on the selected path.
    ``vector_round_count`` covers every rounded position-vector stage on it.
    """
    counts=(trig_count,product_count,vector_round_count)
    work.charge("uniform_bound_counts",3)
    if any(type(value) is not int or value<0 for value in counts):
        raise ReachAdmissionError("reach_numeric","Source path counts must be nonnegative integers.")
    work.guard(*counts)
    values=tuple(rational(v,work) for v in (max_position_l1_m,path_offset_l1_m,
        coordinate_angle_error_rad,anchor_position_error_m,anchor_rotation_error_rad,radius_m))
    if any(compare(value,F(0),work)<0 for value in values):
        raise ReachAdmissionError("reach_numeric","Source uniform allowances must be nonnegative.")
    extent,offset,coordinate,anchor_position,anchor_rotation,radius=values
    op=lambda a,b,kind:exact(a,b,kind,work)
    rotation=op(op(anchor_rotation,coordinate,"add"),
        op(op(F(trig_count),AXIS_ERROR,"mul"),op(F(product_count),PRODUCT_ERROR,"mul"),"add"),"add")
    position=op(op(anchor_position,op(offset,rotation,"mul"),"add"),
        op(F(vector_round_count),VECTOR_ERROR,"mul"),"add")
    position=op(position,op(op(extent,F(1,1<<53),"mul"),F(3,1<<1075),"add"),"add")
    rotation=op(rotation,EXPOSED_ROTATION_ERROR,"add")
    return {"method":METHOD,"position_m":position,"rotation_rad":rotation,
            "point_m":op(position,op(radius,rotation,"mul"),"add"),
            "proper_rotation_defect":F(0)}


def source_numeric_basis(*,work):
    """Hash bounded, identified implementation inputs under the execution lock.

    The caller must retain the execution rule's stable source identity. Missing
    source/derivation files fail explicitly instead of publishing an invented
    or stale implementation hash. No paths are supplied by a request.
    """
    key=(METHOD,"source_numeric_basis")
    cached=work.lookup(key)
    if cached is not None: return cached
    root=Path(__file__).resolve().parent.parent
    implementation_names=("ontokin/reach_numeric.py","ontokin/reach_kinematics.py","ontokin/reach_pose.py",
                          "ontokin/reach_phase.py","ontokin/reach_runtime.py","ontokin/reach_export.py",
                          "ontokin/reach_recording_fast.py", "ontokin/reach_recording_capture.py",
                          "ontokin/reach_transfer_bounds.py")
    derivation_names=("docs/engineering/reach-numeric-kernel.md",
                      "docs/engineering/reach-source-kernel.md",
                      "docs/engineering/reach-coaxial-phase-bounds.md",
                      "docs/engineering/reach-carrier-rotation-cursors.md",
                      "docs/engineering/reach-recording-certified-planar.md",
                      "docs/engineering/reach-deferred-phase-locations.md",
                      "docs/engineering/reach-planning-reuse.md",
                      "docs/engineering/reach-release-cell-envelope.md")
    names=implementation_names+derivation_names
    entries=[]
    for name in names:
        work.charge("numeric_basis_open")
        digest=sha256(); size=0
        try:
            with (root/name).open("rb") as source:
                while True:
                    work.charge("numeric_basis_read")
                    block=source.read(16384)
                    work.charge("numeric_basis_read_return")
                    if not block: break
                    size+=len(block)
                    if size>262144:
                        work.resource("numeric_basis_input_bytes",262144,size)
                    work.charge("numeric_basis_hash")
                    digest.update(block)
        except OSError as error:
            raise ReachAdmissionError("reach_numeric","The source numerical basis cannot be identified.",
                                      missing_basis_input=name) from error
        entries.append((name,digest.hexdigest()))
    def aggregate(values):
        work.charge("numeric_basis_digest")
        return sha256("".join(name+"\0"+digest+"\n" for name,digest in values).encode("ascii")).hexdigest()
    implementation=aggregate(entries[:len(implementation_names)])
    derivation=aggregate(entries[len(implementation_names):])
    result=SourceNumericBasis("OntoKin controlled source poses","0.2","sha256:"+implementation,
        METHOD,"sha256:"+derivation,tuple(entries))
    work.remember(key,result)
    return result
