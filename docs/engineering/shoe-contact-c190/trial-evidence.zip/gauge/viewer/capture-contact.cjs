// Capture verified C190 outputs using the unchanged C187 camera.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const {chromium} = require(process.env.PLAYWRIGHT_CORE || 'playwright-core');
const [binary, url, output, kitPath, manifestPath] = process.argv.slice(2);
async function main() {
  const root=path.resolve(kitPath), files=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
  fs.mkdirSync(output,{recursive:true});
  const browser=await chromium.launch({executablePath:binary,args:['--no-sandbox','--disable-dev-shm-usage','--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader']});
  try {
    const page=await browser.newPage({viewport:{width:880,height:720},deviceScaleFactor:1});
    const errors=[], shots=[];
    page.on('pageerror',e=>errors.push(String(e)));
    await page.goto(url+'gauge/viewer/');
    const canvas=page.locator('#stage');
    const state=()=>canvas.evaluate(e=>JSON.parse(e.dataset.frame));
    await page.waitForFunction(()=>document.querySelector('#stage').dataset.frame);
    for(const entry of files) {
      const before=await state();
      const file=path.join(root,entry.path);
      const sha=crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
      await page.locator('#file').setInputFiles(file);
      await page.waitForFunction(h=>JSON.parse(document.querySelector('#stage').dataset.frame).sha===h,sha);
      const after=await state();
      for(const key of ['eye','target','fov','size','time','registration']) {
        if(JSON.stringify(before[key])!==JSON.stringify(after[key]))throw Error('Changed during swap: '+key);
      }
      if(after.meshCount!==7 || after.duration!==2)throw Error('Unexpected clip contents');
      for(const [pose,time] of [['rest',0],['contact',entry.idealContactS],['after',2]]) {
        await page.locator('#time').evaluate((e,v)=>{e.value=v;e.dispatchEvent(new Event('input'))},time);
        await page.waitForFunction(t=>JSON.parse(document.querySelector('#stage').dataset.frame).time===t,time);
        const name=entry.id+'-'+pose+'.png';
        await canvas.screenshot({path:path.join(output,name)});
        shots.push({id:entry.id,route:entry.route,stopNearFaceMm:entry.stopNearFaceMm,pose,file:name,sourcePath:entry.path,...await state()});
      }
      await page.locator('#play').click();
      await page.waitForFunction(()=>{const t=JSON.parse(document.querySelector('#stage').dataset.frame).time;return t>0&&t<1.95});
      await page.locator('#play').click();
      await page.locator('#time').evaluate(e=>{e.value=2;e.dispatchEvent(new Event('input'))});
    }
    if(errors.length)throw Error(errors.join('\n'));
    fs.writeFileSync(path.join(output,'frames.json'),JSON.stringify({browser:browser.version(),backend:'software WebGL2',errors,shots},null,2)+'\n');
    console.log(JSON.stringify({browser:browser.version(),captures:shots.length,errors}));
  } finally {await browser.close()}
}
main().catch(error=>{console.error(error);process.exitCode=1});
