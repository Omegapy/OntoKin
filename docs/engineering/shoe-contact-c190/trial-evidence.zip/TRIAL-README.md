# C190-R2 trial evidence

This archive preserves newly executed recovery replication evidence after the original C190 result artifacts were unavailable. See the repository README and results.json beside this archive for conclusions and limits.

Run `python -IB replay.py` from the extracted root with CPython 3.12.14, NumPy 2.3.5 and Node 24.22.1. This validates seals, checker controls, all six expected outcomes, raw/final GLBs and Three.js readback. Pinned native OntoKin source, Three.js and the Khronos validator are included. The NumPy wheel is supplied in the full user handoff, not this repository archive.

Native rebuilds require fresh output paths; see audit/ontokin/README.md and audit/blender/README.md. Blender 4.5.3 LTS build 67807e1800cc is separately installed. Its official Linux archive SHA-256 is 975c58fcb244273838534bba771e64ad87739216b0f9b39a888531a49a72d845. Tool provenance is in evidence/recovery/blender-provenance.json.

The final visual evidence is evidence/playback/comparison.png. Extract the adjacent render-evidence.zip into this same root for all 18 final frames and the preserved lighting attempt. These are actual GLB CPU renders with the fixed C187 camera, not browser captures or re-simulation. Raw native Blender motion and its disclosed final projection remain separate. The first failed Blender submission is preserved. Expected OntoKin contact failures are evidence of its current unsupported capability.

TRIAL-MANIFEST.json hashes every other member; all paths are relative to this root. Native scripts and original receipts retain historical source paths; portable audit instructions resolve the included files.
