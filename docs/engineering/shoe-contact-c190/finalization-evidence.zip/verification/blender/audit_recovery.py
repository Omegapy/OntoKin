"""Read-only audit of surviving C190 Blender evidence; outputs stay beside this file."""
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
import csv
import hashlib
import json
import math
import struct
import subprocess
import sys

ROOT = Path('/workspace/scratch/d0b9f6a77602/c190')
OUT = Path(__file__).resolve().parent
DEL = ROOT/'deliveries/blender'
COMP = ROOT/'evidence/completion/verification/blender'
NEW = COMP/'replay'
OLD = ROOT/'evidence/blender-audit'
BIN = Path('/workspace/scratch/eb7f3f78ef8f/toolchain/blender-4.5.3-linux-x64/blender')
STABLE = ('raw.glb', 'final.glb', 'native-transforms.json', 'native-trace.csv', 'native-summary.json')

def read(p): return json.loads(p.read_text())
def sha(p):
    with p.open('rb') as f: return hashlib.file_digest(f, 'sha256').hexdigest()
def write(name, data): (OUT/name).write_text(json.dumps(data, indent=2, allow_nan=False)+'\n')
def inventory():
    files=set()
    for rel in ('deliveries/blender','submissions/blender-1','audit/blender','checker','evidence/blender-audit','evidence/completion/verification/blender'):
        files.update(p for p in (ROOT/rel).rglob('*') if p.is_file())
    files.update(ROOT/p for p in ('README-START-HERE.md','HANDOFF-C190.md','COMPLETION-C190.md','RECOVERY-C190.md','evidence/dispatch.json'))
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}
def seal(p):
    checks=[]
    for line in p.read_text().splitlines():
        if not line.strip(): continue
        expect, name=line.split(None,1); name=name.lstrip(' *')
        found=sha(p.parent/name)
        checks.append({'path':str((p.parent/name).relative_to(ROOT)),'sha256':found,'matched':found==expect})
    assert all(c['matched'] for c in checks), p
    return {'manifest':str(p.relative_to(ROOT)),'manifestSha256':sha(p),'filesVerified':len(checks)}
def fields(a,b,path=''):
    if type(a)!=type(b): return [path]
    if isinstance(a,dict):
        return [q for k in sorted(a.keys()|b.keys()) for q in (fields(a[k],b[k],path+'/'+k) if k in a and k in b else [path+'/'+k])]
    if isinstance(a,list):
        if len(a)!=len(b): return [path]
        return [q for i,(v,w) in enumerate(zip(a,b)) for q in fields(v,w,path+'/'+str(i))]
    return [] if a==b else [path]
def same(a,b):
    ah,bh=sha(a),sha(b); assert ah==bh,(a,b)
    return {'first':str(a.relative_to(ROOT)),'second':str(b.relative_to(ROOT)),'sha256':ah}
def decode(p):
    data=p.read_bytes(); assert struct.unpack_from('<4sII',data)==(b'glTF',2,len(data))
    n,kind=struct.unpack_from('<II',data,12); assert kind==0x4e4f534a
    doc=json.loads(data[20:20+n]); m,kind=struct.unpack_from('<II',data,20+n)
    binary=data[28+n:]; assert kind==0x004e4942 and m==len(binary)
    return doc,binary

def accessor(doc,binary,index):
    a=doc['accessors'][index]; assert a['componentType']==5126
    w={'SCALAR':1,'VEC3':3,'VEC4':4}[a['type']]; v=doc['bufferViews'][a['bufferView']]
    start=v.get('byteOffset',0)+a.get('byteOffset',0); stride=v.get('byteStride',w*4)
    pos=[start+i*stride for i in range(a['count'])]
    return [struct.unpack_from('<'+'f'*w,binary,p) for p in pos],pos

def mapping(folder):
    a,ab=decode(folder/'raw.glb'); b,bb=decode(folder/'final.glb'); expected=deepcopy(a)
    channels=a['animations'][0]['channels']; removed=[c for c in channels if c['target']['path']=='rotation']
    assert len(removed)==1 and a['nodes'][removed[0]['target']['node']]['name']=='left_carriage'
    expected['animations'][0]['channels']=[c for c in channels if c not in removed]
    assert expected==b and len(ab)==len(bb)
    changes=[]; allowed=set(); tracks={}
    native=read(folder/'native-transforms.json')
    for c in b['animations'][0]['channels']:
        assert c['target']['path']=='translation'
        name=b['nodes'][c['target']['node']]['name']; s=b['animations'][0]['samplers'][c['sampler']]
        av,pos=accessor(a,ab,s['output']); bv,pos2=accessor(b,bb,s['output']); assert len(av)==481 and pos==pos2
        xbytes=b''.join(ab[p:p+4] for p in pos); assert xbytes==b''.join(bb[p:p+4] for p in pos)
        assert all(x[0]==n['matrices_blender_m'][name][0][3] for x,n in zip(av,native))
        for i,(v,w) in enumerate(zip(av,bv)):
            for axis in (1,2):
                if v[axis]!=w[axis]:
                    assert name=='left_carriage' and w[axis]==av[0][axis]
                    allowed.update(range(pos[i]+4*axis,pos[i]+4*axis+4))
                    changes.append({'sample':i,'axis':'XYZ'[axis],'beforeM':v[axis],'afterM':w[axis]})
        at,tp=accessor(a,ab,s['input']); bt,tq=accessor(b,bb,s['input']); assert at==bt and tp==tq
        timebytes=b''.join(ab[p:p+4] for p in tp); assert timebytes==b''.join(bb[p:p+4] for p in tp)
        assert all(struct.unpack('<f',struct.pack('<f',n['time_s']))[0]==t[0] for n,t in zip(native,at))
        tracks[name]={'samples':len(av),'xFloatBytesIdentical':True,'xEqualsNativeMatrix':True,'timeFloatBytesIdentical':True,'timesEqualNativeWhenFloat32Encoded':True,'xSha256':hashlib.sha256(xbytes).hexdigest(),'timeSha256':hashlib.sha256(timebytes).hexdigest()}
    offsets=[i for i,(x,y) in enumerate(zip(ab,bb)) if x!=y]
    assert len(changes)==3 and set(offsets)<=allowed
    rs=a['animations'][0]['samplers'][removed[0]['sampler']]; qs,_=accessor(a,ab,rs['output'])
    angles=[math.degrees(2*math.atan2(math.sqrt(sum(q[i]*q[i] for i in range(3))),abs(q[3]))) for q in qs]
    return {'rawSha256':sha(folder/'raw.glb'),'finalSha256':sha(folder/'final.glb'),'onlyJsonEdit':'Removed left-carriage rotation channel','transverseFloatChanges':changes,'changedBinaryByteOffsets':offsets,'allOtherBinaryBytesIdentical':True,'tracks':tracks,'maximumRawQuaternionRotationDeg':max(angles)}

def native_metrics(folder,stop):
    d=read(folder/'native-transforms.json'); assert len(d)==481
    assert all(n['frame']==i and n['time_s']==i/240 for i,n in enumerate(d))
    rows=list(csv.DictReader((folder/'native-trace.csv').open())); assert len(rows)==481
    result={'stopNearFaceMm':stop,'samples':len(d),'captureFps':240,'nominalNativeStepS':1/2400,'lanes':{}}
    ideal=(stop-180)/125
    for lane in ('left','right'):
        x=[n['matrices_blender_m'][lane+'_carriage'][0][3]*1000 for n in d]
        travel=[v-x[0] for v in x]; gap=[n['bounds_gltf_mm'][lane+'_stop'][0][0]-n['bounds_gltf_mm'][lane+'_shoe'][1][0] for n in d]
        vel=[None]+[(b-a)*240 for a,b in zip(x,x[1:])]
        for i,row in enumerate(rows):
            assert float(row[lane+'_carriage_travel_mm'])==travel[i]
            assert float(row[lane+'_gap_mm'])==gap[i]
            if i: assert float(row[lane+'_vx_fd_mm_s'])==vel[i]
        post=[v for n,v in zip(d,vel) if n['time_s']>ideal]
        nonzero_post=[i for i in range(1,len(d)) if d[i]['time_s']>ideal and vel[i]!=0]
        m=[n['matrices_blender_m'][lane+'_carriage'] for n in d]
        # atan2(skew norm, trace) remains stable for small angles where acos loses precision.
        rotation=[math.degrees(math.atan2(math.sqrt((a[2][1]-a[1][2])**2+(a[0][2]-a[2][0])**2+(a[1][0]-a[0][1])**2),sum(a[k][k] for k in range(3))-1)) for a in m]
        transverse=max(math.hypot(a[1][3]-m[0][1][3],a[2][3]-m[0][2][3])*1000 for a in m)
        result['lanes'][lane]={'finalTravelMm':travel[-1],'finalGapMm':gap[-1],'minimumGapMm':min(gap),'firstGeometricContactSampleS':next((n['time_s'] for n,g in zip(d,gap) if abs(g)<=.01),None),'postIdealContactVelocityRangeMmPerS':[min(post),max(post)],'maximumRotationDegFromMatrices':max(rotation),'maximumTransverseDisplacementMm':transverse,'maximumBackwardCorrectionMm':max(travel)-travel[-1],'firstSampleAfterLastNonzeroPostContactVelocityS':d[max(nonzero_post)+1]['time_s'] if nonzero_post and max(nonzero_post)+1<len(d) else None,'traceExactlyMatchesMatricesAndBounds':True}
    return result

before=inventory(); write('source-hashes-before.json',before)
seals=[seal(DEL/'SHA256SUMS'),seal(COMP/'SHA256SUMS'),seal(ROOT/'submissions/blender-1/SHA256SUMS')]
# The previous reviewer hash inventory is a separate 161-file source receipt.
prior_hashes=read(COMP/'source-hashes-before.json'); assert prior_hashes==read(COMP/'source-hashes-after.json')
assert all(before[k]==v for k,v in prior_hashes.items())
formal=[]
for case in ('stop-380','stop-355'):
    for repeat in ('a','b'):
        for name in STABLE: formal.append(same(DEL/case/name,NEW/('formal-'+repeat)/case/name))
third=[same(NEW/'third-stop/replay-a'/name,NEW/'third-stop/replay-b'/name) for name in STABLE]
assert read(NEW/'third-stop/settings.json')=={'left_stop_near_face_mm':367.5}
assert read(DEL/'settings/stop-380.json')=={'left_stop_near_face_mm':380.0}
assert read(DEL/'settings/stop-355.json')=={'left_stop_near_face_mm':355.0}
preserved=[same(ROOT/'submissions/blender-1'/case/name,DEL/case/name) for case in ('stop-380','stop-355') for name in ('scene.blend','raw.glb','native-transforms.json','native-trace.csv','native-summary.json')]
prior_matches=[]; representation=[]; excluded=[]
for p in sorted(NEW.rglob('*')):
    if not p.is_file(): continue
    rel=p.relative_to(NEW)
    if p.suffix=='.blend' or rel.parts[0]=='commands' or str(rel) in ('commands.json','summary.json'):
        excluded.append(str(rel)); continue
    old=OLD/rel
    assert old.is_file(),old
    if p.read_bytes()==old.read_bytes(): prior_matches.append(str(rel))
    else:
        assert p.suffix=='.json' and read(p)==read(old),(p,old)
        representation.append({'path':str(rel),'oldSha256':sha(old),'completionSha256':sha(p),'decodedJsonEqual':True})
summary=read(NEW/'summary.json'); previous=read(OLD/'summary.json'); summary.pop('completedAtUtc');previous.pop('completedAtUtc');assert summary==previous
commands=read(NEW/'commands.json'); prior_commands=read(OLD/'commands.json')
assert len(commands)==18 and [(x['label'],x['returncode']) for x in commands]==[(x['label'],x['returncode']) for x in prior_commands]
assert all(x['returncode'] in x['allowedReturncodes'] for x in commands)
assert read(COMP/'invocation.json')['returncode']==0
case_results={}
for case,stop,folder in [('stop-380',380,DEL/'stop-380'),('stop-355',355,DEL/'stop-355'),('stop-367.5',367.5,NEW/'third-stop/replay-a')]:
    final=read(NEW/(case+'-final-acceptance.json'));raw=read(NEW/(case+'-raw-acceptance.json'))
    assert final['pass'] and not raw['pass'] and raw['reason']=='time-varying rotation outside translation-only profile'
    assert final['candidateSha256']==sha(folder/'final.glb') and raw['candidateSha256']==sha(folder/'raw.glb')
    case_results[case]={'native':native_metrics(folder,stop),'mapping':mapping(folder),'recordedFinalAcceptance':True,'recordedRawRejection':raw['reason'],'projectionBoundMm':next(x['maximumContinuousRawToFinalVertexDeviationBoundMm'] for x in summary['projectionAudits'] if x['case']==case)}
base=NEW/'native-control/baseline';removed=NEW/'native-control/removed-left-shoe-collider'
bc=read(base/'configuration-before.json');rc=read(removed/'configuration-before.json');assert bc==rc
assert read(base/'configuration-after.json')==bc
changed=fields(bc,read(removed/'configuration-after.json')); assert set(changed)=={'/objects/left_shoe/rigidBody','/world/bodyCollection'}
bd,rd=read(base/'transforms.json'),read(removed/'transforms.json');assert len(bd)==len(rd)==481
unchanged={name:all(a['parts'][name]==b['parts'][name] for a,b in zip(bd,rd)) for name in ('base','left_stop','right_carriage','right_shoe','right_stop')};assert all(unchanged.values())
causal={}
for label,data,folder in [('baseline',bd,base),('removedLeftShoeCollider',rd,removed)]:
    out={};recorded=read(folder/'summary.json');ideal=recorded['idealContactS']
    for lane in ('left','right'):
        x=[r['parts'][lane+'_carriage']['matrixBlenderM'][0][3]*1000 for r in data]
        gaps=[r['parts'][lane+'_stop']['boundsGltfMm'][0][0]-r['parts'][lane+'_shoe']['boundsGltfMm'][1][0] for r in data]
        v=[(b-a)*240 for a,b in zip(x,x[1:])];post=[val for r,val in zip(data[1:],v) if r['timeS']>ideal]
        out[lane]={'finalTravelMm':x[-1]-x[0],'finalGapMm':gaps[-1],'minimumGapMm':min(gaps),'postIdealContactVelocityRangeMmPerS':[min(post),max(post)]}
        assert all(recorded['lanes'][lane][k]==val for k,val in out[lane].items())
    causal[label]=out
causal.update({'onlyConfigurationChanges':changed,'unchangedNativePartsBitIdentical':unchanged})
assert bc['world']['cacheIsBaked']==False and bc['world']['fps']==240 and bc['world']['substepsPerFrame']==10 and bc['world']['solverIterations']==100
for lane in ('left','right'):
    body=bc['objects'][lane+'_carriage'];shoe=bc['objects'][lane+'_shoe'];guide=bc['objects']['_'+lane+'_generic'];motor=bc['objects']['_'+lane+'_motor']
    assert body['rigidBody']['collision_shape']=='COMPOUND' and body['rigidBody']['mass']==1 and body['action'] is None and not body['drivers']
    assert shoe['rigidBody']['collision_shape']=='BOX' and shoe['parent']==lane+'_carriage'
    assert not guide['constraint']['use_limit_lin_x']
    drive,=motor['drivers'];assert drive['expression']=='-speed_mm_s / 1000.0' and drive['variables'][0]['targets'][0]['id']==lane+'_carriage'
assert sha(BIN)=='5e15447670804c855fef6033ac9b8fd82696b762095becf0df79b1c2f8034397'
v=subprocess.run([str(BIN),'--version'],capture_output=True,text=True)
assert v.returncode==0 and 'Blender 4.5.3 LTS' in v.stdout and '67807e1800cc' in v.stdout
write('native-version.json',{'argv':[str(BIN),'--version'],'returncode':v.returncode,'stdout':v.stdout,'stderr':v.stderr,'executableSha256':sha(BIN)})
after=inventory();write('source-hashes-after.json',after);assert before==after
report={'auditVersion':'C190-surviving-Blender-evidence-2026-11-10','checkedAtUtc':datetime.now(timezone.utc).isoformat(),'scope':'Read-only recovery verification; no new authoring trial, rebuild or runtime change. Existing sufficient native tests reused.','sourceRoot':str(ROOT),'ownedOutputDirectory':str(OUT),'result':'Surviving Blender recovery evidence is complete and internally consistent within its stated scope.','materialDiscrepancies':[],'integrity':{'sourceFilesUnchanged':len(before),'seals':seals,'priorSourceInventoryMatches':len(prior_hashes),'installedBlenderSha256':sha(BIN)},'observedPriorNativeExecution':{'formalBuilds':4,'twoPerFormalSetting':True,'thirdStopSavedSceneReplays':2,'nativeColliderControlRuns':2,'outerAuditExit':0,'subprocesses':len(commands),'successfulSubprocesses':sum(c['returncode']==0 for c in commands),'expectedRawProfileRejections':sum(c['returncode']==1 for c in commands),'labelsAndExits':[{'label':c['label'],'returncode':c['returncode']} for c in commands]},'freshReadOnlyChecks':{'formalStableComparisons':formal,'thirdStopStableComparisons':third,'submissionOneNativeEvidencePreserved':preserved,'priorAuditComparableFilesByteIdentical':len(prior_matches),'priorAuditRepresentationDifferences':representation,'priorAuditSemanticSummaryEqualExceptTimestamp':True,'sourceFilesUnchanged':True},'cases':case_results,'causalControl':causal,'sourceInspection':{'nativeSceneSavedBeforeCapture':True,'sequentialUnbakedNativeEvaluation':True,'oneStopPropertyEditNoGeometryRebuild':True,'noCarriageTransformAnimationOrDriver':True,'constantIndependentFeedMotorsAndUnboundedXGuides':True,'projectionNoStopTimeOrDistanceInput':True},'limits':['These checks confirm the surviving C190-R2 recovery replication, not the older unavailable original trial.','The third stop is supported as a coordinator-authored independent saved-scene edit; no blind-study claim is supported or made.','Native contact timestamps and velocities are pose-derived, not Bullet manifold times or impulses.','Native residual rotation and post-contact correction remain present in raw exports; only projected finals satisfy the translation-only playback profile.','The continuous projection bound covers exported interpolation, not unrecorded native substeps.','Blend serialization is not asserted byte-identical across separate processes.','No new native builds were needed because complete logged repeat builds and controls survive, with unchanged inputs and direct record recomputation.','Historical comparison scripts and invocation receipts retain original execution paths; use the portable audit entry point to reproduce after relocation.']}
write('AUDIT.json',report)
print(json.dumps({'result':report['result'],'sourceFilesUnchanged':len(before),'seals':seals,'formalComparisons':len(formal),'thirdComparisons':len(third),'priorAuditByteMatches':len(prior_matches),'semanticJsonDifferences':len(representation),'nativeCases':{case:result['native']['lanes']['left'] for case,result in case_results.items()},'materialDiscrepancies':[]},indent=2))
