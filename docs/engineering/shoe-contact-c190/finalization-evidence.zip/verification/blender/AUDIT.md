# C190 Blender surviving-evidence audit

**Result: the surviving Blender C190-R2 recovery result is complete and internally consistent for its stated scope. No material discrepancy was found.** This is recovery verification of existing results, not a new authoring trial or formal submission.

Source package: `/workspace/scratch/d0b9f6a77602/c190`. All new files are confined to `/workspace/scratch/9a70819518c4/verification/blender`. The machine-readable receipt is [AUDIT.json](AUDIT.json); exact input hashes are in [source-hashes-before.json](source-hashes-before.json) and the identical [source-hashes-after.json](source-hashes-after.json). The read-only verification script is [audit_recovery.py](audit_recovery.py).

## What was already completed

The recovered completion audit has a successful outer process receipt, eighteen logged subprocesses, source/output seals, four formal native builds (two each at 380 and 355 mm), two independent saved-scene replays at 367.5 mm, and two native collider controls. Fifteen subprocess exits were zero; the three expected raw-GLB profile rejection exits were one. These labels and outcomes also match the preceding audit.

Fresh read-only checks in this review verified all 50 accepted-delivery files, all 123 completion-review files, and all 46 preserved first-submission files against their respective SHA-256 seals. All 448 inventoried source/evidence files remained unchanged. The earlier 161-file before/after source inventory also matches the surviving package exactly.

All 20 stable comparisons between formal rebuilds and sealed delivery pass. All five third-stop repeat comparisons pass. Compared with the preceding audit, 61 files remain byte-identical; three raw/final JSON reports differ only in serialization order and have exactly equal decoded contents. Summary outcomes match after excluding the completion timestamp. The ten original native evidence files across the two formal cases—including both editable scenes—are unchanged between submissions one and two.

No additional native builds were needed. The complete repeated native tests survive, their inputs and results match the seals, and their reported motion can be independently recomputed from the preserved matrices. The installed Blender executable was checked by hash and `--version`: **4.5.3 LTS, build `67807e1800cc`**, SHA-256 `5e15447670804c855fef6033ac9b8fd82696b762095becf0df79b1c2f8034397`. No runtime or repository changes were made.

## Native collision, residual velocity and rotation

The following values were independently recomputed from all 481 native matrices per case. The trace CSVs match those matrices and geometric bounds exactly. Contact time is the first recorded shoe/stop gap within 0.01 mm, not a Bullet manifold timestamp.

| Left stop, mm | First contact sample, s | Final left travel, mm | Post-contact finite-difference velocity, mm/s | Maximum native rotation, degrees |
| ---: | ---: | ---: | ---: | ---: |
| 380 | 1.6 | 200.000002980232 | -1.730918884 to 1.505613327 | 0.015816137854 |
| 355 | 1.4 | 174.999997019768 | -1.730918884 to 1.505613327 | 0.015816211863 |
| 367.5 | 1.5 | 187.499985098839 | -1.730918884 to 1.502037048 | 0.015816381392 |

Each case has a maximum sampled native penetration of **0.007003545761 mm**, maximum transverse carriage displacement of **0.001810491085 mm**, and maximum backward correction of **0.007584691048 mm**. All recorded left X velocities are zero from **25 ms after the contact sample** through the end. The native halt therefore includes the explicitly disclosed short numerical correction. It is not an exact zero-velocity, fixed-rotation state immediately at impact.

The collider control supports causality. With the shoe collision component, left final travel is **200.000002980232 mm**. Removing only that component produces **250.000000000000 mm** travel and continued post-event speed of **124.998092651367–125.001668930054 mm/s**. Configuration snapshots differ only in the removed left-shoe rigid-body component and its removal from the world body collection. The base, left stop, right carriage, right shoe and right stop records are bit-identical between the two variants.

Source and configuration inspection support an unbaked native solve with two independent feed motors, active compound carriage bodies, shoe BOX collision children, and X-unbounded guides. The native scene is saved before simulation; neither carriage has transform animation or a transform driver. Saved-scene replay changes only `near_face_mm` and sequentially evaluates frames 0–480 without rebuilding geometry or constraints. The native world records at 240 Hz and uses ten substeps per frame and 100 solver iterations, giving a nominal native step of 1/2400 second.

## Independent 367.5 mm edit

The coordinator-authored setting contains exactly `{"left_stop_near_face_mm": 367.5}`. Both logged processes reopen the sealed 380 mm `.blend` scene and use the saved-scene replay path. All five stable files match across repeats and also match the preceding audit. This supports an independent one-property edit and recomputed stopping position. It does not establish a blind-study claim; the recovery record already discloses prior-outcome information.

## Raw simulation versus final playback

All three raw GLBs retain the declared rejection, `time-varying rotation outside translation-only profile`. All three projected final GLBs have passing receipts against the unchanged checker, each bound to the matching candidate SHA-256.

A new standard-library decoder verified the projection directly for all three cases. Its sole semantic JSON change removes the left-carriage rotation channel. Exactly three transverse Y float fields return to their initial guide coordinate: samples 385–387 at 380 mm, 337–339 at 355 mm, and 361–363 at 367.5 mm. All other binary bytes are unchanged. Every carriage X float is identical to the native matrix's X value; all 481 raw/final timestamps per lane are bit-identical and equal the native timestamp after float32 encoding. The mapper has no contact-time or stop-distance input.

The preserved independent projection audit bounds maximum continuous raw-playback-to-final deviation at **0.056595812450493 mm** across these three cases. The maximum projected-final near-face penetration, **0.007583759725094 mm**, differs slightly from the native-bound penetration because the projection removes native guide rotation. Both are explicitly retained as separate measurements.

## Exact source identities

The complete 448-file inventory is in the two hash receipts. Key sources and native scene identities are:

| Source relative to package root | SHA-256 |
| --- | --- |
| `deliveries/blender/build.py` | `7869fb8440ff849120fd342819f8ae6143e495f1a5f166c87b7127fbae08a4b8` |
| `deliveries/blender/replay.py` | `693e20714f4dc6c8d49533d77660ae0126adb09a03c56103f4795e03e7623936` |
| `deliveries/blender/map_playback.py` | `c6d590c6a9306e83752e4de20e6f2007c64bc522cac59dd353631698dc168b59` |
| `audit/blender/probe_native.py` | `7bb598c76324e19fa92a874f0f3f29053fdc340d0052d3072cd3bf129525602f` |
| `audit/blender/replay.py` | `64937d004fbb5ed53634ee690a049162fd3287970405b7c4fccccc9731cba69f` |
| `deliveries/blender/source/c189-feed-125.blend` | `a778e94196e35e2c27b939ca2b143f6426fd11e0487147328de2d9e3837d9b72` |
| `deliveries/blender/stop-380/scene.blend` | `d88c0ce1238421882514fb29dfc97b2a5dcb8923ffc7e9cf414e5866d27a947b` |
| `deliveries/blender/stop-355/scene.blend` | `c03dac23e6cd36a151fb1771a7f60e54141985d20c4b165cec5f0dc8228c3742` |
| `evidence/completion/verification/blender/replay/third-stop/settings.json` | `fb2a2abd6c61713eed1efde603db39640f078e6991e2982d743042199536da60` |

## Remaining limits

This evidence confirms C190-R2; it cannot recover or certify the older unavailable C190 trial. Contact flags and velocities are derived from recorded poses. No Bullet contact manifolds, normal impulses, or unrecorded native substep positions were measured. The continuous projection bound covers the exported interpolation. The high-impulse feed motor remains a bounded contact demonstration, not a calibrated actuator-force model. Native `.blend` serialization is not claimed byte-identical across separate processes. Historical receipts retain their original execution paths; the package's portable native-audit entry point is the supported reproduction path after relocation.
