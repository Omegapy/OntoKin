# C190 recovered evaluator and evidence audit

The recovered numerical and receiving-format evidence passes fresh read-only verification. This is a recovery audit, not another participant trial.

## Verified

- CPython 3.12.14, NumPy 2.3.5 and Node v24.22.1 executed `python -IB replay.py` successfully.
- All 104 frozen checker entries, 209 native-runtime files, 50 accepted Blender files, 48 OntoKin files and 46 failed-first Blender files matched their seals.
- All 45 trajectory controls and three swept-intersection controls reproduced. All six expected outcomes matched: three Blender final-playback passes and three OntoKin contact failures.
- Twelve raw/final GLBs passed structural validation with zero errors/warnings; the three Blender projected finals retain their disclosed informational unused sampler. Three.js reproduced six clips and eighteen selected poses.
- All twelve output hashes match the published results. Each raw Blender file still fails with `time-varying rotation outside translation-only profile`; no acceptance rule changed.
- Trial, render, completion and frozen-checker archives have valid CRCs, safe paths and no mismatched shared files. All 106 frozen-checker archive members match `checker/`.
- The original four C190 checkpoint files remain byte-identical to commit `0eadf3e42feff552ded597447e3db8e83a8b6e12`. The recovery freeze hash agrees across results and dispatch. Its recorded time precedes every submission seal.

## Completion still needed at inspection

The surviving local repository is clean at publication commit `dc0aa56e77eebb236f7ed4c5ad1272b114c45881`. That local identity is not proof of the current remote PR or main state. The coordinator must reconcile and finish publication.

The staged handoff lacks `CHECKPOINT-C190.json`, the source snapshot, incremental Git bundle, repository guidance snapshots and package manifest. Complete these from the verified final revision, then validate and save the ZIP. Root-document statements that publication and handoff have finished are provisional until those steps succeed.

## Evidence boundaries

The checker certifies exported geometry and piecewise-linear playback. Native collision causality comes from the separate source/solver and collider-removal audit. Accepted Blender finals project small guide residuals while preserving every carriage X sample and time. The raw files remain preserved and rejected under the strict translation-only profile. OntoKin is an explicit unsupported-contact result in the unchanged native runtime.

The shared environment does not establish blind isolation. No new native rebuild, new browser capture, full regression, hosted CI pass or comparative cost claim is made by this evaluator audit. Route auditors review native reproduction separately.

See `AUDIT.json`, `replay.json`, `integrity.json`, `archive-comparison.json` and `raw-profile-rejections.json` for exact identities and outcomes.
