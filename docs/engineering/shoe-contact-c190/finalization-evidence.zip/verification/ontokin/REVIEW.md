# OntoKin C190 recovery audit

**The surviving OntoKin negative result is intact and reproducible.** The left shoe follows its carriage but has no collision shape or force-transfer relationship. The pinned native profile therefore passes through the stop. This verification found no discrepancy in that scientific result. It did find missing publication/restoration files in the recovered package.

This is recovery verification, not a participant trial, new submission, C191 implementation, or full product regression. Inputs were read from `/workspace/scratch/d0b9f6a77602/c190`; all new files are confined to this audit directory. The machine-readable record is [AUDIT.json](AUDIT.json), with exact inputs, commands, hashes, diagnostics, comparisons, limitations and discrepancies.

## What was actually verified

The focused execution ran on **2026-11-10, 01:23:41–01:23:48 UTC**, with CPython **3.12.14** in the shared Linux environment. It used the unchanged sealed builder for one fresh 380 mm case and both minimal rejection probes. The raw GLB, final GLB, native state and naming-change report matched their preserved counterparts byte for byte. The fresh frozen contact check returned its expected failure: `left: maximum penetration exceeds 0.5 mm`. That expected failure verifies the disclosed limitation; it is not a contact pass. [Commands](commands.json) · [Fresh acceptance](fresh-stop-380-acceptance.json)

Existing repeatability evidence was sufficient for the other cases. The preserved standalone standard-library inspector was rerun against the saved files. It rechecked fourteen stable files across five formal-build directories, four stable files across four third-stop-build directories, and eleven prior audit reports. It freshly decoded all three raw/final GLB pairs and confirmed the unchanged binary data, observed trajectories and continuous clearance of all twenty unrelated visible-part pairs. This audit did not repeat all six earlier native builds. [Rechecked inspection](independent-inspection.json)

Integrity checks verified **48 sealed delivery files**, **209 pinned runtime files**, **105 checker-manifest entries** (including the freeze record; **104 entries** are frozen by that record), and **125 files** in the prior completion verification. All manifests still matched after fresh execution. The 483-file protected inventory was unchanged during this audit. Two differences from the earlier inventory—`HANDOFF-C190.md` and `RECOVERY-C190.md`—match the exact later documentation hashes already disclosed in the preserved verification receipt.

## Exact source and runtime identity

The runtime reports **OntoKin reference 0.4.0**, source **0.22**, profile **`torque-0.1`**, agent protocol **`ontokin.agent/0.22`**, and target **`ontokin.glb/0.22`**.

| Identity | SHA-256 |
| --- | --- |
| Native implementation source | `3e6ef2df6a7e8837050abb949075bff9b65f6a4aa4a9f1587850d7ddd59bce56` |
| 209-file runtime manifest | `937c5ec626aee8dbe7668010143d0825c6559226ccad2cc7d9164cf54f6db24e` |
| Sealed delivery manifest | `ea2fc2bdc6e85001eed8eda4b84d4b4fd7786b21df14f1af738bab57cfedbe95` |
| 380 mm `.ok` source | `f06e93f54442f6e5e6cfcc651dcc967fb6a914dfad15979b378470a7a0167483` |
| 355 mm `.ok` source | `209eae4fd3acf542f89ce86f57a0ac7c91b16ec719e1c707f895de17e3551bbc` |
| 367.5 mm `.ok` source | `8b85869290c42186e8e3d365179416fe83f6d3862445eb59ac771f23963624c2` |

The exact program revisions and raw/final GLB hashes are retained in [AUDIT.json](AUDIT.json). Each source hash matches its native export envelope. The formal and third-stop variants differ from the 380 mm source only in the single left-stop X literal.

## Result and its meaning

| Stop near face | First geometric crossing | Left travel at 2 s | Final left signed gap |
| ---: | ---: | ---: | ---: |
| 380 mm | 1.600000024 s | 250.000007451 mm | −50.000011921 mm |
| 355 mm | 1.399999976 s | 250.000007451 mm | −75.000017881 mm |
| 367.5 mm | 1.500000119 s | 250.000007451 mm | −62.500000000 mm |

These are freshly redecoded preserved outputs. The 380 mm source was also freshly rebuilt. In every case the right carriage travels 300.000004470 mm and retains 15.000008047 mm clearance. The native state keeps the left and right velocities at exactly 0.125 and 0.15 m/s, respectively. The event-boundary list contains only time zero, with no authored stop action.

A negative gap means that the displayed shoe face has advanced past the stop's near face. It is a geometric quantity, not native contact-manifold penetration. Both the source and evaluated state identify each carriage as one 1 kg sphere with radius 20 mm. The visible shoe and stop use `no_body()`. The shoe's `follow` authority determines its pose without ownership or force transfer. The catalog permits only disabled collision and marks contacts unsupported; the state reports contact response unavailable. [Fresh catalog](native-capabilities.json) · [Rechecked states and geometry](independent-inspection.json)

The fresh minimal probes reproduce the complete compared diagnostic envelopes, including source/program identity, source span, phase and blocked result levels:

- `collision = enabled` gives **`OKL-E-NAME`**, binding phase: `Unknown name 'enabled' in this lexical scope.` This is rejection of an unsupported value before a solve.
- Giving a following shoe physical mass gives **`OKL-E-PHYSICAL-DOMAIN`**, elaboration phase: `A follow relation may control only a massless child with no_body().`

Neither probe produces a GLB. Their full envelopes remain under `fresh/collision-enabled/` and `fresh/mass-bearing-follower/`.

For all three cases, export adaptation changes exactly seven mesh-name JSON fields and leaves the complete **30,752-byte binary chunk** unchanged. It does not modify motion. All rotations are identity, and 121 common keys describe two seconds at a requested 60 Hz. The native runtime uses analytical trajectories and an event clock; 60 Hz is recording cadence, not a physics timestep.

## Material recovery discrepancy

The recovered package's completion and restoration text refers to files that do not exist at the inspected location:

- `CHECKPOINT-C190.json`
- `source/snapshot.txt`
- `source/c189-to-c190.bundle`

`source/` contains only `README.md`. The local evidence therefore does not substantiate the prose's claimed final publication state, exact final repository head, or ready-to-deliver restoration bundle. This is separate from the intact native evidence. Remote GitHub state and outgoing archives were outside this subtask; the coordinator must reconcile those claims before final delivery.

## C191 implication

The narrow missing capability is an explicit shoe collision shape owned by the carriage's mass body, a fixed stop collider, and actual solver response that controls carriage motion. Existing massless spatial following does not provide that relationship.

The surviving C191 brief remains a **proposal**, with no adopted new syntax or version. Its appropriate next step is to freeze an experimental source/profile/backend/output contract, then qualify a thin `.ok`-to-pinned-Blender/Bullet adapter. Preserve one mass owner and one solver motion authority per lane. Keep the current 0.22 semantics and historical tests unchanged. Independent fixtures should cover the three contact placements, a disabled-collider pass-through control, stable identity, diagnostics, resource limits and atomic failure. The proposal calls for two fresh subagents in the current shared environment: contract/adapter author and independent fixture reviewer. This audit did not start that implementation.

Continuous geometric bounds apply to exported linear interpolation. No contact manifold, impulse, unrecorded solver behavior, new receiving-application playback, full regression, general contact release or comparative authoring benefit is established here.
