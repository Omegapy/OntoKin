"""Read-only recovery audit, with outputs confined to this directory.

This is verification of surviving C190-R2 evidence, not an authoring trial.
"""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path('/workspace/scratch/d0b9f6a77602/c190')
OUT = Path(__file__).resolve().parent
DELIVERY = ROOT / 'deliveries/ontokin'
RUNTIME = ROOT / 'tools/native'
PRIOR = ROOT / 'evidence/completion/verification/ontokin'


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def verify_manifest(path, base):
    checked = []
    failures = []
    for row in path.read_text().splitlines():
        if not row.strip():
            continue
        expected, relative = row.split(None, 1)
        relative = relative.lstrip(' *')
        candidate = base / relative
        actual = sha(candidate) if candidate.is_file() else None
        checked.append(relative)
        if actual != expected:
            failures.append({'path': relative, 'expected': expected, 'actual': actual})
    return {'manifest': str(path), 'sha256': sha(path), 'files_checked': len(checked),
            'all_match': not failures, 'failures': failures}


def runtime_manifest():
    lines = []
    for p in sorted(RUNTIME.rglob('*')):
        rel = p.relative_to(RUNTIME)
        if p.is_file() and '.git' not in rel.parts and '__pycache__' not in rel.parts and p.suffix != '.pyc':
            lines.append(f'{sha(p)}  {rel.as_posix()}')
    return '\n'.join(lines) + '\n'


def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    started = utc()
    before = runtime_manifest()
    (OUT / 'runtime-before.sha256').write_text(before)
    manifests = [
        verify_manifest(DELIVERY / 'SHA256SUMS', DELIVERY),
        verify_manifest(DELIVERY / 'build/runtime-before.sha256', RUNTIME),
        verify_manifest(ROOT / 'checker/SHA256SUMS', ROOT / 'checker'),
        verify_manifest(PRIOR / 'SHA256SUMS', PRIOR),
    ]
    frozen = read(ROOT / 'checker/FREEZE.json')
    frozen_failures = [name for name, expected in frozen['files'].items()
                       if sha(ROOT / 'checker' / name) != expected]
    assert all(x['all_match'] for x in manifests), manifests
    assert not frozen_failures, frozen_failures
    prior_protected = read(PRIOR / 'protected-inputs-after.json')
    protected_before = {name: sha(ROOT / name) if (ROOT / name).is_file() else None
                        for name in prior_protected}
    documented_changes = {x['path']: x['afterSha256'] for x in
                          read(PRIOR / 'verification-receipt.json')['subsequentCoordinatorDocumentationChanges']}
    deviations = [{'path': name, 'prior': expected, 'current': protected_before[name],
                   'matches_documented_later_change': documented_changes.get(name) == protected_before[name]}
                  for name, expected in prior_protected.items() if protected_before[name] != expected]
    write(OUT / 'protected-inputs-before.json', protected_before)
    assert all(x['matches_documented_later_change'] for x in deviations), deviations

    # Rerun the existing standalone inspector on the sealed and preserved rebuilds.
    # It imports neither entrant measurements nor the frozen contact checker.
    inspection_script = PRIOR / 'inspect_recovery.py'
    inspector = load_module(inspection_script, 'preserved_c190_inspector')
    inspector.OUT = OUT
    inspector.ROOT = ROOT
    inspector.OLD = ROOT / 'evidence/ontokin-audit'
    inspector.NEW = PRIOR / 'replay'
    inspector.DELIVERY = DELIVERY
    inspector.main()
    inspected = read(OUT / 'independent-inspection.json')

    commands = []

    def run(label, argv, expected):
        begin = utc()
        proc = subprocess.run(argv, capture_output=True, text=True, check=False, timeout=90)
        end = utc()
        (OUT / (label + '.stdout.txt')).write_text(proc.stdout)
        (OUT / (label + '.stderr.txt')).write_text(proc.stderr)
        commands.append({'label': label, 'argv': argv, 'cwd': str(ROOT),
                         'started_at_utc': begin, 'finished_at_utc': end,
                         'returncode': proc.returncode, 'expected_returncode': expected})
        write(OUT / 'commands.json', commands)
        assert proc.returncode == expected, (label, proc.returncode, proc.stderr)

    # One fresh formal build and the two minimal probes resolve current execution
    # viability; preserved repeat builds suffice for repeatability and the edit.
    fresh = OUT / 'fresh'
    jobs = [('stop-380', DELIVERY / 'stop-380/main.ok', 0),
            ('collision-enabled', DELIVERY / 'probes/collision-enabled.ok', 2),
            ('mass-bearing-follower', DELIVERY / 'probes/mass-bearing-follower.ok', 2)]
    for label, source, expected in jobs:
        run(label, [sys.executable, '-IB', str(DELIVERY / 'build.py'), str(RUNTIME),
                    str(source), str(fresh / label)], expected)

    fresh_matches = []
    for name in ['native.glb', 'assembly.glb', 'native-state.json', 'export-diff.json']:
        original = DELIVERY / 'build/stop-380' / name
        rebuilt = fresh / 'stop-380' / name
        assert original.read_bytes() == rebuilt.read_bytes(), name
        fresh_matches.append({'path': name, 'sha256': sha(rebuilt)})

    projection = ['outcome', 'achieved_level', 'diagnostics', 'implementation_identity',
                  'source_revision', 'program_revision']
    diagnostic_results = []
    for label in ['collision-enabled', 'mass-bearing-follower']:
        original = read(DELIVERY / 'build/probes' / label / 'export.json')
        rebuilt = read(fresh / label / 'export.json')
        assert {k: original[k] for k in projection} == {k: rebuilt[k] for k in projection}, label
        assert not (fresh / label / 'native.glb').exists()
        diagnostic_results.append({'probe': label, 'stable_envelope_matches': True,
                                   'source_revision': rebuilt['source_revision'],
                                   'program_revision': rebuilt['program_revision'],
                                   'diagnostic': rebuilt['diagnostics'][0], 'glb_produced': False})

    run('fresh-stop-380-acceptance', [sys.executable, '-IB', str(ROOT / 'checker/measure_contact.py'),
        'ontokin', str(fresh / 'stop-380/assembly.glb'), '--stop-mm', '380',
        '--out', str(OUT / 'fresh-stop-380-acceptance.json')], 1)
    acceptance = read(OUT / 'fresh-stop-380-acceptance.json')
    assert not acceptance['pass'] and acceptance['reason'] == 'left: maximum penetration exceeds 0.5 mm'

    sys.path.insert(0, str(RUNTIME))
    from ontokin.agent import implementation_identity
    from ontokin.agent_catalog import catalog
    from ontokin.torque_agent_catalog import torque_interface
    identity = implementation_identity()
    capability_names = {'CollisionMode', 'disabled', 'follow', 'Object.collision', 'sphere_body'}
    capabilities = {'implementation_identity': identity, 'torque_interface': torque_interface(),
                    'core_selected': [x for x in catalog()['items'] if x['name'] in capability_names]}
    write(OUT / 'native-capabilities.json', capabilities)

    source380 = (DELIVERY / 'stop-380/main.ok').read_text()
    source355 = (DELIVERY / 'stop-355/main.ok').read_text()
    source367path = PRIOR / 'replay/third-stop/main.ok'
    source367 = source367path.read_text()
    literal = 'vec3(380[mm], 130[mm], -220[mm])'
    assert source380.count(literal) == 1
    assert source355 == source380.replace(literal, 'vec3(355[mm], 130[mm], -220[mm])')
    assert source367 == source380.replace(literal, 'vec3(367.5[mm], 130[mm], -220[mm])')
    source_identities = []
    for name, source, output in [
        ('stop-380', DELIVERY / 'stop-380/main.ok', DELIVERY / 'build/stop-380'),
        ('stop-355', DELIVERY / 'stop-355/main.ok', DELIVERY / 'build/stop-355'),
        ('stop-367.5', source367path, PRIOR / 'replay/third-stop/build-a'),
    ]:
        envelope = read(output / 'export.json')
        assert envelope['source']['entry_revision'] == 'sha256:' + sha(source)
        source_identities.append({'case': name, 'source_path': str(source), 'source_sha256': sha(source),
            'source_revision': envelope['source']['entry_revision'],
            'program_revision': envelope['program_revision'],
            'raw_glb_sha256': sha(output / 'native.glb'), 'final_glb_sha256': sha(output / 'assembly.glb')})

    after = runtime_manifest()
    (OUT / 'runtime-after.sha256').write_text(after)
    assert before == after
    protected_after = {name: sha(ROOT / name) if (ROOT / name).is_file() else None
                       for name in prior_protected}
    write(OUT / 'protected-inputs-after.json', protected_after)
    assert protected_before == protected_after
    sources_manifest = {str(p.relative_to(ROOT)): sha(p) for p in [
        ROOT / 'README-START-HERE.md', ROOT / 'HANDOFF-C190.md', ROOT / 'COMPLETION-C190.md',
        ROOT / 'next/C191-BRIEF.md', ROOT / 'next/C191-ACCEPTANCE.json',
        DELIVERY / 'SHA256SUMS', PRIOR / 'REVIEW.md', PRIOR / 'SHA256SUMS',
        inspection_script, DELIVERY / 'build.py', ROOT / 'checker/FREEZE.json']}
    missing = [str(p.relative_to(ROOT)) for p in [ROOT / 'CHECKPOINT-C190.json',
               ROOT / 'source/snapshot.txt', ROOT / 'source/c189-to-c190.bundle'] if not p.exists()]
    report = {
        'audit_kind': 'recovery verification of surviving C190-R2 evidence; not a new authoring trial',
        'started_at_utc': started, 'finished_at_utc': utc(), 'evidence_root': str(ROOT),
        'output_root': str(OUT), 'python_executable': sys.executable,
        'python_version': sys.version, 'platform': platform.platform(),
        'result': 'Native negative result verified; no scientific-result discrepancy found',
        'new_trial_or_submission': False, 'runtime_identity': identity,
        'source_bindings': {'language': '0.22', 'profile': 'torque-0.1',
                            'agent_protocol': 'ontokin.agent/0.22', 'target': 'ontokin.glb/0.22'},
        'source_identities': source_identities, 'input_hashes': sources_manifest,
        'manifest_checks': manifests,
        'frozen_checker': {'version': frozen['version'], 'freeze_sha256': sha(ROOT / 'checker/FREEZE.json'),
                           'frozen_entries_checked': len(frozen['files']), 'all_match': not frozen_failures},
        'runtime_files_checked': len(before.splitlines()), 'runtime_unchanged': True,
        'runtime_manifest_sha256': hashlib.sha256(before.encode()).hexdigest(),
        'protected_files_checked': len(protected_before), 'protected_files_unchanged_during_this_audit': True,
        'preserved_record_deviations': deviations,
        'existing_repeatability_receipts_rechecked': {
            'formal_directories': inspected['formalDirectoriesCompared'],
            'formal_stable_files_per_directory': inspected['formalStableFilesPerDirectory'],
            'third_stop_directories': inspected['thirdDirectoriesCompared'],
            'third_stable_files_per_directory': inspected['thirdStableFilesPerDirectory'],
            'prior_reports_byte_identical': len(inspected['byteIdenticalAuditReports']),
            'reused_inspector_path': str(inspection_script), 'reused_inspector_sha256': sha(inspection_script)},
        'fresh_execution': {'formal_builds': 1, 'native_state_inspections': 1, 'minimal_probes': 2,
                            'frozen_contact_checks': 1, 'all_expected_returncodes': True,
                            'stable_files_matched': fresh_matches,
                            'contact_acceptance': {k: acceptance[k] for k in
                                ['version', 'stopNearFaceMm', 'candidateSha256', 'pass', 'reason', 'scope', 'contact']},
                            'full_contact_report': 'fresh-stop-380-acceptance.json'},
        'diagnostic_probes': diagnostic_results,
        'cases': [{'case': x['case'], 'left': x['lanes']['left'], 'right': x['lanes']['right'],
                   'keys': x['keys'], 'maximum_recorded_interval_s': x['maxIntervalS'],
                   'binary_bytes_unchanged': x['binaryBytes'], 'exact_mesh_name_changes': len(x['jsonPatches']),
                   'all_twenty_unrelated_pairs_continuously_clear': x['allTwentyUnrelatedPairsContinuouslyClear'],
                   'native_contact_response': x['nativeContactResponse'], 'event_boundaries_s': x['nativeBoundaryTimesS']}
                  for x in inspected['cases']],
        'narrow_missing_capability': 'An inspectable shoe collision shape bound to the carriage mass owner, fixed stop colliders, and solver-controlled contact response. Existing follow is massless pose following without ownership or force transfer.',
        'c191_next_step': 'Adopt a bounded experimental source/profile/backend/output contract, then qualify a thin source-to-pinned-Blender/Bullet adapter with one mass owner and one solver motion authority per lane. Freeze independent A/B/C contact, D collider-disabled, identity, diagnostic, resource and atomic-failure fixtures. Keep existing 0.22 bindings and tests unchanged.',
        'c191_status': read(ROOT / 'next/C191-ACCEPTANCE.json')['status'],
        'material_discrepancies': [{'kind': 'recovered_package_completeness', 'missing': missing,
            'consequence': 'Completion/restoration prose refers to absent final-publication evidence; this local package does not establish the claimed final GitHub head or ready-to-deliver archive.'}] if missing else [],
        'limitations': [
            'This audits surviving R2 recovery evidence; it does not recover the unavailable original C190 trial.',
            'The reused inspector freshly checks preserved bytes; this audit does not rerun all six prior native builds.',
            'Geometric signed gaps and GLB interpolation bounds are not native contact manifolds or impulses.',
            '60 Hz is recording cadence; the analytical runtime has no fixed integration timestep or contact solver.',
            'No runtime, historical test, original delivery, repository, or prior evidence was changed.',
            'No full product regression, new browser playback, rendering, repository publication or remote-head verification was performed.',
            'C191 remains a proposal, not implemented or adopted contact support.'
        ],
    }
    write(OUT / 'AUDIT.json', report)
    print(json.dumps({'result': report['result'], 'manifest_files': [x['files_checked'] for x in manifests],
        'fresh_formal_builds': 1, 'fresh_probes': 2, 'runtime_unchanged': True,
        'missing_publication_files': missing, 'report': str(OUT / 'AUDIT.json')}))


if __name__ == '__main__':
    main()
