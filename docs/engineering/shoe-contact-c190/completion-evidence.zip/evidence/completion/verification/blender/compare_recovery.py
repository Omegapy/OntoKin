"""Read-only comparisons for the second C190 recovery; write only new receipts."""
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import struct

HERE = Path(__file__).resolve().parent
C190 = HERE.parents[1] / 'c190'
NEW = HERE / 'replay'
OLD = C190 / 'evidence/blender-audit'


def read(path):
    return json.loads(path.read_text())


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def write(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False) + '\n')


def decode(path):
    blob = path.read_bytes()
    assert struct.unpack_from('<4sII', blob) == (b'glTF', 2, len(blob))
    size, kind = struct.unpack_from('<II', blob, 12)
    assert kind == 0x4e4f534a
    doc = json.loads(blob[20:20 + size])
    nbytes, kind = struct.unpack_from('<II', blob, 20 + size)
    assert kind == 0x004e4942
    binary = blob[28 + size:]
    assert len(binary) == nbytes
    return doc, binary


def floats(doc, blob, index):
    acc = doc['accessors'][index]
    assert acc['componentType'] == 5126 and 'sparse' not in acc
    width = {'SCALAR': 1, 'VEC3': 3, 'VEC4': 4}[acc['type']]
    view = doc['bufferViews'][acc['bufferView']]
    start = view.get('byteOffset', 0) + acc.get('byteOffset', 0)
    stride = view.get('byteStride', 4 * width)
    offsets = [start + i * stride for i in range(acc['count'])]
    return [struct.unpack_from('<' + 'f' * width, blob, p) for p in offsets], offsets


def inspect_mapping(folder):
    raw, rb = decode(folder / 'raw.glb')
    final, fb = decode(folder / 'final.glb')
    assert len(rb) == len(fb)
    assert len(raw['animations']) == len(final['animations']) == 1
    expected = deepcopy(raw)
    channels = expected['animations'][0]['channels']
    removed = [c for c in channels if c['target']['path'] == 'rotation']
    assert len(removed) == 1
    assert raw['nodes'][removed[0]['target']['node']]['name'] == 'left_carriage'
    expected['animations'][0]['channels'] = [c for c in channels if c not in removed]
    assert expected == final, 'Unexpected JSON edit beyond removal of left rotation channel'
    allowed, changed_values, x_tracks, time_tracks = set(), [], {}, {}
    for channel in final['animations'][0]['channels']:
        target = channel['target']
        assert target['path'] == 'translation'
        name = final['nodes'][target['node']]['name']
        sampler = final['animations'][0]['samplers'][channel['sampler']]
        x, pos = floats(raw, rb, sampler['output'])
        y, pos2 = floats(final, fb, sampler['output'])
        assert pos == pos2 and len(x) == len(y) == 481
        xb = b''.join(rb[p:p + 4] for p in pos)
        yb = b''.join(fb[p:p + 4] for p in pos)
        assert xb == yb
        x_tracks[name] = {'samples': len(x), 'identicalFloat32Bytes': True,
                         'sha256': hashlib.sha256(xb).hexdigest()}
        for i, (a, b) in enumerate(zip(x, y)):
            for axis in (1, 2):
                if a[axis] != b[axis]:
                    assert name == 'left_carriage' and b[axis] == x[0][axis]
                    allowed.update(range(pos[i] + 4 * axis, pos[i] + 4 * axis + 4))
                    changed_values.append({'node': name, 'sample': i, 'axis': 'XYZ'[axis],
                                           'beforeM': a[axis], 'afterM': b[axis]})
        ta, tp = floats(raw, rb, sampler['input'])
        tb, tq = floats(final, fb, sampler['input'])
        assert ta == tb and tp == tq
        raw_time = b''.join(rb[p:p + 4] for p in tp)
        final_time = b''.join(fb[p:p + 4] for p in tp)
        assert raw_time == final_time
        time_tracks[name] = {'samples': len(ta), 'identicalFloat32Bytes': True,
                            'sha256': hashlib.sha256(raw_time).hexdigest()}
    assert len(changed_values) == 3
    byte_changes = [i for i, (a, b) in enumerate(zip(rb, fb)) if a != b]
    assert set(byte_changes) <= allowed
    return {'rawSha256': digest(folder / 'raw.glb'), 'finalSha256': digest(folder / 'final.glb'),
            'removedChannels': removed, 'onlyJsonChangeIsLeftRotationChannelRemoval': True,
            'transverseFloatChanges': changed_values, 'binaryChangedByteOffsets': byte_changes,
            'allOtherBinaryBytesUnchanged': True, 'xTracks': x_tracks, 'timeTracks': time_tracks}


summary = read(NEW / 'summary.json')
old_summary = read(OLD / 'summary.json')
new_semantic, old_semantic = deepcopy(summary), deepcopy(old_summary)
new_semantic.pop('completedAtUtc')
old_semantic.pop('completedAtUtc')
assert new_semantic == old_semantic, 'Prior and fresh audit outcomes differ'

matches, excluded, mismatches, representation_differences = [], [], [], []
for path in sorted(NEW.rglob('*')):
    if not path.is_file():
        continue
    rel = path.relative_to(NEW)
    if path.suffix == '.blend' or rel.parts[0] == 'commands' or rel.as_posix() in ('commands.json', 'summary.json'):
        excluded.append(rel.as_posix())
        continue
    prior = OLD / rel
    if (prior.is_file() and path.name.endswith('-raw-final.json')
            and path.read_bytes() != prior.read_bytes()
            and read(path) == read(prior)):
        representation_differences.append({'path': rel.as_posix(),
            'priorSha256': digest(prior), 'freshSha256': digest(path),
            'decodedJsonExactlyEqual': True,
            'reason': 'nativeTraceSha256 moved from final key to fourth key; values unchanged'})
    elif not prior.is_file() or path.read_bytes() != prior.read_bytes():
        mismatches.append(rel.as_posix())
    else:
        matches.append({'path': rel.as_posix(), 'sha256': digest(path)})
assert not mismatches, mismatches

prior_commands, fresh_commands = read(OLD / 'commands.json'), read(NEW / 'commands.json')
assert len(prior_commands) == len(fresh_commands) == 18
assert [(v['label'], v['returncode']) for v in prior_commands] == [(v['label'], v['returncode']) for v in fresh_commands]
assert all(v['returncode'] in v['allowedReturncodes'] for v in fresh_commands)

before = read(HERE / 'source-hashes-before.json')
after = {rel: digest(C190 / rel) for rel in before}
assert before == after, 'Recovered sources or seals changed'
write(HERE / 'source-hashes-after.json', after)

native_unchanged_from_submission_one = []
for case in ('stop-380', 'stop-355'):
    for name in ('scene.blend', 'raw.glb', 'native-transforms.json', 'native-trace.csv', 'native-summary.json'):
        a = C190 / 'submissions/blender-1' / case / name
        b = C190 / 'deliveries/blender' / case / name
        assert a.read_bytes() == b.read_bytes()
        native_unchanged_from_submission_one.append({'path': case + '/' + name, 'sha256': digest(b)})
starter = C190.parent / 'c189/drive/deliveries/blender/feed-125.blend'
delivered_starter = C190 / 'deliveries/blender/source/c189-feed-125.blend'
assert starter.read_bytes() == delivered_starter.read_bytes()

mapping = {}
for case, folder in [('stop-380', NEW / 'formal-a/stop-380'),
                     ('stop-355', NEW / 'formal-a/stop-355'),
                     ('stop-367.5', NEW / 'third-stop/replay-a')]:
    mapping[case] = inspect_mapping(folder)
write(HERE / 'independent-mapping-check.json', mapping)

report = {
    'reviewVersion': 'C190-second-crash-recovery-blender-1',
    'completedAtUtc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Recovery verification, not a new authoring trial or formal submission',
    'auditProcessExitCode': read(HERE / 'invocation.json')['returncode'],
    'priorAuditOutcomeExactlyMatchedIgnoringCompletionTime': True,
    'priorAuditComparison': {'stableFilesByteIdentical': matches, 'mismatches': mismatches,
                             'reportSerializationDifferences': representation_differences,
                             'excludedPathOrSessionDependentFiles': excluded,
                             'all18ProcessLabelsAndReturnCodesMatched': True},
    'recoveredInputFilesUnchanged': len(before),
    'c189StarterUnchangedSha256': digest(starter),
    'submissionOneNativeEvidenceUnchangedInSubmissionTwo': native_unchanged_from_submission_one,
    'freshStableComparisonsAgainstDeliverySeal': summary['formalStableComparisons'],
    'freshThirdStopStableComparisons': summary['thirdStopStableComparisons'],
    'formalBuilds': summary['formalBuilds'],
    'thirdStopReplays': summary['independentThirdStopReplays'],
    'colliderControlRuns': summary['colliderControlRuns'],
    'independentMappingCheck': 'independent-mapping-check.json',
    'sourceInspection': {
        'builderSavesNativeSceneBeforeCapture': True,
        'nativeReplayAssertsUnbakedCacheBeforeCapture': True,
        'nativeReplayEditsOnlyNearFaceMmAndDoesNotCallConfigure': True,
        'nativeCaptureSequentiallyEvaluatesFrames0Through480': True,
        'carriagesHaveNoTransformActionsOrDrivers': True,
        'guidesLeaveXTranslationUnbounded': True,
        'twoMotorDriversUseOwnCarriageSpeedProperty': True,
        'projectionHasNoStopTimeOrDistanceInput': True,
        'differenceFromSubmissionOneOnlyAddsFinalMapper': True,
    },
    'nativeColliderControl': read(NEW / 'causal-control.json'),
    'projectionAudits': summary['projectionAudits'],
    'limits': summary['limits'] + [
        'Native .blend serialization was not compared between runs because path and session data can differ',
        'No new authoring trial, external visual validation, or full product regression was run',
        'The earlier unavailable C190 trial is not recovered or certified by this result'],
    'recoverableBlenderResultComplete': True,
}
assert report['auditProcessExitCode'] == 0
write(HERE / 'review.json', report)
print(json.dumps({'status': 'pass', 'stableFilesByteIdenticalToPriorAudit': len(matches),
                  'recoveredInputFilesUnchanged': len(before), 'mismatches': mismatches,
                  'reportSerializationDifferences': len(representation_differences),
                  'priorSummaryMatchedIgnoringCompletionTime': True,
                  'independentMappingCases': len(mapping)}, indent=2))
