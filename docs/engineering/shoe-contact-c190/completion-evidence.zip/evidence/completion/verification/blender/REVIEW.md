# C190 Blender recovery verification

The recovered Blender result is complete for its stated experimental scope. A fresh run of the packaged native audit finished with exit code **0** at **2026-11-10T01:08:30.111032+00:00**. Its outcome matches the previous audit exactly after excluding the completion timestamp. This is verification of recovered evidence, not another authoring trial or formal submission.

The reviewer read the C190 handoff, Blender delivery and audit documentation, the supplied repository guidance, and the builder, saved-scene replay, projection, independent decoder and collider-control sources. All writes were confined to this new verification directory. The 161 files inventoried under recovered `audit/blender`, `deliveries/blender`, and `checker` remained unchanged. The audit verified all 50 files in the Blender delivery seal. [Input verification](replay/input-verification.json) · [before hashes](source-hashes-before.json) · [after hashes](source-hashes-after.json)

## Executed recovery checks

The audit used CPython **3.12.14** and the specified Blender **4.5.3 LTS**, build **67807e1800cc**. The Blender executable hash before and after was `5e15447670804c855fef6033ac9b8fd82696b762095becf0df79b1c2f8034397`.

- Four fresh source builds: two for the 380 mm stop and two for the 355 mm stop. All 20 comparisons of raw GLB, final GLB, native transforms, native trace and native summary matched the sealed delivery bytes.
- Two fresh processes reopened the delivered 380 mm native scene and edited its single stop property to 367.5 mm. All five stable files matched across repeats, and both repeats also matched the corresponding prior audit files.
- All three projected final exports passed the unchanged C190-R2.1 checker. All three raw exports failed with the preserved reason `time-varying rotation outside translation-only profile`.
- Two native causal controls reproduced the left halt with the shoe collider present and continued left motion when only that collider component was removed.
- All 18 subprocess labels and exit codes matched the previous audit: 15 exits were 0 and three expected raw-profile rejection exits were 1. The outer audit process exited 0.

[Outer invocation and status](invocation.json), [all subprocess arguments, timestamps and exits](replay/commands.json), and the corresponding [stdout](audit.stdout.txt) and [stderr](audit.stderr.txt) are preserved. The subprocess logs are under `replay/commands/`.

## Confirmed measurements

The native results below come from evaluated Blender poses. Contact time is the first sampled geometric gap within 0.01 mm, not a Bullet contact-manifold timestamp.

| Stop near face, mm | Native contact sample, s | Native final left travel, mm | Final-playback zero-gap crossing, s |
| ---: | ---: | ---: | ---: |
| 380 | 1.6 | 200.00000298023224 | 1.600002983077006 |
| 355 | 1.4 | 174.99999701976776 | 1.4000029354779557 |
| 367.5 | 1.5 | 187.4999850988388 | 1.4999998882380936 |

For every final export, the last left gap is **0.0000009313225746154785 mm**; maximum near-face penetration is **0.0075837597250938416 mm**; and final right gap is **14.999967999756336 mm**. All 20 unrelated pairs remain continuously clear under the audit's stated 0.001 mm numerical contact tolerance. Each native run records 481 states at 240 Hz; the world uses ten substeps per frame and 100 solver iterations, giving a nominal native step of 1/2400 s. [Summary and per-case observations](replay/summary.json)

In the native 380 mm causal control, left final travel changes from **200.00000298023224 mm** with the shoe collider to **250.0 mm** after collider removal. The corresponding left final gap changes from **0.000029802322387695312 mm** to **−49.99998211860657 mm**. After the ideal event, the collider-removed left lane retains **124.99809265136719–125.00166893005371 mm/s** sampled velocity. The unchanged control has a brief correction of **−1.7309188842773438 to 1.5056133270263672 mm/s** before resting. Native maximum sampled penetration is **0.0070035457611083984 mm**.

Every native transform and bound for the right carriage, right shoe, right stop, base and left stop is bit-identical between causal variants. Right final travel is **300.00001192092896 mm**, its final native gap is **14.999985694885254 mm**, and maximum right-lane bounds difference is exactly **0.0 mm**. The configuration differences contain only the removed left-shoe rigid-body component and its removal from the world body collection. [Causal-control receipt](replay/causal-control.json)

## Causality and truthful projection

Source inspection and saved-scene configuration receipts confirm an active COMPOUND carriage, a shoe BOX collision child, an independent feed MOTOR for each lane, and guides with unbounded X translation. The carriage has no transform action or driver. The motor driver reads its own carriage's constant speed property. The only scene-position driver sets the fixed stop from `near_face_mm`; no elapsed-time or travel-distance branch commands a halt.

The builder saves the native scene at frame zero before capture. Saved-scene replay asserts that the physics cache is unbaked, changes only the stop property, and evaluates frames 0 through 480 sequentially. The independent causal probe also asserts an unbaked cache and evaluates native poses. It does not read the delivered transform records to produce motion. Changing the stop or removing its colliding shoe component changes the resulting solve. These checks support fresh native simulation rather than playback of preserved transform records.

A separate standard-library GLB decoder written for this review verified all three raw/final pairs. The sole JSON change removes the left-carriage rotation channel. Exactly three float fields change in its Y translation: samples 385–387 for 380 mm, 337–339 for 355 mm, and 361–363 for 367.5 mm. Every changed value returns to the initial guide coordinate. All other binary bytes, every carriage X float and all 481 timestamps per lane remain identical. The old rotation sampler and data remain inert. The mapper has no contact-time or target-stop input. [Independent byte-level mapping check](independent-mapping-check.json) · [review comparison source](compare_recovery.py)

| Stop, mm | Maximum recorded raw-to-final vertex change, mm | Maximum recorded native-to-final vertex change, mm | Continuous raw-playback bound, mm |
| ---: | ---: | ---: | ---: |
| 380 | 0.054198648766199196 | 0.054194154300393 | 0.05659517564026058 |
| 355 | 0.054198903870749715 | 0.054194253280466835 | 0.05659536901939741 |
| 367.5 | 0.054199488229782024 | 0.05419448003648714 | 0.056595812450492625 |

The original native scenes, raw GLBs, transforms, traces and native summaries for both formal cases are byte-identical between submission 1 and submission 2. The C189 starter also matches its supplied source, SHA-256 `a778e94196e35e2c27b939ca2b143f6426fd11e0487147328de2d9e3837d9b72`. Thus the disclosed final projection does not hide an X stopping-law rewrite or a revised native solve.

## Prior-evidence comparison and limits

**61 comparable files are byte-identical to the previous audit.** Three `*-raw-final.json` reports differ only in JSON key order: `nativeTraceSha256` moved from the last key to the fourth key. Their decoded fields and all values are exactly equal. The initial strict byte comparison exited 1 on those three representation differences; that result is retained, and the final comparison records them explicitly. No numerical, geometric or causal mismatch was found. [Review receipt](review.json) · [initial comparison result](comparison-initial-result.json) · [final comparison invocation](comparison-invocation.json)

Native `.blend` serialization was not compared between fresh runs because paths and session details can differ. The continuous projection bound covers exported LINEAR/SLERP playback; it does not cover unrecorded native substeps. No Bullet manifolds or normal impulses were measured. The high-impulse feed motor is a bounded demonstration, not a calibrated actuator-force model. This review did not rerun external visual validation or full product regression. It confirms the recovered Blender replication and cannot certify the older, unavailable C190 trial.
