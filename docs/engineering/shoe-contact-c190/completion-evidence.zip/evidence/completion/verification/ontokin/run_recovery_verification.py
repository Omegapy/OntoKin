"""Run the preserved C190 audit without modifying any preserved input.

This is a new verification of recovered evidence, not another entrant trial.
All writes are confined to this directory and its new replay subdirectory.
"""
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1] / "c190"
RUNTIME = ROOT / "tools/native"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def runtime_manifest():
    return "\n".join(
        sha(path) + "  " + path.relative_to(RUNTIME).as_posix()
        for path in sorted(RUNTIME.rglob("*"))
        if path.is_file()
        and ".git" not in path.relative_to(RUNTIME).parts
        and "__pycache__" not in path.relative_to(RUNTIME).parts
        and path.suffix != ".pyc"
    ) + "\n"


def protected_inventory():
    roots = [ROOT / p for p in (
        "tools/native", "deliveries/ontokin", "checker", "audit/ontokin",
        "evidence/ontokin-audit")]
    paths = {p for r in roots for p in r.rglob("*") if p.is_file()}
    paths.update(ROOT / p for p in ("HANDOFF-C190.md", "RECOVERY-C190.md", "audit/observe.py"))
    return {p.relative_to(ROOT).as_posix(): sha(p) for p in sorted(paths)}


def main():
    replay = OUT / "replay"
    assert not replay.exists(), "Replay must use a new output directory."
    before = runtime_manifest()
    (OUT / "runtime-before.sha256").write_text(before)
    expected = (ROOT / "deliveries/ontokin/build/runtime-before.sha256").read_text()
    assert before == expected, "Recovered runtime differs from preserved manifest."
    assert len(before.splitlines()) == 209
    protected_before = protected_inventory()
    write_json("protected-inputs-before.json", protected_before)
    frozen = json.loads((ROOT / "checker/FREEZE.json").read_text())
    for relative, digest in frozen["files"].items():
        assert sha(ROOT / "checker" / relative) == digest, f"Checker seal mismatch: {relative}"
    delivery = ROOT / "deliveries/ontokin"
    delivery_count = 0
    for line in (delivery / "SHA256SUMS").read_text().splitlines():
        if not line.strip():
            continue
        expected_hash, name = line.split(None, 1)
        assert sha(delivery / name.lstrip(" *")) == expected_hash
        delivery_count += 1
    command = [sys.executable, "-IB", "audit/ontokin/replay.py", "--out", str(replay)]
    receipt = {
        "scope": "Fresh recovery verification of preserved C190; not a new trial or submission",
        "verifier": "/root/verify_ontokin",
        "startedAtUtc": datetime.now(timezone.utc).isoformat(),
        "cwd": str(ROOT), "argv": command,
        "pythonExecutable": sys.executable, "pythonVersion": sys.version,
        "platform": platform.platform(), "numpyVersion": importlib.metadata.version("numpy"),
        "runtimeFileCount": len(before.splitlines()),
        "runtimeManifestSha256": hashlib.sha256(before.encode()).hexdigest(),
        "runtimeMatchesPreservedManifestBefore": before == expected,
        "frozenCheckerVersion": frozen["version"],
        "frozenCheckerManifestSha256": sha(ROOT / "checker/FREEZE.json"),
        "frozenCheckerFilesVerified": len(frozen["files"]),
        "sealedDeliveryFilesVerified": delivery_count,
        "protectedFileCount": len(protected_before),
    }
    write_json("run-receipt.json", receipt)
    with (OUT / "replay.stdout.txt").open("w") as stdout, (OUT / "replay.stderr.txt").open("w") as stderr:
        proc = subprocess.run(command, cwd=ROOT, stdout=stdout, stderr=stderr, check=False)
    after = runtime_manifest()
    (OUT / "runtime-after.sha256").write_text(after)
    protected_after = protected_inventory()
    write_json("protected-inputs-after.json", protected_after)
    receipt.update({
        "finishedAtUtc": datetime.now(timezone.utc).isoformat(),
        "returncode": proc.returncode,
        "runtimeUnchanged": before == after,
        "protectedInputsUnchanged": protected_before == protected_after,
    })
    write_json("run-receipt.json", receipt)
    print(json.dumps(receipt, indent=2))
    assert proc.returncode == 0, "Preserved replay failed; inspect replay.stderr.txt."
    assert before == after, "Runtime changed."
    assert protected_before == protected_after, "Preserved inputs changed."


if __name__ == "__main__":
    main()
