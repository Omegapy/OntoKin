"""Independent byte comparison and GLB inspection for the recovery replay.

Uses only the standard library and does not import the entrant's measurement,
adapter, replay, or frozen-checker code. This verifies the inspected cuboid,
identity-rotation profile; it is not a new general glTF validator.
"""
from datetime import datetime, timezone
import hashlib
import itertools
import json
from pathlib import Path
import struct

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1] / "c190"
OLD = ROOT / "evidence/ontokin-audit"
NEW = OUT / "replay"
DELIVERY = ROOT / "deliveries/ontokin"
IDS = ["base", "left_carriage", "left_shoe", "left_stop", "right_carriage", "right_shoe", "right_stop"]


def load(path):
    return json.loads(path.read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def decode(path):
    data = path.read_bytes()
    assert struct.unpack_from("<4sII", data) == (b"glTF", 2, len(data))
    length, kind = struct.unpack_from("<I4s", data, 12)
    assert kind == b"JSON"
    doc = json.loads(data[20:20 + length])
    count, kind = struct.unpack_from("<I4s", data, 20 + length)
    assert kind == b"BIN\0" and 28 + length + count == len(data)
    return doc, data[28 + length:]


def differences(a, b, path=""):
    assert type(a) is type(b), path
    if isinstance(a, dict):
        assert a.keys() == b.keys(), path
        return [v for k in a for v in differences(a[k], b[k], path + "/" + k)]
    if isinstance(a, list):
        assert len(a) == len(b), path
        return [v for i in range(len(a)) for v in differences(a[i], b[i], path + "/" + str(i))]
    return [] if a == b else [{"path": path, "before": a, "after": b}]


def accessor(doc, blob, number):
    a = doc["accessors"][number]
    assert "sparse" not in a and not a.get("normalized")
    view = doc["bufferViews"][a["bufferView"]]
    assert view["buffer"] == 0
    shape = {"SCALAR": 1, "VEC3": 3, "VEC4": 4}[a["type"]]
    component = {5123: "H", 5125: "I", 5126: "f"}[a["componentType"]]
    fmt = "<" + component * shape
    size = struct.calcsize(fmt)
    stride = view.get("byteStride", size)
    start = view.get("byteOffset", 0) + a.get("byteOffset", 0)
    assert stride >= size
    return [struct.unpack_from(fmt, blob, start + i * stride) for i in range(a["count"])]


def all_bounds(doc, blob):
    assert len(doc["animations"]) == 1
    assert doc["scenes"][doc["scene"]]["nodes"] == list(range(7))
    assert [n["name"] for n in doc["nodes"]] == IDS
    animation = doc["animations"][0]
    tracks, common_times = {}, None
    for channel in animation["channels"]:
        sampler = animation["samplers"][channel["sampler"]]
        assert sampler.get("interpolation", "LINEAR") == "LINEAR"
        times = [x[0] for x in accessor(doc, blob, sampler["input"])]
        assert len(times) == 121 and times[0] == 0 and times[-1] == 2
        assert all(a < b for a, b in zip(times, times[1:]))
        if common_times is None:
            common_times = times
        assert common_times == times
        node, kind = channel["target"]["node"], channel["target"]["path"]
        assert (node, kind) not in tracks
        tracks[node, kind] = accessor(doc, blob, sampler["output"])
    assert len(tracks) == 14
    boxes = {}
    for i, node in enumerate(doc["nodes"]):
        assert not any(k in node for k in ("matrix", "children", "scale"))
        assert node.get("rotation", [0, 0, 0, 1]) == [0, 0, 0, 1]
        assert all(r == (0., 0., 0., 1.) for r in tracks[i, "rotation"])
        positions = [p for primitive in doc["meshes"][node["mesh"]]["primitives"]
                     for p in accessor(doc, blob, primitive["attributes"]["POSITION"])]
        lo = [min(p[d] for p in positions) for d in range(3)]
        hi = [max(p[d] for p in positions) for d in range(3)]
        assert all(p[d] in (lo[d], hi[d]) for p in positions for d in range(3))
        assert len(set(positions)) == 8
        boxes[node["name"]] = [
            [[1000 * (p[d] + t[d]) for d in range(3)] for p in (lo, hi)]
            for t in tracks[i, "translation"]]
    return common_times, tracks, boxes


def overlap_window(a0, a1, b0, b1, tolerance=0.001):
    """Solve all six strict affine overlap inequalities on one interval."""
    lo, hi = 0., 1.
    for d in range(3):
        for v0, v1 in ((a0[1][d] - b0[0][d], a1[1][d] - b1[0][d]),
                       (b0[1][d] - a0[0][d], b1[1][d] - a1[0][d])):
            first, slope = v0 - tolerance, v1 - v0
            if slope == 0:
                if first <= 0:
                    return None
            elif slope > 0:
                lo = max(lo, -first / slope)
            else:
                hi = min(hi, -first / slope)
            if lo >= hi:
                return None
    return [lo, hi]


def inspect_case(label, directory):
    raw, blob = decode(directory / "native.glb")
    final, final_blob = decode(directory / "assembly.glb")
    patches = differences(raw, final)
    assert patches == [{"path": f"/meshes/{i}/name", "before": "extrusion", "after": name}
                       for i, name in enumerate(IDS)]
    assert blob == final_blob and len(blob) == 30752
    times, tracks, boxes = all_bounds(raw, blob)
    lanes = {}
    for lane in ("left", "right"):
        shoe, stop, car = [boxes[lane + "_" + suffix] for suffix in ("shoe", "stop", "carriage")]
        gaps = [b[0][0] - a[1][0] for a, b in zip(shoe, stop)]
        first_crossing = None
        for i, (a, b) in enumerate(zip(gaps, gaps[1:])):
            if a >= 0 and b <= 0:
                first_crossing = times[i] + (times[i+1] - times[i]) * a / (a - b)
                break
        overlaps = [min(shoe[-1][1][d], stop[-1][1][d]) - max(shoe[-1][0][d], stop[-1][0][d])
                    for d in range(3)]
        offset0 = [shoe[0][0][d] - car[0][0][d] for d in range(3)]
        drift = max(abs(a[0][d] - b[0][d] - offset0[d]) for a, b in zip(shoe, car) for d in range(3))
        lanes[lane] = {"firstZeroGapS": first_crossing, "initialGapMm": gaps[0],
                       "finalSignedGapMm": gaps[-1], "finalSolidOverlapMm": overlaps,
                       "carriageTravelMm": car[-1][0][0] - car[0][0][0],
                       "shoeTravelMm": shoe[-1][0][0] - shoe[0][0][0],
                       "maxAttachmentOriginOffsetDriftMm": drift}
        reference = load(NEW / f"{label}-observation.json")
        assert abs(lanes[lane]["finalSignedGapMm"] - reference["gaps"][lane]["endMm"]) < 1e-10
        assert first_crossing == reference["gaps"][lane]["firstZeroGapS"]
    pairs = []
    for a, b in itertools.combinations(IDS, 2):
        if {a, b} == {"left_shoe", "left_stop"}:
            continue
        for i in range(len(times)-1):
            assert overlap_window(boxes[a][i], boxes[a][i+1], boxes[b][i], boxes[b][i+1]) is None, (a, b, i)
        pairs.append([a, b])
    native = load(directory / "native-state.json")
    assert native["physical_assumptions"]["collision"] == "disabled"
    assert native["physical_assumptions"]["contact_response"] == "unavailable"
    assert native["boundary_times_seconds"] == ["0"]
    for sample in native["samples"]:
        assert not sample["actions"]
        for lane, speed in (("left", .125), ("right", .15)):
            objects = sample["objects"]
            assert objects[lane + "_carriage"]["physical"]["kind"] == "sphere_body"
            assert objects[lane + "_carriage"]["physical"]["radius"] == .02
            assert objects[lane + "_carriage"]["own_mass_kg"] == 1
            for name in (lane + "_carriage", lane + "_shoe"):
                assert objects[name]["velocity_m_per_s"] == [speed, 0., 0.]
            for name in (lane + "_shoe", lane + "_stop"):
                assert objects[name]["physical"]["kind"] == "no_body"
            assert objects[lane + "_shoe"]["pose_authority"]["kind"] == "follow"
            assert objects[lane + "_stop"]["velocity_m_per_s"] == [0., 0., 0.]
    return {"case": label, "rawSha256": sha(directory / "native.glb"),
            "finalSha256": sha(directory / "assembly.glb"), "jsonPatches": patches,
            "binaryBytes": len(blob), "binaryUnchanged": True,
            "binarySha256": hashlib.sha256(blob).hexdigest(), "allRotationsIdentity": True,
            "keys": len(times), "maxIntervalS": max(b-a for a,b in zip(times,times[1:])),
            "lanes": lanes, "allTwentyUnrelatedPairsContinuouslyClear": True,
            "unrelatedPairs": pairs, "contactToleranceMm": .001,
            "nativeBoundaryTimesS": native["boundary_times_seconds"],
            "nativeContactResponse": native["physical_assumptions"]["contact_response"],
            "nativeSampleTimesS": [s["time_seconds"] for s in native["samples"]]}


def main():
    stable = ["native-capabilities.json", "between-case-comparison.json", "runtime-before.sha256", "runtime-after.sha256"]
    stable += [f"{case}/{name}" for case in ("stop-380", "stop-355")
               for name in ("native.glb", "assembly.glb", "native-state.json", "measurements.json", "export-diff.json")]
    roots = [DELIVERY / "build", OLD / "formal-a", OLD / "formal-b", NEW / "formal-a", NEW / "formal-b"]
    for relative in stable:
        assert all((r / relative).read_bytes() == (roots[0] / relative).read_bytes() for r in roots[1:])
    third = ["native.glb", "assembly.glb", "native-state.json", "export-diff.json"]
    thirds = [r / "third-stop" / b for r in (OLD, NEW) for b in ("build-a", "build-b")]
    for relative in third:
        assert all((r / relative).read_bytes() == (thirds[0] / relative).read_bytes() for r in thirds[1:])
    reports = ["adapter-audit.json", "native-source-audit.json", "third-stop/main.ok", "third-stop/settings.diff",
               "third-stop/independent-native-state.json"]
    reports += [f"{case}-{kind}.json" for case in ("stop-380", "stop-355", "stop-367.5")
                for kind in ("acceptance", "observation")]
    for name in reports:
        assert (OLD / name).read_bytes() == (NEW / name).read_bytes(), name
    old_summary, new_summary = load(OLD / "summary.json"), load(NEW / "summary.json")
    old_summary.pop("completedAtUtc")
    new_summary.pop("completedAtUtc")
    assert old_summary == new_summary
    diagnostics = {}
    fields = ["outcome", "achieved_level", "diagnostics", "implementation_identity", "source_revision", "program_revision"]
    for name, code, phase in (("collision-enabled", "OKL-E-NAME", "binding"),
                              ("mass-bearing-follower", "OKL-E-PHYSICAL-DOMAIN", "elaboration")):
        envelopes = [load(r / "probes" / name / "export.json") for r in roots]
        projections = [{k: e[k] for k in fields} for e in envelopes]
        assert all(p == projections[0] for p in projections[1:])
        d = projections[0]["diagnostics"][0]
        assert d["code"] == code and d["phase"] == phase
        assert all(not (r / "probes" / name / "native.glb").exists() for r in roots)
        diagnostics[name] = projections[0]
    cases = [inspect_case(label, directory) for label, directory in (
        ("stop-380", NEW / "formal-a/stop-380"),
        ("stop-355", NEW / "formal-a/stop-355"),
        ("stop-367.5", NEW / "third-stop/build-a"))]
    output = {"verificationKind": "Independent comparison and standard-library GLB inspection",
              "completedAtUtc": datetime.now(timezone.utc).isoformat(),
              "result": "Preserved negative contact result reproduced; no mismatch found",
              "formalStableFilesPerDirectory": len(stable), "formalDirectoriesCompared": len(roots),
              "thirdStableFilesPerDirectory": len(third), "thirdDirectoriesCompared": len(thirds),
              "byteIdenticalAuditReports": reports,
              "summaryMatchedExceptCompletionTimestamp": True,
              "probeStableProjectionKeys": fields, "probeDiagnostics": diagnostics,
              "cases": cases,
              "limits": ["New verification does not recover the unavailable original C190 trial",
                         "Contact acceptance remains false; geometric overshoot is not a native manifold quantity",
                         "Continuous bounds cover exported linear interpolation, not unrecorded dynamics",
                         "No runtime, frozen-checker, delivery, test, or prior-evidence changes",
                         "No full product regression or receiving-application playback rerun in this review"]}
    (OUT / "independent-inspection.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"result": output["result"], "formalStableFilesPerDirectory": len(stable),
                      "formalDirectoriesCompared": len(roots), "thirdDirectoriesCompared": len(thirds),
                      "auditReportsMatched": len(reports),
                      "cases": [{"case": c["case"], "lanes": c["lanes"]} for c in cases]}, indent=2))


if __name__ == "__main__":
    main()
