# C190 OntoKin recovery verification

**The preserved negative result reproduces.** None of the three stop placements produces native contact response or a carriage halt. The fresh audit completed successfully because it reproduced the expected failures; it did not convert them into contact passes. No result discrepancy or execution blocker was found within this verification scope.

## Provenance and scope

The inputs are the recovered C190 package under `c190/`, including its sealed OntoKin delivery, unchanged packaged runtime, frozen C190-R2.1 checker and earlier coordinator audit. The package itself is a recovery replication. Its recovery record states that the original interrupted C190 trial artifacts were unavailable. This review does not recover or authenticate those missing original artifacts.

This is a **new verification**, separate from the preserved entrant trial and its prior audit. It ran on 2026-11-10 from **01:08:57.414797 to 01:09:28.893134 UTC**, using CPython **3.12.14**, NumPy **2.3.5**, and Linux x86-64. The documented command was executed from the recovered handoff root:

```sh
python -IB audit/ontokin/replay.py --out /workspace/scratch/d0b9f6a77602/verification/ontokin/replay
```

The [run receipt](run-receipt.json) records the executable, environment, times, identities and return code. [Full replay stdout](replay.stdout.txt), [stderr](replay.stderr.txt), and the [eleven subprocess records](replay/commands.json) are retained. The only newly authored inspection code is in this verification directory. Preserved sources, runtime, checker, seals, tests and earlier evidence were not edited.

## Fresh results

The audit rebuilt both formal cases twice, rebuilt the independent 367.5 mm source twice, and executed each rejection probe twice. Each frozen contact check returned its expected exit code **1**, with reason `left: maximum penetration exceeds 0.5 mm`. Every observation completed and retained the other lane and unrelated pairs. The overall audit returned **0**, meaning the expected result reproduced.

| Left stop near face (mm) | First zero-gap crossing (s) | Left carriage travel at 2 s (mm) | Final left signed gap (mm) | Final right gap (mm) |
| ---: | ---: | ---: | ---: | ---: |
| 380 | 1.600000024 | 250.000007451 | −50.000011921 | 15.000008047 |
| 355 | 1.399999976 | 250.000007451 | −75.000017881 | 15.000008047 |
| 367.5 | 1.500000119 | 250.000007451 | −62.500000000 | 15.000008047 |

The table is rounded to nine decimal places; [independent inspection](independent-inspection.json) and the [fresh audit summary](replay/summary.json) retain full floating-point precision. Negative signed gap means the visible shoe face advanced past the stop's near face. It is not a native contact-manifold penetration measure.

The independently decoded final left shoe/stop overlap is approximately **30 × 40 × 80 mm** in all three cases. The positive overlap on all three axes confirms intersection of the displayed cuboids. The right carriage travels **300.00000447034836 mm** and retains **15.000008046627045 mm** clearance. All **20 other solid pairs** remain continuously clear throughout all **120 linear playback intervals**, using the inherited 0.001 mm numerical contact tolerance.

## Native interpretation and diagnostics

Inspection of the `.ok` source, the runtime catalog and freshly evaluated native states establishes the same boundary:

| Element | Inspected native representation |
| --- | --- |
| Carriages | One 1 kg sphere each, radius 20 mm, with its center at the carriage origin. The left initial center is (−100, 80, −200) mm. This physical proxy does not extend to the shoe's leading face at X = 180 mm. |
| Shoes | Visible extrusions with `no_body()`, zero own mass and a `follow` pose authority. The catalog explicitly excludes ownership and force transfer. |
| Stops | Visible extrusions with `no_body()` and prescribed fixed poses. They have no physical collider. |
| Contact | Runtime state reports collision `disabled` and contact response `unavailable`; the catalog permits only the `disabled` collision value. |

Every inspected native sample retains left velocity **(0.125, 0, 0) m/s** and right velocity **(0.15, 0, 0) m/s**. This includes samples immediately around the formal crossings and the separate third-stop samples at 1.499, 1.5 and 1.501 s. The native event-boundary list remains `["0"]`, with no authored actions. No timed stop or clamping behavior appears in these sources or states. The runtime uses analytical trajectories and a rational event clock; 60 Hz specifies recording cadence, not a fixed physics integration step.

Both minimal probes reproduce their complete compared diagnostic projections, including source identity and source spans:

- `collision = enabled` returns **`OKL-E-NAME`**, phase **binding**: `Unknown name 'enabled' in this lexical scope.` This rejects an unsupported value before a physical solve.
- A mass-bearing following shoe returns **`OKL-E-PHYSICAL-DOMAIN`**, phase **elaboration**: `A follow relation may control only a massless child with no_body().`

Neither rejected probe produces a GLB. The exact envelopes remain under [fresh probe output](replay/formal-a/probes/), and their stable projections are copied into the independent inspection record.

## Comparison and integrity

A separate standard-library decoder, which imports neither the entrant's measurement code nor the frozen checker, confirms these properties for all three cases:

- Raw and final GLBs differ at exactly seven JSON fields: `/meshes/0/name` through `/meshes/6/name`, changing `extrusion` to occurrence names.
- The entire **30,752-byte BIN chunk** is unchanged. All other decoded JSON values are identical. This preserves vertex, timestamp, transform, material and animation values.
- All recorded rotations are identity; each clip has 121 common keys over two seconds. Maximum stored interval is **0.016666769981384277 s**.
- The continuous unrelated-pair check solves affine overlap inequalities over each recorded interval. It applies to GLB playback, not unrecorded solver behavior.

The fourteen selected stable formal files match byte for byte across the sealed entrant build, both preserved coordinator rebuilds and both fresh rebuilds: **five directories**. The four selected third-stop files match across both preserved and both fresh third-stop builds: **four directories**. Eleven additional audit reports/source files match their preserved counterparts byte for byte. The full audit summary matches after excluding only its completion timestamp. Probe projections exclude execution-budget elapsed time and other expressly unselected execution metadata; no claim of byte identity is made for wall-clock records.

Before replay, all **104 checker-freeze entries** and **48 sealed delivery files** verified. All **209 pinned runtime files** match the preserved manifest before and after replay. Its SHA-256 remains:

`937c5ec626aee8dbe7668010143d0825c6559226ccad2cc7d9164cf54f6db24e`

The broader protection inventory covers **483 files** across the runtime, sealed delivery, frozen checker, preserved native audit, replay script and handoff/provenance records. Its before/after inventories also match through replay. Runtime identity remains `3e6ef2df6a7e8837050abb949075bff9b65f6a4aa4a9f1587850d7ddd59bce56`.

A final check detected subsequent changes to `HANDOFF-C190.md` and `RECOVERY-C190.md`. The coordinator confirmed these were its completion links and recovery-context updates. These later documentation edits are recorded separately in [the final verification receipt](verification-receipt.json), with old and new hashes. All **481 other inventoried files**, including every runtime, source, delivery-seal, checker and prior-audit file, still match. The clean replay receipt has not been rewritten to hide the later documentation update.

## Handoff implication

This evidence supports continuing to the already proposed bounded C191 contact-binding/Blender-adapter qualification. It does not support relabeling native OntoKin following as a load-bearing attachment or native contact support. The missing link remains an inspectable collision shape bound to its mass owner and an actual solver response. No new authoring trial, runtime change, full product regression or receiving-application playback was performed in this review.
