# OntoKin C190 · Contact at an attached shoe

**November 9, 2026 — recovery replication.** The interrupted discussion had opened PR #123 and committed its plan and evaluator identity. Its reported result files were unavailable. This handoff preserves that checkpoint and supplies newly executed, independently checked results. C189 was already complete; its supplied archive and numerical replay were verified again. [Recovery record](RECOVERY-C190.md)

**Contact at the shoe stops its carriage in Blender. The pinned OntoKin profile has no contact response.** Blender passed the two formal stop positions and an independent third position. Removing only its shoe collider made the carriage continue. OntoKin preserved following and right-lane motion but passed through each stop. [Results and limits](HANDOFF-C190.md)

The Blender final GLBs project a small solver guide error onto straight playback. Every native carriage X sample and recorded timestamp is preserved; raw simulation exports and the failed first submission remain included. The maximum continuous raw-playback mapping bound is 0.056596 mm. This mapping is separate from the native collision result.

![The two routes at rest, first contact and two seconds](evidence/playback/comparison.png)

## Next step: C191

**Start by spawning two fresh subagents in this conversation's execution environment**, with `fork_turns="none"` and default settings: one contract/adapter author and one independent fixture reviewer. No separate host or isolation preflight is required.

Define an explicit experimental `.ok` contract for a shoe collision shape owned by a carriage body, then qualify a small mapping to the measured Blender/Bullet setup. Keep current native source/profile behavior unchanged. The next task must preserve source identity, one mass owner, one motion authority and a declared solver boundary. [Coordinator instructions](NEXT-TASK.md) · [Detailed proposal](next/C191-BRIEF.md)

## Inspect or reproduce

| Need | File |
| --- | --- |
| Measurements, native causality and limitations | [C190 handoff](HANDOFF-C190.md) |
| What survived the earlier crash | [Recovery record](RECOVERY-C190.md) |
| Editable Blender scenes, raw/final exports and build scripts | [Blender delivery](deliveries/blender/README.md) |
| Editable OntoKin sources and exact native diagnostics | [OntoKin delivery](deliveries/ontokin/README.md) |
| Independent rebuild and collider-removal evidence | [Blender audit](audit/blender/README.md) |
| Independent unsupported-contact reproduction | [OntoKin audit](audit/ontokin/README.md) |
| Frozen evaluator and controls | [Checker](checker/README.md) |
| Tool setup and portable commands | [Tools](tools/README.md) |
| Repository revision and restore instructions | [Checkpoint](CHECKPOINT-C190.json) · [Source](source/README.md) |

Run `python -IB replay.py` from the extracted root with the listed Python/NumPy and Node versions. It checks the seals, regenerates the independent controls, remeasures all six final outputs, validates raw/final GLBs and repeats Three.js readback. Native rebuild commands are separate in the two audit READMEs.
