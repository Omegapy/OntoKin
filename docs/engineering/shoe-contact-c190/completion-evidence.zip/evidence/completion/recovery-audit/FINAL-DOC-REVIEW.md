# C190 publication and C191 scope review

## Decision

The recommended C191 adapter is a bounded and justified next step under the revised GOAL. The reviewed documents distinguish a proposed contract from adopted support, preserve the existing .22 profiles, and separate native collision behavior from exported playback. One small acceptance clarification is needed before the C191 handoff is sealed: explicitly carry forward the maximum-penetration and unrelated-pair checks already required and measured in C190.

## Scope and alignment

GOAL directs OntoKin to own typed design intent, stable identity, dimensions, relationships and targeted edits while delegating general simulation to specialist tools. It specifically calls for a qualified common Blender backend before comparing the language's contribution with direct authoring. C191 addresses the demonstrated contact limitation with one source-owned mapping to the already measured backend. It does not propose a general contact engine, broad importer or production backend.

The promised domain remains seven visible solids, two moving 1 kg bodies, source-owned shoe/stop boxes, enumerated native helper shapes, independent world-X guides, declared feed motors and two modeled seconds. Initial conditions, resource ceilings, cancellation, malformed output and atomic publication are required contract work; they are not presented as current capabilities. The independent stop edit and collider-disabled case are relevant controls within this same domain.

## Compatibility and authority

The brief labels its status as proposed and explicitly assigns neither syntax nor a version. The acceptance JSON uses null source/profile, backend and recorded-output bindings and requires an adoption decision before implementation. Existing source 0.22, torque-0.1, Agent/0.22 and GLB/0.22 remain unchanged; existing contact rejection/pass-through fixtures are retained.

Source ownership, identity, exactly one mass owner per carriage, explicit collider attachment and one solver motion authority per lane are stated consistently. Following is not silently reinterpreted as mechanical force transfer, and an inherited spherical physical proxy is not renamed into a box. Native helper geometry is enumerated rather than hidden as an unmeasured four-shape design. The feed-motor setup and large native impulse setting are disclosed without claiming a calibrated actuator model.

## Native result and playback claims

Publication text is consistent with the saved evidence reviewed in this recovery:

- Blender's raw native result and the small final playback projection remain separate. X samples and times are preserved, while removed rotation/transverse residuals are disclosed.
- The 0.056596 mm continuous bound is attributed to raw-to-final GLB interpolation, not unobserved native solver substeps.
- Native contact flags and finite-difference velocities are identified as pose-derived. No Bullet manifold or normal-impulse telemetry is asserted.
- The collider-removal control supports causality within the measured native construction; it is not promoted into a general collision guarantee.
- OntoKin's preserved pass-through and exact source diagnostics are described as a capability boundary, not a collision solver that attempted and failed the contact.
- The rendered images are identified as actual GLB reimports. Browser startup failure, independent Three.js decoding and native simulation are not conflated.
- Fresh-history author participation, disclosed recovery outcomes and missing cost telemetry are stated without claiming a blind comparison or an authoring advantage.

## Concrete correction

The proposed acceptance prose and JSON currently constrain final travel/gap, contact onset, settling, speed, rebound and mapping error. They should also explicitly state:

1. For positive contact cases, maximum shoe leading-face penetration past the stop near face must remain at or below 0.5 mm over every piecewise-linear exported interval. Retain the distinction from native manifold penetration and unobserved solver substeps.
2. All twenty unrelated visible-part pairs must remain continuously nonoverlapping through the full clip in all cases.

These are existing C190 obligations. Their explicit inclusion prevents a future checker from accepting an excursion that returns to a valid final pose, or an unrelated overlap while the intended contact succeeds. They do not change C190 artifacts or expand C191's modeled domain. The saved final maximum penetration of approximately 0.007584 mm is within the proposed 0.5 mm bound.

## Review boundary

This is a document, scope and evidence-claim review. It does not adopt C191, implement the adapter, rerun native simulations or replace independent route verification. Pending completion records, checkpoint files and the merge are intentionally outside this review. No source or remote state was changed.

`final-doc-review-inputs.json` identifies the five document versions reviewed by SHA-256. The earlier `AUDIT.md`, authenticated snapshots and byte-comparison receipts identify the recovered evidence.
