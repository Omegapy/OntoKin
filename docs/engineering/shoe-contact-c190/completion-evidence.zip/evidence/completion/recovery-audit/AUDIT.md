# C190 recovery audit

This is an independent, read-only audit of authenticated GitHub state and the surviving previous workspace. It does not rerun the native simulations or replace their original provenance.

## What survived

At the initial audit, GitHub main was `4e1b5d1f1eeb5dc67807ed82f3675ab0412f3de2`. Draft [PR #123](https://github.com/Omegapy/OntoKin/pull/123) remained on `work/c190-shoe-contact` at `b54ff44546df2f675916aabbe02d55382a000ea1`. The six changed paths were the original participant, cases, plan and evaluator-freeze documents; the recovery record; and `recovery-r2-checker.zip`. Neither completed delivery nor final result evidence had been committed to that branch.

The previous workspace at `/workspace/scratch/eb7f3f78ef8f/c190` does retain the later recovery replication, sealed participant deliveries, the failed first Blender submission, numerical and native audit receipts, raw/final GLBs, renders, tools, a replay driver and drafted handoff instructions. Its sibling repository has the corresponding result documentation and archives as uncommitted/staged work. Therefore another participant trial is unnecessary merely to recover the delivery. Fresh verification and publication can proceed from these identified files.

The old main integration lease ended at `2026-11-10T00:54:00Z`. Its expiry does not itself grant a new agent ownership. Reconcile current refs immediately before any conditional lease acquisition or merge.

## Independent byte checks

| Check | Result |
| --- | --- |
| Authenticated R2 checker archive | 263,883 bytes; 106 members; valid CRCs |
| Remote archive vs surviving checker directory | All 106 members match exactly |
| Recovered evaluator freeze | All 104 bound entries match |
| Pinned native runtime | All 209 bound entries match |
| Sealed accepted Blender delivery | All 50 entries match |
| Sealed OntoKin delivery | All 48 entries match |
| Sealed failed Blender first submission | All 46 entries match |
| Published immutable checkpoint inputs | Four original documents and R2 archive match local repository bytes |

The authenticated checker ZIP SHA-256 is `cb3a1a4e086726701eead2dc2f15206cdf684dab859e1fd4bf2b390a420026f7`; Git blob identity is `c2c445a7d2ab84851617d8d089eb41eae7b1d3ef`. It was fetched at the exact PR head via the GitHub file connector in base64 form, decoded, and compared locally. It is the separately identified C190-R2.1 evaluator, not the unavailable original C190.1 evaluator. The surviving freeze hash, `0c82dbc7d5fb90a3b721cf56cd6c8ba87216678fc8b90a816bdfc152fb6ab86b`, matches dispatch and results records.

The accepted Blender, OntoKin and failed Blender manifest hashes match their dispatch records. This establishes byte identity and recorded ordering; it does not reconstruct absent independent platform telemetry or establish a blind participant study.

## Publication and package work still incomplete

The recovered package lacks `CHECKPOINT-C190.json`, `PACKAGE-MANIFEST.json`, `source/snapshot.txt`, `source/c189-to-c190.bundle`, and the three intended repository guidance snapshots. Its source README and closing recovery text anticipate files and final publication identities that must still be supplied. Do not distribute those draft claims without finishing their corresponding records.

The pending main status and result publication are not proof of a successful merge. Rebuild the publication archive from the verified working copy, finish the scoped checks, publish actual commits, verify the resulting main tree, then create the matching bundle/checkpoint and seal the final ZIP. Preserve the four original checkpoint files, the remote R2 archive, sealed participant directories and all earlier failure identities.

The repository branch inventory was paginated to exhaustion and contained `archive/c174-model-research`, `main`, and `work/c190-shoe-contact`. The exact PR head returned no combined commit statuses and no PR-triggered workflow runs. This is not a hosted CI pass. No remote state or historical input was mutated during this audit.

## Evidence

- `github-snapshots.json`: authenticated initial refs, paths, branches, workflow/status results and checkpoint document snapshots.
- `branches-page2.json`: exhausted branch pagination.
- `remote-recovery-r2-checker.zip`: actual authenticated archived evaluator bytes.
- `checker-comparison.json`: remote archive identity and recovered-member comparison.
- `local-provenance-audit.json`: sealed file counts, original input hashes and missing closing files.

The native result conclusions and C191 proposal should be assessed against the preserved route audits and fresh coordinator checks; this audit only establishes recovery, identities and remaining publication work.
