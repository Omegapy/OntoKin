# C191 proposal review disposition

The independent reviewer found two C190 checks implicit but not explicitly carried into the proposed C191 acceptance table. The coordinator added the 0.5 mm whole-clip near-face penetration limit for positive contact cases A–C and continuous nonoverlap for all twenty unrelated visible pairs in all four cases. The disabled-collider control retains its expected pass-through. The proposal remains unadopted. No frozen C190 evaluator, acceptance threshold, source or evidence changed.

The amended files are `next/C191-BRIEF.md`, `next/C191-ACCEPTANCE.json` and the coordinator next-task instructions, in the handoff and repository record.
