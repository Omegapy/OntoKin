# C190 imported-GLB captures

**Use `attempt-02/` for the final visual comparison.** It contains 18 PNGs: the four formal outputs and both independent 367.5 mm edits, each at 0 s, its ideal contact time and 2 s. [Contact sheet](attempt-02/contact-sheet.png) · [Full receipt](attempt-02/receipt.json)

These are **Blender 4.5.3 CPU Cycles renders of the actual delivered GLB imports**. They are not screenshots or browser-playback evidence. The C187 camera is preserved; the renderer and lighting differ from the C189 browser presentation. This capture operation plays the recorded GLB animation. It does not rebuild native source geometry or rerun the original physical simulation.

## What was checked before rendering

`audit/render_frames.py` imports each supplied GLB into an empty scene. It requires exactly seven named mesh objects and no native rigid-body system. A separate GLB reader evaluates the file's actual vertices, hierarchy and animation at all three requested times. Every imported world bound must agree with that decoded pose within 0.05 mm before any frame for that file is rendered.

All 18 corrected sample checks passed. The largest difference was **0.0000298 mm**. Each job receipt records all seven world bounds, source GLB hash, imported animation range, sampled seconds/Blender frame, left/right gaps and PNG hashes. The Blender GLBs retain approximately zero left final gap for all three stops. The OntoKin GLBs show final signed gaps of −50, −75 and −62.5 mm. Physics attribution belongs to the separate native audits, not these images.

| Setting | Value |
| --- | --- |
| Blender | 4.5.3 LTS, build `67807e1800cc`; executable SHA-256 in receipt |
| Renderer | CPU Cycles; 32 samples; denoising; fixed seed 190; 8 threads |
| Camera eye, glTF metres | `(0.46, 0.90, 0.96)` |
| Camera target, glTF metres | `(0.19, 0.014, 0.09)` |
| Frame mapping | glTF `(x, y, z)` → Blender `(x, −z, y)` |
| Projection | Vertical FOV 34°; 720 × 410; near 0.01 m; far 30 m |
| Background shader | sRGB `#21323d` for camera rays |
| Color management | Standard, look None, exposure 0, gamma 1 |
| Lighting | Key area 20 W; fill area 8 W; ambient world strength 0.2; full positions/sizes in receipt |
| Animation sampling | Import at 60 fps; time zero is frame 0; samples at 0, 1.4/1.5/1.6 and 2 s |

## Preserved rendering attempts

The first pass at this directory's root completed 18 imports/renders but its 200 W/80 W area lighting washed out top-face contrast. Its original `receipt.json`, `render.log`, PNGs and exact executed `attempt-01-render_frames.py` are retained.

The corrected pass uses the same camera, source GLBs, imported materials, animation, background and sampling. Only area-light power is reduced to 10%. The first corrected trio was visually inspected before completing the remaining five jobs. Its two execution logs and combined receipt are under `attempt-02/`. No first-pass evidence was overwritten. The contact sheet only scales and arranges copies of the corrected PNGs; it does not modify the full-resolution captures.

## Portable reproduction

From the `c190` directory, use the pinned binary and a fresh output directory. `--job` can be repeated for any subset; the following reproduces all six files:

```sh
BLENDER=/workspace/scratch/eb7f3f78ef8f/toolchain/blender-4.5.3-linux-x64/blender
"$BLENDER" --background --factory-startup --threads 8 --python-exit-code 1 \
  --python audit/render_frames.py -- \
  --output /absolute/path/to/fresh-captures --attempt corrected-low-light --light-scale 0.1 \
  --job blender-stop-380 deliveries/blender/stop-380/final.glb 1.6 \
  --job blender-stop-355 deliveries/blender/stop-355/final.glb 1.4 \
  --job ontokin-stop-380 deliveries/ontokin/build/stop-380/assembly.glb 1.6 \
  --job ontokin-stop-355 deliveries/ontokin/build/stop-355/assembly.glb 1.4 \
  --job blender-stop-367-5 evidence/blender-audit/third-stop/replay-a/final.glb 1.5 \
  --job ontokin-stop-367-5 evidence/ontokin-audit/third-stop/build-a/assembly.glb 1.5
```

To make the overview with Python and Pillow:

```sh
python3 -IB evidence/playback/blender-render/make_contact_sheet.py /absolute/path/to/fresh-captures
```

The actual two corrected command argument vectors are retained in `attempt-02/receipt.json` under `command_history`. Exact PNG byte reproduction is not claimed across renderers or environments. Native geometry and playback readback remain separately identified from rendering quality and browser validation.
