"""Arrange verified native PNG captures; this does not alter the source images."""
import hashlib
import json
from pathlib import Path
import sys

from PIL import Image, ImageDraw, ImageFont

root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parent / "attempt-02"
receipt = json.loads((root / "receipt.json").read_text())
jobs = {job["label"]: job for job in receipt["jobs"]}
order = [f"{route}-stop-{stop}" for stop in ["380", "355", "367-5"] for route in ["blender", "ontokin"]]
assert set(jobs) == set(order)
canvas = Image.new("RGB", (1080, 1440), (24, 37, 46))
draw = ImageDraw.Draw(canvas)
font_path = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
font = ImageFont.truetype(font_path, 16)
title = ImageFont.truetype(font_path, 21)
draw.text((12, 8), "C190 | Imported GLB frames | Blender 4.5.3 CPU Cycles | Corrected light", font=title, fill="white")
sources = []
for row, label in enumerate(order):
    job = jobs[label]
    for col, frame in enumerate(job["frames"]):
        path = root / label / frame["png"]
        digest = hashlib.sha256(path.read_bytes()).hexdigest()
        assert digest == frame["png_sha256"]
        image = Image.open(path)
        assert image.size == (720, 410)
        x, y = 360 * col, 42 + 233 * row
        name = label.replace("blender", "Blender").replace("ontokin", "OntoKin").replace("-stop-", " | stop ").replace("367-5", "367.5")
        draw.text((x + 8, y + 3), f"{name} mm | {frame['time_seconds']:.3f} s", font=font, fill="white")
        canvas.paste(image.resize((360, 205), Image.Resampling.LANCZOS), (x, y + 27))
        sources.append({"source": str(path.relative_to(root)), "sha256": digest,
                        "input_glb_sha256": job["input_sha256"], "time_seconds": frame["time_seconds"]})
output = root / "contact-sheet.png"
canvas.save(output)
(root / "contact-sheet.json").write_text(json.dumps({
    "purpose": "review overview only; full-resolution source PNGs remain unchanged",
    "thumbnail_scale": 0.5, "layout": "six rows, three sampled times per row",
    "sources": sources, "output_sha256": hashlib.sha256(output.read_bytes()).hexdigest()
}, indent=2) + "\n")
print(output)
