"""Preserve exact development receipts and original local Git history.

Run only after all validation processes and other workers are fully paused.
The previous continuation is read-only. Reproducible copied workspaces and
Python bytecode are excluded; execution logs, reports, artifacts and failures
are retained without relabeling their outcomes.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile


def now():
    return datetime.now(timezone.utc).isoformat()


def identity(path):
    raw = path.read_bytes()
    return {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")


def main():
    root, current, previous, output = map(lambda value: Path(value).resolve(), sys.argv[1:5])
    attempt = sys.argv[5]
    archive = output / ("execution-" + attempt + ".zip")
    manifest = output / ("execution-" + attempt + ".json")
    if archive.exists() or manifest.exists():
        raise ValueError("Archive output must be fresh")
    history = current / ("source-history-" + attempt)
    history.mkdir(exist_ok=False)
    output.mkdir(parents=True, exist_ok=True)
    started = now()

    def git(*args):
        return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()

    def source_snapshot():
        return {"commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
                "files": {name: identity(root / name) for name in git("ls-files").splitlines()}}

    source_before = source_snapshot()
    bundle = history / "local-source-history.bundle"
    base = "767a1d7e88a946d4936122fe21d5abf769488f81"
    refs = ["refs/heads/work/reach06-release-review-20261020-2320-7of9",
            "refs/heads/work/reach06-rate-audit-20261020-2338-7of9",
            "refs/heads/work/reach06-native-verifier-20261021-0015-7of9"]
    commands = []
    for label, args in (("bundle-create", ["bundle", "create", str(bundle), *refs, "^" + base]),
                        ("bundle-verify", ["bundle", "verify", str(bundle)])):
        command = ["git", "-C", str(root), *args]
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        log = history / (label + ".log")
        log.write_bytes(result.stdout)
        commands.append({"command": command, "returncode": result.returncode,
                         "log": log.name, **identity(log)})
        if result.returncode:
            write(history / "creation.json", {"status": "failed", "started_at": started,
                  "finished_at": now(), "commands": commands, "source": source_before["commit"]})
            raise RuntimeError(label + " failed; preserve this attempt")
    write(history / "creation.json", {"status": "passed", "started_at": started,
          "finished_at": now(), "commands": commands, "source_commit": source_before["commit"],
          "source_tree": source_before["tree"], "base_exclusion": base,
          "included_refs": {ref: git("rev-parse", ref) for ref in refs},
          "bundle": {"path": bundle.name, **identity(bundle)},
          "notes": ["Local development commit identities are preserved independently of API publication commits.",
                    "This is an incremental Git bundle; use the prerequisites listed by git bundle verify."]})

    roots = [("current-continuation", current), ("previous-continuation", previous)]
    def inputs():
        entries = {}
        for label, directory in roots:
            for path in sorted(directory.rglob("*")):
                relative = path.relative_to(directory)
                if any(part in {"workspace", ".git", "__pycache__"} for part in relative.parts):
                    continue
                if path.is_file():
                    if path.is_symlink():
                        raise ValueError("Unexpected symlink: " + str(path))
                    entries[label + "/" + relative.as_posix()] = (path, identity(path))
        return entries

    before = inputs()
    with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for name, (path, expected) in before.items():
            data = path.read_bytes()
            if {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()} != expected:
                raise ValueError("Input changed before archive write: " + name)
            info = zipfile.ZipInfo(name, date_time=(2000, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            zipped.writestr(info, data, compresslevel=9)
    with zipfile.ZipFile(archive) as zipped:
        bad = zipped.testzip()
        if bad is not None:
            raise ValueError("ZIP CRC failure: " + bad)
        if zipped.namelist() != list(before):
            raise ValueError("Archive member inventory changed")
        for name, (_, expected) in before.items():
            data = zipped.read(name)
            if {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()} != expected:
                raise ValueError("Archive member hash mismatch: " + name)
    after = inputs()
    source_after = source_snapshot()
    stable = before == after and source_before == source_after
    record = {"schema_version": "ontokin.reach-development-archive/0.1",
              "started_at": started, "finished_at": now(),
              "command": [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
              "archive": {"path": archive.name, **identity(archive)},
              "archive_member_count": len(before),
              "uncompressed_bytes": sum(item[1]["bytes"] for item in before.values()),
              "zip_crc_checked": True, "all_member_sha256_verified": True,
              "original_receipts_unchanged": before == after,
              "tracked_source_unchanged": source_before == source_after,
              "source_commit": source_before["commit"], "source_tree": source_before["tree"],
              "tracked_source_file_count": len(source_before["files"]),
              "tracked_source_inventory_sha256": hashlib.sha256(json.dumps(
                  source_before["files"], sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
              "status": "passed" if stable else "failed",
              "source_roots": {label: str(directory) for label, directory in roots},
              "exclusions": ["Copied workspace directories: original inputs have per-run before/after identities.",
                             "Git administrative directories and Python bytecode caches."],
              "notes": ["ZIP member dates are fixed to 2000-01-01 for deterministic packaging; execution clocks remain in the original reports.",
                        "Archive integrity is not release acceptance. Failed and incomplete attempts retain their original meaning.",
                        "The previous-continuation files were read without modification.",
                        "This package does not newly certify every preexisting historical release archive."],
              "release_acceptance": False, "full_product_complete": False,
              "members": [{"path": name, **expected} for name, (_, expected) in before.items()]}
    write(manifest, record)
    print(json.dumps({key: value for key, value in record.items() if key != "members"}, indent=2))
    return 0 if stable else 1


if __name__ == "__main__":
    raise SystemExit(main())
