from pathlib import Path
from dataclasses import asdict
from datetime import datetime, timezone
import platform
from fractions import Fraction
from unittest.mock import patch
import hashlib, json, subprocess, sys, time, traceback

ROOT, OUT = (Path(value).resolve() for value in sys.argv[1:3])
OUT.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(ROOT))
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.gltf import export_glb
from ontokin.scene import ExportOptions
from ontokin import reach_export

def snapshot():
    names = subprocess.check_output(['git', '-C', str(ROOT), 'ls-files', '-z']).decode().split('\0')
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() if (ROOT / name).exists() else None
            for name in names if name}

before = snapshot()
started_utc = datetime.now(timezone.utc).isoformat()
rows = []
for name, end in [('p01-prefix', Fraction(1, 4)), ('p01-full', Fraction(3))]:
    row = {'case': 'P01', 'end': str(end), 'fps': 2, 'helpers': False, 'stages': [], 'artifact': None}
    start = time.monotonic()
    compiler = None
    try:
        program = load_file_manifest(ROOT / 'docs/language-design/planar-reach-v0.1/p01.files.json')
        compiler = compile_construction(program)
        row['program_revision'] = program.program_revision
        row['after_compile_work'] = compiler.reach_work.record()
        row['after_compile_operations'] = compiler.budget.operations
        stage = reach_export.recording_stage
        def record(name, **kwargs):
            row['stages'].append({'name': name, 'work_before': kwargs['work'].record()})
            return stage(name, **kwargs)
        with patch.object(reach_export, 'recording_stage', side_effect=record):
            result = export_glb(compiler.model, options=ExportOptions(end=end, fps=2, helpers=False),
                                target_contract='ontokin.glb/0.6', work=compiler.reach_work)
        path = OUT / (name + '.glb')
        path.write_bytes(result.data)
        row.update(status='passed', artifact={'path': path.name, 'bytes': len(result.data),
                   'sha256': hashlib.sha256(result.data).hexdigest()}, report=result.report)
    except Exception as error:
        row.update(status='failed', exception=type(error).__name__, message=str(error), traceback=traceback.format_exc())
        if hasattr(error, 'diagnostic'):
            row['diagnostic'] = asdict(error.diagnostic)
    row['work_final'] = compiler.reach_work.record() if compiler is not None else None
    row['construction_operations'] = compiler.budget.operations if compiler is not None else None
    row['duration_seconds'] = time.monotonic() - start
    rows.append(row)
    print(json.dumps({k:v for k,v in row.items() if k not in {'traceback','stages','report','work_final','after_compile_work'}}), flush=True)
after = snapshot()
report = {'started_at': started_utc, 'ended_at': datetime.now(timezone.utc).isoformat(),
          'environment': {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform()},
          'command': sys.argv, 'release_acceptance': False, 'full_product_complete': False,
          'source_commit': subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD']).decode().strip(),
          'source_tree': subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD^{tree}']).decode().strip(),
          'stable_inputs': before == after, 'rows': rows, 'source_file_hashes': before,
          'claim': 'Actual development export attempts; no release or destination acceptance.',
          'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
(OUT / 'report.json').write_text(json.dumps(report, indent=2, default=str) + '\n')
(OUT / 'probe_current_export.py').write_bytes(Path(__file__).read_bytes())
