"""Run one literal development command with immutable tracked input receipts."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

root, output = (Path(value).resolve() for value in sys.argv[1:3])
command = sys.argv[3:]
if not command or root == output or root in output.parents:
    raise ValueError("Need a literal command and a fresh output outside the source checkout")
output.mkdir(parents=True, exist_ok=False)

def git(*args):
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()

def write(name, value):
    (output / name).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")

def snapshot():
    files = {}
    for name in git("ls-files").splitlines():
        raw = (root / name).read_bytes()
        files[name] = {"bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}
    return {"commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
            "status": git("status", "--porcelain"), "files": files}

before = snapshot()
write("inputs-before.json", before)
report = {"schema_version": "ontokin.development-command/0.1", "command": command,
          "cwd": str(root), "started_at": datetime.now(timezone.utc).isoformat(),
          "source_commit": before["commit"], "source_tree": before["tree"],
          "environment": {"python": sys.version, "platform": platform.platform(),
                          "python_executable": sys.executable},
          "release_acceptance": False, "full_product_complete": False,
          "runner_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
try:
    report["environment"]["command_version"] = subprocess.check_output(
        [command[0], "--version"], cwd=root, text=True, stderr=subprocess.STDOUT, timeout=10).strip()
except (OSError, subprocess.SubprocessError) as error:
    report["environment"]["version_error"] = str(error)
start = time.monotonic()
with (output / "command.log").open("wb") as log:
    result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT,
                            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"})
after = snapshot()
write("inputs-after.json", after)
report.update(ended_at=datetime.now(timezone.utc).isoformat(),
              duration_seconds=time.monotonic() - start, returncode=result.returncode,
              stable_inputs=before == after, tracked_input_count=len(before["files"]),
              status="passed" if result.returncode == 0 and before == after else "failed",
              log_sha256=hashlib.sha256((output / "command.log").read_bytes()).hexdigest())
write("report.json", report)
(output / "record_command.py").write_bytes(Path(__file__).read_bytes())
print(json.dumps(report, indent=2))
print((output / "command.log").read_text(errors="replace")[-6000:])
raise SystemExit(0 if report["status"] == "passed" else 1)
