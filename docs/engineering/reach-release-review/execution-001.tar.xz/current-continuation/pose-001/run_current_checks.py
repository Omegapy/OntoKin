"""Record actual current-checkout tests without hiding sparse historical inputs."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import unittest


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def worker(root, report, patterns):
    os.chdir(root)
    sys.path[:0] = [str(root), str(root / 'tests')]
    suite = unittest.TestSuite()
    for pattern in patterns:
        suite.addTests(unittest.defaultTestLoader.discover(str(root / 'tests'), pattern=pattern))
    ids = []
    def collect(test):
        if isinstance(test, unittest.TestSuite):
            for item in test: collect(item)
        else: ids.append(test.id())
    collect(suite)
    if not ids or len(ids) != len(set(ids)):
        raise ValueError('Test inventory is empty or duplicated')
    records = []
    class Result(unittest.TextTestResult):
        def addSuccess(self, test):
            super().addSuccess(test)
            records.append({'test': test.id(), 'status': 'passed'})
        def addFailure(self, test, error):
            super().addFailure(test, error)
            records.append({'test': test.id(), 'status': 'failed', 'traceback': self._exc_info_to_string(error, test)})
        def addError(self, test, error):
            super().addError(test, error)
            records.append({'test': test.id(), 'status': 'error', 'traceback': self._exc_info_to_string(error, test)})
        def addSkip(self, test, reason):
            super().addSkip(test, reason)
            records.append({'test': test.id(), 'status': 'skipped', 'reason': reason})
        def addExpectedFailure(self, test, error):
            super().addExpectedFailure(test, error)
            records.append({'test': test.id(), 'status': 'expected_failure'})
        def addUnexpectedSuccess(self, test):
            super().addUnexpectedSuccess(test)
            records.append({'test': test.id(), 'status': 'unexpected_success'})
        def addSubTest(self, test, subtest, error):
            super().addSubTest(test, subtest, error)
            if error is not None:
                records.append({'test': test.id(), 'subtest': str(subtest), 'status': 'failed',
                                'traceback': self._exc_info_to_string(error, test)})
    result = unittest.TextTestRunner(verbosity=2, resultclass=Result).run(suite)
    passed = result.wasSuccessful() and result.testsRun == len(ids) and not result.skipped and not result.expectedFailures
    write(report, {'status': 'passed' if passed else 'failed', 'tests_discovered': len(ids),
                   'tests_run': result.testsRun, 'inventory': ids, 'records': records,
                   'failures': len(result.failures), 'errors': len(result.errors),
                   'skips': len(result.skipped), 'expected_failures': len(result.expectedFailures),
                   'unexpected_successes': len(result.unexpectedSuccesses)})
    return 0 if passed else 1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('repository', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--pattern', action='append', default=[])
    parser.add_argument('--worker', action='store_true')
    parser.add_argument('--timeout', type=int, default=900)
    args = parser.parse_args()
    root, output = args.repository.resolve(), args.output.resolve()
    patterns = args.pattern or ['test_*.py']
    if args.worker:
        return worker(root, output, patterns)
    if root == output or root in output.parents:
        raise ValueError('Keep execution output outside the source checkout')
    output.mkdir(parents=True, exist_ok=False)
    def git(*parts):
        return subprocess.check_output(['git', '-C', str(root), *parts], text=True).rstrip('\n')
    def snapshot():
        tracked = git('ls-files', '--stage', '-z').split('\0')
        files = []
        for entry in tracked:
            if not entry: continue
            header, path = entry.split('\t', 1)
            mode, expected, stage = header.split()
            local = root / path
            if not local.exists():
                files.append({'path': path, 'git_blob': expected, 'available': False})
                continue
            raw = local.read_bytes()
            actual = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
            files.append({'path': path, 'git_blob': expected, 'actual_git_blob': actual,
                          'available': True, 'matches_index': actual == expected, 'bytes': len(raw),
                          'sha256': hashlib.sha256(raw).hexdigest()})
        return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
                'status': git('status', '--porcelain'), 'files': files}
    before = snapshot()
    write(output / 'inputs-before.json', before)
    missing = [x for x in before['files'] if not x['available']]
    if any(not x['path'].endswith('.zip') and '.zip.part' not in x['path'] for x in missing):
        raise ValueError('Required non-archive input is missing')
    if any(not x.get('matches_index', True) for x in before['files']):
        raise ValueError('Tracked bytes differ from their observed index identities')
    command = [sys.executable, str(Path(__file__).resolve()), str(root), str(output / 'tests.json'), '--worker']
    for pattern in patterns: command += ['--pattern', pattern]
    report = {'schema_version': 'ontokin.reach-development-execution/0.1',
              'started_at': datetime.now(timezone.utc).isoformat(), 'command': command, 'cwd': str(root),
              'source_commit': before['commit'], 'source_tree': before['tree'], 'patterns': patterns,
              'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'environment': {'executable': sys.executable, 'python': platform.python_version(),
                              'platform': platform.platform(), 'pythonpath': os.environ.get('PYTHONPATH')},
              'unavailable_historical_archives': missing, 'complete_checkout': not missing,
              'release_acceptance': False, 'full_product_complete': False}
    write(output / 'report.json', report)
    start = time.monotonic()
    with (output / 'tests.log').open('wb') as log:
        try:
            result = subprocess.run(command, cwd=root, stdout=log, stderr=subprocess.STDOUT,
                                    timeout=args.timeout, env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'})
            report['returncode'] = result.returncode
        except subprocess.TimeoutExpired:
            report['returncode'] = None
            report['timeout_seconds'] = args.timeout
    after = snapshot()
    write(output / 'inputs-after.json', after)
    report.update(ended_at=datetime.now(timezone.utc).isoformat(), duration_seconds=time.monotonic() - start,
                  stable_inputs=before == after,
                  available_input_count=sum(x['available'] for x in before['files']),
                  log_sha256=hashlib.sha256((output / 'tests.log').read_bytes()).hexdigest(),
                  status='passed' if report['returncode'] == 0 and before == after else 'failed')
    if (output / 'tests.json').exists():
        tests = json.loads((output / 'tests.json').read_text())
        report.update({key: tests[key] for key in ('tests_discovered', 'tests_run', 'failures', 'errors', 'skips', 'expected_failures')})
    write(output / 'report.json', report)
    (output / 'run_current_checks.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({k: v for k, v in report.items() if k not in {'unavailable_historical_archives', 'command'}}, indent=2))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
