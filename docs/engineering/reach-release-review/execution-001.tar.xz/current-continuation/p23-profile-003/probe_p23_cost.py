"""Development-only counters around unchanged bounded P23 execution."""
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
import time
from unittest.mock import patch

root, output = map(lambda s: Path(s).resolve(), sys.argv[1:3])
output.mkdir(parents=True, exist_ok=False)
sys.path[:0] = [str(root), str(root / "tests")]

def git(*args):
    return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()

def snapshot():
    return {"commit": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
            "status": git("status", "--porcelain"),
            "files": {name: hashlib.sha256((root / name).read_bytes()).hexdigest()
                      for name in git("ls-files").splitlines()}}

before = snapshot()
report = {"source": before, "started_at": datetime.now(timezone.utc).isoformat(),
          "environment": {"python": sys.version, "platform": platform.platform()},
          "command": sys.argv, "release_acceptance": False, "observations": []}
from ontokin.reach_numeric import ReachExecutionWork
from ontokin.reach_runtime import ReachSimulator
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from test_reach_source_corpus import CASES

directory, case = CASES["P23"]
original_charge = ReachExecutionWork.charge
original_methods = {name: getattr(ReachSimulator, name) for name in
                    ("_resolve_kinematics", "_process_boundary", "_validate_staged", "_reach_map", "snapshot", "_latch", "_tip_base")}

for when, side in [(Fraction(2), "after")]:
    row = {"time": str(when), "side": side, "stages": []}
    report["observations"].append(row)
    compiler = compile_construction(load_file_manifest(directory / case["file_manifest"]))
    row["construction_operations"] = compiler.budget.operations
    stacks = Counter()
    def charged(self, kind="checkpoint", amount=1):
        if self is compiler.reach_work:
            frame = sys._getframe(1)
            names = []
            for _ in range(6):
                if frame is None: break
                names.append(frame.f_code.co_name)
                frame = frame.f_back
            stacks[(kind, " <- ".join(names))] += amount
        return original_charge(self, kind, amount)
    def wrapped(name):
        original = original_methods[name]
        def run(self, *args, **kwargs):
            initial = self.work.operations
            counts = Counter(self.work.counts)
            details = {"method": name, "time": str(args[0]) if args else None,
                       "started_operations": initial}
            row["stages"].append(details)
            try:
                result = original(self, *args, **kwargs)
                details["status"] = "returned"
                return result
            except BaseException as error:
                details["status"] = "raised"
                details["exception"] = str(error)
                raise
            finally:
                details["ended_operations"] = self.work.operations
                details["operation_delta"] = self.work.operations - initial
                details["counts"] = dict(Counter(self.work.counts) - counts)
        return run
    from contextlib import ExitStack
    try:
        with ExitStack() as stack:
            stack.enter_context(patch.object(ReachExecutionWork, "charge", charged))
            for name in original_methods:
                stack.enter_context(patch.object(ReachSimulator, name, wrapped(name)))
            result = ReachSimulator(compiler.model, work=compiler.reach_work).advance(when, side)
            row["status"] = "returned"
            row["reaches"] = len(result["reaches"])
    except BaseException as error:
        row["status"] = "raised"
        row["exception"] = {"type": type(error).__name__, "message": str(error)}
    row["final_construction_operations"] = compiler.budget.operations
    row["reach_work"] = compiler.reach_work.record()
    row["charge_stacks"] = [{"kind": kind, "stack": stack, "charged": n}
                            for (kind, stack), n in stacks.most_common()]

after = snapshot()
report.update(ended_at=datetime.now(timezone.utc).isoformat(), stable_inputs=before == after)
(output / "probe_p23_cost.py").write_bytes(Path(__file__).read_bytes())
(output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
(output / "inputs-after.json").write_text(json.dumps(after, indent=2) + "\n")
for row in report["observations"]:
    print(json.dumps({k: v for k, v in row.items() if k not in {"stages", "charge_stacks"}}, indent=2))
    print(json.dumps(row["charge_stacks"][:18], indent=2))
