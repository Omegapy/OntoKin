"""Publish the exact verified receipt members in a compact solid tar.xz."""
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys
import tarfile
import zipfile

output = Path(sys.argv[1]).resolve()
backup = Path(sys.argv[2]).resolve()
backup.mkdir(parents=True, exist_ok=True)
source = output / "execution-001.zip"
manifest_path = output / "execution-001.json"
target = output / "execution-001.tar.xz"
if target.exists():
    raise ValueError("Compact archive must be new")

def identity(data):
    return {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}

original_manifest = manifest_path.read_bytes()
original = json.loads(original_manifest)
if identity(source.read_bytes()) != {key: original["archive"][key] for key in ("bytes", "sha256")}:
    raise ValueError("Intermediate ZIP identity changed")
for path in (source, manifest_path):
    saved = backup / path.name
    if saved.exists():
        raise ValueError("Backup must be new")
    shutil.copy2(path, saved)
    if identity(saved.read_bytes()) != identity(path.read_bytes()):
        raise ValueError("Backup mismatch")

def verify_original_files():
    for member in original["members"]:
        label, relative = member["path"].split("/", 1)
        path = Path(original["source_roots"][label]) / relative
        if identity(path.read_bytes()) != {key: member[key] for key in ("bytes", "sha256")}:
            raise ValueError("Original receipt changed: " + member["path"])

verify_original_files()
started = datetime.now(timezone.utc).isoformat()
members = list(original["members"])
extras = {"packaging/original-zip-manifest.json": original_manifest,
          "packaging/compact_archive.py": Path(__file__).read_bytes()}
members.extend({"path": name, **identity(data)} for name, data in extras.items())
with zipfile.ZipFile(source) as zipped, tarfile.open(target, "x:xz", preset=6) as packed:
    if zipped.testzip() is not None:
        raise ValueError("Intermediate ZIP CRC failed")
    for member in members:
        name = member["path"]
        if name.startswith("/") or ".." in Path(name).parts:
            raise ValueError("Unsafe archive member")
        data = extras[name] if name in extras else zipped.read(name)
        if identity(data) != {key: member[key] for key in ("bytes", "sha256")}:
            raise ValueError("Input member changed: " + name)
        info = tarfile.TarInfo(name)
        info.size, info.mtime, info.mode = len(data), 946684800, 0o644
        packed.addfile(info, io.BytesIO(data))
with tarfile.open(target, "r:xz") as packed:
    if packed.getnames() != [member["path"] for member in members]:
        raise ValueError("Compact inventory mismatch")
    for member in members:
        data = packed.extractfile(member["path"]).read()
        if identity(data) != {key: member[key] for key in ("bytes", "sha256")}:
            raise ValueError("Compact member mismatch: " + member["path"])
verify_original_files()
result = dict(original)
result.update(schema_version="ontokin.reach-development-archive/0.2",
              archive={"path": target.name, **identity(target.read_bytes())},
              archive_member_count=len(members),
              uncompressed_bytes=sum(member["bytes"] for member in members),
              tar_member_sha256_verified=True,
              intermediate_zip=original["archive"],
              packaging={"started_at": started, "finished_at": datetime.now(timezone.utc).isoformat(),
                         "command": [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
                         "format": "tar.xz", "xz_preset": 6,
                         "original_receipts_rechecked_before_and_after": True},
              members=members)
result["notes"] = ["Archive member dates are fixed to 2000-01-01; execution clocks remain in the original reports.",
                   "All original ZIP members are retained byte-for-byte. Two packaging records are added.",
                   "The intermediate ZIP was an uncommitted packaging artifact; its manifest is retained inside this archive.",
                   "Archive integrity is not release acceptance. Failed and incomplete attempts retain their original meaning.",
                   "The previous-continuation files were read without modification.",
                   "This package does not newly certify every preexisting historical release archive."]
result["intermediate_zip_crc_checked"] = result.pop("zip_crc_checked")
manifest_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
source.unlink()
print(json.dumps({key: result[key] for key in ("status", "archive", "archive_member_count",
                  "uncompressed_bytes", "tar_member_sha256_verified", "packaging")}, indent=2))
