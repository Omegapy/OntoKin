# C270 evidence finalization: integrated failure evidence, open acceptance

## What this phase establishes

The existing C270 candidate was independently reviewed and its eligible evidence integrated. Actual-main documentation/workflow checks passed, and the unfinished scope branch was observed retained. Exact PR/commit, review and check identities are in CHECKPOINT.json and session-evidence/FINALIZATION-STATE.json. This delivers a reviewable failure checkpoint; it does not qualify H16 or finish C270.

| Requirement | State at freeze |
| --- | --- |
| R01 independent source-valid fixture/oracle | Done; frozen original expectations retained |
| R02 exact refusal classification | Unmet: three actual calls returned MALFORMED instead of UNSUPPORTED_SOURCE_FORM |
| R03 affected checks and independent review | Done; original 108-method cohort plus exact-candidate review |
| R04 reviewed evidence integration | Done; verified resulting main and unfinished-branch disposition |
| R05 verified partial delivery/closure decision | Final package review, saves and separate receipt occur after freeze; parent remains open |

The original execution revision is `1ae7b594cc075031d11f2f1a33e4c5c0f0171da4`. Original-source observation and comparison passed. Modified-source observation, binding and comparison retained identities/reason and no qualified partial outputs, but failed the exact category. Existing regressions passed 108 methods and 14 original corpus bindings. Passing regressions do not erase the failed new control. This recovery did not rerun behavioral execution or modify observer/runtime/control/expectation/contract bytes.

## Evidence and preservation

Every C270 engineering file and task record at `a8e0bd1d446396b220075b5329e2c769c338f6a2` is included, with original failures, setup corrections, preexecution evidence, candidate review and integrated records. Each snapshot has exact commit/blob/mode/size/hash provenance. Current-session checks not committed at the snapshot are distinctly supplied under session-evidence with Director-provided identities. The package preserves the original historical dependency record and confirmed early-recovery identity.

No passing hosted-CI claim follows from zero status contexts or runs. Parent/issue remain open; branch-disposition evidence records actual observations, including any automatic removal/restoration. Repository settings may delete branches at merge; preserve the unfinished branch according to recorded disposition rather than assuming absence is intentional cleanup.

## Remaining work and stop

Complete independent package review, confirmed ZIP/prompts saves, external receipt and ownership disposition. Stop this finalization phase. A fresh main chat can explicitly declare one narrow C270 correction to classify declared unsupported SiteRef forms correctly while preserving genuine malformed-input refusals and existing supported behavior. Retain all original failed evidence and unchanged exact-category assertions; select affected checks and obtain independent review for that later change.

H20/H22/H24 remain open. No full C260, site/world, physical, native/model, accepted-revision or whole-product claim is made. Live GitHub supplies current state; package integrity is not product qualification.
