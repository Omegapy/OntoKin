#!/usr/bin/env python3
"""Read-only C270 package/state/prompt reconciliation; reviewer-owned outputs only."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/9e9d17639499')
OUT = ROOT / 'recovery_evidence/package_review'
REPO = ROOT / 'OntoKin'
ARCHIVE = ROOT / 'deliverables/OntoKin_C270_Development_Handoff_2026-11-20.zip'
SPEC = ROOT / 'recovery_evidence/final_package_inputs.json'
rows = []


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def check(ok, subject, detail=None):
    row = {'id': len(rows) + 1, 'subject': subject, 'passed': bool(ok)}
    if detail is not None:
        row['detail'] = detail
    rows.append(row)


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def ancestor(a, b):
    return subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', a, b], check=False).returncode == 0


def read_local(path):
    return json.loads(Path(path).read_bytes())


result = {'schema': 'ontokin.c270.package-boundary-audit/1',
          'reviewer': '/root/package_review', 'checks': rows,
          'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
try:
    spec = read_local(SPEC)
    with zipfile.ZipFile(ARCHIVE) as z:
        def j(name):
            return json.loads(z.read(name))

        def text(name):
            return z.read(name).decode()

        c = j('CHECKPOINT.json')
        source = spec['source_revision']
        integration = j('repository/' + spec['integration']['record'])
        merge = integration['merge_commit']
        candidate = integration['candidate']
        main_before = integration['starting_main']
        task = j('repository/docs/workflow/tasks/C270/task.json')
        current = j('repository/docs/workflow/CURRENT.json')
        observed = j('session-evidence/publication/freeze-state-readback.json')
        review_path = 'repository/' + spec['review']['report']
        review = j(review_path)
        check(spec['integration']['merge_commit'] == merge, 'Merge identity agrees across package inputs and canonical integration')
        check(spec['integration']['reviewed_candidate'] == candidate == spec['review']['candidate'], 'Candidate identity agrees across integration and review')
        check(spec['integration']['reviewed_tree'] == integration['candidate_tree'], 'Reviewed tree agrees')
        check(git('rev-parse', candidate + '^{tree}').decode().strip() == integration['candidate_tree'], 'Reviewed candidate is exact declared Git tree')
        check(git('rev-parse', merge + '^{tree}').decode().strip() == integration['merge_tree'] == integration['candidate_tree'], 'Merged tree equals exact reviewed tree')
        parents = git('show', '-s', '--format=%P', merge).decode().strip().split()
        check(parents == integration['merge_parents'] == [main_before, candidate], 'Merge has exact expected-main and reviewed-candidate parents')
        check(git('show', '-s', '--format=%P', source).decode().strip().split() == [merge], 'Packaged checkpoint directly descends from verified merge')
        check(ancestor('1ae7b594cc075031d11f2f1a33e4c5c0f0171da4', candidate), 'Original execution history retained by candidate')
        check(ancestor('1a2e9f85fa3ba210a16235e5660f1762ea8a953e', source), 'Original published failure history retained by packaged source')
        check(current['observed_main'] == merge, 'CURRENT records preceding observed merge without inventing its own later SHA')
        check(c['observed_main']['sha'] == source == observed['main'], 'Outer checkpoint records later actual frozen main')
        check(observed['observed_at_utc'] == spec['observed_at_utc'], 'Freeze observation time agrees')
        check(observed['issue'] == spec['issue'] and observed['issue']['state'] == 'open', 'Observed scope270 remains open')
        check(observed['pr'] == spec['integration']['pull_request'], 'Exact PR readback agrees with checkpoint input')
        check(observed['pr']['merged'] is True and observed['pr']['state'] == 'closed' and observed['pr']['number'] == 271, 'PR271 is observed merged and closed')
        check(observed['pr']['merge_commit'] == merge and observed['pr']['head'] == candidate, 'PR merge and head match Git integration identities')
        check(task['completion']['merge_commit'] == merge and task['completion']['evidence_candidate'] == candidate, 'Task completion metadata binds the evidence merge only')
        check(task['completion']['implementation_commit'] is None and task['status'] == 'in_progress', 'Task claims no corrective implementation or parent completion')
        check(task['completion']['scope_issue_state'] == 'open' and task['completion']['branch_disposition'] == 'retained', 'Task open issue and retained branch agree')
        check(observed['branch']['name'] == spec['branch']['name'] == task['branch'], 'Existing branch name agrees across all current records')
        check(observed['branch']['head'] == spec['branch']['head'] == candidate, 'Restored unfinished branch head agrees')
        check(integration['branch']['restoration_readback_verified'] is True and integration['branch']['restored_same_name'] is True, 'Canonical integration preserves branch restoration fact')
        branch_readback = j('repository/docs/engineering/localized-repair-c270/evidence/recovery-20261120/branch-retention-readback.json')
        branch_ref = json.loads(branch_readback['readback']['content'])
        check(branch_ref['ref'] == 'refs/heads/' + spec['branch']['name'] and branch_ref['object']['sha'] == candidate, 'Raw GitHub branch restoration readback agrees')
        merge_readback = j('repository/docs/engineering/localized-repair-c270/evidence/recovery-20261120/integration-readback.json')
        main_ref = json.loads(merge_readback['readback']['content'])
        check(merge_readback['update']['success'] is True and main_ref['ref'] == 'refs/heads/main' and main_ref['object']['sha'] == merge, 'Raw integration update/readback agrees')
        check(identity(z.read(review_path))['sha256'] == spec['review']['sha256'] == integration['review']['report_sha256'], 'Exact independent review report hash agrees')
        check(review['candidate'] == candidate and review['tree'] == integration['candidate_tree'] and review['compared_main'] == main_before, 'Review covers exact candidate, tree and expected main')
        check(review['passed'] is True and review['mandatory_findings'] == [] and review['total_static_checks'] == 429, 'Review result and 429-check count are substantiated')
        check(review['reviewer'] == spec['review']['reviewer'] == '/root/candidate_review', 'Candidate reviewer identity agrees and is separate from package reviewer')
        check(review['behavioral_runs'] == 0 and review['parent_and_issue_must_remain_open'] is True, 'Independent candidate review preserves failed parent boundary')

        for label, record_path, expected_rev, local in [
            ('actual-main', 'repository/' + spec['actual_main_checks']['integration_record'], merge, ROOT / 'recovery_evidence/checks/actual-main'),
            ('published-checkpoint', spec['actual_main_checks']['published_checkpoint_record'], source, ROOT / 'recovery_evidence/checks/published-checkpoint'),
        ]:
            checks = j(record_path)
            check(z.read(record_path) == (local / 'CHECKS.json').read_bytes(), label + ' exact supplied check record')
            check(checks['source_revision'] == expected_rev and checks['source_tree'] == git('rev-parse', expected_rev + '^{tree}').decode().strip(), label + ' checks bind exact source/tree')
            check(checks['source_clean'] is True and checks['result'] == 'passed', label + ' clean-source successful result')
            check({x['name'] for x in checks['checks']} == {'documentation', 'workflow'}, label + ' required scope-specific check inventory')
            check(bool(checks['environment']['python']) and bool(checks['environment']['platform']), label + ' explicit execution environment')
            runner_path = str(Path(checks['runner']['path']).relative_to(REPO))
            check(identity(git('show', expected_rev + ':' + runner_path)) == {k: checks['runner'][k] for k in ['bytes', 'sha256']}, label + ' exact pinned record runner')
            for row in checks['checks']:
                name = row['name']
                log_path = str(Path(record_path).parent / row['log']['path'])
                data = z.read(log_path)
                check(identity(data) == {k: row['log'][k] for k in ['bytes', 'sha256']}, label + ' exact log identity: ' + name)
                check(data == (local / row['log']['path']).read_bytes(), label + ' supplied log bytes agree: ' + name)
                check(row['result'] == 'passed' and row['exit_code'] == 0 and row['started_at_utc'] < row['finished_at_utc'], label + ' successful recorded process: ' + name)
                expected_cmd = ['-B', 'tools/chat_workflow.py', 'check'] if name == 'workflow' else ['-B', 'docs/maintenance/reorganization-2026-10-17/verify_reorganization.py']
                check(row['command'][1:] == expected_cmd, label + ' exact required command: ' + name)
                if name == 'workflow':
                    check(b'Workflow structure passed' in data and b'Local structural check only' in data, label + ' workflow log reports pass with correct limit')
                else:
                    check(json.loads(data)['failures'] == [], label + ' documentation log has no failures')

        status = text('repository/STATUS.md')
        lease_start = status.index('## Main integration lease')
        lease_end = status.find('\n## ', lease_start + 1)
        lease = status[lease_start:lease_end]
        check('State: held.' in lease and spec['ownership']['owner'] in lease, 'Frozen STATUS lease agrees with held ownership')
        check(spec['ownership']['acquired_at_utc'] in lease and spec['ownership']['expires_at_utc'] in lease, 'Lease acquisition and expiry agree')
        check(spec['ownership']['owner'] == task['owner'] == task['session_phase']['owner'] == integration['owner'], 'Canonical owner agrees across frozen task and integration')
        frozen = datetime.datetime.fromisoformat(c['frozen_at_utc'])
        acquired = datetime.datetime.fromisoformat(spec['ownership']['acquired_at_utc'].replace('Z', '+00:00'))
        expires = datetime.datetime.fromisoformat(spec['ownership']['expires_at_utc'].replace('Z', '+00:00'))
        check(acquired <= frozen < expires, 'Freeze occurs within declared lease')
        check(spec['ownership']['release'] == 'pending confirmed final delivery and external receipt', 'Future ownership release is not claimed at freeze')
        check(c['unknown_operations'] == task['recovery']['known_unknown_operations'] == [], 'Known unknown-operation lists agree')
        check({x['id'] for x in c['workers']} == {'/root', '/root/candidate_review', '/root/handoff_audit', '/root/package_review'}, 'All actual workers and remaining duties recorded at freeze')
        for path, local_path in spec['additional_session_files'].items():
            check(z.read(path) == Path(local_path).read_bytes(), 'Exact unique session evidence: ' + path)
        for name in ['README.md', 'INPUTS.json', 'IMPLEMENTATION.md', 'endpoint_reader.py', 'endpoint_control_fixtures.py', 'test_endpoint_reader.py']:
            path = 'docs/engineering/localized-repair-c268/' + name
            check('repository/' + path in z.namelist(), 'C268 next-action dependency included: ' + name)
        for path in ['docs/workflow/prompts/CONTINUE.md', 'docs/workflow/prompts/RECOVER.md']:
            check('repository/' + path in z.namelist(), 'PKG-001 corrected snapshot included: ' + path)

        continued = text('PROMPT-1-CONTINUE.md')
        recovered = text('PROMPT-2-RECOVER.md')
        next_task = text('NEXT-TASK.md')
        for name, prompt in [('continue', continued), ('recover', recovered)]:
            check('Repository: https://github.com/Omegapy/OntoKin' in prompt and ARCHIVE.name in prompt, name + ' identifies repository and exact handoff without prior chat')
            check('Observe actual main' in prompt and 'read live CHATGPT-START-HERE.md' in prompt, name + ' reconciles live instructions/state')
            check('Inspect actual destinations before retry' in prompt and 'Frozen save_pending does not negate a later confirmed receipt' in prompt, name + ' handles uncertain writes and temporal receipts')
            check('Confirm an early recovery ZIP before substantial work' in prompt, name + ' preserves early-save gate')
            check('receipt separately' in prompt and 'stop' in prompt.lower(), name + ' requires external receipt and stop')
        check('First confirm the existing finalization is integrated, checked and saved.' in continued, 'Continuation first confirms prior finalization delivery')
        check('If a finalization gate remains, finish only that gate' in continued and 'do not start the correction in the same chat' in continued, 'Continuation cannot mix unmet recovery with correction')
        check('If all finalization gates are complete, explicitly declare one narrow C270 classification-correction phase' in continued, 'Continuation explicitly declares one new bounded phase under active parent')
        check('resume the existing task/unfinished branch' in continued and 'update its plan' in continued, 'Continuation preserves active task and unfinished branch')
        check('preserving true malformed-input diagnostics' in continued and 'Preserve the frozen fixture/expectation and adopted C260/source semantics' in continued, 'Continuation keeps original acceptance and malformed-input distinction')
        pin_clause = 'Inspect the dependency pin chain C265 → C266 → C267 → C268; update only necessary successor/pin identities without weakening byte binding, and include C268 historical-admission checks if its pins change.'
        check(pin_clause in continued and pin_clause in next_task, 'PKG-002 pin and affected-check obligation preserved in both entry points')
        check('If all finalization gates and saved delivery are already complete, report the existing handoff and stop' in recovered, 'Recovery stops when finalization delivery already exists')
        check('do not start the queued correction as part of recovery' in recovered, 'Recovery never starts queued correction')
        check('complete no more than one bounded phase' in recovered and 'Stop after one bounded phase and verified delivery' in continued, 'Both complete reusable prompts preserve one-phase boundary')
        check('Keep C270 and issue open while acceptance fails' in recovered and 'Keep parent/issue open while any acceptance remains unmet' in continued, 'Both prompts preserve parent and issue while failed')
        check('no H20/H22/H24 work or second milestone in that chat' in next_task, 'Next task excludes a second milestone')
        check('Final package verification and eventual save receipt necessarily follow this freeze and remain external.' in ' '.join(spec['known_unpublished_work']), 'Final verification and save receipt are explicitly external future events')
        early = j('session-evidence/recovery/CONFIRMED-EARLY-RECOVERY.json')
        upload = read_local(ROOT / 'recovery_evidence/early_finalization_upload_result.json')['results'][0]
        early_verification = j('session-evidence/recovery/early_finalization_verification.json')
        check(upload['status'] == 'succeeded' and early['status'] == 'confirmed', 'Early recovery save uses observed successful result')
        check(early['library_file_id'] == upload['library_file_id'] and early['filename'] == upload['file_name'] and early['version'] == upload['current_version_number'], 'Early saved identity agrees with upload result')
        check({k: early[k] for k in ['bytes', 'sha256']} == {k: early_verification[k] for k in ['bytes', 'sha256']}, 'Early receipt and verification archive identities agree')
        check(early['filename'] != ARCHIVE.name and 'not the final handoff' in early['purpose'], 'Early confirmed save is distinct from final pending save')
        selfcheck = read_local(ROOT / 'recovery_evidence/final_package_verification.json')
        check(identity(ARCHIVE.read_bytes()) == {k: selfcheck[k] for k in ['bytes', 'sha256']}, 'Independent archive identity equals packager frozen identity')
        check(selfcheck['source_revision'] == source and selfcheck['source_tree'] == spec['source_tree'], 'Packager source identity agrees')
        check(selfcheck['save'].startswith('pending') and selfcheck['independent_package_review'] == 'pending', 'Frozen packager result makes no future review/save claim')
        result['archive'] = {'path': str(ARCHIVE), **identity(ARCHIVE.read_bytes())}
        result['source_revision'] = source
        result['source_tree'] = spec['source_tree']
        result['prompts'] = [{'path': str(ROOT / 'deliverables' / name), **identity((ROOT / 'deliverables' / name).read_bytes())} for name in ['OntoKin_C270_Continue.md', 'OntoKin_C270_Recover.md']]
except Exception as exc:
    result['exception'] = {'type': type(exc).__name__, 'message': str(exc)}

result['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
result['check_count'] = len(rows)
result['failed_count'] = sum(not r['passed'] for r in rows)
result['result'] = 'passed' if not result.get('exception') and result['failed_count'] == 0 else 'failed'
result['limits'] = ['Static package and supplied readback agreement; no new behavioral execution or direct GitHub query', 'Final saved delivery and receipt remain the Director’s post-review obligations']
(OUT / 'BOUNDARY-AUDIT.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result.get(k) for k in ['result', 'check_count', 'failed_count', 'exception', 'archive', 'prompts']}, indent=2))
raise SystemExit(0 if result['result'] == 'passed' else 1)
