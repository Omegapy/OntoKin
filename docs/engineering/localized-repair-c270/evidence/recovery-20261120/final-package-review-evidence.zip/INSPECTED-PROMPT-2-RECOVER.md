# Recover active C270 at its first unmet gate

Repository: https://github.com/Omegapy/OntoKin

Source handoff: the attached or selected `OntoKin_C270_Development_Handoff_2026-11-20.zip`. Resolve its exact saved identity from the file/receipt; do not invent an ID. Read README-START-HERE.md, CHECKPOINT.json, HANDOFF.md, RECOVERY-STATUS.md and NEXT-TASK.md. Observe actual main; read live CHATGPT-START-HERE.md and required repository instructions in full once per unchanged file, retaining the read-set. Follow docs/workflow/PROTOCOL.md and HANDOFF.md.

Reconcile task/plan, existing C270 branch/PR/issue, ownership, exact test evidence, Library receipts, workers/processes and unpublished work. A timeout proves neither failed GitHub mutation nor failed upload. Inspect actual destinations before retry; retain operation and commit/ref identities. Frozen save_pending does not negate a later confirmed receipt. Use bounded independent subagents where available; keep evidence in files and canonical writes under one Director.

Recover the existing authorized task/branch at the first unmet gate and complete no more than one bounded phase. Separate completed, pending and unknown gates. If evidence is already integrated, address only remaining applicable checks, unfinished-branch disposition, saves/receipt and ownership. Do not replay the completed experiment, review or integration. If all finalization gates and saved delivery are already complete, report the existing handoff and stop; do not start the queued correction as part of recovery.

Preserve the failed R02 category evidence and any newer unique unpublished bytes with their exact base/application instructions. Confirm an early recovery ZIP before substantial work. Use independent bounded review where needed. Save a verified handoff if work remains, including exact remaining action and workers/operation state, and publish its receipt separately. Keep C270 and issue open while acceptance fails. Report verified outcomes, limits and the next action; stop. The narrow classification-correction phase is for a separately declared fresh main chat after finalization delivery is confirmed.
