#!/usr/bin/env python3
"""Independent C270 package integrity/source audit; local read-only inputs.

Writes only in the reviewer-owned output directory. This never executes product
code, modifies a repository/ref/package, uploads, or creates a delivery receipt.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import tempfile
import time
import zipfile

FROZEN_EXECUTION = '1ae7b594cc075031d11f2f1a33e4c5c0f0171da4'
ORIGINAL_BRANCH = '1a2e9f85fa3ba210a16235e5660f1762ea8a953e'
ROOT_FILES = {
    'README-START-HERE.md', 'CHECKPOINT.json', 'HANDOFF.md', 'NEXT-TASK.md',
    'RECOVERY-STATUS.md', 'PROMPT-1-CONTINUE.md', 'PROMPT-2-RECOVER.md',
    'HISTORICAL-DEPENDENCIES.json', 'MANIFEST-SHA256.json', 'SNAPSHOT-SOURCES.json',
}
REQUIRED_SNAPSHOTS = {
    'CHATGPT-START-HERE.md', 'AGENTS.md', 'GOAL.md', 'STATUS.md', 'ROLE.md',
    'docs/README.md', 'docs/workflow/registry.json', 'docs/workflow/CURRENT.json',
    'docs/workflow/PROTOCOL.md', 'docs/workflow/HANDOFF.md',
    'docs/workflow/BROWSER-PROMPTS.md',
    'docs/workflow/prompts/CONTINUE.md', 'docs/workflow/prompts/RECOVER.md',
    '.agents/skills/ontokin-session/SKILL.md',
    '.agents/skills/ontokin-delivery/SKILL.md',
    '.agents/skills/ontokin-learning/SKILL.md',
    'docs/engineering/OK-ENG-006-local-validation-and-hosted-ci-policy.md',
    'docs/engineering/OK-ENG-009-development-integration-and-branch-lifecycle.md',
    'docs/engineering/browser-workflow-c263/MIGRATION.md',
}

def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def safe_path(name):
    parts = PurePosixPath(name).parts
    return (bool(name) and not name.startswith('/') and '\\' not in name
        and '\0' not in name and ':' not in name and not name.endswith('/')
        and all(p not in ('', '.', '..') for p in name.split('/'))
        and parts and str(PurePosixPath(name)) == name)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', required=True)
    parser.add_argument('--spec', required=True)
    parser.add_argument('--repo', required=True)
    parser.add_argument('--continue-prompt', required=True)
    parser.add_argument('--recover-prompt', required=True)
    parser.add_argument('--historical-dependencies', required=True)
    parser.add_argument('--out', required=True)
    args = parser.parse_args()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    rows = []
    result = {'schema':'ontokin.c270.independent-package-audit/1',
        'worker':'/root/package_review', 'role':'independent package reviewer',
        'started_at_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
        'assertions':rows, 'inputs':{}, 'limits':[
            'No behavioral rerun, implementation repair, hosted CI or external model execution',
            'No repository, Git ref, package, external application or delivery mutation',
            'Package audit precedes save; final receipt/ownership updates are external',
            'Supplied Director live-state observations are checked for agreement; this script does not re-query GitHub',
            'Online GitHub continuation; not full historical offline restoration or product qualification']}
    def check(ok, subject, detail=None):
        row={'id':len(rows)+1, 'result':'passed' if ok else 'failed', 'subject':subject}
        if detail is not None: row['detail']=detail
        rows.append(row)
        return bool(ok)
    def require(ok, subject, detail=None):
        if not check(ok,subject,detail):
            raise ValueError(subject)
    def git(*argv):
        return subprocess.check_output(['git','-C',args.repo,*argv])
    def textgit(*argv):
        return git(*argv).decode().strip()
    def jread(path):
        return json.loads(path.read_bytes())
    try:
        archive=Path(args.archive)
        spec_path=Path(args.spec)
        spec=jread(spec_path)
        archive_id=identity(archive.read_bytes())
        result['inputs']={'archive':{'path':str(archive),**archive_id},
            'director_spec':{'path':str(spec_path),**identity(spec_path.read_bytes())},
            'script':{'path':str(Path(__file__)),**identity(Path(__file__).read_bytes())}}
        rev=spec['source_revision']
        tree=spec['source_tree']
        result['source_revision']=rev
        result['source_tree']=tree
        require(re.fullmatch('[0-9a-f]{40}',rev) is not None,'Full source commit identity')
        require(textgit('rev-parse',rev+'^{tree}')==tree,'Git tree matches Director source')
        require(spec['ready_to_freeze'] is True,'Director freeze authorization present')
        with zipfile.ZipFile(archive) as z:
            infos=z.infolist()
            names=[i.filename for i in infos]
            require(len(names)==len(set(names)),'ZIP names unique')
            require(all(safe_path(n) for n in names),'ZIP paths safe and canonical')
            require(all(not i.is_dir() for i in infos),'ZIP contains payload files only')
            require(all(not i.flag_bits & 1 for i in infos),'ZIP entries are unencrypted')
            require(all(stat.S_IFMT(i.external_attr >> 16) != stat.S_IFLNK for i in infos),'ZIP has no symlinks')
            require(z.testzip() is None,'CRC verification')
            require(ROOT_FILES <= set(names),'Required root filenames present',sorted(ROOT_FILES-set(names)))
            manifest=json.loads(z.read('MANIFEST-SHA256.json'))
            require('MANIFEST-SHA256.json' not in manifest,'Manifest excludes itself')
            require(set(names)==set(manifest)|{'MANIFEST-SHA256.json'},'Exact ZIP/manifest inventory')
            with tempfile.TemporaryDirectory(prefix='fresh-extraction-',dir=out) as tmp:
                dest=Path(tmp)
                z.extractall(dest)
                extracted={str(p.relative_to(dest)) for p in dest.rglob('*') if p.is_file()}
                require(extracted==set(names),'Fresh extraction exact inventory')
                for name,expected in sorted(manifest.items()):
                    require(set(expected)=={'bytes','sha256'},'Manifest identity schema: '+name)
                    require(isinstance(expected['bytes'],int) and expected['bytes']>=0 and re.fullmatch('[0-9a-f]{64}',expected['sha256']) is not None,'Manifest identity values: '+name)
                    check(identity((dest/name).read_bytes())==expected,'Manifest byte/hash equality: '+name)
                sources=jread(dest/'SNAPSHOT-SOURCES.json')
                require(sources['revision']==rev and sources['tree']==tree,'Snapshot index source/tree agreement')
                entries=sources['files']
                source_names=[r['package_path'] for r in entries]
                require(len(source_names)==len(set(source_names)),'Snapshot index entries unique')
                require(set(source_names)=={n for n in names if n.startswith('repository/')},'Snapshot index exactly covers repository payload')
                declared_paths={r['repository_path'] for r in entries}
                check(REQUIRED_SNAPSHOTS <= declared_paths,'Required governing snapshots including both canonical prompts',sorted(REQUIRED_SNAPSHOTS-declared_paths))
                for row in entries:
                    path=row['repository_path']
                    data=(dest/row['package_path']).read_bytes()
                    require(row['package_path']=='repository/'+path and safe_path(path),'Snapshot path mapping: '+path)
                    require(row['revision']==rev,'Snapshot exact declared revision: '+path)
                    check(identity(data)=={k:row[k] for k in ['bytes','sha256']},'Snapshot byte/hash identity: '+path)
                    source=git('show',rev+':'+path)
                    check(data==source,'Exact Git source bytes: '+path)
                    entry=git('ls-tree','-z',rev,'--',path).decode().rstrip('\0')
                    mode,kind,blob=entry.split('\t')[0].split()
                    check(kind=='blob' and mode==row['mode'] and blob==row['git_blob'],'Git blob and mode agreement: '+path)
                    check(hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob,'Computed Git blob hash: '+path)
                for directory in ['docs/workflow/tasks/C270','docs/workflow/tasks/C269','docs/engineering/localized-repair-c270']:
                    expected=set(textgit('ls-tree','-r','--name-only',rev,'--',directory).splitlines())
                    check(expected <= declared_paths,'Complete scoped repository directory: '+directory,{'files':len(expected),'missing':sorted(expected-declared_paths)})
                c=jread(dest/'CHECKPOINT.json')
                embedded=jread(dest/'session-evidence/FINALIZATION-STATE.json')
                task=jread(dest/'repository/docs/workflow/tasks/C270/task.json')
                current=jread(dest/'repository/docs/workflow/CURRENT.json')
                h16=jread(dest/'repository/docs/engineering/localized-repair-c270/evidence/candidate/h16/RESULTS.json')
                regressions=jread(dest/'repository/docs/engineering/localized-repair-c270/evidence/candidate/regressions/CHECKS.json')
                oracle=jread(dest/'repository/docs/engineering/localized-repair-c270/control/EXPECTED.json')
                require(embedded==spec,'Embedded finalization state equals Director input')
                check(c['task']=='C270' and c['phase']=='C270-recovery-finalization','Expected existing task and recovery phase')
                check(c['package_type']=='browser-session handoff for online GitHub continuation','Online continuation package type')
                check(c['source_snapshot_revision']==rev and c['source_snapshot_tree']==tree,'Checkpoint source/tree agreement')
                check(c['observed_main']=={'sha':rev,'tree':tree,'observed_at_utc':spec['observed_at_utc']},'Checkpoint observed-main agreement')
                for key in ['branch','integration','ownership','review','actual_main_checks','workers','unknown_operations','known_unpublished_work','snapshot_limit']:
                    check(c[key]==spec[key],'Checkpoint/Director agreement: '+key)
                check(c['scope_issue']==spec['issue'] and spec['issue']['state']=='open','Scope issue remains observed open')
                check(spec['branch']['retained'] is True,'Unfinished branch observed retained')
                check(spec['integration']['verified'] is True,'Integration is marked verified')
                check(spec['review']['verdict'] in ['approved','approved_with_limitations'],'Independent candidate review permits evidence integration')
                check(spec['actual_main_checks']['passed'] is True,'Applicable actual-main checks marked passed')
                check(task['status'] in ['in_progress','review'] and c['parent_task_status']==task['status'],'Parent remains incomplete')
                req={r['id']:r['status'] for r in task['requirements']}
                check(c['requirements']==req,'Checkpoint exact requirement state')
                check(req['R01']=='done' and req['R02']=='not_done' and req['R03']=='done' and req['R04']=='done','Acceptance states preserve failed R02 and completed evidence gates')
                check(req['R05']!='done' and task['delivery']['status']!='confirmed','Final delivery remains pending at snapshot')
                check(current['active_task']=='C270' and current['latest_task']=='C270','Current active/latest parent preserved')
                for taskid in {current['active_task'],current['latest_task']}:
                    check(all('docs/workflow/tasks/'+taskid+'/'+n in declared_paths for n in ['REQUIREMENTS.md','PLAN.md','task.json']),'Full current task core records: '+taskid)
                check(task['branch']=='work/c270-valid-siteref-control','Existing unfinished task branch preserved')
                check(h16['source_revision']==FROZEN_EXECUTION and regressions['source_revision']==FROZEN_EXECUTION,'Original behavioral execution revision retained')
                check(h16['source_tree']==textgit('rev-parse',FROZEN_EXECUTION+'^{tree}') and h16['source_tree']==regressions['source_tree'],'Original execution tree retained')
                check(h16['passed'] is False,'Original H16 control remains failed')
                failures=[x for x in h16['cases'] if x.get('exception',{}).get('code')=='MALFORMED']
                check(len(failures)==3 and all(x['passed'] is False for x in failures),'Three original MALFORMED failures retained')
                check(h16['expected_code']=='UNSUPPORTED_SOURCE_FORM','Unchanged exact unsupported-category acceptance')
                check(regressions['passed'] is True and regressions['total_methods']==108,'Original 108-method cohort preserved')
                corpus=[x for x in regressions['checks'] if x['name']=='corpus'] if 'checks' in regressions else []
                if not corpus:
                    corpus=[x for value in regressions.values() if isinstance(value,list) for x in value if isinstance(x,dict) and x.get('name')=='corpus' and 'assertions' in x]
                check(len(corpus)==1 and corpus[0]['passed'] is True and corpus[0]['assertions']['fourteen_original_bindings'] is True,'Original 14 corpus bindings preserved')
                check(c['original_execution']['behavioral_rerun_in_recovery'] is False and task['session_phase']['behavioral_reruns_this_phase']==0,'Recovery claims no behavioral rerun')
                input_rows=h16['inputs']+regressions['inputs']+oracle['reference_identities']
                for row in input_rows:
                    path=row['path']
                    check(path in declared_paths,'Referenced input included: '+path)
                    if path in declared_paths:
                        check(identity((dest/'repository'/path).read_bytes())=={k:row[k] for k in ['bytes','sha256']},'Frozen execution/contract input identity: '+path)
                for path in textgit('ls-tree','-r','--name-only',ORIGINAL_BRANCH,'--','docs/engineering/localized-repair-c270/control','docs/engineering/localized-repair-c270/evidence/candidate').splitlines():
                    check((dest/'repository'/path).read_bytes()==git('show',ORIGINAL_BRANCH+':'+path),'Original published failed-control evidence unchanged: '+path)
                for internal,external in [('PROMPT-1-CONTINUE.md',args.continue_prompt),('PROMPT-2-RECOVER.md',args.recover_prompt)]:
                    data=(dest/internal).read_bytes()
                    check(data==Path(external).read_bytes(),'Standalone prompt equality: '+internal)
                    result['inputs'][internal]={'path':external,**identity(data)}
                historical=(dest/'HISTORICAL-DEPENDENCIES.json').read_bytes()
                check(historical==Path(args.historical_dependencies).read_bytes(),'Historical dependency record unchanged')
                deps=json.loads(historical)
                for key in ['bytes','sha256','url']:
                    check(deps['C262'][key]==current['historical_handoff'][key],'C262 historical identity: '+key)
                check('save_pending' in c['session_delivery_at_freeze'] and 'external' in c['session_delivery_at_freeze'],'Frozen save state explicitly pending/external')
                check(c['external_delivery_record']=='docs/engineering/localized-repair-c270/DELIVERY.json','Canonical external final receipt path')
                check('repository/'+c['external_delivery_record'] not in names,'Future final delivery receipt absent from frozen package')
                check(not any(archive_id['sha256'].encode() in (dest/n).read_bytes() for n in names),'No self-referential future archive digest')
                for marker in [b'ldc1.',b'completion_token',b'upload_url',b'download_url']:
                    hits=[n for n in names if marker in (dest/n).read_bytes()]
                    check(not hits,'No raw transfer capability marker: '+marker.decode(),hits)
                result['counts']={'zip_entries':len(names),'manifest_payload_files':len(manifest),'exact_git_snapshots':len(entries),'referenced_input_rows':len(input_rows)}
                for name in ['CHECKPOINT.json','README-START-HERE.md','HANDOFF.md','NEXT-TASK.md','RECOVERY-STATUS.md','PROMPT-1-CONTINUE.md','PROMPT-2-RECOVER.md']:
                    (out/('INSPECTED-'+name)).write_bytes((dest/name).read_bytes())
    except Exception as exc:
        result['exception']={'type':type(exc).__name__,'message':str(exc)}
    result['finished_at_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
    result['assertion_count']=len(rows)
    result['passed_count']=sum(r['result']=='passed' for r in rows)
    result['failed_count']=sum(r['result']=='failed' for r in rows)
    result['result']='passed' if not result.get('exception') and not result['failed_count'] else 'failed'
    result['semantic_review']='separate independent report required'
    (out/'AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ['result','assertion_count','passed_count','failed_count']} | {'counts':result.get('counts'),'exception':result.get('exception')},indent=2))
    return 0 if result['result']=='passed' else 1

if __name__=='__main__':
    raise SystemExit(main())
