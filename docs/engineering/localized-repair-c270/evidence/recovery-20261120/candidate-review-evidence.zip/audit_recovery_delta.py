#!/usr/bin/env python3
"""Read-only static checks of C270 recovery records and fresh record-check logs."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys

REPO=Path('/workspace/scratch/9e9d17639499/OntoKin')
OUT=Path(__file__).resolve().parent
OLD='1a2e9f85fa3ba210a16235e5660f1762ea8a953e'
NEW='096803b2377966a04f9043139324bac2c65b6a52'
MAIN='ab0f196cd8c67dfa94cba369381dafa8b6c7a015'
P='docs/engineering/localized-repair-c270/'
checks=[]
def git(*args): return subprocess.check_output(['git','-C',str(REPO),*args])
def raw(path,rev=NEW): return git('show',rev+':'+path)
def obj(path,rev=NEW): return json.loads(raw(path,rev))
def digest(b): return hashlib.sha256(b).hexdigest()
def ident(b): return {'bytes':len(b),'sha256':digest(b)}
def check(name,value,detail=None):
    row={'name':name,'passed':bool(value)}
    if detail is not None: row['detail']=detail
    checks.append(row)

changes=[x.split('\t') for x in git('diff','--name-status',OLD,NEW).decode().splitlines()]
inventory=[]
for status,path in changes:
    b=raw(path)
    if path.endswith('.json'): json.loads(b)
    else: b.decode('utf-8')
    inventory.append({'status':status,'path':path,**ident(b)})
check('exact published recovery candidate tree',git('rev-parse',NEW+'^{tree}').decode().strip()=='e409ba91c9918b8c682e5364ccab92e2e6c6154c')
check('recovery commit retains original candidate and acquired-main parents',git('show','-s','--format=%P',NEW).decode().strip().split()==[OLD,MAIN])
check('all 13 recovery delta paths are declared docs/state',len(changes)==13 and all(status in {'A','M'} and (path in {'STATUS.md','docs/workflow/CURRENT.json'} or path.startswith(('docs/workflow/tasks/C270/',P))) for status,path in changes))
old_evidence=git('ls-tree','-r','--name-only',OLD,'--',P).decode().splitlines()
for path in old_evidence:
    check('original frozen evidence byte preservation: '+path,raw(path)==raw(path,OLD))
old_task=obj('docs/workflow/tasks/C270/task.json',OLD); task=obj('docs/workflow/tasks/C270/task.json')
check('acceptance criteria and current unfinished R01-R05 states preserved',task['requirements']==old_task['requirements'])
check('entire original phase record preserved verbatim in phase history',task['phase_history']==[old_task['session_phase']])
check('recovery phase bounded, same branch, no behavioral reruns',task['session_phase']['id']=='C270-recovery-finalization' and task['session_phase']['behavioral_reruns_this_phase']==0 and task['status']=='in_progress' and task['branch']==old_task['branch'] and task['completion']['branch_disposition']=='active')
check('R02 remains not_done',next(r for r in task['requirements'] if r['id']=='R02')['status']=='not_done')
cur=obj('docs/workflow/CURRENT.json')
check('CURRENT selects active parent and exact acquired main',cur['active_task']==cur['latest_task']=='C270' and cur['observed_main']==MAIN and 'do not implement' in cur['next_action']['summary'])
check('scope requirements unmodified',raw('docs/workflow/tasks/C270/REQUIREMENTS.md')==raw('docs/workflow/tasks/C270/REQUIREMENTS.md',OLD))
lease=obj(P+'evidence/recovery-20261120/LEASE.json')
check('lease commit has recorded exact tree and parent main',git('rev-parse',MAIN+'^{tree}').decode().strip()==lease['lease_tree'] and git('show','-s','--format=%P',MAIN).decode().strip()==lease['starting_main'])
check('lease delta updates only STATUS',git('diff','--name-only',lease['starting_main'],MAIN).decode().splitlines()==['STATUS.md'])
check('current STATUS declares recovery owner and parent/branch preservation','Owner: `c270-recovery-9e9d17639499`' in raw('STATUS.md').decode() and 'preserve unfinished branch' in raw('STATUS.md').decode())
readset=obj(P+'evidence/recovery-20261120/startup_read_set.json')
for row in readset['entries']:
    b=raw(row['path'],row['revision'])
    check('recovery startup-read identity: '+row['path'],row['bytes']==len(b) and row['sha256']==digest(b) and row['missing_or_truncated'] is False)
old_readset=obj(P+'STARTUP-READ-SET.json')
for row in old_readset['reads']:
    check('preserved original startup-read identity: '+row['path'],row['sha256']==digest(raw(row['path'],row['revision'])))
saved=obj(P+'RECOVERY-EARLY-RECEIPT.json'); verification=obj(P+'evidence/recovery-20261120/early_finalization_verification.json')
b=Path(saved['saved']['local_path']).read_bytes()
check('new early receipt matches actual frozen archive bytes',ident(b)=={k:saved['archive'][k] for k in ('bytes','sha256')}=={k:verification[k] for k in ('bytes','sha256')})
check('early receipt/check/source identities agree', saved['verification']['check_count']==verification['assertions']==525 and saved['source_revisions']['work_branch']==OLD and saved['source_revisions']['main']==lease['starting_main'])
check('early save evidence explicitly separate from final delivery',saved['saved']['status']=='succeeded' and saved['saved']['local_metadata_applied'] is True and task['delivery']['status']=='pending')

record_dir=OUT.parent/'checks/recovery-checkpoint'
record=json.loads((record_dir/'CHECKS.json').read_bytes())
check('fresh documentation/workflow check receipt binds exact clean recovery candidate',record['source_revision']==NEW and record['source_tree']==git('rev-parse',NEW+'^{tree}').decode().strip() and record['source_clean'] is True and record['result']=='passed')
check('record checker itself is preserved unchanged',digest(raw('docs/engineering/localized-repair-c269/evidence/run_record_checks.py'))==record['runner']['sha256'] and raw('docs/engineering/localized-repair-c269/evidence/run_record_checks.py')==raw('docs/engineering/localized-repair-c269/evidence/run_record_checks.py',OLD))
check('fresh record-check environment matches recorded interpreter/platform',record['environment']['python']==sys.version and record['environment']['platform']==platform.platform())
for row in record['checks']:
    b=(record_dir/row['log']['path']).read_bytes()
    check('fresh '+row['name']+' exact log identity and process success',ident(b)=={k:row['log'][k] for k in ('bytes','sha256')} and row['exit_code']==0 and row['result']=='passed')
    if row['name']=='documentation':
        result=json.loads(b);check('fresh documentation result actually passes with no failures',result['status']=='passed' and result['failures']==[])
    else:
        check('fresh workflow result actually passes',b'Workflow structure passed (11 tasks).' in b and b'FAIL' not in b)
check('both mandatory record check commands ran', [r['name'] for r in record['checks']]==['workflow','documentation'] and record['checks'][0]['command'][-2:]==['tools/chat_workflow.py','check'] and record['checks'][1]['command'][-1]=='docs/maintenance/reorganization-2026-10-17/verify_reorganization.py')
result={'schema':'ontokin.c270.recovery-delta-review/1','reviewer':'/root/candidate_review','candidate':NEW,'tree':git('rev-parse',NEW+'^{tree}').decode().strip(),'previous_candidate':OLD,'compared_current_main':MAIN,'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'checks':checks,'check_count':len(checks),'passed':all(r['passed'] for r in checks),'failed_checks':[r for r in checks if not r['passed']],'delta_files':inventory,'original_evidence_files_preserved':len(old_evidence),'fresh_record_check_receipt':{'path':str(record_dir/'CHECKS.json'),**ident((record_dir/'CHECKS.json').read_bytes())},'behavioral_runs':0,'remote_operations':0,'unknown_operations':[],'script':{'path':Path(__file__).name,**ident(Path(__file__).read_bytes())},'limits':['No independent live GitHub operation or upload repeated; Director-owned receipts reviewed.','Approval covers evidence and recovery records only; actual-main checks and confirmed final partial delivery remain gates.']}
(OUT/'RECOVERY-DELTA-RESULTS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('candidate','check_count','passed','failed_checks','original_evidence_files_preserved')}))
