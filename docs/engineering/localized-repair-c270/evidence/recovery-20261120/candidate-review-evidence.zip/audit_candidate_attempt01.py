#!/usr/bin/env python3
"""Static, independent review of frozen C270 evidence; no observer imports/runs."""
from __future__ import annotations

import ast
from collections import Counter
from datetime import datetime, timezone
from functools import lru_cache
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import platform
import re
import subprocess
import sys
import zipfile

REPO = Path('/workspace/scratch/9e9d17639499/OntoKin')
OUT = Path(__file__).resolve().parent
CANDIDATE = '1a2e9f85fa3ba210a16235e5660f1762ea8a953e'
MAIN = 'c7b99e7c37bf8e3b11b58660b2903150211dc355'
EXECUTION = '1ae7b594cc075031d11f2f1a33e4c5c0f0171da4'
BASE = '254e481351239b536394c182b6761ec4c8662764'
P = 'docs/engineering/localized-repair-c270/'
checks = []

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

@lru_cache(None)
def raw(path, revision=CANDIDATE):
    return git('show', revision + ':' + path)

def digest(b):
    return hashlib.sha256(b).hexdigest()

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('Duplicate JSON key: ' + key)
        result[key] = value
    return result

def obj(path):
    return json.loads(raw(path), object_pairs_hook=unique_object)

def check(name, passed, detail=None):
    row = {'name': name, 'passed': bool(passed)}
    if detail is not None:
        row['detail'] = detail
    checks.append(row)

def identity(b):
    return {'bytes': len(b), 'sha256': digest(b)}

def same(row, b):
    return row['bytes'] == len(b) and row['sha256'] == digest(b)

def resolve_saved(path):
    for old, new in mappings:
        if path == old or path.startswith(old + '/'):
            return new + path[len(old):]
    if path == '/workspace/scratch/1242e9ec1f21/operations/h16-candidate.log':
        return P + 'evidence/candidate/h16.log'
    return path

OUT.mkdir(parents=True, exist_ok=True)
changed = [line.split('\t') for line in git('diff', '--name-status', MAIN, CANDIDATE).decode().splitlines()]
inventory = []
for status, path in changed:
    data = raw(path)
    row = {'status': status, 'path': path, **identity(data)}
    if path.endswith('.json'):
        parsed = json.loads(data, object_pairs_hook=unique_object)
        row['inspection'] = 'parsed complete JSON, duplicate keys rejected'
    elif path.endswith('.py'):
        ast.parse(data)
        row['inspection'] = 'parsed complete Python AST, not executed'
    elif path.endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = z.namelist()
            check(path + ': ZIP integrity, unique safe relative member paths', z.testzip() is None and len(names) == len(set(names)) and all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n for n in names))
            row['archive_members'] = len(names)
            row['inspection'] = 'complete CRC/path/duplicate inspection'
    else:
        data.decode('utf-8')
        row['inspection'] = 'complete UTF-8 payload read; relevant prose/log claims separately reviewed'
    inventory.append(row)

check('exact frozen candidate tree', git('rev-parse', CANDIDATE + '^{tree}').decode().strip() == '8aeb8aa68784fd18bf4ff9aceab34977bf076ca6')
check('exact original execution tree', git('rev-parse', EXECUTION + '^{tree}').decode().strip() == '2af435b52ca1047a1a16e5a66afb91a855d1d1bd')
check('original main is candidate ancestor', subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor',MAIN,CANDIDATE]).returncode == 0)
check('original execution is candidate ancestor', subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor',EXECUTION,CANDIDATE]).returncode == 0)
check('all 94 cumulative changes confined to authorized evidence/task/current paths', len(changed) == 94 and all(status in {'A','M'} and (p in {'STATUS.md','docs/workflow/CURRENT.json'} or p.startswith(('docs/workflow/tasks/C270/',P))) for status,p in changed))
check('all added evidence syntactically read; no implementation files deleted', len(inventory) == len(changed) and not any(s == 'D' for s,p in changed))

expected = obj(P + 'control/EXPECTED.json')
pre = obj(P + 'PREEXECUTION.json')
h16 = obj(P + 'evidence/candidate/h16/RESULTS.json')
reg = obj(P + 'evidence/candidate/regressions/CHECKS.json')
finding = obj(P + 'FINDING.json')
mapping_record = obj(P + 'EVIDENCE-LOCATIONS.json')
mappings = [(r['original'],r['repository']) for r in mapping_record['mappings']]

verified_inputs = []
for label, inputs in [('preexecution',pre['inputs']), ('h16',h16['inputs']), ('regressions',reg['inputs'])]:
    for item in inputs:
        path = item['path']
        a, b = raw(path, EXECUTION), raw(path)
        check(label + ': exact execution and candidate input ' + path, same(item,a) and a == b)
        verified_inputs.append({'receipt':label,**item,'identical_execution_candidate': a == b})
        if '/localized-repair-c270/' not in path:
            check(label + ': preexisting input identical on base and main ' + path, a == raw(path, BASE) == raw(path, MAIN))
for collection in ('original_inputs','supplied_sources','reference_identities'):
    for row in expected[collection]:
        check('frozen oracle identity: '+row['path'], same(row,raw(row['path'])))

leaf = raw(P + 'control/hinges.ok')
entry = raw(P + 'control/main.ok')
old_leaf = raw('docs/engineering/semantic-export-c210/evidence/proof/hinges.ok')
old_entry = raw('docs/engineering/semantic-export-c210/evidence/proof/before.main.ok')
decl = b'    private param parent_site_ref @ "parent-site-ref": SiteRef = self.pivot;\n'
old_parent = b'        parent = self.pivot;\n'
new_parent = b'        parent = self.parent_site_ref;\n'
check('exactly two declared leaf edits preserve all other original source bytes', leaf.count(decl) == 1 and leaf.count(new_parent) == 1 and leaf.replace(decl,b'',1).replace(new_parent,old_parent,1) == old_leaf)
check('entry changes only the exact companion digest', entry.count(digest(leaf).encode()) == 1 and entry.replace(digest(leaf).encode(),digest(old_leaf).encode(),1) == old_entry)
check('parameter name and literal key are new, unique, and scoped beside Finger.flex', b'parent_site_ref' not in old_leaf and b'parent-site-ref' not in old_leaf and leaf.count(b'parent_site_ref') == 2 and leaf.count(b'"parent-site-ref"') == 1 and decl + b'    public joint flex @ "flex": hinge {' in leaf)
manifest = expected['program_identity_reference']['manifest']
check('program manifest explicitly matches both frozen sources', [r['source_revision'] for r in manifest['units']] == ['sha256:'+digest(entry),'sha256:'+digest(leaf)])
canonical = json.dumps(manifest,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()
check('independent canonical program identity', expected['program_identity_reference']['program_revision'] == 'sha256:'+digest(b'ontokin.bundle/0.1\0'+canonical))
check('oracle remains predeclared exact UNSUPPORTED_SOURCE_FORM', digest(raw(P+'control/EXPECTED.json')) == 'aa73df1e9ffb4d76bc589a7239f454be28e4cd6ae4ee523b208dbf66860ef4a7' and all(r['exact_code']=='UNSUPPORTED_SOURCE_FORM' for r in expected['expected'].values()))
check('original artifact is explicitly only a refusal propagation input', all(expected['comparison_input'][k] is False for k in ('source_matched','provenance_rebound','agreement_expected')))

for label,record in [('h16',h16),('regressions',reg)]:
    check(label+': actual historical execution identity retained', record['source_revision']==EXECUTION and record['source_tree']=='2af435b52ca1047a1a16e5a66afb91a855d1d1bd' and record['phase']=='frozen-candidate')
    check(label+': tracked source clean at execution', record['tracked_dirty_status']=='')
    env = record['environment']
    check(label+': full Python build and platform match current applicable environment', env['python']==sys.version and env['platform']==platform.platform())
    check(label+': exact Python executable bytes match current', same(env['executable'],Path(sys.executable).resolve().read_bytes()))
check('historical H16 before/after input, source revision and cleanliness recorded unchanged', h16['inputs']==h16['inputs_after'] and all(h16[k] is True for k in ('inputs_unchanged','source_revision_unchanged','tracked_clean_after')))
check('historical regression input stability recorded', reg['input_identity_unchanged'] is True)
check('H16 only untracked file was disclosed review record, outside dependency inputs', h16['all_dirty_status']=='?? '+P+'evidence/review/REGRESSION-RUNNER-REVIEW.json' and all(r['path'] != P+'evidence/review/REGRESSION-RUNNER-REVIEW.json' for r in h16['inputs']))

labels = ['original-source','original-comparison','siteref-source','siteref-binding','siteref-comparison']
check('five planned H16 calls retained in order', [r['label'] for r in h16['cases']]==labels)
failed = [{'case':c['label'],'assertion':k} for c in h16['cases'] for k,v in c['assertions'].items() if not v]
check('H16 failure consists exactly of three category assertions', failed==h16['failed_assertions']==finding['failed_assertions']==[{'case':n,'assertion':'exact_unsupported_category'} for n in labels[2:]] and h16['passed'] is False)
check('45 H16 assertions, 42 passed, match published finding', sum(len(c['assertions']) for c in h16['cases'])==finding['assertions']==45 and sum(sum(c['assertions'].values()) for c in h16['cases'])==finding['passed_assertions']==42)
logrows = [json.loads(l) for l in raw(P+'evidence/candidate/h16.log').decode().splitlines()]
check('five historical console log rows match saved cases', len(logrows)==5 and all(l['case']==c['label'] and l['passed']==c['passed'] and l['outcome']==c['outcome'] for l,c in zip(logrows,h16['cases'])))
source_hashes={r['filename']:r['sha256'] for r in expected['supplied_sources']}
source_sizes={r['filename']:r['bytes'] for r in expected['supplied_sources']}
for case in h16['cases'][:2]:
    path=resolve_saved(case['response']['path']); b=raw(path); response=json.loads(b)
    check(case['label']+': exact saved response bytes',same(case['response'],b))
    check(case['label']+': complete actual records and unique identities',len(response['records'])==response['hingeCount']==8 and len(response['sites'])==response['siteCount']==16 and len({tuple(r['id']) for r in response['records']})==8 and len({tuple(r['id']) for r in response['sites']})==16)
    check(case['label']+': all assertions pass; broader qualification flags remain false',case['passed'] is True and all(case['assertions'].values()) and all(response[k] is False for k in ('historicalInputsBound','sitePosesEvaluated','sourceValidityQualified','acceptedRevisionQualified','completeC255Semantic','executionAllowed')))
    if case['label']=='original-comparison':
        check('original comparison actually sets all four required agreement flags',all(response[k] is True for k in ('inputBindingVerified','hingeComparisonVerified','hingeSetAgreementVerified','endpointAgreementVerified')))
for case in h16['cases'][2:]:
    e=case['exception']; chain=case['cause_chain']; label=case['label']
    check(label+': wrong typed category with exact source identities retained',case['outcome']=='typed_refusal' and e['code']=='MALFORMED' and e['detail']=='endpoint must resolve to a declared site' and e['sourceHashes']==source_hashes and e['sourceBytes']==source_sizes)
    check(label+': no response/partial qualified output, origin explicitly null', 'response' not in case and case['diagnostic_origin'] is None and all(n.get('origin') is None and not (set(n)&{'records','hinges','sites','objects','hingeCount','siteCount','objectCount','inputBindingVerified','hingeComparisonVerified','hingeSetAgreementVerified','endpointAgreementVerified','qualified'}) for n in chain))
    check(label+': exact source cause reaches site/endpoint assertion',all(any(f['file'].endswith('/docs/engineering/localized-repair-c265/source_hinges.py') and f['line']==line and f['function']==fun for f in chain[-1]['traceback']) for line,fun in ((521,'site'),(552,'endpoint'),(63,'_require'))))
    if label!='siteref-source':
        check(label+': actual upstream source failure propagated unchanged',chain[-1]['module']=='_c266_pinned_source' and all(n['code']==e['code'] and n['detail']==e['detail'] for n in chain) and chain[-1]['sourceHashes']==source_hashes and chain[-1]['sourceBytes']==source_sizes)
        check(label+': supplied artifact identity retained',e['artifactSha256']==expected['comparison_input']['sha256'] and e['artifactBytes']==expected['comparison_input']['bytes'])
source_lines=raw('docs/engineering/localized-repair-c265/source_hinges.py').decode().splitlines()
check('retained source actually combines absent/wrong member kinds under MALFORMED', 'member is not None and member["memberKind"] == "site"' in source_lines[520] and 'code="MALFORMED"' in source_lines[60])

check('seven planned regression/record commands and completed outcomes agree',len(reg['checks'])==len(reg['planned_commands'])==7 and all(a['name']==b['name'] and a['command']==b['command'] for a,b in zip(reg['checks'],reg['planned_commands'])))
for r in reg['checks']:
    b=raw(resolve_saved(r['log']['path'])); txt=b.decode()
    check('saved '+r['name']+' log exact bytes',same(r['log'],b))
    check('historical '+r['name']+' process/result passed',r['exit_code']==0 and r['passed'] is True and all(r['assertions'].values()))
    if r['methods']:
        n=r['methods']; logs=re.findall(r'^test_.* \.\.\. ok$',txt,re.M)
        check(r['name']+': all test method lines and aggregate plain OK confirm count',len(logs)==n and re.search(r'^Ran '+str(n)+r' tests in ',txt,re.M) is not None and re.search(r'^OK$',txt,re.M) is not None and not re.search(r'^FAILED|^ERROR:|^FAIL:| skipped ',txt,re.M))
    elif r['name']=='corpus':
        corpus=json.loads(b); check('14 original corpus bindings retained',corpus['passed'] is True and corpus['boundFiles']==14)
check('108-method regression pass remains distinct from failed H16 control',reg['total_methods']==reg['expected_methods']==108 and reg['passed'] is True and h16['passed'] is False)

archive_refs=[]
for number,count,test_name in ((265,49,'source_hinges'),(266,34,'hinge_binding'),(267,25,'hinge_compare')):
    prefix=P+f'evidence/candidate/regressions/c{number}-controls/'
    result=obj(prefix+'results.json')
    test_path=f'docs/engineering/localized-repair-c{number}/test_{test_name}.py'
    tree=ast.parse(raw(test_path)); methods=[n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
    check(f'C{number}: all test definitions counted without running them',len(methods)==count)
    inputs=result['inputs'] if number==265 else result['implementationAndControlInputs']
    for path,item in inputs.items():
        check(f'C{number} exact recorded code identity '+path,same(item,raw(path)) and raw(path)==raw(path,EXECUTION))
    check(f'C{number}: saved result clean pass and expected environment', result.get('testMethods',result.get('testsRun'))==count and result['passed'] is True and not any(result[k] for k in ('failures','errors','skipped')) and result['python']==sys.version and result['platform']==platform.platform())
    if number==265:
        for suffix,source in [('source_hinges.py.txt',f'docs/engineering/localized-repair-c265/source_hinges.py'),('test_source_hinges.py.txt',test_path)]:
            check('C265 retained checked code '+suffix,raw(prefix+suffix)==raw(source))
        continue
    z=zipfile.ZipFile(io.BytesIO(raw(prefix+'inputs.zip')))
    bad=[]; cases=result['cases']
    for index,case in enumerate(cases):
        source_key='sourceInputs' if number==266 else 'sources'; artifact_key='artifactInput' if number==266 else 'artifact'
        for role,item in [*case[source_key].items(),('artifact',case[artifact_key])]:
            member=item['snapshot'].split('!',1)[1]
            payload=z.read(member)
            verified=same(item,payload)
            archive_refs.append({'component':number,'case':index,'role':role,'member':member,'verified':verified})
            if not verified: bad.append({'case':index,'role':role})
    check(f'C{number}: every recorded actual source/artifact input resolves to exact ZIP bytes',not bad,{'cases':len(cases),'references':len(cases)*3,'mismatches':bad})
    check(f'C{number}: API outcome counts match saved cases',len(cases)==result['apiCalls'] and sum(c['outcome']=='typed_refusal' for c in cases)==result['typedRefusals'])
    for path in inputs:
        copy=prefix+'checked-code/'+Path(path).name
        if copy not in {r['path'] for r in inventory}:
            continue
        copy_bytes=raw(copy)
        check(f'C{number}: saved checked-code copy '+Path(path).name,copy_bytes==raw(path))

for path in ['evidence/review/PREEXEC-REVIEW.json','evidence/review/PREEXEC-FIXTURE-CHECKS.json','evidence/review/EXECUTION-REVIEW.json','evidence/review/REGRESSION-RUNNER-REVIEW.json']:
    review=obj(P+path)
    for k in ('fixture_identities','retained_inputs'):
        for item in review.get(k,[]):
            check(path+': exact saved reviewed input '+item['path'],same(item,raw(resolve_saved(item['path']))))
    for k in ('script','runner','normative_position'):
        if k in review:
            item=review[k];check(path+': exact '+k+' bytes',same(item,raw(item['path'])))
    if 'check_count' in review:
        check(path+': declared static check count and passing status accurate',review['check_count']==len(review['checks']) and all(r['passed'] for r in review['checks']) and review['passed'] is True)
check('77 prior execution-audit checks remain distinct from H16 acceptance',obj(P+'evidence/review/EXECUTION-REVIEW.json')['check_count']==77 and obj(P+'evidence/review/EXECUTION-REVIEW.json')['audit_result_is_control_pass'] is False)
api=obj(P+'evidence/review/EXECUTION-COMMIT-API.json')
check('saved GitHub execution-commit response binds actual local commit/tree',api['sha']==EXECUTION and api['commit']['tree']['sha']==git('rev-parse',EXECUTION+'^{tree}').decode().strip())
task=obj('docs/workflow/tasks/C270/task.json')
check('parent task remains active and exact R02 acceptance remains unmet',task['status']=='in_progress' and next(r for r in task['requirements'] if r['id']=='R02')['status']=='not_done' and task['completion']['merge_commit'] is None and task['completion']['branch_disposition']=='active')
check('next action explicitly completes evidence finalization before fresh correction phase','saved partial handoff' in task['next_action'] and 'next fresh phase' in task['next_action'])
check('previous setup failures and later corrections remain present',all(P+'evidence/setup/'+p in {r['path'] for r in inventory} for p in ('CORRECTION.md','workflow-initial-failure.json','workflow-second-failure.json','documentation-initial-failure.json','workflow-passed.json','PUBLICATION-RECONCILIATION.json')))

report={
    'schema':'ontokin.c270.recovery-candidate-review/1','reviewer':'/root/candidate_review','director':'c270-recovery-9e9d17639499',
    'recorded_at_utc':datetime.now(timezone.utc).isoformat(),'candidate':CANDIDATE,'candidate_tree':git('rev-parse',CANDIDATE+'^{tree}').decode().strip(),
    'compared_main':MAIN,'historical_execution':EXECUTION,'historical_execution_tree':h16['source_tree'],
    'scope':'Static independent evidence review only; existing failed control and regression evidence preserved. No behavioral reruns, implementation changes or remote writes.',
    'environment':{'python':sys.version,'platform':platform.platform(),'executable':{'path':str(Path(sys.executable).resolve()),**identity(Path(sys.executable).resolve().read_bytes())}},
    'command':[sys.executable,'-B',str(Path(__file__).resolve())],
    'script':{'path':'audit_candidate.py',**identity(Path(__file__).read_bytes())},
    'changed_files':len(inventory),'check_count':len(checks),'checks':checks,'passed':all(c['passed'] for c in checks),
    'failed_checks':[c for c in checks if not c['passed']],
    'behavioral_runs':0,'remote_operations':0,'unknown_operations':[],
    'historical_evidence':{'api_calls':5,'h16_assertions':45,'h16_passed':42,'h16_failed':3,'regression_methods':108,'corpus_bindings':14,'archive_input_references_verified':len(archive_refs)},
    'reuse_assessment':'Execution remains attributed to 1ae7b594. Recorded implementation/dependency/test/fixture/runner bytes match 1a2e9f85; prior environment and exact Python binary match the present audit environment. Saved planned child commands agree with saved executed child commands. No fresh behavior or main execution is claimed. Documentation/workflow inputs changed after execution and require fresh checks of final candidate and actual resulting main.',
    'limits':['Static records and byte checks do not independently rerun behavior or prove every historical shell/environment setting.','Current live GitHub lease/refs/PR/issue and conditional publication are Director-owned and outside this audit.','Final state/integration/delivery deltas require the assigned follow-up review.','H16/R02 remains failed; H20/H22/H24 and broader product/compatibility/native/model roles remain unqualified.']}
for name,value in [('RESULTS.json',report),('CHANGED-FILES.json',inventory),('VERIFIED-INPUTS.json',verified_inputs),('ARCHIVE-INPUT-REFERENCES.json',archive_refs)]:
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ('candidate','check_count','passed','failed_checks','historical_evidence')}))
