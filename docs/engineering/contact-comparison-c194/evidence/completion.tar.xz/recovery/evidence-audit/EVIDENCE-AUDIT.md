# Independent C194 recovered-evidence audit

The recovered C194 preparation, first submissions and reuse outputs pass the
recorded-evidence checks. The audit made **2,092 checks**, including fresh
checks of **16 retained artifacts** and verification of **10 saved-scene replay
receipts**, without constructing or resimulating a scene or dispatching an
author. Complete calculations and hashes are in `EVIDENCE-AUDIT.json` and the
sixteen accompanying artifact reports.

## What was completed before interruption

- The preparation freeze preceded the four reserved native builds: one `.ok`
  and one Python build at each of 365 and 375 mm. Both qualified, with twelve
  original receiving panels bound to the final qualification receipt.
- The public protocol freeze preceded the first author phases. The retained
  dispatch record names exactly two authors, requests empty histories and no
  model or reasoning overrides, and gives equal allowances. Provider-level
  model, token, cost and hidden-turn telemetry remain unavailable.
- Both first submissions were independently accepted before the same authors
  began reuse. Each author changed only the left-stop literal, preserved its
  first source and regenerated its first accepted output exactly.
- Both reuse submissions, both regenerated first submissions and all six clean
  coordinator rebuilds pass the original source, native, geometry, contact and
  continuous checks. All four canonical/native/raw/final files match between
  routes and across required regenerations.
- All ten saved-scene receipts bind the actual delivered scene hashes, report
  no reconstruction or repair, and reproduce all 481 decoded native records
  exactly. The serialization hashes differ where JSON formatting differs;
  decoded records are equal.
- The receiving records cover twenty raw/final GLB paths, sixty Three.js poses
  and ten Blender imports. They report zero Khronos errors and warnings, and
  ten informational unused-sampler findings. Their actual input files, command
  completion and render input identities verify.

| Target | Continuous mapping bound | Unchanged allowance |
| --- | ---: | ---: |
| 365 mm first edit | 0.07451646802035088 mm | 0.2 mm |
| 375 mm reuse | 0.116442262620993 mm | 0.2 mm |

The 589 preparation inputs, 607 public inputs in each of the coordinator and
two author worktrees, and inherited C193 frozen reader files remain intact.
No historical product implementation, checker gate or tolerance was changed.

## Remaining finalization at inspection

The old reuse `RESULTS.json` properly remains marked `visual_review=PENDING`.
There was no reuse visual-review or acceptance receipt in that run directory
when inspected. The parent has since reported direct inspection of all twelve
original reuse panels; a new dated recovery receipt must bind that observation
and final acceptance without editing the old records. Publication, actual-main
verification and self-contained handoff are separate remaining tasks.

This audit did not itself view panels, run receiving applications or verify a
provider model snapshot. It rechecked actual retained bytes with the frozen
independent readers and validated the recorded native/receiving executions.
The inherited full regression remains FAILED with 4,239 distinct passing
methods and thirteen NOT RUN. One public pair on this prepared mechanism does
not establish comparative advantage or full-product acceptance.

The first audit harness invocation stopped before any artifact replay because
of a duplicate Python keyword in its reporting function. That audit-only error
was corrected; its stdout/stderr are retained as `audit-attempt01.*`. The final
invocation passed all assigned checks and executed no native builds.
