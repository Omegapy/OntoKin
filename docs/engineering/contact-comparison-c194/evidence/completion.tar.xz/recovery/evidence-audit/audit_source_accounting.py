from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess

BASE=Path('/workspace/scratch/efc86516cbb7')
OUT=Path('/workspace/scratch/40c44e911c4b/c194-recovery-audits')
rows=[]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def visit(obj,origin):
    if isinstance(obj,dict):
        if {'path','bytes','sha256'} <= obj.keys() and str(obj['path']).startswith(str(BASE)):
            p=Path(obj['path'])
            assert p.is_file(),str(p)
            assert p.stat().st_size==obj['bytes'] and sha(p)==obj['sha256'],str(p)
            rows.append({'origin':str(origin),'path':str(p),'sha256':obj['sha256'],'bytes':obj['bytes']})
        for v in obj.values():visit(v,origin)
    elif isinstance(obj,list):
        for v in obj:visit(v,origin)

authors={}
for route in ['ok','python']:
    repo=BASE/'authors'/route
    folder=repo/'docs/engineering/contact-comparison-c194/authors'/route
    for file in sorted(folder.glob('*.json')):visit(read(file),file)
    authors[route]=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
inventories=[]
for stage in ['first','reuse']:
    result=read(BASE/f'c194-{stage}-validation/RESULTS.json')
    for run in result['runs']:
        snapshot=BASE/f'c194-{stage}-validation/inventories'/f"{run['id']}-before.json"
        original=Path(run['submitted_run'])
        inv=read(snapshot)
        actual={str(p.relative_to(original)) for p in original.rglob('*') if p.is_file()}
        assert actual==set(inv),str(original)
        for path,info in inv.items():
            p=original/path
            assert p.stat().st_size==info['bytes'] and sha(p)==info['sha256'],str(p)
        inventories.append({'stage':stage,'id':run['id'],'files':len(inv),'snapshot_sha256':sha(snapshot),'exact_inventory_and_bytes':True})

audit=read(OUT/'evidence-audit/EVIDENCE-AUDIT.json')
report={'schema':'ontokin.c194.source-accounting-review/0.1','passed':True,
 'reviewer':'c194_evidence_audit','reviewed_at_utc':datetime.now(timezone.utc).isoformat(),
 'scope':'Recovered actual authored sources, immutable submissions, phase chronology, native attempts, repair and available telemetry accounting',
 'author_heads':authors,'phases':audit['author_accounting'],'single_coordinate_deltas':audit['source_diffs'],
 'all_reference_hashes_verified':len(rows),'unique_referenced_files_verified':len({r['path'] for r in rows}),
 'complete_submitted_inventories_verified':inventories,
 'first_acceptance_sha256':sha(BASE/'c194-first-validation/ACCEPTANCE.json'),
 'reuse_results_sha256':sha(BASE/'c194-reuse-validation/RESULTS.json'),
 'numerical_and_receiving_audit_sha256':sha(OUT/'evidence-audit/EVIDENCE-AUDIT.json'),
 'qualified_before_dispatch':True,'exactly_two_recorded_authors':True,'same_authors_reused_own_accepted_sources':True,
 'first_acceptance_precedes_both_reuse_phases':True,'first_sources_and_output_bytes_preserved':True,
 'first_pass_automatic_gates_both_phases':True,'reuse_visual_acceptance_separate':True,
 'native_author_builds':6,'failed_author_native_builds':0,'invalid_author_source_attempts':0,'formal_repair_turns':0,
 'failed_read_only_inspection_commands':2,'human_interventions':0,'coordinator_interventions_during_author_phases':0,
 'native_builds_by_this_recovery_audit':0,'author_redispatches_by_this_recovery_audit':0,
 'limits':['Counts and phase times are bound author receipts; unavailable provider tokens, cost, snapshot and hidden turns are not inferred',
 'Two original dispatch records were written after author starts; recorded_utc denotes record publication, not exact provider dispatch time',
 'The .ok and Python forms are prepared literal variants through a shared constructor; no general authoring advantage is established'],
 'reference_checks':rows}
(OUT/'REUSE-SOURCE-ACCOUNTING-REVIEW.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'passed':True,'references':len(rows),'unique_files':report['unique_referenced_files_verified'],'inventory_files':sum(x['files'] for x in inventories),'authors':authors}))
