# Historical unpublished C266 evidence recovered during C267 startup

These 18 files survived in earlier C266 worktrees. Their bytes do not match current main or any file in the supplied C266 session ZIP, including nested ZIP entries. They contain historical task drafts, recovery records, and evidence audits. They do not contain changes to product code.

Current live GitHub C266 completion governs. Do not apply these stale task, plan, recovery, or lease states to current main. This payload preserves the old files for provenance only. No source worktree was modified. Existing C266 closure, accepted code and reviews remain unchanged.

Observed main: 47681b1e4c442a580910dba1fc5a823dc86ee6b0. Source handoff: OntoKin_C266_Input_Binding_Handoff_2026-11-18.zip, SHA-256 8540ac67af254b87321c851d762750d82fa02eb213e571ec4c6533c98a954726.

MANIFEST-SHA256.json binds every historical file to its size and SHA-256. The outer handoff must bind this ZIP as an inert recovery payload. This archive is not complete source restoration and grants no new work authority.
