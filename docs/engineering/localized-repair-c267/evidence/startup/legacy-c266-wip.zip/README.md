# Historical C266 worktree evidence recovered at C267 startup

This payload preserves 18 historical draft/audit files whose exact bytes were not found in current main or the supplied C266 session handoff, including nested ZIP entries. It also includes the complete audit of 31 surviving dirty/untracked files. The other 13 have exact current-main copies.

The 18 files are historical task drafts, recovery records and evidence audits. There are no product-code changes. Their old in-progress task states and old integration owners are superseded by the current live C266 completion at main 47681b1e4c442a580910dba1fc5a823dc86ee6b0. Do not apply these old operational records to main. They are retained for provenance only. Source worktrees were not modified.

Each historical entry has its original workspace path, repository head, branch, SHA-256, byte count and disposition in LOCAL-WORKTREE-AUDIT.json and RECOVERABILITY.json. To inspect an old file, extract its exact historical/WORKSPACE_ID/REPO_PATH entry. The manifest verifies its original bytes. Do not restore an old task state, lease, or review claim as current authority.

The pre-existing local commit 74bba31a23f4acbda4484159576ae21c024664ce is not an ancestor of current main, but its recovery is separately registered in current docs/workflow/tasks/C266/RECOVERY-CLOSURE.md: saved prerequisite-bound recovered-work archive libfile_fde3_f-a65ce970e75081919869f5940f032ce1_2ab2a24d43748191957f9bcc356b59de, 2,758,073 bytes, SHA-256 f12aec3c49a2a21070ab2c273932c8cb104691fb4d1e6f0ed2e50a8ecac4e9f6. That separate archive was not downloaded/reverified in this audit. The integrated C266 head 665d344a118ac2f6689e13dbafdff99b480a02d3 is retained as an ancestor of current main.

Source handoff examined: OntoKin_C266_Input_Binding_Handoff_2026-11-18.zip, SHA-256 8540ac67af254b87321c851d762750d82fa02eb213e571ec4c6533c98a954726. The source handoff's no-known-unpublished-files statement is now qualified by this newly observed historical metadata/evidence. No current product implementation is displaced.

This is not complete source restoration. It changes no product contract, scientific result, completed gate or current ownership.
