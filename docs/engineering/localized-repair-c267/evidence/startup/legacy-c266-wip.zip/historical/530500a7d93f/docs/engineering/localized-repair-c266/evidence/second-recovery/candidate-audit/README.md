# C266 recovered candidate verification audit

The independent `/root/regression` worker audited the completed candidate run
retained from the interrupted session. The run identifies source commit
`4986089edbd4443b05ef091d06bf4df55dfcdfa9`, tree
`f0240182b44a91e9db362f43ae90d6005b397c3b`, and CPython 3.12.14 on Linux x86-64.
It ran from 2026-11-18T23:57:41.468105+00:00 to
2026-11-18T23:58:56.077338+00:00. This recovery audits that retained execution;
it does not present the prior run as a new execution.

`RECOVERED-EVIDENCE-AUDIT.json` passes. It verifies:

- All 119 declared before/after source inputs against the exact Git revision.
- Every declared output and log: 16 files, with no missing declared output.
- Ten complete check groups and 222 passing test methods with no failures,
  errors, skips or expected failures.
- C253's 14 corpus bindings and three tasks.
- C266's 34 authored methods and 748 API calls: 28 bound results and 720 typed
  refusals. All 2,237 retained byte witnesses match 741 distinct input ZIP
  members; four nonbyte input type witnesses remain explicitly identified.
- The exact interpreter and runner identities recorded by the original run.

The first audit used an exact directory inventory and found one extra file,
`run_checks.py`, copied into the evidence directory after the run froze its
output inventory. The retained first report records that failed audit.
The final audit separately verifies that supplement against the original
recorded runner hash, rather than modifying the frozen run report or ignoring
unexpected files. The earlier audit is not a product-test failure.

## Reuse and remaining verification

The retained source-cohort evidence is eligible for reuse on exactly matching
inputs. It remains insufficient to prove a merge or qualify resulting main.
Fresh applicable resulting-main checks, final task/documentation checks,
independent review, integration, branch disposition and saved delivery remain
the Director's separate obligations.

The original full product aggregate, source conformance/export, native/visual
or model trials, other Python compatibility roles and hosted workflows were
not run for this isolated component. Prior product failures are unchanged.
No hinge-field, joint-set, endpoint, physical or comparative claim follows from
the input-binding cohort.

The exact identified runner is preserved as `run_checks.py`. The audit source
is `audit_recovered_checks.py`. The Director can run the cohort against a clean,
authentic checkout of resulting main with:

```sh
python3 -B run_checks.py --repo /absolute/path/to/checkout --phase actual-main --output /absolute/path/to/new-evidence-directory
```

The output directory must not already exist. The runner records the real Git
commit/tree, clean tracked state, input hashes, commands, environment, logs,
failure accounting and exact counts. It does not publish or mutate Git refs.
