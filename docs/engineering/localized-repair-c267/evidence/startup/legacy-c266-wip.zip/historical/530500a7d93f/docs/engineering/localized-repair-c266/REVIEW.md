# C266 independent review receipt

The separate reviewer approves implementation `5454bfeb2c27aed0af23fb4dd363638ffbb10b07`, SHA-256 `68849dbe3339c158eac7ec43fb1defcbd2993c37c6a0a5ee813d2da71fb03dda`. The reviewer independently fetched the published GitHub blob and verified byte equality with the inspected/executed source.

[Full review](evidence/review/REVIEW.md), [structured outcomes](evidence/review/SUMMARY.json), [exact review script](evidence/review/review_c266.py) and [verified evidence bundle](evidence/review/C266_Independent_Review_Evidence.zip) retain the evidence. There are 87 distinct passing controls across 89 retained executions: 88 passes and one corrected reviewer-fixture failure. Candidate source did not change. The evidence bundle preserves every original script/input/result and its manifest; its [verification](evidence/review/EVIDENCE-VERIFICATION.json) is separate.

This review covers the C266 source/program/object binding prerequisite. It does not qualify hinge values, joint sets, endpoints, historical admission or any complete C260 H group. A later publication can reuse this review only with exact source and pinned-dependency equality. Integration, actual-main checks, branch disposition and confirmed saved delivery remain separate gates.

## Dependency admission supplement

A targeted separate review passes five isolated two-call experiments: after a successful call, same-size mutations of each C265/C261/C257 dependency, a missing C261 dependency, and an identical-byte C257 symlink all cause the next call to refuse INPUT_BINDING. The real checkout and original review archive were unchanged. This establishes that an earlier cached module cannot bypass the new per-call pin checks. The supplement and exact scripts/results are retained with the review evidence.

## Interrupted-session evidence audit

Independent reviewer `/root/candidate_review` approves reuse of the exact implementation and original review after inspecting current source and validating the retained archives and every reported input identity. Its [review](evidence/recovery-review/REVIEW.md) and [audit](evidence/recovery-review/AUDIT.json) identify the actual scope, commands and preserved first audit attempt. The Director separately executed the complete candidate cohort. This adds no hinge comparison or wider validity claim.

## Second recovery and publication repair

Independent `/root/candidate_audit` approves the unchanged source after a fresh [full source/evidence audit](evidence/second-recovery/review/REVIEW.md). Independent `/root/regression` verifies all 119 source inputs, sixteen output hashes and 2,237 input byte witnesses in the [candidate evidence audit](evidence/second-recovery/candidate-audit/RECOVERED-EVIDENCE-AUDIT.json). The sole mandatory publication finding was ten ignored candidate logs; their exact bytes are now retained at the original recorded paths. Earlier audit/fixture failures remain visible. These are new evidence-integrity audits, not new behavioral test runs.
