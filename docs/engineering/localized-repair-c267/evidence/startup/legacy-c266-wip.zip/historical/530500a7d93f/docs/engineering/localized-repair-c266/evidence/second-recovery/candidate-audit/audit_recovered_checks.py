#!/usr/bin/env python3
"""Validate retained C266 candidate evidence against its exact source revision."""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import zipfile


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(raw):
    return {"bytes": len(raw), "sha256": digest(raw)}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo", required=True, type=Path)
    ap.add_argument("--evidence", required=True, type=Path)
    ap.add_argument("--runner", required=True, type=Path)
    ap.add_argument("--output", required=True, type=Path)
    a = ap.parse_args()
    repo, ev = a.repo.resolve(), a.evidence.resolve()
    report = json.loads((ev / "CHECKS.json").read_text())
    source = report["source_before"]["commit"]
    errors = []

    def check(ok, name):
        if not ok:
            errors.append(name)

    def git(*args):
        return subprocess.check_output(["git", *args], cwd=repo)

    def matches(raw, row):
        return identity(raw) == {k: row[k] for k in ("bytes", "sha256")}

    check(source == "4986089edbd4443b05ef091d06bf4df55dfcdfa9", "expected source commit")
    check(git("rev-parse", source + "^{tree}").decode().strip() == report["source_before"]["tree"], "source tree")
    check(report["source_before"]["tracked_dirty_status"] == "", "source initially clean")
    check(report["source_after"]["tracked_dirty_status"] == "", "source finally clean")
    check(report["source_after"]["commit"] == source, "source commit stable")
    check(report["source_after"]["tree"] == report["source_before"]["tree"], "source tree stable")
    check(report["input_files_before"] == report["input_files_after"], "before/after inputs")
    check(report["input_identity_unchanged"] is True, "input identity result")
    for row in report["input_files_before"]:
        check(matches(git("show", source + ":" + row["path"]), row), "source input " + row["path"])
    expected_outputs = {row["path"] for row in report["output_files"]}
    actual_outputs = {str(p.relative_to(ev)) for p in ev.rglob("*") if p.is_file() and p.name != "CHECKS.json"}
    supplemental_outputs = actual_outputs - expected_outputs
    check(not (expected_outputs - actual_outputs), "complete declared output inventory")
    check(supplemental_outputs <= {"run_checks.py"}, "only identified post-run runner supplement")
    if "run_checks.py" in supplemental_outputs:
        check(matches((ev / "run_checks.py").read_bytes(), report["runner"]), "post-run runner supplement identity")
    for row in report["output_files"]:
        check(matches((ev / row["path"]).read_bytes(), row), "output " + row["path"])
    check(matches(a.runner.read_bytes(), report["runner"]), "runner identity")
    check(report["complete"] is True and report["passed"] is True, "overall complete/pass")
    check(report["planned_check_count"] == report["completed_check_count"] == len(report["checks"]) == 10, "ten complete check groups")
    check(report["remaining_checks"] == [], "no remaining checks")
    counts = {}
    for item in report["checks"]:
        name = item["name"]
        check(item["result"] == "passed" and item["exit_code"] == 0 and item["failure"] is None, name + " success")
        check(all(v is True for v in item["assertions"].values()), name + " assertions")
        raw = (ev / item["log"]["path"]).read_bytes()
        check(matches(raw, item["log"]), name + " log identity")
        if item["expected_methods"] is not None:
            text = raw.decode()
            n = re.findall(r"(?m)^Ran (\d+) tests? in ", text)
            check(bool(n) and int(n[-1]) == item["expected_methods"] == item["methods"], name + " method count")
            check(bool(re.search(r"(?m)^OK\r?$", text)), name + " zero failure/error/skip result")
            counts[name] = item["methods"]
    check(sum(counts.values()) == report["total_methods"] == report["expected_total_methods"] == 222, "222 total methods")
    controls = json.loads((ev / "c266-controls/results.json").read_text())
    check(controls["passed"] is True and not any(controls[k] for k in ["failures", "errors", "skipped"]), "controls zero failures/errors/skips")
    check(controls["testMethods"] == 34 and len(controls["cases"]) == controls["apiCalls"] == 748, "control accounting")
    outcomes = Counter(c["outcome"] for c in controls["cases"])
    check(outcomes == {"bound": 28, "typed_refusal": 720}, "bound/refusal outcomes")
    for path, row in controls["implementationAndControlInputs"].items():
        check(matches(git("show", source + ":" + path), row), "control implementation " + path)
    referenced, byte_witnesses, type_witnesses = set(), 0, 0
    with zipfile.ZipFile(ev / "c266-controls/inputs.zip") as z:
        names = z.namelist()
        check(len(names) == len(set(names)), "input ZIP duplicate names")
        check(z.testzip() is None, "input ZIP CRC")
        check(all(not n.startswith("/") and ".." not in Path(n).parts for n in names), "input ZIP safe names")
        for case in controls["cases"]:
            source_inputs = case["sourceInputs"]
            if source_inputs.get("type") == "list":
                descriptors = [case["artifactInput"]]
                type_witnesses += 1
            else:
                descriptors = [*source_inputs.values(), case["artifactInput"]]
            for row in descriptors:
                if "snapshot" not in row:
                    check(set(row) == {"type"}, "bounded nonbyte type witness")
                    type_witnesses += 1
                    continue
                archive, member = row["snapshot"].split("!", 1)
                check(archive == "inputs.zip", "input archive name")
                referenced.add(member)
                check(matches(z.read(member), row), "input snapshot " + member)
                byte_witnesses += 1
        check(referenced == set(names), "exact referenced input ZIP inventory")
    audit = {
        "schema": "ontokin.c266.recovered-candidate-evidence-audit/1",
        "auditor": "/root/regression",
        "audited_at": datetime.now(timezone.utc).isoformat(),
        "kind": "retained execution evidence audit; no repeat test execution",
        "source_commit": source,
        "source_tree": report["source_before"]["tree"],
        "retained_report": {"path": str(ev / "CHECKS.json"), **identity((ev / "CHECKS.json").read_bytes())},
        "retained_runner": {"path": str(a.runner.resolve()), **identity(a.runner.read_bytes())},
        "source_inputs_verified_against_git": len(report["input_files_before"]),
        "outputs_verified": len(expected_outputs),
        "post_run_supplements_verified": [{"path": p, **identity((ev / p).read_bytes())} for p in sorted(supplemental_outputs)],
        "check_groups": 10,
        "test_methods_by_group": counts,
        "total_test_methods": sum(counts.values()),
        "control_api_calls": len(controls["cases"]),
        "control_outcomes": dict(outcomes),
        "control_byte_witnesses_verified": byte_witnesses,
        "control_nonbyte_type_witnesses": type_witnesses,
        "distinct_control_input_zip_members": len(referenced),
        "environment": report["environment"],
        "untracked_evidence_disclosed_by_original_run": {"before": report["source_before"]["all_dirty_status"], "after": report["source_after"]["all_dirty_status"]},
        "not_run": report["not_run"],
        "limits": report["limits"] + ["Preserved original run was executed in the preceding session; this audit verifies its retained identity and accounting, not a new run.", "Resulting-main checks and final metadata/documentation checks remain the integrator's separate obligation."],
        "passed": not errors,
        "errors": errors,
    }
    a.output.parent.mkdir(parents=True, exist_ok=True)
    a.output.write_text(json.dumps(audit, indent=2) + "\n")
    print(json.dumps({k:audit[k] for k in ("passed", "errors", "source_inputs_verified_against_git", "outputs_verified", "total_test_methods", "control_api_calls", "control_byte_witnesses_verified", "distinct_control_input_zip_members")}))
    return 0 if audit["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
