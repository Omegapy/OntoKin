#!/usr/bin/env python3
"""Audit recovered C266 source and retained evidence from exact Git objects."""
import collections
import hashlib
import io
import json
import platform
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

REPO = Path('/workspace/scratch/31766bc15fec/OntoKin')
PUBLISHED = '4986089edbd4443b05ef091d06bf4df55dfcdfa9'
RECOVERED = '74bba31a23f4acbda4484159576ae21c024664ce'
BASE = '7818de1f17e379df50680cb94347ce86bcabb8a5'
ROOT = 'docs/engineering/localized-repair-c266/'
OUT = Path(__file__).resolve().parent

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def read(path, rev=RECOVERED):
    return git('show', rev + ':' + path)

def js(path, rev=RECOVERED):
    return json.loads(read(path, rev))

def ident(raw):
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

def assert_identity(raw, record):
    assert ident(raw) == {k: record[k] for k in ('bytes', 'sha256')}

def archive(raw):
    z = zipfile.ZipFile(io.BytesIO(raw))
    names = z.namelist()
    assert len(names) == len(set(names))
    assert all(not PurePosixPath(n).is_absolute() and '..' not in PurePosixPath(n).parts and '\\' not in n for n in names)
    assert z.testzip() is None
    return z

report = {
    'schema': 'ontokin.c266.second-recovery-audit/1',
    'reviewer': '/root/candidate_audit',
    'recorded_at': datetime.now(timezone.utc).isoformat(),
    'published_candidate': PUBLISHED,
    'recovered_commit': RECOVERED,
    'python': sys.version,
    'platform': platform.platform(),
    'command': [sys.executable, '-B', str(Path(__file__).resolve())],
    'script': ident(Path(__file__).read_bytes()),
}

bindings = []
for row in js(ROOT + 'INPUTS.json')['files']:
    raw = read(row['path'])
    assert_identity(raw, row)
    assert raw == read(row['path'], PUBLISHED) == read(row['path'], row['gitRevision'])
    bindings.append({'path': row['path'], **ident(raw), 'exact_revision_equality': True})
report['pinned_inputs'] = bindings

code = []
for name in ['hinge_binding.py', 'test_hinge_binding.py', 'binding_control_fixtures.py']:
    raw = read(ROOT + name)
    assert raw == read(ROOT + name, PUBLISHED)
    assert raw == read(ROOT + 'evidence/independent-controls/run-02/checked-code/' + name)
    assert raw == read(ROOT + 'evidence/candidate/c266-controls/checked-code/' + name)
    code.append({'path': ROOT + name, **ident(raw), 'published_and_checked_snapshots_equal': True})
report['candidate_code'] = code

checks_path = ROOT + 'evidence/candidate/CHECKS.json'
checks = js(checks_path)
assert checks['source_before']['commit'] == PUBLISHED == checks['source_after']['commit']
assert checks['passed'] and checks['complete'] and checks['input_identity_unchanged']
assert checks['planned_check_count'] == checks['completed_check_count'] == 10
assert checks['total_methods'] == checks['expected_total_methods'] == 222
assert checks['input_files_before'] == checks['input_files_after']
for row in checks['input_files_before']:
    assert_identity(read(row['path'], PUBLISHED), row)
report['candidate_checks'] = {
    'path': checks_path,
    **ident(read(checks_path)),
    'groups': len(checks['checks']),
    'methods': checks['total_methods'],
    'inputs_bound_to_exact_candidate': len(checks['input_files_before']),
    'groups_passed': all(c['result'] == 'passed' and c['exit_code'] == 0 for c in checks['checks']),
    'corpus_files': checks['checks'][0]['details']['boundFiles'],
}
assert report['candidate_checks']['groups_passed']

tracked = set(git('ls-tree', '-r', '--name-only', RECOVERED).decode().splitlines())
outputs = []
missing = []
for row in checks['output_files']:
    path = ROOT + 'evidence/candidate/' + row['path']
    in_commit = path in tracked
    raw = read(path) if in_commit else (REPO / path).read_bytes()
    assert_identity(raw, row)
    outputs.append({'path': path, **ident(raw), 'retained_in_recovered_commit': in_commit})
    if not in_commit:
        missing.append(path)
report['candidate_output_files'] = outputs
report['required_publication_repair'] = {
    'count': len(missing),
    'files': missing,
    'finding': 'Exact logs survive in the old workspace but were ignored by Git and absent from 74bba. Preserve these unchanged bytes in the recovery publication or a hash-bound durable archive.',
}

control_reports = []
for run in ['independent-controls/run-01', 'independent-controls/run-02', 'candidate/c266-controls']:
    prefix = ROOT + 'evidence/' + run + '/'
    results = js(prefix + 'results.json')
    z = archive(read(prefix + 'inputs.zip'))
    referenced = set()
    mismatches = []
    for case in results['cases']:
        items = [case['artifactInput']]
        if isinstance(case['sourceInputs'], dict):
            items.extend(case['sourceInputs'].values())
        for item in items:
            if not isinstance(item, dict) or 'snapshot' not in item:
                continue
            name = item['snapshot'].split('!', 1)[1]
            referenced.add(name)
            assert_identity(z.read(name), item)
        expected_outcome = {'binding': 'bound', 'refusal': 'typed_refusal'}[case['expected']]
        if case['outcome'] != expected_outcome:
            mismatches.append(case['label'])
    assert referenced == set(z.namelist())
    for name in z.namelist():
        assert hashlib.sha256(z.read(name)).hexdigest() == name.split('.')[0]
    control_reports.append({
        'run': run, 'methods': results['testMethods'], 'api_calls': results['apiCalls'],
        'outcomes': dict(collections.Counter(c['outcome'] for c in results['cases'])),
        'expectation_mismatches': mismatches, 'recorded_passed': results['passed'],
        'exact_input_payloads': len(referenced),
    })
assert control_reports[0]['recorded_passed'] is False and len(control_reports[0]['expectation_mismatches']) == 2
for row in control_reports[1:]:
    assert row['recorded_passed'] and not row['expectation_mismatches']
    assert row['methods'] == 34 and row['api_calls'] == 748
    assert row['outcomes'] == {'typed_refusal': 720, 'bound': 28}
report['control_evidence'] = control_reports

archives = []
for filename, receipt_name in [
    ('C266_Independent_Review_Evidence.zip', 'EVIDENCE-VERIFICATION.json'),
    ('C266_Dependency_Review_Supplement.zip', 'DEPENDENCY-SUPPLEMENT-VERIFICATION.json'),
]:
    raw = read(ROOT + 'evidence/review/' + filename)
    receipt = js(ROOT + 'evidence/review/' + receipt_name)
    assert_identity(raw, receipt)
    z = archive(raw)
    manifest = json.loads(z.read('MANIFEST-SHA256.json'))['files']
    assert set(manifest) == set(z.namelist()) - {'MANIFEST-SHA256.json'}
    for path, record in manifest.items():
        assert_identity(z.read(path), record)
    archives.append({'archive': filename, **ident(raw), 'verified_manifest_payloads': len(manifest)})
report['review_archives'] = archives

recovery_audit = js(ROOT + 'evidence/recovery-review/AUDIT.json')
assert recovery_audit['passed'] and not recovery_audit['errors']
assert recovery_audit['implementation'] == ident(read(ROOT + 'hinge_binding.py'))
assert_identity(read(ROOT + 'evidence/recovery-review/audit_recovery.py'), recovery_audit['script'])
report['retained_recovery_review'] = {
    'passed': True, 'source_equality': True,
    'distinct_passing_controls': recovery_audit['reviewDistinctPassingDispositions'],
    'retained_passed_attempts': recovery_audit['reviewRetainedPassedAttempts'],
    'retained_failed_attempts': recovery_audit['reviewRetainedFailedAttempts'],
    'dependency_experiments': recovery_audit['dependencyExperiments'],
}

changed = git('diff', '--name-only', BASE, RECOVERED).decode().splitlines()
assert not [p for p in changed if p.startswith(('ontokin/', 'tests/', 'fixtures/', 'examples/', 'tools/', '.github/'))]
report['product_and_hosted_workflow_changes'] = []
report['new_behavioral_tests_run'] = False
report['code_review_verdict'] = 'approve bounded input-binding implementation'
report['evidence_audit_passed'] = True
report['integration_condition'] = 'Preserve the ten exact scratch-only candidate logs before claiming the recovered evidence is durable; complete normal current-head integration and resulting-main checks.'
report['limits'] = ['Evidence integrity and full candidate source review only; not a fresh behavioral rerun', 'No complete hinge comparison or C260 H group', 'No historical admission, site-pose, source validity, accepted-revision, atomicity, rebuild, native, physical, model-trial or comparative claim']
(OUT / 'AUDIT.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['evidence_audit_passed', 'code_review_verdict', 'candidate_checks', 'required_publication_repair']}, indent=2))
