"""Record the complete split-process disposition without relabelling any run."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import runpy


OUT = Path(__file__).resolve().parent
PARSE = runpy.run_path(str(OUT / "reconcile.py"))


def read(name):
    return json.loads((OUT / name).read_text())


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


def file_identity(name):
    raw = (OUT / name).read_bytes()
    return {"path": name, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()}


def main():
    stock = read("stock-core-1800/summary.json")
    tail_command = read("ordered-tail/command.json")
    tail_result = read("ordered-tail/test-result.json")
    selection = read("ordered-tail/selection.json")
    if not stock.get("finished_at") or not tail_command.get("finished_at"):
        raise RuntimeError("Both invocations must finish before final reconciliation")
    names = selection["full_discovered_ids_in_order"]
    required = set(names)
    historical = read("prior-c191/reconstructed-test-inventory.json")
    prior_gap = read("prior-c191/regression-inventory.json")["missingMethods"]
    if len(names) != 4252 or len(required) != len(names) or required != set(historical["test_ids"]):
        raise RuntimeError("Fresh inventory does not match the identified complete obligation")
    logs = {"stock": "stock-core-1800/logs/unit-tests.log", "tail": "ordered-tail/unit-tests.log"}
    parsed = {key: PARSE["parse_methods"]((OUT / name).read_text(errors="replace"))
              for key, name in logs.items()}
    observations = {name: [] for name in names}
    unexpected = []
    for invocation, data in parsed.items():
        for row in data["methods"]:
            item = {"invocation": invocation, "status": row["status"]}
            if row["test_id"] in observations:
                observations[row["test_id"]].append(item)
            else:
                unexpected.append(dict(row, invocation=invocation))
    passed = {name for name, rows in observations.items() if any(row["status"] == "ok" for row in rows)}
    missing = sorted(name for name, rows in observations.items() if not rows)
    unresolved = sorted(name for name, rows in observations.items()
                        if rows and not any(row["status"] == "ok" for row in rows))
    bad = [{"test_id": name, **row} for name, rows in observations.items() for row in rows
           if row["status"] not in {"ok", "no_result"}]
    primary_passed = {row["test_id"] for row in parsed["stock"]["methods"] if row["status"] == "ok"}
    tail_passed = {row["test_id"] for row in parsed["tail"]["methods"] if row["status"] == "ok"}
    started_overlap = sorted({row["test_id"] for row in parsed["stock"]["methods"]}
                             & {row["test_id"] for row in parsed["tail"]["methods"]})
    passed_overlap = sorted(primary_passed & tail_passed)
    completed_after_interrupt = sorted(name for name, rows in observations.items()
                                      if any(row["status"] == "no_result" for row in rows)
                                      and any(row["status"] == "ok" for row in rows))
    tail_text = (OUT / logs["tail"]).read_text(errors="replace")
    fresh_fingerprint = PARSE["failure_fingerprints"](tail_text)
    prior_fingerprint = PARSE["failure_fingerprints"](
        (OUT / "prior-c191/baseline-torque-artifact-targeted.log").read_text())
    expected_fixture = [{"fixture": "setUpClass",
                         "identity": "test_torque_artifact_reads.TorqueArtifactReadTests", "status": "ERROR"}]
    source_binding = read("prior-source-binding.json")
    inputs_stable = bool(stock.get("source_unchanged") and tail_command.get("source_unchanged")
                         and tail_command.get("workspace_immutable_inputs_unchanged")
                         and source_binding["all_available_inputs_equal"])
    other_steps_passed = all(step["status"] == "passed" for step in stock["steps"]
                             if step["id"] != "unit-tests")
    exact_prior_gap = missing == prior_gap
    matching_failure = fresh_fingerprint == prior_fingerprint and bool(fresh_fingerprint)
    duplicates = {key: data["duplicates"] for key, data in parsed.items()}
    clean_methods = not bad and not unresolved and not unexpected and not any(duplicates.values())
    same_inherited = bool(exact_prior_gap and matching_failure and clean_methods
                          and parsed["stock"]["fixture_errors"] == []
                          and parsed["tail"]["fixture_errors"] == expected_fixture
                          and len(passed) == 4239 and inputs_stable and other_steps_passed)
    all_methods_passed = bool(len(passed) == len(required) and not missing and clean_methods
                             and not parsed["stock"]["fixture_errors"]
                             and not parsed["tail"]["fixture_errors"] and inputs_stable and other_steps_passed)
    official_counts_consistent = bool(parsed["tail"]["official_test_counts"]
        and parsed["tail"]["official_test_counts"][-1]["count"] == tail_result["tests_run"]
        == len(parsed["tail"]["methods"]))
    if not official_counts_consistent:
        raise RuntimeError("Tail official and method-level execution counts disagree")
    dependency_record = read("dependencies.json")
    report = {
        "schema": "c193-recovery-combined-legacy-disposition/1",
        "created_at": datetime.now(timezone.utc).isoformat(),
        "analysis_status": "completed" if same_inherited or all_methods_passed else "needs_investigation",
        "source": stock["git"], "environment": stock["environment"],
        "dependencies": dependency_record["packages"],
        "dependency_lock_sha256": dependency_record["lock_sha256"],
        "original_c193_interrupted_execution": {"status": "unknown", "result_recovered": False},
        "recovery_default900_attempt": read("interrupted-inventory.json"),
        "stock_driver_status": stock["status"], "stock_driver_exit_code": stock["exit_code"],
        "stock_driver_unit_status": stock["steps"][0]["status"],
        "stock_driver_unit_reason": stock["steps"][0].get("reason"),
        "stock_driver_complete_regression_passed": stock["steps"][0]["test_execution"]["complete_regression_passed"],
        "stock_driver_steps": [{key: step[key] for key in ["id", "status", "duration_seconds"]}
                               for step in stock["steps"]],
        "stock_prefix_passed_methods": len(primary_passed),
        "stock_prefix_started_methods": len(parsed["stock"]["methods"]),
        "stock_prefix_interrupted_methods": [row for row in parsed["stock"]["methods"] if row["status"] == "no_result"],
        "supplemental_tail_status": tail_command["status"],
        "supplemental_selected_count": selection["selected_count"],
        "supplemental_tests_run": tail_result["tests_run"],
        "supplemental_passed_methods": len(tail_passed),
        "supplemental_complete_selected_cohort_passed": tail_result["complete_selected_cohort_passed"],
        "full_discovered_method_count": len(required), "combined_unique_passed_methods": len(passed),
        "combined_not_run_count": len(missing), "combined_not_run_methods": missing,
        "unresolved_started_methods": unresolved, "completed_nonpassing_method_observations": bad,
        "unexpected_methods": unexpected, "duplicates_within_invocation": duplicates,
        "previously_passing_method_overlap": passed_overlap,
        "started_method_overlap": started_overlap,
        "completed_after_original_interruption": completed_after_interrupt,
        "fixture_errors": {key: data["fixture_errors"] for key, data in parsed.items()},
        "tail_skipped": tail_result["skipped"], "tail_expected_failures": tail_result["expected_failures"],
        "official_tail_counts_consistent": official_counts_consistent,
        "same_prior_thirteen_method_gap": exact_prior_gap,
        "fresh_failure_fingerprints": fresh_fingerprint,
        "prior_baseline_failure_fingerprints": prior_fingerprint,
        "same_prior_failure_fingerprint": matching_failure,
        "source_and_workspace_inputs_stable": inputs_stable,
        "same_contained_incomplete_feature_failure": same_inherited,
        "no_new_or_worsened_legacy_product_failure_observed": same_inherited or all_methods_passed,
        "performance_equivalence_established": False,
        "outer_supervision_failures_retained": True,
        "all_method_obligations_passed": all_methods_passed,
        "coverage_form": "combined split-process method coverage; prior process warm state was not restored",
        "single_process_equivalence_claimed": False,
        "stock_driver_result_relabelled": False,
        "fixture_limits_changed": False, "remote_checks_executed": False,
        "pending_external_cases": stock.get("pending_external_cases", []),
        "unexecuted_compatibility": "Only CPython 3.12.14 Linux x86_64 was executed; other interpreter/platform roles remain open.",
        "release_certified": False, "full_product_goal_completed": False,
        "commands": {"stock": read("complete-command.json")["argv"],
                     "supplemental_supervisor": read("supplemental-invocation.json")["argv"],
                     "supplemental_child": tail_command["argv"]},
        "evidence": [file_identity(name) for name in [
            "stock-core-1800/summary.json", logs["stock"], logs["tail"],
            "ordered-tail/selection.json", "ordered-tail/test-result.json", "ordered-tail/command.json",
            "input-equality.json", "prior-source-binding.json", "dependencies.json",
            "ordered_remainder.py", "reconcile.py", "reconcile_combined.py"]],
        "interpretation": (
            "The original stock driver remains FAILED for its outer unit watchdog. Separately recorded prefix and ordered-tail observations account for the complete inventory. The only unexecuted methods are the same thirteen experimental .22 artifact-read methods after the unchanged real-clock A08 setup failure. This supports the bounded development failure disposition under OK-ENG-009; it does not pass the complete regression driver, torque release, external roles, or unexecuted compatibility."
            if same_inherited else
            "All discovered methods passed across separately recorded processes; the original stock-driver timeout remains failed, and no single-process or release-equivalence claim is made."
            if all_methods_passed else
            "The combined observations require investigation; no unchanged-failure or integration clearance is inferred.")}
    write("disposition.json", report)
    write("combined-method-observations.json", {"schema": "c193-combined-method-observations/1",
        "method_count": len(names), "methods": [{"test_id": name, "observations": observations[name],
        "status": "passed" if name in passed else "not_run" if name in missing else "unresolved"} for name in names]})
    write("tail-method-results.json", parsed["tail"])
    print(json.dumps({key: report[key] for key in ["analysis_status", "stock_driver_status",
        "stock_prefix_passed_methods", "supplemental_selected_count", "supplemental_tests_run",
        "supplemental_passed_methods", "combined_unique_passed_methods", "combined_not_run_count",
        "same_contained_incomplete_feature_failure", "source_and_workspace_inputs_stable"]}, indent=2))
    return 0 if report["analysis_status"] == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
