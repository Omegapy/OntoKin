"""Execute one separately identified ordered remainder after an actual timeout.

Uses unchanged source, full stock discovery, preserved module-suite objects,
standard unittest fixtures, and a finite outer watchdog. Never edits a gate or
substitutes this result into the original stock-driver summary.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
from importlib import metadata
import json
from pathlib import Path
import platform
import runpy
import subprocess
import sys
import time
import unittest


OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent / "regression-source"
PRIMARY = OUT / "stock-core-1800"
TAIL = OUT / "ordered-tail"
WORKSPACE = TAIL / "workspace"
TIMEOUT = 1800
HEAD = "bc8c0918045248cd3d34c64e40c135fff0eec985"
TREE = "631034be6fcd5249af753a9852a13f76baf44493"


def utc():
    return datetime.now(timezone.utc).isoformat()


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")


def identity(path):
    raw = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


def flatten(item):
    if isinstance(item, unittest.TestSuite):
        for child in item:
            yield from flatten(child)
    else:
        yield item.id()


def execute_selected():
    if Path.cwd().resolve() != WORKSPACE.resolve():
        raise RuntimeError("Child cwd is not the fresh identified workspace")
    sys.path.insert(0, str(WORKSPACE))
    loader = unittest.TestLoader()
    full = loader.discover("tests")
    if loader.errors:
        raise RuntimeError("Full discovery errors: " + repr(loader.errors))
    groups = list(full)
    group_ids = [list(flatten(group)) for group in groups]
    all_ids = [name for names in group_ids for name in names]
    historical = json.loads((OUT / "prior-c191/reconstructed-test-inventory.json").read_text())
    if len(all_ids) != 4252 or len(all_ids) != len(set(all_ids)) or set(all_ids) != set(historical["test_ids"]):
        raise RuntimeError("Fresh full discovery differs from the unchanged required inventory")
    parse = runpy.run_path(str(OUT / "reconcile.py"))["parse_methods"]
    primary = parse((PRIMARY / "logs/unit-tests.log").read_text(errors="replace"))
    if not primary["methods"] or primary["duplicates"]:
        raise RuntimeError("Primary log has no unambiguous method boundary")
    observed_ids = {row["test_id"] for row in primary["methods"]}
    if not observed_ids <= set(all_ids):
        raise RuntimeError("Primary log contains IDs outside current discovery")
    observed_order = [row["test_id"] for row in primary["methods"]]
    if observed_order != all_ids[:len(observed_order)]:
        raise RuntimeError("Primary method order is not the exact prefix of fresh stock discovery")
    boundary_id = primary["methods"][-1]["test_id"]
    module = boundary_id.split(".")[0]
    module_indexes = [i for i, names in enumerate(group_ids)
                      if any(name.split(".")[0] == module for name in names)]
    if len(module_indexes) != 1 or boundary_id not in group_ids[module_indexes[0]]:
        raise RuntimeError("Boundary module does not map to exactly one discovered module suite")
    index = module_indexes[0]
    selected_ids = [name for names in group_ids[index:] for name in names]
    passed = {row["test_id"] for row in primary["methods"] if row["status"] == "ok"}
    if set(all_ids) != passed | set(selected_ids):
        raise RuntimeError("Passing prefix and selected module tail do not cover the full inventory")
    selection = {
        "schema": "c193-ordered-supplemental-selection/1", "created_at": utc(),
        "source_head": HEAD, "source_tree": TREE, "cwd": str(WORKSPACE),
        "full_discovery_command_equivalent": "unittest.TestLoader().discover('tests')",
        "full_discovered_count": len(all_ids), "full_discovered_ids_in_order": all_ids,
        "boundary_method": boundary_id, "boundary_module": module,
        "boundary_group_index": index, "top_level_group_count": len(groups),
        "selected_top_level_group_count": len(groups) - index,
        "selected_count": len(selected_ids), "selected_ids_in_order": selected_ids,
        "primary_passed_count": len(passed), "primary_passed_ids": sorted(passed),
        "overlap_passed_count": len(passed & set(selected_ids)),
        "overlap_passed_ids": sorted(passed & set(selected_ids)),
        "primary_incomplete_started_methods": [row for row in primary["methods"] if row["status"] == "no_result"],
        "selection_rule": "Rewind the entire intact last-started module suite and retain every later top-level suite in original discovery order.",
        "runner": "standard unittest.TestSuite with unchanged module-suite objects; TextTestRunner(verbosity=2) with the stock CLI warning setting",
        "fixture_caps_changed": False, "prefix_process_warm_state_restored": False,
        "claim_scope": "Separate split-process coverage; not a passing or equivalent single-process stock-driver run.",
        "primary_log": identity(PRIMARY / "logs/unit-tests.log"),
        "runner_source": identity(Path(__file__)), "parser_source": identity(OUT / "reconcile.py")}
    write(TAIL / "selection.json", selection)
    print("Ordered supplemental selection: " + json.dumps({key: selection[key] for key in [
        "boundary_module", "selected_count", "primary_passed_count", "overlap_passed_count"]}), flush=True)
    started = time.monotonic()
    started_at = utc()
    warning_setting = None if sys.warnoptions else "default"
    result = unittest.TextTestRunner(verbosity=2, warnings=warning_setting).run(
        unittest.TestSuite(groups[index:]))
    complete_pass = (result.wasSuccessful() and result.testsRun == len(selected_ids)
                     and not result.skipped and not result.expectedFailures
                     and not result.unexpectedSuccesses)
    outcome = {"schema": "c193-ordered-supplemental-execution/1", "started_at": started_at,
        "finished_at": utc(), "duration_seconds": round(time.monotonic() - started, 3),
        "tests_run": result.testsRun, "was_successful": result.wasSuccessful(),
        "complete_selected_cohort_passed": complete_pass,
        "status": "passed" if complete_pass else "failed",
        "failures": [{"id": test.id(), "traceback": trace} for test, trace in result.failures],
        "errors": [{"id": test.id(), "traceback": trace} for test, trace in result.errors],
        "skipped": [{"id": test.id(), "reason": reason} for test, reason in result.skipped],
        "expected_failures": [{"id": test.id(), "traceback": trace} for test, trace in result.expectedFailures],
        "unexpected_successes": [test.id() for test in result.unexpectedSuccesses],
        "stock_driver_result_relabelled": False, "fixture_caps_changed": False}
    write(TAIL / "test-result.json", outcome)
    return 0 if complete_pass else 1


def supervise():
    summary = json.loads((PRIMARY / "summary.json").read_text())
    if summary.get("status") != "failed" or not summary.get("finished_at"):
        raise RuntimeError("Wait for the stock driver to finish normally with its retained failure")
    if summary.get("source_unchanged") is not True:
        raise RuntimeError("The original driver did not establish stable source inputs; resolve this first")
    steps = {step["id"]: step for step in summary["steps"]}
    if steps.get("unit-tests", {}).get("reason") != "Exceeded 1800 seconds":
        raise RuntimeError("No actual authorized outer unit watchdog expiration")
    if any(steps.get(name, {}).get("status") != "passed" for name in [
            "source", "agent", "construction", "surface", "impulse", "documents"]):
        raise RuntimeError("A separate core role failed or did not finish; seek a precise disposition first")
    sys.path.insert(0, str(SOURCE))
    from tools.check_local import (git_environment, git_metadata, inventory, immutable_workspace_inputs,
                                  prepare_workspace, stop_process)
    git_before = git_metadata(SOURCE)
    if (git_before.get("local_head"), git_before.get("local_tree")) != (HEAD, TREE):
        raise RuntimeError("Source revision changed")
    if git_before.get("tracked_worktree_status") or git_before.get("untracked_source_files"):
        raise RuntimeError("Source is not clean")
    dependencies = json.loads((OUT / "dependencies.json").read_text())
    for name, pin in dependencies["packages"].items():
        if metadata.version(name) != pin["expected"]:
            raise RuntimeError("Verification package differs: " + name)
    TAIL.mkdir(exist_ok=False)
    print("Preparing fresh isolated supplemental workspace at " + str(WORKSPACE), flush=True)
    before = inventory(SOURCE)
    if before != json.loads((PRIMARY / "source-before.json").read_text()):
        raise RuntimeError("Source bytes differ from the stock attempt")
    write(TAIL / "source-before.json", before)
    workspace = prepare_workspace(SOURCE, TAIL, False, source_git=git_before)
    if inventory(workspace) != before:
        raise RuntimeError("Fresh workspace inputs differ from the stock source")
    review = OUT.parent / "recovery-evidence/ORDERED-REMAINDER-REVIEW.md"
    (TAIL / "ORDERED-REMAINDER-REVIEW.md").write_bytes(review.read_bytes())
    argv = [sys.executable, str(Path(__file__).resolve()), "--execute"]
    command = {"schema": "c193-ordered-supplemental-command/1", "argv": argv,
        "cwd": str(workspace), "started_at": utc(), "status": "running",
        "supervisor_timeout_seconds": TIMEOUT, "fixture_caps_changed": False,
        "source_git": git_before, "workspace_git": git_metadata(workspace),
        "python": sys.version, "platform": platform.platform(),
        "runner_source": identity(Path(__file__)), "parser_source": identity(OUT / "reconcile.py"),
        "independent_review": identity(TAIL / "ORDERED-REMAINDER-REVIEW.md"),
        "primary_summary": identity(PRIMARY / "summary.json"),
        "log": "unit-tests.log", "original_stock_driver_status": "failed",
        "prefix_process_warm_state_restored": False,
        "claim_scope": "Separate ordered tail; combined coverage does not change the original driver result."}
    write(TAIL / "command.json", command)
    print(json.dumps(command), flush=True)
    started = time.monotonic()
    with (TAIL / "unit-tests.log").open("x") as log:
        process = subprocess.Popen(argv, cwd=workspace, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True, env=git_environment(workspace))
        try:
            returncode = process.wait(timeout=TIMEOUT)
            reason = None
        except subprocess.TimeoutExpired:
            stop_process(process)
            returncode = process.returncode
            reason = "Exceeded " + str(TIMEOUT) + " seconds"
    after = inventory(SOURCE)
    write(TAIL / "source-after.json", after)
    workspace_after = inventory(workspace)
    write(TAIL / "workspace-after.json", workspace_after)
    command.update(returncode=returncode, reason=reason, finished_at=utc(),
        duration_seconds=round(time.monotonic() - started, 3),
        status="passed" if returncode == 0 and reason is None else "failed",
        source_after_git=git_metadata(SOURCE),
        source_unchanged=after == before and git_metadata(SOURCE) == git_before,
        workspace_immutable_inputs_unchanged=(immutable_workspace_inputs(workspace_after)
                                             == immutable_workspace_inputs(before)),
        log_identity=identity(TAIL / "unit-tests.log"))
    integrity_errors = []
    if not command["source_unchanged"]:
        integrity_errors.append("Original source inputs changed")
    if not command["workspace_immutable_inputs_unchanged"]:
        integrity_errors.append("Fresh workspace immutable inputs changed")
    command["integrity_errors"] = integrity_errors
    if integrity_errors:
        command["status"] = "failed"
        command["reason"] = (reason + "; " if reason else "") + "; ".join(integrity_errors)
    write(TAIL / "command.json", command)
    print(json.dumps(command), flush=True)
    return 0 if command["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(execute_selected() if sys.argv[1:] == ["--execute"] else supervise())
