"""Reconcile retained unittest text against unchanged actual discovery.

This evidence helper neither runs tests nor changes a product or gate input.
Run it only after the identified stock driver has completed.
"""
from __future__ import annotations

import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys


OUTPUT = Path(__file__).resolve().parent
SOURCE = OUTPUT.parent / "regression-source"
COMPLETE = OUTPUT / "stock-core-1800"


def identity(path: Path) -> dict:
    data = path.read_bytes()
    return {"path": str(path.relative_to(OUTPUT)), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def write(name: str, data: object) -> None:
    (OUTPUT / name).write_text(json.dumps(data, indent=2) + "\n")


def parse_methods(text: str) -> dict:
    starts = list(re.finditer(
        r"(?m)^(?P<method>test\w*) \((?P<id>[^)\n]+)\)", text))
    methods = []
    for index, match in enumerate(starts):
        end = starts[index + 1].start() if index + 1 < len(starts) else len(text)
        segment = text[match.end():end]
        result = re.search(
            r"\.\.\. (ok|ERROR|FAIL|expected failure|unexpected success|skipped\b[^\n]*)",
            segment)
        methods.append({"test_id": match["id"],
                        "status": result.group(1) if result else "no_result"})
    counts = Counter(row["test_id"] for row in methods)
    return {"methods": methods,
            "status_counts": dict(Counter(row["status"] for row in methods)),
            "duplicates": sorted(name for name, count in counts.items() if count > 1),
            "fixture_errors": [
                {"fixture": match[1], "identity": match[2], "status": match[3]}
                for match in re.finditer(
                    r"(?m)^(setUpClass|tearDownClass|setUpModule|tearDownModule) "
                    r"\(([^)]+)\) \.\.\. (ERROR|FAIL)", text)],
            "official_test_counts": [
                {"count": int(match[1]), "seconds": float(match[2])}
                for match in re.finditer(r"(?m)^Ran (\d+) tests? in ([0-9.]+)s$", text)],
            "official_endings": re.findall(r"(?m)^(?:OK|FAILED)(?: \([^\n]*\))?$", text)}


def failure_fingerprints(text: str) -> list[dict]:
    result = []
    for line in text.splitlines():
        if not line.startswith("AssertionError: {"):
            continue
        try:
            payload = ast.literal_eval(line.partition("AssertionError: ")[2])
        except (ValueError, SyntaxError):
            continue
        budget = payload.get("execution_budget", {})
        diagnostics = payload.get("diagnostics", [])
        if not budget or not diagnostics:
            continue
        result.append({
            "schema_version": payload.get("schema_version"),
            "operation": payload.get("operation"),
            "status": payload.get("status"),
            "program_revision": payload.get("program_revision"),
            "entry_revision": budget.get("entry_revision"),
            "implementation": budget.get("implementation"),
            "policy_id": budget.get("policy_id"),
            "effective": budget.get("effective"),
            "host_ceilings": budget.get("host_ceilings"),
            "source_request": budget.get("source_request"),
            "stage": budget.get("stage"),
            "budget_reason": budget.get("budget_reason"),
            "diagnostics": [
                {"code": item.get("code"), "category": item.get("category"),
                 "budget": item.get("details", {}).get("budget"),
                 "budget_reason": item.get("details", {}).get("budget_reason"),
                 "limit": item.get("details", {}).get("limit"),
                 "stage": item.get("details", {}).get("stage")}
                for item in diagnostics]})
    return result


def main() -> int:
    summary = json.loads((COMPLETE / "summary.json").read_text())
    if summary.get("status") not in {"passed", "failed", "interrupted"}:
        raise RuntimeError("The stock driver has not completed; do not finalize.")
    discover_argv = [sys.executable, "-c", "import json; from ontokin.surface_conformance "
                     "import discover_test_ids; print(json.dumps(discover_test_ids()))"]
    discovery = subprocess.run(discover_argv, cwd=SOURCE, capture_output=True, text=True)
    (OUTPUT / "discovery.stdout.log").write_text(discovery.stdout)
    (OUTPUT / "discovery.stderr.log").write_text(discovery.stderr)
    if discovery.returncode:
        raise RuntimeError("Actual discovery failed: " + discovery.stderr)
    names = json.loads(discovery.stdout)
    if not names or len(names) != len(set(names)):
        raise RuntimeError("Discovery did not return a unique nonempty inventory.")
    write("test-inventory.json", {"argv": discover_argv, "cwd": str(SOURCE),
                                 "returncode": discovery.returncode,
                                 "scope": "discovery only; no fixture/test execution",
                                 "test_count": len(names), "test_ids": names})
    required = set(names)
    unit_log = COMPLETE / "logs/unit-tests.log"
    fresh_text = unit_log.read_text(errors="replace")
    fresh = parse_methods(fresh_text)
    fresh_ids = {row["test_id"] for row in fresh["methods"]}
    fresh_passed = {row["test_id"] for row in fresh["methods"] if row["status"] == "ok"}
    prior_text = (OUTPUT / "prior-c191/complete-unit-tests.log").read_text(errors="replace")
    prior = parse_methods(prior_text)
    prior_record = json.loads((OUTPUT / "prior-c191/regression-inventory.json").read_text())
    prior_passed = {row["test_id"] for row in prior["methods"] if row["status"] == "ok"}
    parser_check = (len(prior_passed) == prior_record["passedUniqueMethods"]
                    and sorted(required - prior_passed) == prior_record["missingMethods"]
                    and not prior["duplicates"] and prior_passed <= required)
    if not parser_check:
        raise RuntimeError("The parser does not reproduce the retained reconciled C191 inventory.")
    baseline_text = (OUTPUT / "prior-c191/baseline-torque-artifact-targeted.log").read_text()
    fresh_fingerprints = failure_fingerprints(fresh_text)
    baseline_fingerprints = failure_fingerprints(baseline_text)
    missing = sorted(required - fresh_ids)
    nonpassing = [row for row in fresh["methods"] if row["status"] != "ok"]
    prior_gap_matches = missing == prior_record["missingMethods"]
    failure_matches = fresh_fingerprints == baseline_fingerprints
    fixture_match = fresh["fixture_errors"] == [
        {"fixture": "setUpClass", "identity": "test_torque_artifact_reads.TorqueArtifactReadTests",
         "status": "ERROR"}]
    previous_source = json.loads((OUTPUT / "prior-source-binding.json").read_text())
    same_inherited_failure = bool(
        summary["status"] == "failed" and prior_gap_matches and failure_matches
        and fixture_match and not nonpassing and not fresh["duplicates"]
        and not (fresh_ids - required) and len(fresh_passed) == len(required) - len(missing)
        and summary.get("source_unchanged") is True
        and previous_source["all_available_inputs_equal"])
    reconcile = {
        "schema": "c193-recovery-regression-reconciliation/1",
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "source": summary.get("git"), "unit_log": identity(unit_log),
        "discovered_count": len(required), "started_method_count": len(fresh_ids),
        "passed_unique_method_count": len(fresh_passed),
        "missing_method_count": len(missing), "missing_methods": missing,
        "nonpassing_started_methods": nonpassing,
        "unexpected_methods": sorted(fresh_ids - required),
        "duplicate_methods": fresh["duplicates"],
        "status_counts": fresh["status_counts"], "fixture_errors": fresh["fixture_errors"],
        "official_test_counts": fresh["official_test_counts"],
        "official_endings": fresh["official_endings"],
        "prior_c191_parser_crosscheck": parser_check,
        "exact_prior_missing_method_set": prior_gap_matches,
        "fresh_failure_fingerprints": fresh_fingerprints,
        "prior_baseline_failure_fingerprints": baseline_fingerprints,
        "same_failure_fingerprint": failure_matches,
        "all_historical_failure_source_inputs_equal": previous_source["all_available_inputs_equal"],
        "same_contained_incomplete_feature_failure": same_inherited_failure,
        "stock_driver_status": summary["status"],
        "source_unchanged": summary.get("source_unchanged"),
        "claim_scope": "Observed fresh results only; prior failures and original unknown C193 execution remain unchanged."
    }
    write("reconciliation.json", reconcile)
    write("method-results.json", fresh)
    print(json.dumps({k: reconcile[k] for k in ["stock_driver_status", "discovered_count",
        "passed_unique_method_count", "missing_method_count", "fixture_errors",
        "same_contained_incomplete_feature_failure", "source_unchanged"]}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
