import argparse
import datetime
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import sys
import time

p = argparse.ArgumentParser()
p.add_argument('--revision', required=True)
p.add_argument('--candidate', required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
if not all(re.fullmatch(r'[a-f0-9]{40}', v) for v in (a.revision, a.candidate)):
    raise SystemExit('Exact observed revisions required')
repo = Path('/workspace/scratch/3be63d9ca584/ontokin')
output = a.output.resolve()
if output.exists():
    raise SystemExit('Preserve prior verification outputs; choose a new directory')
output.mkdir(parents=True)

def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args], text=True).strip()

head = git('rev-parse', 'HEAD')
tree = git('rev-parse', 'HEAD^{tree}')
if head != a.revision or git('status', '--porcelain'):
    raise SystemExit('Resulting-main checkout is not the exact clean revision')
candidate_tree = git('rev-parse', a.candidate + '^{tree}')
if tree != candidate_tree:
    raise SystemExit('Merge tree differs from reviewed candidate')

tested = 'bc8c0918045248cd3d34c64e40c135fff0eec985'
preserved = [
    'ontokin', 'tests', 'tools', '.github', 'prototypes',
    'docs/language-design', 'docs/engineering/guided-contact-c191',
    'docs/engineering/contact-comparison-c192',
    'docs/engineering/guide-repair-c193/native',
    'docs/engineering/guide-repair-c193/independent',
    'docs/engineering/guide-repair-c193/receiving-evidence.tar.xz',
    'docs/engineering/guide-repair-c193/evidence/receiving',
    'docs/engineering/guide-repair-c193/IMPLEMENTATION.json',
    'docs/engineering/guide-repair-c193/NEXT-TASK.md',
    'pyproject.toml', 'GOAL.md', 'AGENTS.md',
]
changed = git('diff', '--name-only', tested, head, '--', *preserved).splitlines()
if changed:
    raise SystemExit('Previously verified execution inputs changed: ' + ', '.join(changed))

env = dict(os.environ)
env['PYTHONDONTWRITEBYTECODE'] = '1'
commands = [
    ('documentation', [sys.executable, '-B', 'docs/maintenance/reorganization-2026-10-17/verify_reorganization.py']),
    ('conformance', [sys.executable, '-B', '-m', 'ontokin', 'conformance', '--output', str(output / 'conformance.json')]),
    ('recorded-replay', [sys.executable, '-B', 'docs/engineering/guide-repair-c193/independent/replay_evidence.py',
        '--formal', 'docs/engineering/guide-repair-c193/native/formal-native-complete.tar.xz',
        '--out', str(output / 'recorded-replay')]),
]
result = {'pass': False, 'revision': head, 'tree': tree, 'reviewed_candidate': a.candidate,
    'candidate_tree': candidate_tree, 'candidate_merge_tree_equal': True,
    'regression_tested_revision': tested, 'eligible_execution_inputs_equal': True,
    'preserved_scopes': preserved, 'changed_preserved_paths': changed,
    'python': sys.version, 'platform': platform.platform(),
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'new_native_trials': 0, 'new_receiving_runs': 0, 'commands': []}
for label, argv in commands:
    start = time.monotonic()
    run = subprocess.run(argv, cwd=repo, env=env, text=True, capture_output=True, timeout=900)
    (output / (label + '.stdout.txt')).write_text(run.stdout)
    (output / (label + '.stderr.txt')).write_text(run.stderr)
    result['commands'].append({'name': label, 'argv': argv, 'returncode': run.returncode,
        'elapsed_seconds': time.monotonic() - start})
    (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'check': label, 'returncode': run.returncode}), flush=True)
    if run.returncode:
        raise SystemExit('Resulting-main check failed: ' + label)
result['worktree_clean_after_checks'] = not git('status', '--porcelain')
result['pass'] = result['worktree_clean_after_checks']
result['completed_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
(output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'pass': result['pass'], 'revision': head, 'tree': tree}))
if not result['pass']:
    raise SystemExit('Checks changed resulting-main checkout')
