#!/usr/bin/env python3
"""Independent C193 recovery audit of retained bytes; never run native tools."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tarfile

REPO = Path('/workspace/scratch/3be63d9ca584/review-source')
OUT = Path('/workspace/scratch/3be63d9ca584/recovery-evidence')
C193 = REPO / 'docs/engineering/guide-repair-c193'
CONTRACT = REPO / 'docs/language-design/guided-contact-v0.2'
EXTRACT = OUT / 'extracted'
report = {'schema': 'ontokin.c193.recovery-retained-byte-audit/0.1',
          'started_utc': datetime.now(timezone.utc).isoformat(),
          'native_or_receiving_app_executions': 0, 'checks': [], 'archives': []}

def sha_bytes(data):
    return hashlib.sha256(data).hexdigest()

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def read(path):
    return json.loads(path.read_text())

def save(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

def check(name, condition, details=None):
    row = {'check': name, 'passed': bool(condition)}
    if details is not None:
        row['details'] = details
    report['checks'].append(row)
    if not condition:
        raise AssertionError(name)

def git(*args, text=False, check=True):
    return subprocess.run(['git', *args], cwd=REPO, capture_output=True,
                          text=text, check=check)

def verify_archive(archive_path, manifest_path, prefix='', internal=False, extract=False):
    manifest = read(manifest_path)
    check('archive identity: ' + archive_path.name,
          archive_path.stat().st_size == manifest['bytes'] and sha(archive_path) == manifest['sha256'])
    with tarfile.open(archive_path) as archive:
        members = archive.getmembers()
        check('unique regular members: ' + archive_path.name,
              len({m.name for m in members}) == len(members) and all(m.isfile() for m in members))
        excluded = set()
        if internal:
            manifest_name = prefix + 'MANIFEST.json'
            manifest_bytes = archive.extractfile(manifest_name).read()
            check('receiving internal manifest identity', sha_bytes(manifest_bytes) == manifest['manifest_sha256'])
            items = json.loads(manifest_bytes)['files']
            excluded.add(manifest_name)
        else:
            items = manifest['files']
        if isinstance(items, list):
            items = {row['path']: row for row in items}
        expected = {prefix + name: row for name, row in items.items()}
        check('archive complete member inventory: ' + archive_path.name,
              set(expected) == {m.name for m in members} - excluded)
        bad = []
        for name, identity in expected.items():
            data = archive.extractfile(name).read()
            if len(data) != identity['bytes'] or sha_bytes(data) != identity['sha256']:
                bad.append(name)
        check('archive every member identity: ' + archive_path.name, not bad, {'mismatches': bad})
        report['archives'].append({'archive_from_repo': str(archive_path.relative_to(REPO)),
            'manifest_from_repo': str(manifest_path.relative_to(REPO)),
            'sha256': sha(archive_path), 'bytes': archive_path.stat().st_size,
            'verified_payload_files': len(expected), 'all_member_identities_match': True})
        if extract:
            EXTRACT.mkdir(exist_ok=True)
            archive.extractall(EXTRACT, filter='data')

def verify_local_inventory(root, rows, label):
    if isinstance(rows, list):
        rows = {row['path']: row for row in rows}
    mismatches = []
    for name, item in rows.items():
        path = root / name
        if not path.is_file() or path.stat().st_size != item['bytes'] or sha(path) != item['sha256']:
            mismatches.append(name)
    check(label, not mismatches, {'count': len(rows), 'mismatches': mismatches})

def main():
    candidate = git('rev-parse', 'HEAD', text=True).stdout.strip()
    tree = git('rev-parse', 'HEAD^{tree}', text=True).stdout.strip()
    check('exact independent candidate', candidate == 'bc8c0918045248cd3d34c64e40c135fff0eec985'
          and tree == '631034be6fcd5249af753a9852a13f76baf44493')
    check('independent checkout initially clean', not git('status', '--porcelain', text=True).stdout)
    report['candidate_commit'] = candidate
    report['candidate_tree'] = tree
    report['branch'] = git('branch', '--show-current', text=True).stdout.strip()
    remote = git('ls-remote', 'origin', 'refs/heads/main', 'refs/heads/work/c193-guide-repair',
                 'refs/pull/126/head', text=True).stdout
    report['observed_remote_refs'] = {line.split()[1]: line.split()[0] for line in remote.splitlines()}
    report['original_worker_objects_present_locally'] = {
        name: git('cat-file', '-e', name + '^{commit}', check=False).returncode == 0
        for name in ('61d20e9a941b14cea091dc38ed1e43232280ecb5', '8e7123f120e1bfb02c21c26a1e78013ad0813275')}

    verify_archive(C193 / 'native/diagnostics-complete.tar.xz', C193 / 'native/diagnostics-archive.json',
                   'c193-native-diagnostics/')
    verify_archive(C193 / 'native/formal-native-complete.tar.xz', C193 / 'native/formal-native-complete-manifest.json', extract=True)
    verify_archive(C193 / 'native/lifecycle-complete.tar.xz', C193 / 'native/lifecycle-complete-manifest.json', extract=True)
    verify_archive(C193 / 'independent/qualification-evidence.tar.xz', C193 / 'independent/evidence/qualification-archive.json',
                   'c193-independent-qualification/')
    verify_archive(C193 / 'receiving-evidence.tar.xz', C193 / 'evidence/receiving-archive.json',
                   'receiving/', internal=True, extract=True)

    implementation = read(C193 / 'IMPLEMENTATION.json')
    verify_local_inventory(REPO, implementation['files'], 'all eleven adopted implementation modules')
    check('implementation module count', len(implementation['files']) == 11)
    contract = read(CONTRACT / 'CONTRACT-FILES.json')
    verify_local_inventory(CONTRACT, contract['files'], 'all thirteen contract dependencies')

    adoption = CONTRACT / 'ADOPTION.md'
    pins = re.findall(r'\| \[([^\]]+)\]\(([^)]+)\) \| `([0-9a-f]{64})` \|', adoption.read_text())
    adoption_pins = []
    for title, link, expected in pins:
        path = (CONTRACT / link).resolve()
        check('adoption pin: ' + title, sha(path) == expected)
        adoption_pins.append({'title': title, 'path_from_repo': str(path.relative_to(REPO)), 'sha256': expected})
    check('all eight adoption pins parsed', len(pins) == 8)
    formal = EXTRACT / 'c193-native-qualification'
    formal_summary = read(formal / 'formal-builds.json')
    check('retained adoption equals published adoption',
          (formal / 'adoption-receipt.md').read_bytes() == adoption.read_bytes()
          and formal_summary['adoption_sha256'] == sha(adoption))
    adoption_commit = '868949b9641eb96d7f59f5e18adff987f2d51da7'
    adoption_relative = str(adoption.relative_to(REPO))
    adopted = git('show', adoption_commit + ':' + adoption_relative).stdout
    check('adoption bytes at publication commit', adopted == adoption.read_bytes())
    for row in adoption_pins:
        committed = git('show', adoption_commit + ':' + row['path_from_repo']).stdout
        check('adoption publication contains pin: ' + row['title'], sha_bytes(committed) == row['sha256'])
    adoption_timestamp = git('show', '-s', '--format=%cI', adoption_commit, text=True).stdout.strip()
    start = datetime.fromtimestamp(formal_summary['started_unix_s'], timezone.utc)
    check('adoption commit precedes formal build receipt', datetime.fromisoformat(adoption_timestamp) < start)
    report['adoption'] = {'commit': adoption_commit, 'committer_timestamp': adoption_timestamp,
        'formal_builds_started_utc': start.isoformat(), 'sha256': sha(adoption), 'all_eight_pins_match': True,
        'publication_commit_bytes_verified': True,
        'chronology_scope': 'Commit timestamp and retained build receipt compared. Coordinator separately reconciled the remote publication/readback chronology.'}

    frozen = read(C193 / 'independent/frozen/inherited-hashes.json')
    verify_local_inventory(REPO, frozen['files'], 'all 474 frozen historical files')
    mismatches = []
    process = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=REPO, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
    for row in frozen['files']:
        process.stdin.write((frozen['base_commit'] + ':' + row['path'] + '\n').encode()); process.stdin.flush()
        header = process.stdout.readline().decode().strip().split()
        if len(header) != 3 or header[1] != 'blob':
            raise AssertionError('Historical base blob unavailable: ' + row['path'])
        data = process.stdout.read(int(header[2])); process.stdout.read(1)
        if len(data) != row['bytes'] or sha_bytes(data) != row['sha256']:
            mismatches.append(row['path'])
    process.stdin.close(); process.wait()
    check('historical freeze also matches actual C192 base blobs', not mismatches,
          {'base_commit': frozen['base_commit'], 'count': len(frozen['files']), 'mismatches': mismatches})

    replay = read(OUT / 'recorded-replay/summary.json')
    results = read(C193 / 'RESULTS.json')
    check('recorded replay all gates pass without native execution', replay['passed'] and
          replay['formal_build_count'] == replay['retained_native_replay_count'] == 14 and
          replay['fresh_saved_scene_resimulations'] == replay['fresh_native_constructions'] == 0)
    for case, expected in results['cases'].items():
        actual = next(row for row in replay['runs'] if row['id'] == 'ok-' + case + '-1')
        check('published numerical summary exact: ' + case,
              all(actual[key] == value for key, value in expected.items()))
    check('published repeat/route equality exact', replay['repeat_and_route_equality'] == results['repeat_and_route_equality'])
    report['recorded_replay'] = {key: replay[key] for key in (
        'passed', 'formal_build_count', 'retained_native_replay_count', 'fresh_saved_scene_resimulations',
        'fresh_native_constructions', 'maximum_native_sample_mm', 'maximum_continuous_mapping_mm')}

    received = EXTRACT / 'receiving'
    received_summary = read(received / 'summary.json')
    received_result = read(received / 'result.json')
    visual = read(received / 'visual-review.json')
    for name in ('artifact-identities.json', 'dependencies.json', 'input-manifest.json', 'khronos.json',
                 'result.json', 'summary.json', 'three.json', 'visual-review.json'):
        check('receiving published copy exact: ' + name,
              (received / name).read_bytes() == (C193 / 'evidence/receiving' / name).read_bytes())
    identities = read(received / 'artifact-identities.json')
    paths = {row['path']: row for row in identities}
    check('28 unique receiving paths, 11 hashes', len(identities) == len(paths) == 28 and
          len({row['sha256'] for row in identities}) == 11)
    for name, row in paths.items():
        run, filename = Path(name).parts[1:]
        retained = next(item for item in formal_summary['runs'] if item['id'] == run)['artifacts'][filename]
        check('receiving artifact bound to formal build: ' + name,
              row['sha256'] == retained['sha256'] == sha(received / name)
              and row['bytes'] == (received / name).stat().st_size)

    dependencies = read(received / 'dependencies.json')
    old_archive = REPO / 'docs/engineering/guided-contact-c191/qualification-evidence.tar.xz'
    check('receiving dependency archive pin', sha(old_archive) == dependencies['sha256'])
    verify_local_inventory(received, dependencies['files'], 'all 27 receiving dependency/script identities')
    with tarfile.open(old_archive) as archive:
        bad = []
        for row in dependencies['files']:
            if 'unchanged_source' in row:
                data = (REPO / row['unchanged_source']).read_bytes()
            else:
                data = archive.extractfile('evidence/r2/coordinator/receiving/' + row['path']).read()
            if sha_bytes(data) != row['sha256']:
                bad.append(row['path'])
    check('receiving dependencies unchanged from C191 originals', not bad, {'mismatches': bad})

    khronos = read(received / 'khronos.json')
    check('Khronos exact input set', set(khronos) == set(paths))
    for name, row in khronos.items():
        check('Khronos source identity: ' + name, row['sha256'] == paths[name]['sha256'])
    issues = [row['report']['issues'] for row in khronos.values()]
    counts = {label: sum(row[key] for row in issues) for label, key in
              (('errors', 'numErrors'), ('warnings', 'numWarnings'), ('infos', 'numInfos'))}
    check('Khronos reported counts', counts == {'errors': 0, 'warnings': 0, 'infos': 12})
    findings = {name: row['report']['issues']['messages'] for name, row in khronos.items()
                if row['report']['issues']['messages']}
    check('informational findings retained in combined result', findings == received_result['informational_findings'])

    three = read(received / 'three.json')
    check('Three.js retained success and coverage', three['pass'] and len(three['reports']) == 28
          and {row['path'] for row in three['reports']} == set(paths))
    check('Three.js input hashes and all 84 poses', all(row['sha256'] == paths[row['path']]['sha256']
          and len(row['poses']) == 3 and row['duration'] == 2 for row in three['reports']))
    blender = read(received / 'renders/receipt.json')
    check('Blender identity and CPU scope', blender['blender_executable_sha256'] ==
          '5e15447670804c855fef6033ac9b8fd82696b762095becf0df79b1c2f8034397'
          and blender['script_sha256'] == sha(received / 'tools/render_frames.py')
          and blender['device'] == 'CPU' and not blender['browser_capture'])
    check('six distinct Blender final imports', len(blender['jobs']) == 6 and
          {row['label'] for row in blender['jobs']} == {'ok-' + c + '-1' for c in 'ABCDEF'})
    frames = []
    for job in blender['jobs']:
        label = job['label']
        check('Blender retained per-job receipt exact: ' + label,
              job == read(received / 'renders' / label / 'receipt.json'))
        check('Blender input and geometry: ' + label,
              job['input_sha256'] == paths['deliveries/' + label + '/final.glb']['sha256']
              and job['mesh_count'] == 7 and job['all_sampled_imports_match_glb'] and len(job['frames']) == 3)
        for frame in job['frames']:
            png = received / 'renders' / label / frame['png']
            check('Blender rendered frame identity: ' + label + '/' + frame['png'],
                  png.stat().st_size == frame['png_bytes'] and sha(png) == frame['png_sha256'])
            expected, actual = frame['expected_glb_world_bounds_m'], frame['imported_world_bounds_gltf_m']
            error = max(abs(expected[name][i][j] - actual[name][i][j])
                        for name in expected for i in (0, 1) for j in (0, 1, 2))
            check('Blender decoded/imported bound agreement: ' + label + '/' + frame['png'],
                  error <= blender['import_vs_glb_bounds_tolerance_m'])
            frames.append({'path': str(png.relative_to(received)), 'sha256': sha(png),
                           'decoded_imported_max_error_m': error})
    check('eighteen original renders covered by visual receipt', len(frames) == 18 and
          {row['path']: row['sha256'] for row in frames} == {row['path']: row['sha256'] for row in visual['panels']})
    for label, command in received_summary['commands'].items():
        check('receiving execution receipt successful and exact: ' + label,
              command == read(received / 'commands' / (label + '.json')) and
              command['completed'] and command['returncode'] == 0 and command['pass'])
    check('visual and combined receipts complete', visual['pass'] and received_result['pass'] and
          not received_result['visual_review_pending'] and received_result['visual_review_sha256'] == sha(received / 'visual-review.json'))
    report['receiving'] = {'paths': 28, 'distinct_glb_hashes': 11, 'khronos': counts,
        'three_poses': 84, 'blender_imports': 6, 'rendered_frames': 18,
        'all_input_and_png_hashes_match': True, 'maximum_imported_bound_error_m':
        max(row['decoded_imported_max_error_m'] for row in frames),
        'actual_render_threads': blender['threads'], 'archived_execution_summary_retains_visual_pending':
        received_summary['visual_review_pending'], 'subsequent_visual_review_completed': visual['pass'],
        'originals': frames}
    check('independent checkout remains clean', not git('status', '--porcelain', text=True).stdout)

try:
    main()
except Exception as error:
    report['exception'] = type(error).__name__ + ': ' + str(error)
    raise
finally:
    report['completed_utc'] = datetime.now(timezone.utc).isoformat()
    report['passed'] = 'exception' not in report and all(row['passed'] for row in report['checks'])
    save(OUT / 'retained-byte-audit.json', report)
    print(json.dumps({'passed': report['passed'], 'checks': len(report['checks']),
                      'archives': len(report['archives']), 'report': str(OUT / 'retained-byte-audit.json')}), flush=True)
