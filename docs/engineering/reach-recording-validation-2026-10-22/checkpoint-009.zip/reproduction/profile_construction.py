"""Read-only construction accounting under the unchanged real source limits."""
import collections
import functools
import json
from pathlib import Path
import sys
import time
import traceback

root, output = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
sys.path.insert(0, str(root))
from tools.reach_delivery_inventory import snapshot, source_files, utc
from ontokin.bundle import load_file_manifest
from ontokin.construction import ConstructionBudget, ConstructionCompiler, compile_construction
from ontokin.validator import Validator
from ontokin import construction, reach_source

output.mkdir(parents=True, exist_ok=False)
before = snapshot()
(output / 'inputs-before.json').write_text(json.dumps(before, indent=2) + '\n')
report = {'diagnostic': True, 'source_commit': before['git']['commit'],
          'started_at': utc(), 'max_operations': 100000, 'level': 'constructed', 'cases': []}

for case in sys.argv[3:]:
    budget_seen = None
    compiler = None
    stack = []
    originals = []
    callers = collections.Counter()
    charged_nodes = collections.Counter()
    expression_nodes = collections.defaultdict(lambda: {'calls': 0, 'operations': 0, 'exclusive': 0})
    binding_fields = collections.defaultdict(lambda: {'calls': 0, 'operations': 0, 'exclusive': 0})
    stats = collections.defaultdict(lambda: {'calls': 0, 'operations': 0, 'exclusive': 0})

    def node_key(node):
        return (str(getattr(node, 'source_id', None)), getattr(node, 'start', None),
                getattr(node, 'end', None), str(getattr(node, 'kind', None)))

    original_tick = ConstructionBudget.tick

    def measured_tick(self, node=None, amount=1):
        global budget_seen
        budget_seen = self
        frame = sys._getframe(1)
        ancestry = []
        while frame is not None and len(ancestry) < 5:
            if frame.f_code.co_name != 'measured':
                ancestry.append(Path(frame.f_code.co_filename).name + ':' +
                                frame.f_code.co_name + ':' + str(frame.f_lineno))
            frame = frame.f_back
        callers[' <- '.join(ancestry)] += amount
        charged_nodes[node_key(node)] += amount
        return original_tick(self, node, amount)

    def wrap(owner, name):
        if not hasattr(owner, name):
            return
        original = getattr(owner, name)
        label = getattr(owner, '__name__', type(owner).__name__) + '.' + name

        @functools.wraps(original)
        def measured(*args, **kwargs):
            start = budget_seen.operations if budget_seen is not None else 0
            entry = [0]
            stack.append(entry)
            try:
                return original(*args, **kwargs)
            finally:
                amount = (budget_seen.operations if budget_seen is not None else 0) - start
                stack.pop()
                exclusive = amount - entry[0]
                targets = [stats[label]]
                if owner is ConstructionCompiler and name == 'expression':
                    targets.append(expression_nodes[(*node_key(args[1]), bool(args[2].abstract))])
                if owner is ConstructionCompiler and name == 'guarded':
                    targets.append(binding_fields[str(args[1][-1])])
                for target in targets:
                    target['calls'] += 1
                    target['operations'] += amount
                    target['exclusive'] += exclusive
                if stack:
                    stack[-1][0] += amount

        originals.append((owner, name, original))
        setattr(owner, name, measured)

    ConstructionBudget.tick = measured_tick
    for name in ('bind', 'check_static_types', '_ensure_collection', 'scene_fields', 'resolve_objects',
                 'action_value', 'assertions', 'relation_validation', 'event_blocks', '_attach_provenance',
                 'run', '_register_tree', 'expression', 'name', 'member', 'guarded', 'invoke',
                 'builtin', 'expect', 'parse_type', 'class_reference', 'effective', 'assignments',
                 '_constant_names', '_mark_generated', '_inherit_value_info'):
        wrap(ConstructionCompiler, name)
    for name in ('expression', 'builtin', 'field', 'default_field', 'resolve_site', 'resolve_joint',
                 'resolve_follow', 'unit_axis'):
        wrap(Validator, name)
    wrap(construction, '_materialize_reach_surface')
    wrap(reach_source, 'bind_reaches')
    wrap(ConstructionBudget, 'charge_value')

    started = time.monotonic()
    row = {'case_id': case, 'started_at': utc()}
    try:
        compiler = compile_construction(load_file_manifest(root / source_files(case)), level='constructed')
        row.update(status='passed', constructed_operations=compiler.budget.operations,
                   value_entries=compiler.budget.value_entries,
                   budget=compiler.budget.report(), reach_work=compiler.reach_work.record())
    except Exception as error:
        row.update(status='failed', error=str(error), traceback=traceback.format_exc())
    finally:
        ConstructionBudget.tick = original_tick
        for owner, name, original in reversed(originals):
            setattr(owner, name, original)
    row.update(elapsed_seconds=time.monotonic() - started, finished_at=utc(), stats=dict(stats),
               charge_callers=callers.most_common(),
               charged_nodes=[{'node': key, 'operations': value} for key, value in charged_nodes.most_common()],
               expression_nodes=sorted(({'node': key, **value} for key, value in expression_nodes.items()),
                                       key=lambda item: item['operations'], reverse=True),
               binding_fields=sorted(({'field': key, **value} for key, value in binding_fields.items()),
                                     key=lambda item: item['operations'], reverse=True))
    report['cases'].append(row)
    (output / (case + '.json')).write_text(json.dumps(row, indent=2) + '\n')
    print(case, row['status'], row.get('constructed_operations'), flush=True)

after = snapshot()
(output / 'inputs-after.json').write_text(json.dumps(after, indent=2) + '\n')
report.update(inputs_stable=before == after, finished_at=utc())
(output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
