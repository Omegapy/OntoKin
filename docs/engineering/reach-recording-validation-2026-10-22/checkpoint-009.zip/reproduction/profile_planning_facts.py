"""Diagnostic stage and caller accounting; retains the real request limits."""
import collections
from fractions import Fraction
import functools
import json
from pathlib import Path
import sys
import time
import traceback

root, output = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
sys.path.insert(0, str(root))
from tools.reach_delivery_inventory import snapshot, settings, source_files, utc
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.gltf import export_glb
from ontokin.scene import ExportOptions
from ontokin import reach_export as producer, reach_conformance as reader, reach_reference as reference
from ontokin.reach_numeric import ReachExecutionWork
from ontokin import reach_runtime, reach_phase, reach_projection, evaluator, reach_pose

output.mkdir(parents=True, exist_ok=False)
before = snapshot()
(output / 'inputs-before.json').write_text(json.dumps(before, indent=2)+'\n')
report = {'diagnostic': True, 'source_commit': before['git']['commit'],
          'started_at': utc(), 'max_operations': 100000, 'cases': []}
for case in sys.argv[3:]:
    compiler = None
    stats = collections.defaultdict(lambda: {'calls': 0, 'operations': 0, 'exclusive': 0})
    stack = []
    callers = collections.Counter()
    originals = []
    exclusive_work_counts = collections.defaultdict(collections.Counter)
    event_calls = []
    finite_calls = collections.Counter()
    finite_values = collections.defaultdict(set)
    finite_poses = collections.defaultdict(dict)
    witness_calls = collections.Counter()
    witness_values = collections.defaultdict(set)
    def wrap(owner, name):
        if not hasattr(owner, name):
            return
        original = getattr(owner, name)
        label = getattr(owner, '__name__', type(owner).__name__) + '.' + name
        @functools.wraps(original)
        def measured(*args, **kwargs):
            start = compiler.budget.operations if compiler else 0
            entry = [0, label]
            stack.append(entry)
            try:
                result = original(*args, **kwargs)
                stage = stack[0][1]
                if owner is reach_pose.ReachPoseOps and name == 'ensure_finite':
                    finite_calls[stage] += 1
                    pose = args[1]
                    if type(pose) is reach_pose.PoseValue:
                        finite_poses[stage][id(pose)] = pose
                        parts = (pose.exact_position, pose.rotation.components,
                                 pose.exact_velocity, pose.exact_omega)
                        if (all(type(vector) is tuple for vector in parts)
                                and all(type(value) is Fraction for vector in parts for value in vector)):
                            finite_values[stage].add((parts, pose.rotation.error_rad,
                                                     pose.rotation.frozen_projection))
                if owner is reach_phase and name == 'current_recording_angular_witness':
                    witness_calls[stage] += 1
                    if result is not None:
                        witness_values[stage].add((args[2], args[3], result))
                return result
            finally:
                amount = (compiler.budget.operations if compiler else 0)-start
                stack.pop()
                stats[label]['calls'] += 1
                stats[label]['operations'] += amount
                stats[label]['exclusive'] += amount-entry[0]
                if name in ('recording_boundary', 'recording_phase_bounds', '_process_boundary', 'append'):
                    event_calls.append({'function': label,
                        'arguments': [str(value) for value in args if type(value) in (str, int, Fraction)],
                        'start_operations': start, 'end_operations': start + amount,
                        'operations': amount, 'exclusive': amount - entry[0]})
                if stack:
                    stack[-1][0] += amount
        originals.append((owner, name, original))
        setattr(owner, name, measured)
    for name in ('reach_prefix_plan', '_sample_recording_nodes', 'interval_certificates',
                 '_certificate_quantities', 'reach_timeline'):
        wrap(producer, name)
    for name in ('validate_reach_export', '_phase_tables', '_key_comparisons', '_geometry_bounds',
                 '_assert_projection', '_certified_stored_arc', '_recording_orientation_bound',
                 '_recording_position_bound'):
        wrap(reader, name)
    for name in ('add', 'flush'):
        wrap(reader._CertificateBatch, name)
    for name in ('build_reference',):
        wrap(reference, name)
    for name in ('_pose_map', '_phase', '_phase_root_poses', '_root_pose',
                 'recording_pose_enclosures', 'recording_stationary_frames'):
        wrap(reference.ReachReference, name)
    for name in ('recording_phase_bounds',):
        wrap(producer, name)
    for name in ('reach_record_bound',):
        wrap(reach_projection, name)
        wrap(reach_runtime, name)
    wrap(evaluator, '_records_per_sample')
    wrap(reach_runtime, '_boundary_history_weight')
    wrap(reach_runtime._BoundaryHistoryPreflight, 'append')
    for name in ('__init__', 'advance', '_next_boundary', '_resolve_kinematics',
                 '_kinematics', '_tip_base', '_world_target', '_physical_observation',
                 '_current', '_reach_map', '_validate_staged', '_process_boundary',
                 'recording_boundary', '_bounded_projection', '_pair', '_latch',
                 '_terminal_static_kinematics', '_snapshot_data'):
        wrap(reach_runtime.ReachSimulator, name)
    for name in ('ensure_finite',):
        wrap(reach_pose.ReachPoseOps, name)
    for name in ('phase_bounds', 'current_recording_angular_witness', 'joint_phase'):
        wrap(reach_phase, name)
    charge = ReachExecutionWork.charge
    def counted(self, kind='checkpoint', amount=1):
        if stack:
            exclusive_work_counts[stack[-1][1]][kind] += amount
        if kind == 'checkpoint':
            f = sys._getframe(1)
            if f.f_code.co_name == 'tick':
                f = f.f_back
            parts = []
            for _ in range(3):
                if f is None:
                    break
                parts.append(Path(f.f_code.co_filename).name+':'+f.f_code.co_name+':'+str(f.f_lineno))
                f = f.f_back
            callers[' <- '.join(parts)] += amount
        return charge(self, kind, amount)
    ReachExecutionWork.charge = counted
    row = {'case_id': case, 'started_at': utc()}
    started = time.monotonic()
    try:
        compiler = compile_construction(load_file_manifest(root / source_files(case)), level='constructed')
        row['constructed_operations'] = compiler.budget.operations
        options = settings(case)
        options['end'] = Fraction(options['end'])
        result = export_glb(compiler.model, options=ExportOptions(**options),
                            target_contract='ontokin.glb/0.6', work=compiler.reach_work)
        row['status'] = 'passed'
    except Exception as error:
        row.update(status='failed', error=str(error), traceback=traceback.format_exc())
    finally:
        ReachExecutionWork.charge = charge
        for owner, name, original in reversed(originals):
            setattr(owner, name, original)
    row.update(elapsed_seconds=time.monotonic()-started, stats=dict(stats),
               checkpoint_callers=callers.most_common(), operations=compiler.budget.operations if compiler else None,
               work=compiler.reach_work.record() if compiler else None, finished_at=utc(),
               exclusive_work_counts={key: dict(value) for key, value in exclusive_work_counts.items()},
               event_calls=event_calls,
               finiteness={stage: {'calls': count, 'unique_pose_identities': len(finite_poses[stage]),
                                  'unique_exact_values': len(finite_values[stage])}
                           for stage, count in finite_calls.items()},
               witnesses={stage: {'calls': count, 'unique_values': len(witness_values[stage])}
                          for stage, count in witness_calls.items()})
    report['cases'].append(row)
    (output / (case+'.json')).write_text(json.dumps(row, indent=2)+'\n')
    print(case, row['status'], row['operations'], 'construction', row.get('constructed_operations'), flush=True)
after = snapshot()
(output / 'inputs-after.json').write_text(json.dumps(after, indent=2)+'\n')
report.update(inputs_stable=before==after, finished_at=utc())
(output / 'report.json').write_text(json.dumps(report, indent=2)+'\n')
