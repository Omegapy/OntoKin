"""Diagnostic stage and caller accounting; retains the real request limits."""
import collections
from fractions import Fraction
import functools
import json
from pathlib import Path
import sys
import time
import traceback

root, output = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
sys.path.insert(0, str(root))
from tools.reach_delivery_inventory import snapshot, settings, source_files, utc
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.gltf import export_glb
from ontokin.scene import ExportOptions
from ontokin import reach_export as producer, reach_conformance as reader, reach_reference as reference
from ontokin.reach_numeric import ReachExecutionWork

output.mkdir(parents=True, exist_ok=False)
before = snapshot()
(output / 'inputs-before.json').write_text(json.dumps(before, indent=2)+'\n')
report = {'diagnostic': True, 'source_commit': before['git']['commit'],
          'started_at': utc(), 'max_operations': 100000, 'cases': []}
for case in sys.argv[3:]:
    compiler = None
    stats = collections.defaultdict(lambda: {'calls': 0, 'operations': 0, 'exclusive': 0})
    stack = []
    callers = collections.Counter()
    originals = []
    def wrap(owner, name):
        if not hasattr(owner, name):
            return
        original = getattr(owner, name)
        label = getattr(owner, '__name__', type(owner).__name__) + '.' + name
        @functools.wraps(original)
        def measured(*args, **kwargs):
            start = compiler.budget.operations if compiler else 0
            entry = [0]
            stack.append(entry)
            try:
                return original(*args, **kwargs)
            finally:
                amount = (compiler.budget.operations if compiler else 0)-start
                stack.pop()
                stats[label]['calls'] += 1
                stats[label]['operations'] += amount
                stats[label]['exclusive'] += amount-entry[0]
                if stack:
                    stack[-1][0] += amount
        originals.append((owner, name, original))
        setattr(owner, name, measured)
    for name in ('reach_prefix_plan', '_sample_recording_nodes', 'interval_certificates',
                 '_certificate_quantities', 'reach_timeline'):
        wrap(producer, name)
    for name in ('validate_reach_export', '_phase_tables', '_key_comparisons', '_geometry_bounds',
                 '_assert_projection', '_certified_stored_arc', '_recording_orientation_bound',
                 '_recording_position_bound'):
        wrap(reader, name)
    for name in ('add', 'flush'):
        wrap(reader._CertificateBatch, name)
    for name in ('build_reference',):
        wrap(reference, name)
    for name in ('_pose_map', '_phase', '_phase_root_poses', '_root_pose',
                 'recording_pose_enclosures', 'recording_stationary_frames'):
        wrap(reference.ReachReference, name)
    charge = ReachExecutionWork.charge
    def counted(self, kind='checkpoint', amount=1):
        if kind == 'checkpoint':
            f = sys._getframe(1)
            if f.f_code.co_name == 'tick':
                f = f.f_back
            parts = []
            for _ in range(3):
                if f is None:
                    break
                parts.append(Path(f.f_code.co_filename).name+':'+f.f_code.co_name+':'+str(f.f_lineno))
                f = f.f_back
            callers[' <- '.join(parts)] += amount
        return charge(self, kind, amount)
    ReachExecutionWork.charge = counted
    row = {'case_id': case, 'started_at': utc()}
    started = time.monotonic()
    try:
        compiler = compile_construction(load_file_manifest(root / source_files(case)), level='constructed')
        row['constructed_operations'] = compiler.budget.operations
        options = settings(case)
        options['end'] = Fraction(options['end'])
        result = export_glb(compiler.model, options=ExportOptions(**options),
                            target_contract='ontokin.glb/0.6', work=compiler.reach_work)
        row['status'] = 'passed'
    except Exception as error:
        row.update(status='failed', error=str(error), traceback=traceback.format_exc())
    finally:
        ReachExecutionWork.charge = charge
        for owner, name, original in reversed(originals):
            setattr(owner, name, original)
    row.update(elapsed_seconds=time.monotonic()-started, stats=dict(stats),
               checkpoint_callers=callers.most_common(), operations=compiler.budget.operations if compiler else None,
               work=compiler.reach_work.record() if compiler else None, finished_at=utc())
    report['cases'].append(row)
    (output / (case+'.json')).write_text(json.dumps(row, indent=2)+'\n')
    print(case, row['status'], row['operations'], 'construction', row.get('constructed_operations'), flush=True)
after = snapshot()
(output / 'inputs-after.json').write_text(json.dumps(after, indent=2)+'\n')
report.update(inputs_stable=before==after, finished_at=utc())
(output / 'report.json').write_text(json.dumps(report, indent=2)+'\n')
