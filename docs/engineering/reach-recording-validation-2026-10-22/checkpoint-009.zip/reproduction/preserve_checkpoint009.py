"""Preserve the identified 22/28 continuation and its complete local evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

base = Path('/workspace/scratch/7fb5bc518974')
root, evidence = base / 'OntoKin', base / 'evidence'
out = root / 'docs/engineering/reach-recording-validation-2026-10-22'
baseline = '25960271dc35fb6391f314a96ba0c6cef61bc162'
def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])
def read(path):
    return json.loads(path.read_text())
def encode(value):
    return (json.dumps(value, indent=2) + '\n').encode()
def sha(raw):
    return hashlib.sha256(raw).hexdigest()

source = read(evidence / 'integrated-source004/report.json')
focused = read(evidence / 'integrated-focused005/report.json')
head = git('rev-parse', 'HEAD').decode().strip()
assert source['source_commit'] == focused['source_commit'] == head
assert source['inputs_stable'] and focused['inputs_stable']
assert focused['status'] == 'passed' and focused['raw_log_complete'] and focused['executed_ids_complete']
assert not git('status', '--porcelain=v1', '--untracked-files=all').strip()
older = {p.name: sha(p.read_bytes()) for p in out.glob('checkpoint-00[1-8]*') if p.is_file()}
folders = ('integrated-source003', 'integrated-source004', 'integrated-focused004',
    'integrated-phase001', 'integrated-focused005', 'orientation-claims002',
    'finite-focused001', 'finite-focused002', 'profile-finite001',
    'captured-phase-focused001', 'captured-phase-focused002', 'captured-phase-source001',
    'captured-chain-focused001', 'captured-chain-source001',
    'certificate-coefficients001', 'certificate-coefficients002',
    'profile-integrated002', 'profile-construction001')
members = {}
for name in folders:
    folder = evidence / name
    assert folder.is_dir(), name
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            assert not path.is_symlink() and path.suffix != '.zip'
            members['execution/' + path.relative_to(evidence).as_posix()] = path.read_bytes()
    console = evidence / (name + '.console.log')
    if console.is_file():
        members['execution/' + console.name] = console.read_bytes()
for name in ('run_focused_buffered.py', 'profile_pipeline.py', 'profile_planning_facts.py',
             'profile_construction.py', 'preserve_checkpoint009.py',
             'checkpoint008-documentation-reconciliation.json',
             'publication008-remote.json', 'publication008-receipt.json', 'publication008-tree.json'):
    members['reproduction/' + name] = (evidence / name).read_bytes()
limitations = {
    'earlier_coefficient_test_failure': 'certificate-coefficients001 ran81 with one new test-setup failure: its allocation trap intercepted fixture construction. The unchanged fixture was moved before the trap; certificate-coefficients002 passes81/81. Production code was unchanged by that correction.',
    'earlier_selection_typo': 'integrated-focused004 selected175 methods. Its phase glob matched no phase module; integrated-phase001 separately executed all15 phase methods. The current integrated-focused005 names the correct phase and chain modules explicitly.',
    'working_file_observation': 'During checkpoint008 publication one working documentation-result file was observed empty while its committed blob remained intact. The intended committed blob was used, exact tree equality was verified before publication, and the working file was restored. Cause is unidentified; reconciliation evidence is included.',
    'profiles': 'Diagnostic wrappers preserve actual work limits; only separately executed source requests establish source recording results.',
    'acceptance': 'Selected focused checks do not replace full regression, compatibility, Agent delivery, independent destination/browser/visual or release acceptance.',
}
members['reproduction/evidence-limitations.json'] = encode(limitations)
commits = {baseline, head}
def source_ids(value):
    if isinstance(value, dict):
        for name, item in value.items():
            if name in ('source_commit', 'commit') and type(item) is str and len(item) == 40:
                try:
                    if git('cat-file', '-t', item).strip() == b'commit':
                        commits.add(item)
                except subprocess.CalledProcessError:
                    pass
            elif isinstance(item, (dict, list)):
                source_ids(item)
    elif isinstance(value, list):
        for item in value:
            source_ids(item)
for name, raw in tuple(members.items()):
    if name.endswith('.json'):
        source_ids(json.loads(raw))
commits.update(git('rev-list', baseline + '..' + head).decode().splitlines())
members['source/changes-from-2596027.patch'] = git('diff', '--binary', baseline, head)
for commit in sorted(commits):
    members['source/commits/' + commit + '.txt'] = git('cat-file', 'commit', commit)
    if commit not in (baseline, head):
        members['source/scoped-inputs/' + commit + '.patch'] = git('diff', '--binary', baseline, commit,
                                                                '--', 'ontokin', 'tests', 'tools')
integrity = []
for folder in folders:
    for report_path in sorted((evidence / folder).rglob('report.json')):
        for row in read(report_path).get('deliveries', []):
            for role in ('artifact', 'export_report'):
                if role in row:
                    item = row[role]
                    raw = (report_path.parent / item['path']).read_bytes()
                    assert item['bytes'] == len(raw) and item['sha256'] == 'sha256:' + sha(raw)
                    integrity.append({'run': folder, 'case_id': row['case_id'], 'role': role, **item})
members['reproduction/artifact-integrity.json'] = encode({'status': 'passed', 'members': integrity})
archive = out / 'checkpoint-009.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, raw in sorted(members.items()):
        bundle.writestr(name, raw)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert len(bundle.namelist()) == len(set(bundle.namelist())) == len(members)
    for name, raw in members.items():
        assert bundle.read(name) == raw
manifest = {'schema_version': 'ontokin.checkpoint-archive/0.1', 'archive': archive.name,
    'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()), 'member_count': len(members),
    'members': [{'path': name, 'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(members.items())]}
(out / 'checkpoint-009.manifest.json').write_bytes(encode(manifest))
rows = [{key: row[key] for key in ('case_id', 'status', 'operations')} for row in source['deliveries']]
passed = sum(row['status'] == 'passed' for row in rows)
failed = [row['case_id'] for row in rows if row['status'] != 'passed']
assert len(rows) == 28 and passed == 22
now = datetime.now(timezone.utc).isoformat()
checkpoint = {'schema_version': 'ontokin.reach-development-checkpoint/0.1', 'recorded_at': now,
    'baseline': baseline, 'source_commit': head, 'source_tree': source['source_tree'],
    'full_source': {'status': source['status'], 'inputs_stable': source['inputs_stable'],
        'started_at': source['started_at'], 'finished_at': source['finished_at'], 'passed': passed,
        'total': len(rows), 'max_operations': 100000, 'cases': rows,
        'report_sha256': sha((evidence / 'integrated-source004/report.json').read_bytes())},
    'focused': {key: focused[key] for key in ('status', 'tests', 'failures', 'errors', 'skipped',
        'inputs_stable', 'elapsed_seconds', 'raw_log_complete', 'executed_ids_complete')},
    'archive': {key: manifest[key] for key in ('archive', 'bytes', 'sha256', 'member_count')},
    'artifacts_hash_verified': len(integrity), 'remaining_recordings': failed,
    'limitations': limitations, 'release_acceptance': False, 'full_product_goal_completed': False,
    'main_unchanged': '2bb4588e121fcfe99b4d42c734b15b38362f3642', 'pr': 27, 'pr_draft': True,
    'pending_roles': ['28/28 source recordings', '10 Agent artifacts', 'complete current regression and compatibility',
        'independent rate verification', 'native and browser destination checks', 'fresh image review',
        'hostile input and inherited gates', 'R01-R12/Q01-Q22 release audit', 'resulting-main verification']}
(out / 'checkpoint-009.json').write_bytes(encode(checkpoint))
counts = {row['case_id']: row['operations'] for row in rows}
section = f'''## Latest checkpoint 009: {focused['tests']} focused tests; 22/28 source recordings

Tested implementation `{head}`, tree `{source['source_tree']}`,
passes **22/28** source recordings at the unchanged **100,000-operation** limit.
The complete run finished **{source['finished_at']}** with stable tracked inputs.
P20 now passes at **{counts['P20']:,} operations** and L01 at **{counts['L01']:,}**;
L02 uses **{counts['L02']:,}**. Remaining failures: **{', '.join(failed)}**.

The same source passes **{focused['tests']}/{focused['tests']} focused methods**, no failures,
errors or skips, in **{focused['elapsed_seconds']:.3f} seconds**. Complete raw logs,
executed method IDs, environment and before/after input inventories are preserved.
This is selected correctness coverage; full regression and compatibility are pending.

Complete captured phase streams now cover static and varying-parent scalar/Z
chains, retain native composition order, and publish bounded cursors only after
final source/topology/claim admission. Other changes reuse complete graph finiteness
proofs, preserve orientation bounds across changed claims, and avoid repeated
intrinsic coefficient decoding while retaining every actual arithmetic guard.
Frozen inputs, trajectories, tolerances and public work/cache limits are unchanged.

[checkpoint-009.zip](checkpoint-009.zip) contains **{len(members)} raw members**,
**{manifest['bytes']:,} bytes**, SHA-256 `{manifest['sha256']}`.
Its [manifest](checkpoint-009.manifest.json) and [checkpoint](checkpoint-009.json)
identify exact source, every run and limitations. All **{len(integrity)} artifact/report
hashes**, archive members and ZIP CRC passed. Earlier evidence is unchanged.
The new coefficient test's setup failure, earlier selection typo and checkpoint008
working-file observation retain their separate evidence and precise limits.

The next gate remains **28/28**. Continue the six budget failures, then execute
Agent delivery, full regression/compatibility, independent verification,
destination/browser/visual checks, inherited/hostile roles and complete release audits.
**Do not merge.** PR #27 remains draft; main is unchanged at
`2bb4588e121fcfe99b4d42c734b15b38362f3642`. No main lease or hosted job is claimed.
The complete GOAL remains open. Runtime, tests and archive creation stay serialized.

'''
readme = out / 'README.md'
text = readme.read_text().replace('The latest complete run passes **20/28**;',
                                'The latest complete run passes **22/28**;', 1)
assert '## Latest checkpoint 008:' in text
readme.write_text(text.replace('## Latest checkpoint 008:', section + '## Preserved checkpoint 008:', 1))
status = root / 'STATUS.md'
text = status.read_text()
start = text.index('Latest tested recording implementation is')
end = text.index('The historical rows below retain their original cuts and limits.', start)
replacement = f'''Latest tested recording implementation is `{head}`,
tree `{source['source_tree']}`. Recovered local checkpoint `e4f51db` is
published at `b1d102a5391721b3e420277526696aca65b11ea5` with its exact tree.
Published checkpoint008 is verified at `{baseline}`.
The newer implementation and results below form checkpoint009.

The [recording checkpoint](docs/engineering/reach-recording-validation-2026-10-22/README.md)
retains a fresh **22/28** complete source run, finished **{source['finished_at']}**,
with stable inputs and the unchanged **100,000-operation** limit. **P20 now passes
at {counts['P20']:,} operations; L01 passes at {counts['L01']:,}.** L02 uses **{counts['L02']:,}**.
Remaining failures: **{', '.join(failed)}**.

The same source passes **{focused['tests']}/{focused['tests']} focused methods**, with no failures,
errors or skips, complete logs/method IDs and stable inputs. This selected cohort
does not replace full regression or compatibility. Historical cohorts retain their
own source identities. Checkpoint009 preserves **{len(members)} raw members**;
all **{len(integrity)} artifact/report hashes**, member identities and ZIP CRC passed.

Captured phase streams support static and varying-parent planar chains while
retaining native composition order and final source/claim/cursor admission.
Complete graph finiteness and independent orientation bounds reuse completed work;
intrinsic exact coefficients avoid repeated decoding. Every actual arithmetic
operation and live operand/cancellation guard remains. No frozen input, tolerance,
100,000-operation limit or 256-entry cache limit changes.

The immediate target remains **28/28**, followed by Agent delivery, full current
regression/compatibility, independent rates, native/browser and visual checks,
inherited/hostile roles and release audits. PR #27 remains draft; **do not merge**
until every mandatory gate passes. The complete language and GOAL remain open.

'''
text = text[:start] + replacement + text[end:]
first = text.index('Checkpoint: **') + len('Checkpoint: **')
last = text.index('**', first)
status.write_text(text[:first] + now + text[last:])
readme = root / 'README.md'
text = readme.read_text()
text = text.replace('passes **20 of 28 source recordings** within the unchanged **100,000-operation** request limit and **686 focused correctness tests**. Eight recordings',
                    f'passes **22 of 28 source recordings** within the unchanged **100,000-operation** request limit and **{focused["tests"]} focused correctness tests**. Six recordings', 1)
readme.write_text(text)
for name, expected in older.items():
    assert sha((out / name).read_bytes()) == expected
print(json.dumps({key: checkpoint[key] for key in ('source_commit', 'focused', 'archive',
                                                  'remaining_recordings', 'artifacts_hash_verified')}, indent=2))
