"""Observe unchanged-budget reader stage/method work through the official driver."""
from collections import defaultdict
from contextlib import ExitStack, redirect_stderr, redirect_stdout
from functools import wraps
from pathlib import Path
import json
import sys
from unittest.mock import patch

sys.path.insert(0, str(Path.cwd()))

from ontokin import reach_conformance as reader, reach_reference as reference, gltf
from tools.build_reach_source_artifacts import main


def profile(case, output):
    methods, stages, key_rows = defaultdict(lambda: [0, 0, 0]), [], []
    stack, stage_stack = [], []

    def wrap_method(original, name, get_work):
        @wraps(original)
        def observed(*args, **kwargs):
            work = get_work(args, kwargs)
            if work is None:
                return original(*args, **kwargs)
            entry = [work.operations, 0]
            stack.append(entry)
            stage = stage_stack[-1] if stage_stack else "outside_reader_stage"
            try:
                return original(*args, **kwargs)
            finally:
                cost = work.operations - entry[0]
                stack.pop()
                counts = methods[stage + "/" + name]
                counts[0] += 1
                counts[1] += cost
                counts[2] += cost - entry[1]
                if stack:
                    stack[-1][1] += cost
        return observed

    def wrap_stage(original, name, get_work):
        @wraps(original)
        def observed(*args, **kwargs):
            work = get_work(args, kwargs)
            if work is None:
                return original(*args, **kwargs)
            entry = {"stage":name, "started_work":work.operations}
            stages.append(entry)
            stage_stack.append(name)
            try:
                return original(*args, **kwargs)
            finally:
                stage_stack.pop()
                entry["finished_work"] = work.operations
                entry["cost"] = work.operations - entry["started_work"]
        return observed

    def key_wrapper(original):
        @wraps(original)
        def observed(*args, **kwargs):
            work = args[5].work
            row = {"index":args[4], "clock":str(args[3]), "started_work":work.operations,
                   "total_keys":len(next(iter(args[2].values()))["rotation"])}
            key_rows.append(row)
            try:
                result = original(*args, **kwargs)
                row["status"] = "passed"
                return result
            except BaseException:
                row["status"] = "failed"
                raise
            finally:
                row["finished_work"] = work.operations
        return observed

    arithmetic_names = ("exact", "exact_sum", "exact_product", "grid", "add", "sub", "mul", "neg", "div",
                        "point", "sincos", "quaternion", "lookup", "remember", "sqrt")
    pose_names = ("vector", "make", "identity", "constant", "compose", "inverse", "multiply", "rotate",
                  "quaternion", "hinge", "spin", "_normalized_axis", "_recording_sincos",
                  "_recording_body_orientation", "_recording_rotate_sincos")
    source_names = ("_pose_map", "_root_pose", "_prescribed_root_translation", "_coordinate", "_joint_path",
                    "_recording_root_body", "_recording_hinge_body", "_recording_attached_body",
                    "_recording_identity_parent", "_recording_coordinate_recipe", "_incoming", "_ancestry",
                    "recording_stationary_frames", "_source_basis", "_axial_derivatives", "_phase")
    bound_names = ("value", "op", "compare", "total", "root", "norm", "cells", "normalize", "difference", "reuse")
    kwargs_work = lambda args, kwargs: kwargs.get("work")
    source_work = lambda args, kwargs: args[0].a.work
    arithmetic_work = lambda args, kwargs: args[0].work
    with ExitStack() as patches:
        for cls, names, get_work in ((reference._Arithmetic, arithmetic_names, arithmetic_work),
                                    (reference._PoseArithmetic, pose_names, source_work),
                                    (reference.ReachReference, source_names, source_work),
                                    (reader._Bounds, bound_names, arithmetic_work)):
            for name in names:
                if hasattr(cls, name):
                    patches.enter_context(patch.object(cls, name, wrap_method(getattr(cls, name), cls.__name__ + "." + name, get_work)))
        for module, name, get_work in (
                (reader, "validate_reach_export", kwargs_work), (gltf, "read_glb", kwargs_work),
                (reference, "build_reference", kwargs_work), (reader, "_verify_metadata", kwargs_work),
                (reader, "verify_retained_clocks", kwargs_work), (reader, "_geometry_bounds", kwargs_work),
                (reader, "_phase_tables", kwargs_work),
                (reference.ReachReference, "boundary_states", source_work),
                (reference.ReachReference, "point_phase", source_work),
                (reader, "_boundary_allowances", lambda args, kwargs: args[-1].work),
                (reader, "_verify_certificates", kwargs_work)):
            patches.enter_context(patch.object(module, name, wrap_stage(getattr(module, name), name, get_work)))
        patches.enter_context(patch.object(reader, "_key_comparisons", key_wrapper(reader._key_comparisons)))
        argv = ["--case", case, "--output-dir", str(output / case)]
        sys.argv = ["tools/build_reach_source_artifacts.py", *argv]
        with (output / (case + ".txt")).open("w") as log, redirect_stdout(log), redirect_stderr(log):
            result = main(argv)
    record = {"case":case, "observational_only":True, "official_driver_returncode":result,
              "stages":stages, "keys":key_rows,
              "methods":{name:{"calls":values[0], "inclusive_work":values[1], "exclusive_work":values[2]}
                         for name, values in sorted(methods.items())}}
    (output / (case + "-profile.json")).write_text(json.dumps(record, indent=2) + "\n")
    print(case, json.dumps(stages, indent=2))
    print("Top exclusive charged work:")
    for name, values in sorted(methods.items(), key=lambda pair: pair[1][2], reverse=True)[:20]:
        print(name, {"calls":values[0], "inclusive":values[1], "exclusive":values[2]})


output = Path(__file__).resolve().parent
for case in sys.argv[1:] or ("P09", "L03"):
    profile(case, output)
