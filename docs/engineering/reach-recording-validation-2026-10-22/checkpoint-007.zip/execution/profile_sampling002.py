import collections, functools, json, pathlib, platform, sys, time, traceback
root = pathlib.Path('/workspace/scratch/655468d5e44d/sampling')
sys.path.insert(0, str(root))
from ontokin import reach_export, reach_recording_fast
from ontokin.reach_runtime import ReachSimulator
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.gltf import export_glb
from ontokin.scene import ExportOptions
from tools.reach_delivery_inventory import snapshot, source_files, settings, fresh_output, write_json, finish_inputs, utc
from fractions import Fraction
force_sharing = '--force-sharing' in sys.argv
out = fresh_output(pathlib.Path('/workspace/scratch/655468d5e44d/evidence/' +
    ('sampling-profile-p16-share002' if force_sharing else 'sampling-profile-p16-002')))
before = snapshot()
write_json(out / 'inputs-before.json', before)
compiler, active = None, False
stats = collections.defaultdict(lambda: {'calls': 0, 'operations': 0, 'max': 0})
samples, stages = [], []
def attach(target, name, label, *, sample=False, phase=False, path=False):
    original = getattr(target, name)
    @functools.wraps(original)
    def call(*args, **kwargs):
        global active
        if phase:
            active = True
            stages.append({'name': label, 'entry': compiler.budget.operations})
        selected = active
        start = compiler.budget.operations if compiler is not None else 0
        counts = dict(compiler.reach_work.counts) if selected and sample else {}
        try:
            return original(*args, **kwargs)
        finally:
            if selected:
                used = compiler.budget.operations - start
                key = label + (':' + str(kwargs.get('path', '')) if path else '')
                row = stats[key]
                row['calls'] += 1
                row['operations'] += used
                row['max'] = max(row['max'], used)
                if sample:
                    delta = {k: v - counts.get(k, 0) for k, v in compiler.reach_work.counts.items()
                             if v != counts.get(k, 0)}
                    samples.append({'name': label, 'time': str(args[1]), 'operations': used,
                                    'counts': delta})
            if phase:
                stages.append({'name': label, 'exit': compiler.budget.operations})
                active = False
    setattr(target, name, call)
attach(reach_export, '_sample_recording_nodes', 'sampling', phase=True)
attach(reach_recording_fast, '_sample_planar_frames', 'native_sample', sample=True)
attach(ReachSimulator, 'recording_frames', 'original_sample', sample=True)
attach(ReachSimulator, '_resolve_kinematics', 'pose_graph')
for name in ('recording_dynamic_pose', 'recording_affine', '_ballistic_position', '_ballistic_law',
             'recording_body_orientation', 'compose_recording_fast', '_axis_rotation',
             '_rotated_offset', '_product', '_project_rotation', '_affine_axis_rotation',
             'recording_constant_pose', 'make_recording', 'recording_relative_pose'):
    attach(reach_recording_fast.Binary64RecordingOps, name, name)
attach(reach_recording_fast.Binary64RecordingOps, 'recording_advance_orientation',
       'recording_advance_orientation', path=True)
if force_sharing:
    original_init = reach_recording_fast.Binary64RecordingOps.__init__
    def force_init(self, *args, **kwargs):
        kwargs['share_arithmetic'] = True
        return original_init(self, *args, **kwargs)
    reach_recording_fast.Binary64RecordingOps.__init__ = force_init
report = {'case': 'P16', 'diagnostic': True, 'source_commit': before['git']['commit'],
          'source_tree': before['git']['tree'], 'started_at': utc(),
          'command': [sys.executable, *sys.argv], 'working_directory': str(root),
          'environment': {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform()},
          'release_acceptance': False, 'force_sharing': force_sharing}
try:
    compiler = compile_construction(load_file_manifest(root / source_files('P16')), level='constructed')
    report['constructed_operations'] = compiler.budget.operations
    opts = settings('P16')
    opts['end'] = Fraction(opts['end'])
    export_glb(compiler.model, options=ExportOptions(**opts), target_contract='ontokin.glb/0.6', work=compiler.reach_work)
    report['status'] = 'passed'
except Exception as error:
    report.update(status='failed', error=str(error), traceback=traceback.format_exc())
report.update(stats=dict(stats), stages=stages, operations=compiler.budget.operations,
              work=compiler.reach_work.record(), finished_at=utc())
write_json(out / 'sampling-keys.json', samples)
finish_inputs(out, before, report)
write_json(out / 'report.json', report)
print(json.dumps({key: report[key] for key in ['case', 'status', 'operations', 'stages', 'stats', 'inputs_stable']}, indent=2))
