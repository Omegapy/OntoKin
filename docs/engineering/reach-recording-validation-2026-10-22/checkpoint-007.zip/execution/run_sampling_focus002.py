import contextlib, json, pathlib, platform, sys, time, unittest
root = pathlib.Path('/workspace/scratch/655468d5e44d/sampling')
sys.path[:0] = [str(root), str(root / 'tests')]
from tools.reach_delivery_inventory import snapshot, write_json, fresh_output, finish_inputs, utc, descriptor
from ontokin.construction_conformance import _run_tests
out = fresh_output(pathlib.Path('/workspace/scratch/655468d5e44d/evidence/sampling-focused002'))
modules = [
    'test_reach_recording_relative_native_reuse',
    'test_reach_recording_affine',
    'test_reach_recording_graph_sharing',
    'test_reach_recording_native_body',
    'test_reach_recording_native_recovery',
    'test_reach_recording_child_origin',
    'test_reach_recording_source_admission',
    'test_reach_recording_exact_seed_reuse',
    'test_reach_recording_captured_seed',
    'test_reach_recording_body_cursor',
    'test_reach_sampling_factor_reuse',
]
loader = unittest.TestLoader()
suite = loader.loadTestsFromNames(modules)
def names(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from names(item)
        else:
            yield item.id()
ids = list(names(suite))
write_json(out / 'test-inventory.json', {'modules': modules, 'test_ids': ids, 'loader_errors': loader.errors})
before = snapshot()
write_json(out / 'inputs-before.json', before)
report = {'status': 'running', 'source_commit': before['git']['commit'],
          'source_tree': before['git']['tree'], 'command': [sys.executable, *sys.argv],
          'started_at': utc(), 'environment': {'python': sys.version, 'executable': sys.executable,
          'platform': platform.platform()}, 'working_directory': str(root), 'release_acceptance': False}
start = time.monotonic()
with (out / 'execution.log').open('x') as stream, contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
    result = _run_tests(ids)
write_json(out / 'test-results.json', result)
report.update(status='passed' if all(r['status'] == 'passed' for r in result['tests']) and not loader.errors else 'failed',
    test_count=len(ids), passed_count=sum(r['status'] == 'passed' for r in result['tests']),
    outcomes=result['outcomes'], nonpassing_test_ids=[r['test_id'] for r in result['tests'] if r['status'] != 'passed'],
    elapsed_seconds=time.monotonic() - start, finished_at=utc())
finish_inputs(out, before, report)
report['members'] = [descriptor(p, relative_to=out) for p in sorted(out.iterdir()) if p.is_file()]
write_json(out / 'report.json', report)
print(json.dumps({k: report[k] for k in ['status', 'test_count', 'passed_count', 'nonpassing_test_ids', 'elapsed_seconds', 'inputs_stable']}))
raise SystemExit(report['status'] != 'passed')
