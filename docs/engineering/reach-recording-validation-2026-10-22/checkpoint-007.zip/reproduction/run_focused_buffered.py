"""Preserve a complete focused-test log in one final atomic file write."""
import contextlib
import fnmatch
import io
import json
import pathlib
import platform
import sys
import time
import unittest

root = pathlib.Path(sys.argv[1]).resolve()
out = pathlib.Path(sys.argv[2]).resolve()
patterns = sys.argv[3:]
sys.path[:0] = [str(root), str(root / 'tests')]
from tools.reach_delivery_inventory import descriptor, finish_inputs, fresh_output, snapshot, utc, write_json

out = fresh_output(out)
before = snapshot()
write_json(out / 'inputs-before.json', before)
files = sorted(p for p in (root / 'tests').glob('test_*.py')
               if any(fnmatch.fnmatch(p.name, pattern) for pattern in patterns))
names = [p.stem for p in files]
write_json(out / 'selection.json', {'patterns': patterns, 'modules': names})
started = time.monotonic()
report = {'started_at': utc(), 'source_commit': before['git']['commit'],
          'source_tree': before['git']['tree'], 'python': sys.version,
          'platform': platform.platform(), 'command': sys.argv, 'release_acceptance': False}

class RecordedResult(unittest.TextTestResult):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.executed_ids = []
        self.success_ids = []
    def startTest(self, test):
        self.executed_ids.append(test.id())
        super().startTest(test)
    def addSuccess(self, test):
        self.success_ids.append(test.id())
        super().addSuccess(test)

stream = io.StringIO()
with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
    suite = unittest.defaultTestLoader.loadTestsFromNames(names)
    result = unittest.TextTestRunner(stream=stream, verbosity=2,
                                    resultclass=RecordedResult).run(suite)
log = stream.getvalue()
pending = out / 'execution.pending'
pending.write_text(log, encoding='utf-8')
pending.replace(out / 'execution.log')
write_json(out / 'executed-tests.json', {'started': result.executed_ids, 'passed': result.success_ids})
report.update(status='passed' if result.wasSuccessful() and not result.skipped else 'failed',
              tests=result.testsRun, failures=len(result.failures), errors=len(result.errors),
              skipped=len(result.skipped), failed_ids=[str(case) for case, trace in result.failures + result.errors],
              elapsed_seconds=time.monotonic() - started, finished_at=utc(),
              raw_log_complete=f'Ran {result.testsRun} tests in ' in log,
              executed_ids_complete=len(result.executed_ids) == result.testsRun)
finish_inputs(out, before, report)
report['members'] = [descriptor(path, relative_to=out) for path in sorted(out.iterdir()) if path.is_file()]
write_json(out / 'report.json', report)
print(json.dumps({k: report[k] for k in ('status', 'tests', 'failures', 'errors', 'skipped',
    'inputs_stable', 'failed_ids', 'raw_log_complete', 'executed_ids_complete', 'elapsed_seconds')}, indent=2), flush=True)
raise SystemExit(0 if report['status'] == 'passed' and report['raw_log_complete'] else 1)
