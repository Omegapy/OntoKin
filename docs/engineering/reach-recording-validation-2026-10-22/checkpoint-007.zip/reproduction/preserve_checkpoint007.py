"""Preserve the next exact recording checkpoint without rewriting earlier evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile
from datetime import datetime, timezone

base = Path('/workspace/scratch/655468d5e44d')
root = base / 'OntoKin'
out = root / 'docs/engineering/reach-recording-validation-2026-10-22'
baseline = 'db745fbd5744624103da1d8c6cf076a719d456a4'

def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])

def read(path):
    return json.loads(path.read_text())

def encode(value):
    return (json.dumps(value, indent=2) + '\n').encode()

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

source = read(base / 'evidence/source005/report.json')
focused = read(base / 'evidence/combined-focused004/report.json')
assert source['inputs_stable'] and focused['inputs_stable']
assert focused['status'] == 'passed' and focused['raw_log_complete'] and focused['executed_ids_complete']
assert source['source_commit'] == focused['source_commit'] == git('rev-parse', 'HEAD').decode().strip()
assert not git('status', '--porcelain=v1', '--untracked-files=all').strip()
earlier = {path.name: sha(path.read_bytes()) for path in out.glob('checkpoint-00[1-6]*') if path.is_file()}

members = {}
folders = (
    'source003', 'source004', 'source005', 'combined-focused002', 'combined-focused003', 'combined-focused004',
    'axis-focused001', 'axis-focused002', 'axis-focused003', 'totals-focused001', 'totals-p20-source001',
    'geometry-focused002', 'geometry-focused003', 'geometry-focused004', 'geometry-p11-source001',
    'reference-focused002', 'reference-profile003', 'reference-profile004', 'reference-arc004',
    'sampling-focused002', 'sampling-focused003', 'sampling-source002',
    'sampling-profile-p16-002', 'sampling-profile-p16-share002',
    'spin-focused001', 'spin-focused002', 'spin-p16-source001',
    'profile-p16-002', 'profile-p09-001', 'profile-l03-001', 'profile-p23-002', 'profile-p23-003',
)
for name in folders:
    folder = base / 'evidence' / name
    assert folder.is_dir(), name
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            members['execution/' + path.relative_to(base / 'evidence').as_posix()] = path.read_bytes()
for name in ('source003.log', 'source004.log', 'source005.log', 'totals-p20-source001.log',
             'checkpoint006-docs.txt', 'profile_sampling002.py', 'run_sampling_focus002.py',
             'run_sampling_focus003.py', 'geometry-focused001/preflight-rejected.json'):
    path = base / 'evidence' / name
    members['execution/' + name] = path.read_bytes()
for name in ('run_focused.py', 'run_focused_buffered.py', 'profile_recording.py',
             'profile_preparation.py', 'profile_planning.py', 'publication006-commit.json',
             'publication006-receipt.json', 'preserve_checkpoint007.py'):
    members['reproduction/' + name] = (base / 'recovery' / name).read_bytes()

limitations = {
    'spin-focused001': {
        'reported_result': '261 passed; tracked before/after identities stable',
        'raw_log_bytes': len(members['execution/spin-focused001/execution.log']),
        'limitation': 'The saved raw log is truncated and is not complete per-test evidence. The report is retained unchanged.',
        'replacement_execution': 'spin-focused002 retains a complete atomically written log and executed/passed test IDs on the same source.',
    },
    'geometry-focused001': {
        'result': 'Clean-checkout preflight rejected before any test executed.',
        'quarantined_zip': read(base / 'evidence/geometry-focused001/preflight-rejected.json'),
        'limitation': 'The unidentified temporary ZIP is retained outside this archive; its recorded bytes and digest identify it. No creator or causal attribution is established.',
    },
    'failed_focused_runs': ['geometry-focused002', 'geometry-focused003', 'axis-focused001',
                            'axis-focused002', 'combined-focused003'],
    'profiles': 'Instrumentation is diagnostic only. Actual source runs separately establish the measured request outcomes.',
    'acceptance': '20/28 is a failed complete source gate. No full current regression, compatibility, Agent, native/browser or release pass is inferred.',
}
members['reproduction/evidence-limitations.json'] = encode(limitations)

# Preserve exact source for every recorded worker and integrated execution.
commits = {baseline, source['source_commit']}
def source_ids(value):
    if isinstance(value, dict):
        for name, item in value.items():
            if name in ('source_commit', 'commit') and type(item) is str and len(item) == 40:
                try:
                    if git('cat-file', '-t', item).strip() == b'commit':
                        commits.add(item)
                except subprocess.CalledProcessError:
                    pass
            elif isinstance(item, (dict, list)):
                source_ids(item)
    elif isinstance(value, list):
        for item in value:
            if isinstance(item, (dict, list)):
                source_ids(item)
for name, raw in tuple(members.items()):
    if name.endswith('.json'):
        source_ids(json.loads(raw))
commits.update(git('rev-list', baseline + '..' + source['source_commit']).decode().splitlines())
members['source/changes-from-db745fb.patch'] = git('diff', '--binary', baseline, source['source_commit'])
for commit in sorted(commits):
    members['source/commits/' + commit + '.txt'] = git('cat-file', 'commit', commit)
    if commit not in (baseline, source['source_commit']):
        members['source/scoped-inputs/' + commit + '.patch'] = git(
            'diff', '--binary', baseline, commit, '--', 'ontokin', 'tests', 'tools')

integrity = []
for folder in folders:
    directory = base / 'evidence' / folder
    for report_path in sorted(directory.rglob('report.json')):
        report = read(report_path)
        for row in report.get('deliveries', []):
            for role in ('artifact', 'export_report'):
                if role in row:
                    item = row[role]
                    path = report_path.parent / item['path']
                    raw = path.read_bytes()
                    assert item['bytes'] == len(raw) and item['sha256'] == 'sha256:' + sha(raw)
                    integrity.append({'run': report_path.parent.relative_to(base / 'evidence').as_posix(),
                                      'case_id': row['case_id'], 'role': role, **item})
members['reproduction/artifact-integrity.json'] = encode({'status': 'passed', 'members': integrity})

archive = out / 'checkpoint-007.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, raw in sorted(members.items()):
        bundle.writestr(name, raw)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert set(bundle.namelist()) == set(members)
    for name, raw in members.items():
        assert bundle.read(name) == raw
manifest = {'schema_version': 'ontokin.checkpoint-archive/0.1', 'archive': archive.name,
    'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()), 'member_count': len(members),
    'members': [{'path': name, 'bytes': len(raw), 'sha256': sha(raw)} for name, raw in sorted(members.items())]}
(out / 'checkpoint-007.manifest.json').write_bytes(encode(manifest))

rows = [{key: row[key] for key in ('case_id', 'status', 'operations')} for row in source['deliveries']]
passed = sum(row['status'] == 'passed' for row in rows)
failed = [row['case_id'] for row in rows if row['status'] != 'passed']
assert passed == 20 and len(rows) == 28
now = datetime.now(timezone.utc).isoformat()
checkpoint = {'schema_version': 'ontokin.reach-development-checkpoint/0.1', 'recorded_at': now,
    'baseline': baseline, 'source_commit': source['source_commit'], 'source_tree': source['source_tree'],
    'full_source': {'status': source['status'], 'inputs_stable': source['inputs_stable'],
        'started_at': source['started_at'], 'finished_at': source['finished_at'], 'passed': passed,
        'total': len(rows), 'max_operations': 100000, 'cases': rows,
        'report_sha256': sha((base / 'evidence/source005/report.json').read_bytes())},
    'focused': {key: focused[key] for key in ('status', 'tests', 'failures', 'errors', 'skipped',
        'inputs_stable', 'elapsed_seconds', 'raw_log_complete', 'executed_ids_complete')},
    'archive': {key: manifest[key] for key in ('archive', 'bytes', 'sha256', 'member_count')},
    'artifacts_hash_verified': len(integrity), 'remaining_recordings': failed,
    'limitations': limitations, 'release_acceptance': False, 'full_product_goal_completed': False,
    'main_unchanged': '2bb4588e121fcfe99b4d42c734b15b38362f3642', 'pr': 27, 'pr_draft': True,
    'pending_roles': ['28/28 source recordings', '10 Agent artifacts', 'complete current regression and compatibility',
        'independent rate verification', 'native and browser destination checks', 'fresh image review',
        'hostile input and inherited gates', 'R01-R12/Q01-Q22 release audit', 'resulting-main verification']}
(out / 'checkpoint-007.json').write_bytes(encode(checkpoint))

section = f'''## Latest checkpoint 007: 686 focused tests; source gate remains 20/28

The tested source is `{source['source_commit']}`, tree
`{source['source_tree']}`. Its complete source run finished
**{source['finished_at']}**, with stable tracked inputs and the original
**100,000-operation** request budget. It still passes **20/28**: P05, P09,
P11, P16, P20, P23, L01 and L03 each stop at operation 100,001. **L02 uses
93,980 operations**, down from checkpoint 006's 99,102. This is progress in
work cost, not a completed source gate.

The same source passes **686/686 focused methods**, zero failures, errors or
skips, in **{focused['elapsed_seconds']:.3f} seconds**. The complete raw log,
started/passed method IDs, interpreter/platform and before/after tracked
inventories are preserved. The preceding 682-method run had one ordinary
composition-interface error; the original test remains unchanged, and the
corrected run includes it. Earlier axis and geometry failures remain visible.

Changes since the verified published checkpoint `{baseline}`:

- Reuse complete immutable spin operands and constant native relative transforms
  in the existing bounded numerical cache; atomic cursor batches retain final
  current-source admission and each actual cache-operation charge.
- Reuse independently constructed native primitives and immutable placed surfaces
  while checking every actual occurrence and retaining the role separation.
- Omit proved exact-zero endpoint/total work, reuse independently proved preceding
  arc envelopes, and fuse scalar/Z recording offset arithmetic before outward
  rounding. Ordinary source observations, cold seeds and unsupported graphs keep
  their original cells and interface.

P16 now completes certification and reaches GLB exact-clock encoding. P20
completes all endpoint rows and stops in the final independent certificate-group
checks. P11 reaches independent phase tables. P23 still exhausts its request
during sampling after about 80,872 operations of preparation on the preceding
profiled cut; its repeated source preparation and sampling need further work.
P05, P09, L01 and L03 remain independent-verification failures.

[checkpoint-007.zip](checkpoint-007.zip) preserves **{len(members)} members**,
**{manifest['bytes']:,} bytes**, SHA-256
`{manifest['sha256']}`. The
[manifest](checkpoint-007.manifest.json) identifies three complete source runs,
the focused passes and failures, diagnostic profiles, reproduction drivers,
exact source patches and raw commit objects. All **{len(integrity)} GLB/report
identities**, every archive member and ZIP CRC were checked. Earlier archives
are unchanged. The [machine-readable checkpoint](checkpoint-007.json) retains
the precise scope and limitations.

The first spin run reported 261 passes but its raw log was truncated. That
report/log remains unchanged and is explicitly limited. A fresh 261-method
run on the same source has a complete atomically written log and method IDs.
An earlier geometry preflight rejected an unidentified untracked temporary ZIP
before executing tests; its path, size and hash are preserved. No responsible
environment component is established for either observation.

The immediate target remains **28/28**, followed by all ten Agent artifacts,
full current regression and compatibility, independent rates, native/browser
checks, fresh capture review, inherited/hostile gates and release audits.
PR #27 remains draft and **must not merge** before every mandatory acceptance
gate passes. Main stays `2bb4588e121fcfe99b4d42c734b15b38362f3642`.
No main integration lease is claimed and no hosted job was dispatched.

'''
readme = out / 'README.md'
text = readme.read_text()
assert '## Latest checkpoint 006:' in text
text = text.replace('## Latest checkpoint 006:', section + '## Preserved checkpoint 006:', 1)
readme.write_text(text)

status = root / 'STATUS.md'
text = status.read_text()
start = text.index('Latest tested recording implementation is')
end = text.index('The historical rows below retain their original cuts and limits.', start)
replacement = f'''Latest tested recording implementation is `{source['source_commit']}`,
tree `{source['source_tree']}`. Published checkpoint 006 is verified at
`{baseline}`; the newer source and evidence below form checkpoint 007.
The originally reported unpublished 20/28 checkout was unavailable; the fresh
reconstruction and both measured baselines retain their separate identities.

The [recording checkpoint](docs/engineering/reach-recording-validation-2026-10-22/README.md)
retains a fresh **20/28** full source run, finished **{source['finished_at']}**,
with stable inputs and the unchanged **100,000-operation** limit. **L02 uses
93,980 operations**. **P05, P09, P11, P16, P20, P23, L01 and L03** still stop at
100,001. P16 now reaches GLB encoding; P20 reaches the final independent group
checks; P11 reaches independent phase tables; P23 remains in sampling. The
other four failures remain in independent verification.

The same integrated source passes **686/686 focused tests**, zero failures,
errors or skips, in **{focused['elapsed_seconds']:.3f} seconds**, with complete raw logs,
method IDs and stable tracked inputs. This is a selected correctness cohort,
not complete regression or compatibility. The preceding composition-interface
error and earlier scoped failures are preserved and were corrected without
changing existing acceptance expectations.

Checkpoint 007 preserves **{len(members)} raw members**: three complete source runs,
focused outcomes, profiles, reproduction drivers, exact patches and raw commits.
All **{len(integrity)} GLB/report hashes**, archive member hashes and ZIP CRC passed.
The first spin run's truncated log and the geometry preflight rejection retain
explicit limitations; the complete spin rerun passed 261/261 on the same source.
Earlier archives retain their original bytes and meaning.

Complete immutable spin/relative operands, atomic cache publication, source
geometry reuse and independent sparse/arc/recording arithmetic remove actual
duplicate work. Current source/cap/callback checks, independent proof authority,
the 256-entry cache, frozen inputs, tolerances and budgets remain unchanged.

The immediate target is **28/28**. Continue P23 captured source sampling and
repeated residual work, P16's remaining total cost, and independent reference
verification. All ten Agent artifacts, full current regression/compatibility,
independent rates, native/browser checks, visual review, inherited/hostile roles
and release audits remain pending. PR #27 stays draft; **do not merge** until
every mandatory acceptance gate passes. Full GOAL remains open.

'''
text = text[:start] + replacement + text[end:]
prefix, suffix = text.split('Checkpoint: **', 1)
text = prefix + 'Checkpoint: **' + now + '**.' + suffix.split('**.', 1)[1]
status.write_text(text)
for name, digest in earlier.items():
    assert sha((out / name).read_bytes()) == digest, name
print(json.dumps({'source_commit': source['source_commit'], 'source_tree': source['source_tree'],
    'passed': passed, 'total': len(rows), 'focused_tests': focused['tests'],
    'archive': checkpoint['archive'], 'verified_artifacts': len(integrity),
    'earlier_checkpoint_files_unchanged': len(earlier)}, indent=2))
