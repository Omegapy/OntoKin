import collections,functools,json,pathlib,sys,time,traceback
root=pathlib.Path(sys.argv[1]).resolve();sys.path.insert(0,str(root))
from ontokin import reach_export as ex
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.gltf import export_glb
from ontokin.scene import ExportOptions
from tools.reach_delivery_inventory import snapshot,source_files,settings
from fractions import Fraction
case=sys.argv[2];out=pathlib.Path(sys.argv[3]);out.mkdir(parents=True)
before=snapshot();c=None;stages=[];stats=collections.defaultdict(lambda:{'calls':0,'operations':0,'max':0})
names=['reach_prefix_plan','recording_phase_bounds','node_geometry_bounds','reach_timeline','_sample_recording_nodes','interval_certificates','_endpoint_group_maxima','_certificate_quantities','_recording_endpoint_excess','upper_binary64','complete_interval_bounds','destination_numeric_bounds']
for name in names:
 if not hasattr(ex,name):continue
 original=getattr(ex,name)
 def wrap(fn,name):
  @functools.wraps(fn)
  def call(*args,**kwargs):
   a=c.budget.operations if c else 0
   if name in ('reach_prefix_plan','recording_phase_bounds','node_geometry_bounds','reach_timeline','_sample_recording_nodes','interval_certificates'):stages.append({'name':name,'entry':a})
   try:return fn(*args,**kwargs)
   finally:
    n=(c.budget.operations if c else 0)-a;s=stats[name];s['calls']+=1;s['operations']+=n;s['max']=max(s['max'],n)
  return call
 setattr(ex,name,wrap(original,name))
from ontokin.reach_runtime import ReachSimulator
from ontokin.reach_pose import ReachPoseOps
for target, names in ((ReachSimulator, ('_process_boundary', '_resolve_kinematics', '_kinematics', 'recording_boundary', '_current', '_physical_observation', '_tip_base', '_bounded_projection', '_world_target', '_validate_staged', '_latch')), (ReachPoseOps, ('make', 'compose', 'multiply', 'rotate', 'project_position', 'project_rotation', 'ensure_finite'))):
 for name in names:
  if hasattr(target, name):
   setattr(target, name, wrap(getattr(target, name), target.__name__ + '.' + name))
report={'case':case,'diagnostic':True,'inputs_before':before,'started_at':time.time()}
try:
 c=compile_construction(load_file_manifest(root/source_files(case)),level='constructed')
 report['constructed_operations']=c.budget.operations
 opts=settings(case);opts['end']=Fraction(opts['end'])
 result=export_glb(c.model,options=ExportOptions(**opts),target_contract='ontokin.glb/0.6',work=c.reach_work)
 report['status']='passed'
except Exception as error:
 report.update(status='failed',error=str(error),traceback=traceback.format_exc())
report.update(stats=dict(stats),stages=stages,operations=c.budget.operations if c else None,work=c.reach_work.record() if c else None,inputs_after=snapshot(),finished_at=time.time())
report['inputs_stable']=report['inputs_before']==report['inputs_after']
(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['case','status','operations','stages','stats','inputs_stable']},indent=2))
