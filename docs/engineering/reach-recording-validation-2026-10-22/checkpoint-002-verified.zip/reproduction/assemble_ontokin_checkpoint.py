"""Retain exact current evidence and recovered source bytes without executing them."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile


parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--base', required=True)
parser.add_argument('--name', required=True)
parser.add_argument('--source')
parser.add_argument('--inventory', type=Path, required=True)
args = parser.parse_args()
repo = args.repo.resolve()


def git(*parts, cwd=repo):
    return subprocess.check_output(['git', '-C', str(cwd), *parts])


def records(raw):
    result = {}
    for row in raw.split(b'\0'):
        if row:
            metadata, path = row.split(b'\t', 1)
            mode, kind, sha = metadata.decode().split()
            if kind == 'blob':
                result[path.decode()] = (mode, sha)
    return result


assert not git('status', '--porcelain').strip(), 'Commit source before archiving evidence.'
assembly_head = git('rev-parse', 'HEAD').decode().strip()
head = args.source or assembly_head
tree = git('rev-parse', head + '^{tree}').decode().strip()
tracked = records(git('ls-tree', '-rz', 'HEAD'))
before = {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in tracked}
members = {}


def add(name, data):
    assert name not in members, name
    members[name] = data


inventory = json.loads(args.inventory.read_text())
for raw in inventory['evidence']:
    path = Path(raw)
    if not path.exists():
        raise FileNotFoundError(path)
    if path.is_dir():
        for file in sorted(path.rglob('*')):
            if file.is_file() and '__pycache__' not in file.parts:
                assert not file.is_symlink(), file
                add('runs/' + path.name + '/' + file.relative_to(path).as_posix(), file.read_bytes())
    else:
        assert not path.is_symlink(), path
        add('files/' + path.name, path.read_bytes())

add('reproduction/assemble_ontokin_checkpoint.py', Path(__file__).read_bytes())
add('reproduction/inventory.json', args.inventory.read_bytes())
add('source/integrated.patch', git('diff', '--binary', args.base, head))
commits = git('rev-list', '--reverse', args.base + '..' + head).decode().splitlines()
for commit in commits:
    add('source/commits/' + commit + '.txt', git('cat-file', 'commit', commit))

# A deduplicated source inventory preserves newly located older work. These
# are static Git bytes, never evidence that the old implementation now passes.
baseline = records(git('ls-tree', '-rz', '215efd6c99d2e42ca54ddbd9d898dd99fa678418'))
recovery = []
recovery_blobs = set()
def selected_recovery_path(name):
    return (name in {'AGENTS.md', 'STATUS.md', 'README.md', 'GOAL.md'}
            or name.startswith(('ontokin/', 'tools/', 'tests/'))
            or name.startswith('docs/') and name.endswith('.md')
            or name == 'docs/language-design/planar-reach-v0.1/conformance-local-v0.1.json')

for raw in inventory.get('recovered_checkouts', []):
    old = Path(raw)
    old_head = git('rev-parse', 'HEAD', cwd=old).decode().strip()
    old_tree = git('rev-parse', 'HEAD^{tree}', cwd=old).decode().strip()
    status = git('status', '--porcelain', cwd=old).decode()
    assert not status.strip(), 'Recovered checkout changed: ' + str(old)
    rows = []
    old_files = records(git('ls-tree', '-rz', old_head, cwd=old))
    for name, (mode, sha) in old_files.items():
        if not selected_recovery_path(name) or baseline.get(name) == (mode, sha):
            continue
        blob_name = 'recovery/git-blobs/' + sha
        if sha in recovery_blobs:
            data = members[blob_name]
        else:
            data = git('cat-file', 'blob', sha, cwd=old)
            assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == sha
            add(blob_name, data)
            recovery_blobs.add(sha)
        rows.append({'path': name, 'mode': mode, 'git_blob': sha, 'bytes': len(data),
                     'sha256': hashlib.sha256(data).hexdigest(), 'archive_member': blob_name})
    add('recovery/commits/' + old.name + '.txt', git('cat-file', 'commit', old_head, cwd=old))
    recovery.append({'checkout': str(old), 'head': old_head, 'tree': old_tree,
                     'clean': True, 'retained_changed_source_files': rows,
                     'removed_baseline_source_paths': sorted(name for name in baseline
                         if selected_recovery_path(name) and name not in old_files)})

original = inventory.get('original_auditor')
if original:
    receipt = json.loads(Path(original['receipt']).read_text())
    for row in receipt['files']:
        data = git('show', receipt['recovery_commit'] + ':' + row['path'], cwd=Path(receipt['source_checkout']))
        assert len(data) == row['byte_length'] and hashlib.sha256(data).hexdigest() == row['sha256']
        add('recovery/original-auditor/' + row['path'], data)

recovery_record = {'status': 'static_source_recovery_only', 'observed_at': datetime.now(timezone.utc).isoformat(),
                   'baseline': '215efd6c99d2e42ca54ddbd9d898dd99fa678418',
                   'scope': 'All changed tracked code/tools/tests, Markdown and the local conformance mapping. Historical binary/evidence archives are outside this source recovery inventory.',
                   'checkouts': recovery}
add('recovery/inventory.json', (json.dumps(recovery_record, indent=2) + '\n').encode())

out = repo / 'docs/engineering/reach-recording-validation-2026-10-22'
archive = out / (args.name + '.zip')
assert not archive.exists()
manifest = {'source_commit': head, 'source_tree': tree, 'assembly_commit': assembly_head, 'patch_base': args.base,
            'created_at': datetime.now(timezone.utc).isoformat(), 'members': []}
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in sorted(members.items()):
        bundle.writestr(name, data)
        manifest['members'].append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for row in manifest['members']:
        data = bundle.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
after = {name: hashlib.sha256((repo / name).read_bytes()).hexdigest() for name in tracked}
assert before == after, 'Tracked source changed during archive creation.'
manifest['tracked_source_stable'] = True
manifest['archive'] = {'path': archive.name, 'bytes': archive.stat().st_size,
                       'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                       'member_count': len(members), 'all_member_hashes_verified': True, 'zip_crc_verified': True}
(out / (args.name + '.manifest.json')).write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'source_commit': head, 'source_tree': tree, 'archive': manifest['archive'],
                  'recovered_checkouts': len(recovery), 'recovered_unique_source_blobs': len(recovery_blobs)}, indent=2))
