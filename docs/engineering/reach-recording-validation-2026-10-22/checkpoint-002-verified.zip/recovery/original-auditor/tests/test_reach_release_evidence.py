"""Negative retained-evidence checks never execute source/Agent/native programs."""
from copy import deepcopy
from fractions import Fraction as F
import json
from pathlib import Path
import struct
import tempfile
import unittest
from unittest.mock import patch

from tools import reach_release as release
from tools import build_reach_release_evidence as collector
from tools import run_reach_release_role as runner


def rational(value):
    value = F(value)
    return {"numerator_hex": hex(value.numerator), "denominator_hex": hex(value.denominator)}


def comparison(actual=(0., 0., 0.), intervals=None, allowance=F(1)):
    intervals = intervals or [(F(0), F(0))] * 3
    minimum, maximum = [], []
    for number, (low, high) in zip(actual, intervals):
        value = F.from_float(float(number))
        minimum.append(max(low - value, value - high, F(0)) ** 2)
        maximum.append(max(abs(low - value), abs(high - value)) ** 2)
    status = "proved" if sum(maximum) <= allowance ** 2 else "contradicted" if sum(minimum) > allowance ** 2 else "unresolved"
    return {"actual": list(actual), "actual_binary64_hex": [struct.pack(">d", value).hex() for value in actual],
        "ideal_intervals": [{"lo": rational(low), "hi": rational(high)} for low, high in intervals],
        "source_arithmetic_allowance": rational(allowance), "allowance_squared": rational(allowance ** 2),
        "minimum_squared_error": rational(sum(minimum)), "maximum_squared_error": rational(sum(maximum)),
        "component_squared_distances": [{"minimum_squared": rational(low), "maximum_squared": rational(high)}
                                        for low, high in zip(minimum, maximum)], "status": status}


def glb(document, binary=b"\0\0\0\0"):
    encoded = release.canonical(document)
    encoded += b" " * (-len(encoded) % 4)
    binary += b"\0" * (-len(binary) % 4)
    length = 12 + 8 + len(encoded) + 8 + len(binary)
    return struct.pack("<III", 0x46546c67, 2, length) + struct.pack("<II", len(encoded), 0x4e4f534a) + encoded + struct.pack("<II", len(binary), 0x004e4942) + binary


class ReachReleaseEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def write(self, name, value):
        path = self.root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(value if isinstance(value, bytes) else release.canonical(value))
        return path

    def test_contract_and_independent_inventory_retain_all_literal_obligations(self):
        mapping = release.load_contract()
        self.assertEqual(len(mapping["requirements"]), 12)
        self.assertEqual(len(mapping["probes"]), 22)
        self.assertEqual(len(mapping["probe_records"]), 43)
        self.assertEqual(len(mapping["protocol_records"]), 42)
        self.assertEqual(len(mapping["additional_protocol_records"]), 12)
        inventory = release.frozen_rate_inventory()
        self.assertEqual(len(inventory), 362)
        self.assertEqual(sum(len(row["frozen_fields"]) for row in inventory), 724)
        self.assertEqual(len({row["id"] for row in inventory}), 362)
        self.assertEqual(len(release.SOURCE_ARTIFACTS), 28)
        self.assertNotIn("P24", release.SOURCE_ARTIFACTS)
        self.assertNotIn("L04", release.SOURCE_ARTIFACTS)
        self.assertEqual(len(release.AGENT_ARTIFACTS), 10)
        self.assertEqual(release.endpoint("P17"), F(2))
        self.assertEqual(release.endpoint("L04"), F(1, 4))

    def test_json_duplicates_nonfinite_and_exponent_overflow_are_rejected(self):
        for raw in (b'{"a":1,"a":2}', b'{"v":NaN}', b'{"v":Infinity}', b'{"v":1e9999}'):
            with self.subTest(raw=raw), self.assertRaises(release.EvidenceError):
                release.json_bytes(raw)

    def test_paths_symlinks_and_traversal_do_not_escape_retained_root(self):
        for name in ("/absolute", "../parent", "a/../b", "a//b", "a/./b", "C:/drive", "a\\b", ""):
            with self.subTest(name=name), self.assertRaises(release.EvidenceError):
                release.safe_name(name)
        target = self.write("actual.json", {})
        (self.root / "alias.json").symlink_to(target)
        with self.assertRaises(release.EvidenceError):
            release.relative_file(self.root, "alias.json")

    def test_named_member_hash_length_and_input_order_are_independent(self):
        first = self.write("a", b"first")
        second = self.write("b", b"second")
        records = [release.file_record(first), release.file_record(second)]
        self.assertEqual(release.inventory_digest(records), release.inventory_digest(list(reversed(records))))
        with self.assertRaises(release.EvidenceError):
            release.input_map([records[0], records[0]])
        wrong = {**records[0], "byte_length": 0}
        with self.assertRaises(release.EvidenceError):
            release.identified(wrong, self.root)
        first.write_bytes(b"changed")
        with self.assertRaises(release.EvidenceError):
            release.identified(records[0], self.root)

    def test_missing_inventory_is_pending_but_executed_failure_wins(self):
        with self.assertRaises(release.MissingEvidence):
            release.exact_inventory([{"id": "a", "status": "passed"}], "id", ("a", "b"), "probe")
        with self.assertRaises(release.EvidenceError) as caught:
            release.exact_inventory([{"id": "a", "status": "failed"}], "id", ("a", "b"), "probe")
        self.assertIs(type(caught.exception), release.EvidenceError)
        self.assertEqual(release.combine(["pending", "failed"]), "failed")

    def test_missing_roles_and_supporting_tests_never_certify_acceptance(self):
        mapping = json.loads((release.ROOT / release.MAP_PATH).read_text())
        current = {"implementation": {"name": "test-only"}, "git": {"commit": "a" * 40, "tree": "b" * 40},
                   "inputs": [], "input_inventory_sha256": release.inventory_digest([]), "committed_inputs_match": True}
        with patch.object(release, "load_contract", return_value=mapping), patch.object(release, "source_identity", return_value=current):
            result = release.audit_release(repository=self.root)
            self.assertEqual(result["status"], "pending")
            self.assertFalse(result["release_acceptance"])
            self.assertFalse(result["finite_release_complete"])
            self.assertFalse(result["full_product_goal_completed"])
            self.assertEqual(len(result["roles"]), 12)
            self.assertEqual(len(result["probe_records"]), 43)
            self.assertEqual(len(result["protocol_records"]), 54)
            auditor = release.Auditor(repository=self.root)
        for category in ("requirements", "probes", "probe_records", "protocol_records", "additional_protocol_records", "source_cases"):
            for row in mapping[category]:
                for name in row.get("test_ids", []) + row.get("supporting_test_ids", []):
                    auditor.tests[name] = ["passed"] * 3
        auditor.source_cases = dict.fromkeys(release.SOURCE_CASES, "passed")
        auditor.protocol_records = {row["id"]: "passed" for row in mapping["protocol_records"] + mapping["additional_protocol_records"]}
        _, families, probes, _ = release.reconcile_rows(auditor, [{"id": name, "status": "passed"} for name in release.ROLES],
            {"status": "passed"}, {"status": "passed"})
        self.assertTrue(all(row["status"] == "pending" for row in probes + families))

    def test_actual_execution_failure_and_false_unstarted_pass_are_failed(self):
        auditor = object.__new__(release.Auditor)
        auditor.envelopes = {}
        base = {"schema_version": release.EXECUTION_SCHEMA, "role": "compatibility",
                "provider": {"kind": "local", "hosted_ci_claimed": False}}
        for changes in ({"executed": True, "status": "failed", "exit_code": -9},
                        {"executed": False, "status": "completed", "exit_code": 0},
                        {"executed": True, "status": "completed", "exit_code": 0,
                         "report_absent_before_execution": False}):
            path = self.write("execution.json", {**base, **changes})
            with patch.object(auditor, "file", return_value=path):
                result = release.assessed("compatibility", lambda: auditor.execution({}, "compatibility", "tools/run_reach_regression.py"))
            self.assertEqual(result["status"], "failed")
        path = self.write("execution.json", {**base, "executed": False, "status": "not_started"})
        with patch.object(auditor, "file", return_value=path):
            result = release.assessed("compatibility", lambda: auditor.execution({}, "compatibility", "tools/run_reach_regression.py"))
        self.assertEqual(result["status"], "pending")

    def test_exact_rate_extrema_handle_negative_zero_crossing_and_subnormal(self):
        row = comparison((-2., 0., float.fromhex("0x0.0000000000001p-1022")),
                         [(F(-3), F(-1)), (F(-1, 4), F(1, 4)), (F(0), F(1, 2 ** 1073))], F(2))
        self.assertEqual(release.check_rate_comparison(row), "proved")
        row["maximum_squared_error"] = rational(0)
        with self.assertRaises(release.EvidenceError):
            release.check_rate_comparison(row)

    def test_rate_rejection_unresolved_and_actual_bit_identity_remain_distinct(self):
        with self.assertRaises(release.EvidenceError) as caught:
            release.check_rate_comparison(comparison((2., 0., 0.), allowance=F(1)))
        self.assertIs(type(caught.exception), release.EvidenceError)
        with self.assertRaises(release.MissingEvidence):
            release.check_rate_comparison(comparison(intervals=[(F(0), F(2)), (F(0), F(0)), (F(0), F(0))], allowance=F(1)))
        row = comparison()
        row["actual_binary64_hex"][0] = "8000000000000000"
        with self.assertRaises(release.EvidenceError):
            release.check_rate_comparison(row)

    def test_clock_and_rational_inputs_have_preallocation_bounds(self):
        for value in ("1e100000000", True, "1/0", "9" * 129):
            with self.subTest(value=str(value)[:20]), self.assertRaises((release.EvidenceError, ZeroDivisionError)):
                release.exact_clock(value)
        with self.assertRaises(release.EvidenceError):
            release.rational_record({"numerator_hex": "0x" + "f" * 9000, "denominator_hex": "0x1"})
        with self.assertRaises(release.EvidenceError):
            release.rational_record({"numerator_hex": "0x1", "denominator_hex": "0x0"})

    def test_exact_mutation_scope_rejects_unrelated_geometry_damage(self):
        document = {"nodes": [{"name": "root", "mesh": 0}], "extras": {"certificate": 1}, "buffers": [{"byteLength": 4}]}
        changed = deepcopy(document); changed["extras"]["certificate"] = 0
        before = self.write("before.glb", glb(document))
        after = self.write("after.glb", glb(changed))
        observed = {"changed_json_pointers": ["/extras/certificate"],
                    "baseline_artifact_sha256": release.file_record(before)["sha256"],
                    "mutated_artifact_sha256": release.file_record(after)["sha256"]}
        criterion = {"allowed_json_pointers": ["/extras/certificate"], "allowed_binary_ranges": []}
        release.check_mutation(before, after, observed, criterion)
        changed["nodes"][0]["name"] = "missing-original-root"
        after.write_bytes(glb(changed))
        observed["mutated_artifact_sha256"] = release.file_record(after)["sha256"]
        observed["changed_json_pointers"] = release.changed_pointers(document, changed)
        with self.assertRaises(release.EvidenceError):
            release.check_mutation(before, after, observed, criterion)

    def test_allocation_preflight_does_not_decode_a_declared_10001_key_accessor(self):
        document = {"animations": [{"samplers": [{"input": 0}], "extras": {"ontokin": {"boundary_times_seconds": ["0", "1"]}}}],
                    "accessors": [{"componentType": 5126, "type": "SCALAR", "count": 10001, "bufferView": 0}],
                    "bufferViews": [{"buffer": 0, "byteLength": 4}]}
        with self.assertRaises(release.EvidenceError):
            release.recording_clock(document, b"\0" * 4)

    def test_literal_probe_assertions_cannot_match_a_different_stage_or_aliased_pointer(self):
        observation = {"rejection": {"stage": "clock_rounding", "code": "clock"}, "allocations": [0]}
        criteria = [{"pointer": "/rejection/stage", "equals": "clock_rounding"}, {"pointer": "/allocations/0", "equals": 0}]
        release.compare_observation(observation, criteria)
        observation["rejection"]["stage"] = "duplicate_json_key"
        with self.assertRaises(release.EvidenceError):
            release.compare_observation(observation, criteria)
        with self.assertRaises(release.EvidenceError):
            release.pointer(observation, "/allocations/00")

    def test_collector_keeps_closed_store_bytes_and_rejects_live_sidecars(self):
        source = self.write("source/agent.sqlite3", b"closed-store-test-bytes")
        rows, excluded = collector.copy_inventory([{"source": str(source.parent), "destination": "agent"}], self.root / "output")
        self.assertEqual(excluded, [])
        self.assertEqual(rows[0][1]["sha256"], release.digest(source.read_bytes()))
        self.write("source/agent.sqlite3-wal", b"uncheckpointed")
        with self.assertRaises(release.EvidenceError):
            collector.copy_inventory([{"source": str(source.parent), "destination": "agent"}], self.root / "output")

    def test_collector_rejects_collisions_and_cannot_execute_template_code(self):
        source = self.write("source/data", b"raw")
        copy = {"source": str(source), "destination": "record"}
        with self.assertRaises(release.EvidenceError):
            collector.copy_inventory([copy, copy], self.root / "output")
        with self.assertRaises(release.EvidenceError):
            collector.resolve_references({"$command": "anything"}, {})
        descriptor = release.file_record(source, "record")
        self.assertEqual(collector.resolve_references({"$file": "record"}, {"record": descriptor}), descriptor)
        with self.assertRaises(release.EvidenceError):
            collector.resolve_references({"$file": "record", "status": "passed"}, {"record": descriptor})

    def test_only_explicit_complete_role_entrypoints_can_execute(self):
        cwd = str(release.ROOT)
        self.assertEqual(release.check_command("compatibility", ["python", "tools/run_reach_regression.py"], cwd), "tools/run_reach_regression.py")
        for command in (["sh", "-c", "anything"], ["python", "tools/unknown.py"],
                        ["python", "tools/run_reach_regression.py", "--case", "P01"]):
            with self.subTest(command=command), self.assertRaises(release.EvidenceError):
                release.check_command("compatibility", command, cwd)

    def test_execution_wrapper_retains_actual_nonzero_failure_without_inventing_a_report(self):
        current = {"implementation": {"name": "test-only"}, "git": {"commit": "a" * 40, "tree": "b" * 40},
                   "inputs": [], "input_inventory_sha256": release.inventory_digest([]), "committed_inputs_match": True}
        class FailedProcess:
            def wait(self, timeout=None):
                return 7
        with patch.object(release, "source_identity", return_value=current), patch.object(runner.platform, "platform", return_value="test-platform"), \
             patch.object(runner.subprocess, "Popen", return_value=FailedProcess()):
            result = runner.execute("compatibility", self.root / "execution", "run/report.json",
                ["python", "tools/run_reach_regression.py"], repository=release.ROOT)
        self.assertTrue(result["executed"])
        self.assertEqual(result["exit_code"], 7)
        self.assertEqual(result["status"], "failed")
        self.assertTrue(result["report_missing"])
        self.assertFalse(result["release_acceptance"])
        self.assertTrue((self.root / "execution/execution.json").is_file())


if __name__ == "__main__":
    unittest.main()
