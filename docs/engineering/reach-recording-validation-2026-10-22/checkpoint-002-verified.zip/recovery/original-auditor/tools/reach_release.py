"""Independent retained-evidence accounting for the adopted finite reach gate.

This module does not import a production solver, sampler, exporter or Agent
service. It reads identified reports; it never runs a command from a report.
The execution wrapper is separate. A missing observation is pending, an
executed contradiction is failed, and no whole-product completion is inferred.
"""
from __future__ import annotations

import ast
from collections import Counter
from datetime import datetime, timezone
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import struct

ROOT = Path(__file__).resolve().parents[1]
BASE = "docs/language-design/planar-reach-v0.1"
MAP_PATH = BASE + "/conformance-local-v0.1.json"
MAPPING_SHA256 = "sha256:17f993b268c19059bf91d11e4d214c5a89a4239c5a785126ea9005018806471a"
ADOPTION_SHA256 = "sha256:05453342c602808f33f1fb0560e2baa2460148f9bf150e174882143b3c63a822"
# The proposal inventory also identified this preimplementation executable.
# Its historical bytes stay frozen in the published recovered implementation;
# it was absent from the earlier proposal commit. Implementation
# successors require an explicit old/current applicability review. Normative
# documents, fixtures, schemas, preparation tools and environment pins do not
# use this exception.
ADOPTION_IMPLEMENTATION_INPUTS = {"ontokin/json_limits.py": "f45f66e428cffe965dc6e50d0746c862b916263e"}
RATE_DECISION = "docs/engineering/reach-rate-acceptance-v0.1.md"
RATE_DECISION_SHA256 = "sha256:72c694e9fb38d3d39239d951c1876c3aa49b0590b2fa653906946c7cc2ec25a9"
EVIDENCE_SCHEMA = "ontokin.reach-release-evidence/0.1"
EXECUTION_SCHEMA = "ontokin.reach-release-execution/0.1"
AUDIT_SCHEMA = "ontokin.reach-release-audit/0.1"
ROLES = ("input_closure", "source_execution", "compatibility", "agent_workflow", "agent_delivery",
         "source_native", "agent_native", "source_browser", "agent_browser", "hostile_inputs",
         "visual_review", "inherited_workflows")
REQUIREMENTS = tuple(f"R{i:02}" for i in range(1, 13))
PROBES = tuple(f"Q{i:02}" for i in range(1, 23))
SOURCE_CASES = tuple(f"P{i:02}" for i in range(1, 27)) + tuple(f"N{i:02}" for i in range(1, 16)) + tuple(f"L{i:02}" for i in range(1, 5))
SOURCE_ARTIFACTS = tuple(f"P{i:02}" for i in range(1, 24)) + ("P25", "P26", "L01", "L02", "L03")
AGENT_ARTIFACTS = ("P01", "P11", "P13", "P20", "P16", "P17", "L01", "L02", "L03", "L04")
SOURCE_BROWSER = ("P01", "P11", "P20", "P16", "P18", "P19", "L01", "L02", "L03")
AGENT_BROWSER = AGENT_ARTIFACTS[:-1]
PYTHONS = ("3.11", "3.12", "3.13")
PYTHON_PINS = {"jsonschema": "4.26.0", "referencing": "0.37.0", "attrs": "26.1.0",
               "jsonschema-specifications": "2025.9.1", "rpds-py": "2026.5.1", "typing_extensions": "4.16.0"}
NODE_PINS = {"three": "0.180.0", "gltf-validator": "2.0.0-dev.3.10", "playwright": "1.56.1", "esbuild": "0.25.10"}
MAX_JSON = 64 * 1024 * 1024
MAX_FILE = 4 * 1024 * 1024 * 1024
MAX_FILES = 20000
MAX_TOTAL = 8 * 1024 * 1024 * 1024
SHA = re.compile(r"sha256:[0-9a-f]{64}\Z")
COMMIT = re.compile(r"(?:[0-9a-f]{40}|[0-9a-f]{64})\Z")
TEST_ID = re.compile(r"test_[A-Za-z0-9_]+\.[A-Za-z0-9_]+\.test_[A-Za-z0-9_]+\Z")
TRANSIENT = re.compile(r"(?:\.sqlite(?:3)?|\.db)-(?:wal|shm|journal)$|\.(?:pyc|pyo)$")
ENTRYPOINTS = {
    "source_execution": {"tools/run_reach_source_corpus.py", "tools/reach_rate_inventory.py"},
    "compatibility": {"tools/run_reach_regression.py"},
    "agent_workflow": {"tools/build_reach_agent_delivery.py", "tools/audit_reach_agent_delivery.py"},
    "agent_delivery": {"tools/build_reach_agent_delivery.py", "tools/audit_reach_agent_delivery.py"},
    "source_native": {"tools/build_reach_source_artifacts.py", "tools/verify_reach_destinations.py"},
    "agent_native": {"tools/verify_reach_destinations.py"},
    "source_browser": {"tools/verify_reach_destinations.py"},
    "agent_browser": {"tools/verify_reach_destinations.py"},
    "hostile_inputs": {"tools/run_reach_hostile_probes.py"},
    "inherited_workflows": {"tools/check_local.py", "tools/run_force_conformance.py"},
}


class EvidenceError(ValueError):
    """Supplied evidence contradicts its declared bytes or adopted obligation."""


class MissingEvidence(EvidenceError):
    """A required execution or independently reviewed observation is absent."""


def require(condition, message):
    if not condition:
        raise EvidenceError(message)


def needed(condition, message):
    if not condition:
        raise MissingEvidence(message)


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")


def digest(raw):
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def utc():
    return datetime.now(timezone.utc).isoformat()


def clock(value):
    require(type(value) is str, "A clock must be an explicit UTC timestamp")
    try:
        result = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as error:
        raise EvidenceError("Invalid execution/review clock") from error
    require(result.utcoffset() is not None and result.utcoffset().total_seconds() == 0,
            "Execution and review clocks must identify UTC")
    return result


def safe_name(name):
    require(type(name) is str and name and "\\" not in name and "\0" not in name
            and not re.match(r"^[A-Za-z]:", name), "Evidence requires a relative POSIX path")
    relative = PurePosixPath(name)
    require(relative.parts and not relative.is_absolute() and relative.as_posix() == name
            and all(part not in ("", ".", "..") for part in name.split("/")), "Unsafe evidence path: " + name)
    return name


def no_symlinks(path):
    path = Path(path).absolute()
    require(not any(parent.is_symlink() for parent in (path, *path.parents)),
            "Evidence and input paths cannot contain symlinks: " + str(path))
    return path


def relative_file(root, name, *, missing_is_pending=False):
    safe_name(name)
    root = no_symlinks(root)
    path = no_symlinks(root / name)
    if not path.exists() and missing_is_pending:
        raise MissingEvidence("Missing retained evidence member: " + name)
    require(path.is_file() and path.resolve().is_relative_to(root.resolve()), "Missing or nonregular member: " + name)
    return path


def read_raw(path, *, maximum=MAX_JSON):
    path = no_symlinks(path)
    require(path.is_file(), "Evidence must be a regular file: " + str(path))
    before = path.stat()
    require(before.st_size <= maximum, "Evidence member exceeds its declared byte bound")
    with path.open("rb") as stream:
        raw = stream.read(maximum + 1)
    after = path.stat()
    require(len(raw) == before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns
            and before.st_ino == after.st_ino, "Evidence changed during reading")
    return raw


def json_bytes(raw):
    require(len(raw) <= MAX_JSON, "Evidence JSON exceeds its byte bound")
    def pairs(values):
        result = {}
        for key, value in values:
            require(key not in result, "Duplicate JSON member: " + key)
            result[key] = value
        return result
    def nonfinite(value):
        raise EvidenceError("Nonfinite JSON value: " + value)
    def number(value):
        result = float(value)
        require(math.isfinite(result), "Nonfinite JSON exponent")
        return result
    try:
        value = json.loads(raw, object_pairs_hook=pairs, parse_constant=nonfinite, parse_float=number)
    except (ValueError, RecursionError, UnicodeError) as error:
        raise EvidenceError("Invalid bounded evidence JSON: " + str(error)) from error
    stack, count = [(value, 0)], 0
    while stack:
        item, depth = stack.pop()
        count += 1
        require(count <= 4000000 and depth <= 128, "Evidence JSON exceeds its structural bound")
        if type(item) in (dict, list):
            stack.extend((child, depth + 1) for child in (item.values() if type(item) is dict else item))
    return value


def json_file(path):
    return json_bytes(read_raw(path))


def file_record(path, name=None):
    path = no_symlinks(path)
    require(path.is_file(), "An identity needs a regular file")
    before, total, hashed = path.stat(), 0, hashlib.sha256()
    require(before.st_size <= MAX_FILE, "Evidence file exceeds its byte bound")
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            total += len(chunk)
            require(total <= MAX_FILE, "Evidence grew beyond its byte bound")
            hashed.update(chunk)
    after = path.stat()
    require(total == before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns
            and before.st_ino == after.st_ino, "Evidence changed while hashing")
    return {"path": safe_name(name or path.name), "sha256": "sha256:" + hashed.hexdigest(), "byte_length": total}


def normalize_record(record):
    require(type(record) is dict and type(record.get("sha256")) is str, "Incomplete file identity")
    require(set(record) >= {"path", "sha256"} and ("bytes" in record) != ("byte_length" in record),
            "A member must have exactly one explicit byte-length field")
    size = record.get("byte_length", record.get("bytes"))
    require(type(size) is int and 0 <= size <= MAX_FILE and SHA.fullmatch(record["sha256"]),
            "Invalid member length or SHA-256")
    return {"path": safe_name(record["path"]), "sha256": record["sha256"], "byte_length": size}


def identified(record, root):
    expected = normalize_record(record)
    path = relative_file(root, expected["path"])
    require(file_record(path, expected["path"]) == expected, "Retained member bytes differ: " + expected["path"])
    return path


def unique_rows(rows, field, description):
    require(type(rows) is list, description + " must be a list")
    result = {}
    for row in rows:
        require(type(row) is dict and type(row.get(field)) is str and row[field] not in result,
                "Duplicate or invalid " + description)
        result[row[field]] = row
    return result


def exact_inventory(rows, field, expected, description):
    result = unique_rows(rows, field, description)
    require(set(result) <= set(expected), "Unexpected " + description)
    require(not any(row.get("status") in {"failed", "error", "interrupted", "contradicted", "not_established"}
                    for row in result.values()), "An executed " + description + " contradicts acceptance")
    needed(set(result) == set(expected), "Missing " + description + ": " + ", ".join(sorted(set(expected) - set(result))))
    return result


def eligible_path(name):
    parts = PurePosixPath(name).parts
    if not parts or any(part in {"node_modules", "__pycache__", ".venv", "venv"} for part in parts) or TRANSIENT.search(name):
        return False
    if name in {"AGENTS.md", "GOAL.md", "pyproject.toml"}:
        return True
    if parts[0] in {"ontokin", "tests", "tools", "prototypes", "schemas", "examples"}:
        return True
    if parts[:2] in ((".github", "workflows"), ("docs", "language-design"), ("docs", "product")):
        return True
    if parts[:3] == ("docs", "maintenance", "reorganization-2026-10-17"):
        return parts[-1] in {"verify_reorganization.py", "source-map.json"}
    if parts[:2] == ("docs", "engineering"):
        return (len(parts) == 3 and parts[-1].endswith(".md")
                or name == "docs/engineering/reach-source-acceptance-validation/source-case-map.json"
                or parts[:3] == ("docs", "engineering", "reach-release-criteria"))
    return False


def git(args, root=ROOT):
    env = {key: value for key, value in os.environ.items() if not key.startswith("GIT_")}
    env.update(GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL=os.devnull, GIT_OPTIONAL_LOCKS="0",
               GIT_NO_REPLACE_OBJECTS="1", GIT_NO_LAZY_FETCH="1", GIT_TERMINAL_PROMPT="0")
    result = subprocess.run(["git", "-c", "core.fsmonitor=false", "-c", "core.hooksPath=/dev/null", *args],
                            cwd=root, env=env, capture_output=True, check=False)
    require(result.returncode == 0, "Read-only Git identity failed: " + result.stderr.decode("utf-8", "replace")[:1000])
    return result.stdout


def input_map(records):
    rows = unique_rows(records, "path", "input path")
    return {name: normalize_record(row) for name, row in rows.items()}


def inventory_digest(records):
    return digest(canonical(sorted(input_map(records).values(), key=lambda row: row["path"])))


def verify_commit_inputs(commit, tree, records, root=ROOT):
    require(type(commit) is str and COMMIT.fullmatch(commit) and type(tree) is str and COMMIT.fullmatch(tree),
            "A complete Git commit and tree are required")
    require(git(["rev-parse", commit + "^{tree}"], root).decode().strip() == tree, "Git commit/tree mismatch")
    blobs = {}
    for item in git(["ls-tree", "-r", "-z", "--full-tree", commit], root).split(b"\0"):
        if item:
            header, raw_name = item.split(b"\t", 1)
            mode, kind, oid = header.decode().split()
            name = raw_name.decode("utf-8")
            if eligible_path(name):
                require(kind == "blob" and mode in {"100644", "100755"}, "Eligible input is not a regular Git blob")
                blobs[name] = oid
    records = input_map(records)
    require(set(blobs) == set(records), "Captured eligible input closure differs from its Git tree")
    algorithm = "sha256" if len(commit) == 64 else "sha1"
    for name, record in records.items():
        raw = read_raw(relative_file(root, name))
        require(digest(raw) == record["sha256"] and len(raw) == record["byte_length"], "Current eligible input differs: " + name)
        actual = hashlib.new(algorithm, b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
        require(actual == blobs[name], "Current input differs from the captured commit: " + name)


def implementation_identity(root=ROOT):
    hashed = hashlib.sha256()
    for path in sorted((Path(root) / "ontokin").glob("*.py")):
        hashed.update(path.name.encode() + b"\0" + read_raw(path) + b"\0")
    module = ast.parse(read_raw(Path(root) / "ontokin/__init__.py"))
    versions = [node.value.value for node in module.body if isinstance(node, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == "__version__" for target in node.targets)
                and isinstance(node.value, ast.Constant) and type(node.value.value) is str]
    require(len(versions) == 1, "Runtime version must have one literal identity")
    return {"name": "ontokin-reference", "version": versions[0], "source_code_sha256": "sha256:" + hashed.hexdigest()}


def source_identity(root=ROOT):
    root = no_symlinks(root)
    commit = git(["rev-parse", "HEAD"], root).decode().strip()
    tree = git(["rev-parse", "HEAD^{tree}"], root).decode().strip()
    names = git(["ls-files", "-z"], root).decode().split("\0")
    records = [file_record(relative_file(root, name), name) for name in sorted(set(names)) if name and eligible_path(name)]
    verify_commit_inputs(commit, tree, records, root)
    # An untracked eligible test/tool is an input too; it cannot silently be left out.
    untracked = git(["ls-files", "--others", "--exclude-standard", "-z"], root).decode().split("\0")
    require(not any(name and eligible_path(name) for name in untracked), "Uncommitted eligible inputs are present")
    return {"implementation": implementation_identity(root), "git": {"commit": commit, "tree": tree},
            "inputs": records, "input_inventory_sha256": inventory_digest(records), "committed_inputs_match": True}


def stable_source(before, after):
    return (before.get("implementation") == after.get("implementation") and before.get("git") == after.get("git")
            and input_map(before.get("inputs", [])) == input_map(after.get("inputs", [])))


def load_contract(root=ROOT):
    mapping_path = relative_file(root, MAP_PATH)
    require(file_record(mapping_path)["sha256"] == MAPPING_SHA256, "The literal mapping changed without a reviewed auditor successor")
    mapping = json_file(mapping_path)
    adoption_path = relative_file(root, BASE + "/adoption.json")
    require(file_record(adoption_path)["sha256"] == ADOPTION_SHA256, "The frozen adoption identity changed")
    adoption = json_file(adoption_path)
    require(mapping.get("release_evidence_schema") == EVIDENCE_SCHEMA and mapping.get("adopted_contract") == "OK-LANG-006/0.1.0",
            "Unsupported reach mapping contract")
    require(tuple(mapping["mandatory_roles"]) == ROLES, "Mandatory release roles changed")
    require(tuple(row["id"] for row in mapping["requirements"]) == REQUIREMENTS
            and tuple(row["id"] for row in mapping["probes"]) == PROBES, "Required R/Q inventory changed")
    require(set(row["id"] for row in mapping["source_cases"]) == set(SOURCE_CASES)
            and len(mapping["source_cases"]) == 45 and len(mapping["probe_records"]) == 43
            and len(mapping["protocol_records"]) == 42 and len(mapping["additional_protocol_records"]) == 12,
            "Frozen source/probe/protocol inventory changed")
    for record in adoption["frozen_inputs"]:
        record = dict(record)
        if not record["sha256"].startswith("sha256:"):
            record["sha256"] = "sha256:" + record["sha256"]
        if record["path"] in ADOPTION_IMPLEMENTATION_INPUTS:
            original = git(["show", ADOPTION_IMPLEMENTATION_INPUTS[record["path"]] + ":" + record["path"]], root)
            expected = normalize_record(record)
            require(digest(original) == expected["sha256"] and len(original) == expected["byte_length"],
                    "Historical adopted executable bytes differ from the published recovered archive")
        else:
            identified(record, root)
    for record in mapping["frozen_authority_inputs"]:
        record = dict(record)
        if not record["sha256"].startswith("sha256:"):
            record["sha256"] = "sha256:" + record["sha256"]
        identified(record, root)
    mapped = {name for key in ("requirements", "probes", "probe_records", "protocol_records", "additional_protocol_records", "source_cases")
              for row in mapping[key] for name in row.get("test_ids", [])}
    for name in mapped:
        require(TEST_ID.fullmatch(name), "A mapped method must be a literal unittest identifier")
        module, cls, method = name.split(".")
        tree = ast.parse(read_raw(relative_file(root, "tests/" + module + ".py")))
        require(any(isinstance(node, ast.ClassDef) and node.name == cls
                    and any(isinstance(member, (ast.FunctionDef, ast.AsyncFunctionDef)) and member.name == method for member in node.body)
                    for node in tree.body), "Mapped method was removed: " + name)
    return mapping


def adoption_implementation_changes(root=ROOT):
    adoption = json_file(Path(root) / BASE / "adoption.json")
    result = {}
    for record in adoption["frozen_inputs"]:
        if record["path"] in ADOPTION_IMPLEMENTATION_INPUTS:
            previous = normalize_record({**record, "sha256": record["sha256"] if record["sha256"].startswith("sha256:") else "sha256:" + record["sha256"]})
            current = file_record(relative_file(root, record["path"]), record["path"])
            if current != previous:
                result[record["path"]] = {"path": record["path"], "previous": previous, "current": current,
                                        "previous_commit": ADOPTION_IMPLEMENTATION_INPUTS[record["path"]]}
    return result


def combine(states):
    values = list(states)
    return "failed" if "failed" in values else "pending" if not values or any(value != "passed" for value in values) else "passed"


def check_command(role, command, cwd):
    require(role in ENTRYPOINTS and type(command) is list and len(command) >= 2
            and all(type(value) is str and value and "\0" not in value for value in command)
            and type(cwd) is str and Path(cwd).is_absolute(), "Incomplete explicit role command")
    script = Path(command[1])
    script = Path(os.path.normpath(script if script.is_absolute() else Path(cwd) / script))
    allowed = {Path(cwd) / name for name in ENTRYPOINTS[role]}
    require(script in allowed, "Command does not invoke the identified role's reviewed entry point")
    require("--case" not in command and "--cases" not in command, "A filtered command cannot establish a complete release role")
    return script.relative_to(cwd).as_posix()


def write_json(path, value):
    path = no_symlinks(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode()
    require(len(raw) <= MAX_JSON, "Generated evidence exceeds its JSON byte bound")
    with path.open("xb") as stream:
        stream.write(raw)
    return file_record(path)


def endpoint(case_id):
    return Fraction({"P14": "4", "P16": "4", "P17": "2", "P26": "60",
                     "L01": "4", "L02": "2", "L03": "4", "L04": "0.25"}.get(case_id, "3"))


def exact_clock(value):
    require(type(value) in (str, int, float), "Exact source clock has an invalid type")
    if type(value) in (int, float):
        require(math.isfinite(value), "Source clock must be finite")
    text = str(value)
    require(len(text) <= 128 and re.fullmatch(r"-?(?:[0-9]+(?:\.[0-9]+)?|[0-9]+/[0-9]+)", text),
            "Source clock must be a bounded exact decimal or fraction")
    return Fraction(text)


def frozen_cases(root=ROOT):
    result = {}
    for relative in (BASE + "/acceptance.json", BASE + "/draft2-supplements/acceptance.json"):
        document = json_file(relative_file(root, relative))
        for row in document["source_cases"]:
            require(row["id"] not in result, "Duplicate frozen source case")
            result[row["id"]] = (relative, row)
    require(set(result) == set(SOURCE_CASES), "The frozen 45-case source inventory changed")
    return result


def frozen_rate_inventory(root=ROOT):
    result = []
    def physical(arm, sample):
        return [{"carrier": arm + ".forearm.tip.frame", "field": "velocity_m_per_s",
                 "frozen_field": "tip_velocity_world_m_per_s", "measurement": sample["tip_velocity_world_m_per_s"]},
                {"carrier": arm + ".forearm.frame", "field": "angular_velocity_rad_per_s",
                 "frozen_field": "forearm_omega_world_rad_per_s", "measurement": sample["forearm_omega_world_rad_per_s"]}]
    for case_id, (relative, case) in frozen_cases(root).items():
        def add(label, time, side, fields):
            manifest = str(PurePosixPath(relative).parent / case["file_manifest"])
            require(file_record(relative_file(root, manifest))["sha256"] == case["file_manifest_sha256"],
                    "Frozen rate source manifest changed")
            result.append({"id": case_id + "." + label, "case_id": case_id, "file_manifest": manifest,
                "program_revision": case["program_revision"], "time_seconds": str(time), "side": side,
                "carriers": list(dict.fromkeys(row["carrier"] for row in fields)), "frozen_fields": fields})
        expected = case.get("expected", case)
        arm = "rig.arm" if case_id.startswith("L") else expected.get("tracked_arm")
        for index, sample in enumerate(expected.get("samples", [])):
            time = Fraction(int(sample["time"]["numerator"]), int(sample["time"]["denominator"]))
            add(f"sample-{index:03}", time, sample["side"], physical(arm, sample.get("physical", sample)))
        if case_id == "P16":
            release = expected["release"]
            add("release-incoming", Fraction(2), "before", physical(arm, release["incoming_state"]))
            for time in (3, 4):
                add(f"payload-{time}", Fraction(time), "after", [
                    {"carrier": "payload.frame", "field": "velocity_m_per_s",
                     "frozen_field": f"velocity_at_{time}_seconds_m_per_s", "measurement": release[f"velocity_at_{time}_seconds_m_per_s"]},
                    {"carrier": "payload.frame", "field": "angular_velocity_rad_per_s",
                     "frozen_field": "constant_free_omega_world_rad_per_s", "measurement": release["constant_free_omega_world_rad_per_s"]}])
    require(len(result) == 362 and len({row["id"] for row in result}) == 362
            and sum(len(row["frozen_fields"]) for row in result) == 724, "Frozen rate inventory changed")
    return result


def rational_record(record):
    require(type(record) is dict and set(record) == {"numerator_hex", "denominator_hex"}, "Expected a complete exact rational record")
    integers = []
    for name in ("numerator_hex", "denominator_hex"):
        value = record[name]
        require(type(value) is str and len(value) <= 8200 and re.fullmatch(r"-?0x[0-9a-f]+", value),
                "Unbounded or invalid exact rational operand")
        integers.append(int(value, 16))
    require(integers[1] > 0 and all(abs(value).bit_length() <= 32768 for value in integers), "Exact rational operand exceeds the unchanged domain")
    return Fraction(*integers)


def check_rate_comparison(row):
    actual, encodings, intervals = row.get("actual"), row.get("actual_binary64_hex"), row.get("ideal_intervals")
    require(type(actual) is list and len(actual) == 3 and type(encodings) is list and len(encodings) == 3
            and type(intervals) is list and len(intervals) == 3, "A rate comparison needs three complete actual and ideal components")
    minima, maxima = [], []
    for value, encoding, interval in zip(actual, encodings, intervals):
        require(type(value) in (int, float) and math.isfinite(value) and type(encoding) is str
                and struct.pack(">d", float(value)).hex() == encoding, "Actual binary64 value and exact hex identity differ")
        value = Fraction.from_float(float(value))
        require(type(interval) is dict and set(interval) == {"lo", "hi"}, "An ideal rate interval is incomplete")
        lo, hi = rational_record(interval["lo"]), rational_record(interval["hi"])
        require(lo <= hi, "An ideal rate interval is reversed")
        # At most 32768-bit input integers; the six exact squared distances
        # have a bounded, fixed expression tree. No approximate norm is used.
        minima.append(max(lo - value, value - hi, Fraction(0)) ** 2)
        maxima.append(max(abs(lo - value), abs(hi - value)) ** 2)
    allowance = rational_record(row.get("source_arithmetic_allowance"))
    require(allowance >= 0, "A source rate allowance is negative")
    minimum, maximum, square = sum(minima), sum(maxima), allowance * allowance
    require(rational_record(row.get("allowance_squared")) == square
            and rational_record(row.get("minimum_squared_error")) == minimum
            and rational_record(row.get("maximum_squared_error")) == maximum, "Recorded exact rate extrema contradict independent recomputation")
    components = row.get("component_squared_distances")
    require(type(components) is list and len(components) == 3, "Per-component rate extrema are incomplete")
    for component, low, high in zip(components, minima, maxima):
        require(rational_record(component.get("minimum_squared")) == low and rational_record(component.get("maximum_squared")) == high,
                "A component rate distance was understated")
    verdict = "proved" if maximum <= square else "contradicted" if minimum > square else "unresolved"
    require(row.get("status") == verdict, "Rate result status contradicts its exact supplied intervals")
    require(verdict != "contradicted", "An executed actual rate contradicts the adopted allowance")
    needed(verdict == "proved", "An actual rate remains unresolved against its exact enclosure")
    if "frozen_measurement" in row:
        require(row["frozen_measurement"].get("used_for_verdict") is False, "An unproved frozen measurement was used as an acceptance oracle")
    return verdict


def check_options(case_id, options):
    require(type(options) is dict and exact_clock(options.get("end")) == endpoint(case_id)
            and type(options.get("fps")) in (int, float) and math.isfinite(options["fps"]) and 0 < options["fps"] <= 10000
            and options.get("helpers") is False, "Recording options changed the required complete prefix or helper policy")
    for name, maximum in (("position_tolerance_m", .001), ("rotation_tolerance_rad", .001), ("time_tolerance_s", .000001)):
        if name in options:
            require(type(options[name]) in (int, float) and 0 < options[name] <= maximum, "An export tolerance was weakened")


def check_export(report, artifact, case_id, revision):
    require(report.get("target_contract") == "ontokin.glb/0.6" and report.get("outcome") == "valid"
            and report.get("program_revision") == revision, "Recording report identifies a different target/source or a failed result")
    sampling, tolerance, validation = report.get("sampling", {}), report.get("tolerances", {}), report.get("validation", {})
    require(exact_clock(sampling.get("start_seconds")) == 0 and exact_clock(sampling.get("end_seconds")) == endpoint(case_id),
            "Recording report shortened or shifted the required source prefix")
    for name, maximum in (("position_m", .001), ("rotation_rad", .001), ("time_seconds", .000001), ("surface_local_vertex_m", .00001)):
        require(type(tolerance.get(name)) in (int, float) and 0 < tolerance[name] <= maximum, "Recording report weakened an adopted tolerance")
    identity = file_record(artifact)
    require(report.get("artifact", {}).get("sha256") == identity["sha256"]
            and report["artifact"].get("byte_length") == identity["byte_length"], "Export validation belongs to different artifact bytes")
    require(validation.get("status") == "passed" and validation.get("failures") == []
            and validation.get("structure") == "passed_bounded_glb_reader"
            and validation.get("reach_continuous_bounds") == "passed_independent_source_and_bytes"
            and validation.get("reach_boundary_histories") == "passed_complete_both_sides_and_incoming_releases"
            and validation.get("surface_geometry_materials_and_provenance") == "passed_source_comparison",
            "Independent supplied-byte bounds, complete histories or source geometry did not pass")
    require(type(sampling.get("keyframe_count")) is int and 1 <= sampling["keyframe_count"] <= 10000
            and validation.get("sample_count") == sampling["keyframe_count"]
            and validation.get("interval_certificates_checked") == sampling.get("interval_certificate_count"),
            "Export validation omitted stored keys or interval certificates")


def decode_glb(path):
    raw = read_raw(path, maximum=64 * 1024 * 1024)
    require(len(raw) >= 20, "Truncated GLB")
    magic, version, length = struct.unpack_from("<III", raw)
    require(magic == 0x46546c67 and version == 2 and length == len(raw), "Invalid GLB header or byte length")
    cursor, chunks = 12, []
    while cursor < len(raw):
        require(cursor + 8 <= len(raw), "Truncated GLB chunk header")
        size, kind = struct.unpack_from("<II", raw, cursor)
        require(size % 4 == 0 and cursor + 8 + size <= len(raw) and len(chunks) < 2, "Invalid GLB chunk bound")
        chunks.append((kind, raw[cursor + 8:cursor + 8 + size])); cursor += size + 8
    require(len(chunks) == 2 and chunks[0][0] == 0x4e4f534a and chunks[1][0] == 0x004e4942, "Expected exactly JSON and BIN chunks")
    return json_bytes(chunks[0][1]), chunks[1][1]


def recording_clock(document, binary):
    animations = document.get("animations")
    require(type(animations) is list and len(animations) == 1, "A recording requires exactly one clip")
    samplers = animations[0].get("samplers")
    require(type(samplers) is list and samplers, "Recorded animation samplers are missing")
    index = samplers[0].get("input")
    require(type(index) is int and all(row.get("input") == index for row in samplers), "Recorded carriers do not share one clock")
    accessors, views = document.get("accessors", []), document.get("bufferViews", [])
    require(0 <= index < len(accessors), "Invalid stored clock accessor")
    accessor = accessors[index]
    count, view_index = accessor.get("count"), accessor.get("bufferView")
    require(accessor.get("type") == "SCALAR" and accessor.get("componentType") == 5126 and not accessor.get("sparse")
            and type(count) is int and 1 <= count <= 10000 and type(view_index) is int and 0 <= view_index < len(views),
            "Invalid or excessive stored clock representation")
    view = views[view_index]
    offset, view_offset, stride = accessor.get("byteOffset", 0), view.get("byteOffset", 0), view.get("byteStride", 4)
    require(all(type(value) is int and value >= 0 for value in (offset, view_offset, stride)) and stride >= 4 and stride % 4 == 0
            and view.get("buffer") == 0 and type(view.get("byteLength")) is int
            and offset + (count - 1) * stride + 4 <= view["byteLength"] and view_offset + view["byteLength"] <= len(binary),
            "Stored clock escapes its bounded buffer view")
    times = [struct.unpack_from("<f", binary, view_offset + offset + i * stride)[0] for i in range(count)]
    require(times[0] == 0 and all(math.isfinite(time) and (not index or time > times[index - 1]) for index, time in enumerate(times)),
            "Stored clocks are nonfinite, collapsed or unordered")
    metadata = animations[0].get("extras", {}).get("ontokin", {})
    values = metadata.get("boundary_times_seconds")
    require(type(values) is list and 1 <= len(values) <= 10000 and all(type(value) is str and len(value) <= 128 for value in values),
            "Complete bounded source boundary clocks are missing")
    boundaries = list(map(exact_clock, values))
    require(boundaries[0] == 0 and all(not index or time > boundaries[index - 1] for index, time in enumerate(boundaries)),
            "Source boundary clocks are unordered")
    return times, boundaries


def check_native_samples(reference, artifact, frozen, end):
    document, binary = decode_glb(artifact)
    times, boundaries = recording_clock(document, binary)
    require(boundaries[-1] == end and list(map(exact_clock, reference.get("source_boundary_times_seconds", []))) == boundaries,
            "Native reference omitted a source boundary or changed the required horizon")
    wanted = {}
    def add(identity, kind, time, side="after", source_time=None):
        row = {"sample_id": identity, "kind": kind, "time_seconds": time, "side": side}
        if source_time is not None:
            row["source_time_seconds"] = source_time
        wanted[identity] = row
    for index, time in enumerate(times):
        add(f"key:{index}", "recorded_key", time)
    for index, (left, right) in enumerate(zip(times, times[1:])):
        for numerator, denominator in ((1, 16), (1, 8), (1, 4), (3, 8), (1, 2), (5, 8), (3, 4), (7, 8)):
            add(f"interval:{index}:fraction:{numerator}-{denominator}", "interval_interior", left + (right - left) * numerator / denominator)
    for index, time in enumerate(boundaries):
        for side in ("before", "after"):
            add(f"boundary:{index}:{side}", "source_boundary", float(time), side, time)
    _, case = frozen
    for index, sample in enumerate(case.get("expected", case).get("samples", [])):
        time = Fraction(int(sample["time"]["numerator"]), int(sample["time"]["denominator"]))
        if time <= end:
            add(f"fixture:{case['id']}:fixed:{index}", "fixture", float(time), sample["side"], time)
    for index, (left, right) in enumerate(zip(boundaries, boundaries[1:])):
        offset = min(Fraction(1, 1000000), (right - left) / 16)
        for label, time in (("after_left", left + offset), ("before_right", right - offset)):
            add(f"fixture:phase:{index}:{label}", "fixture", float(time), source_time=time)
    actual = exact_inventory(reference.get("samples"), "sample_id", wanted, "independent native sample")
    nodes = unique_rows(reference.get("expected_nodes"), "path", "source carrier")
    sites = {site["path"] for node in nodes.values() for site in node.get("sites", [])}
    for identity, planned in wanted.items():
        observed = actual[identity]
        require(all(observed.get(key) == value for key, value in planned.items() if key != "source_time_seconds"),
                "Native schedule changed an exact key, interior, boundary side or fixture observation")
        if "source_time_seconds" in planned:
            require(type(observed.get("source_time_seconds")) is str and exact_clock(observed["source_time_seconds"]) == planned["source_time_seconds"],
                    "Native source comparison used a rounded clock")
        require(type(observed.get("poses")) is dict and set(observed["poses"]) == set(nodes)
                and type(observed.get("sites")) is dict and set(observed["sites"]) == sites,
                "Native comparison omitted an untouched carrier or promised source landmark")
    return {"stored_keys": len(times), "required_samples": len(wanted), "source_boundaries": len(boundaries)}


def pointer(value, path):
    require(type(path) is str and len(path) <= 4096 and (path == "" or path.startswith("/")), "An observation needs a literal JSON pointer")
    for segment in path.split("/")[1:] if path else ():
        require(not re.search(r"~(?![01])", segment), "Malformed JSON pointer escape")
        key = segment.replace("~1", "/").replace("~0", "~")
        if type(value) is list:
            require(re.fullmatch(r"0|[1-9][0-9]*", key) and len(key) < 10 and int(key) < len(value), "JSON pointer has no observed list element")
            value = value[int(key)]
        else:
            require(type(value) is dict and key in value, "JSON pointer has no observed member")
            value = value[key]
    return value


def changed_pointers(first, second, path=""):
    """Exact structural changes; array length changes identify the whole array."""
    if type(first) is not type(second):
        return [path]
    if type(first) is dict:
        result = []
        for key in sorted(set(first) | set(second)):
            child = path + "/" + key.replace("~", "~0").replace("/", "~1")
            result.extend([child] if key not in first or key not in second else changed_pointers(first[key], second[key], child))
        return result
    if type(first) is list:
        if len(first) != len(second):
            return [path]
        return [child for index, (left, right) in enumerate(zip(first, second))
                for child in changed_pointers(left, right, path + "/" + str(index))]
    return [] if first == second else [path]


def compare_observation(observation, assertions):
    require(type(assertions) is list and assertions, "A probe criterion needs concrete observed field assertions")
    seen = set()
    for assertion in assertions:
        require(type(assertion) is dict and set(assertion) == {"pointer", "equals"}
                and assertion["pointer"] not in seen and assertion["pointer"] != "", "A probe assertion must bind one distinct literal observed field")
        seen.add(assertion["pointer"])
        require(canonical(pointer(observation, assertion["pointer"])) == canonical(assertion["equals"]),
                "Actual probe observation contradicts its published criterion: " + assertion["pointer"])


def check_mutation(before_path, after_path, row, criterion):
    """Verify actual changes and preserve everything outside reviewed paths/ranges."""
    before, old_binary = decode_glb(before_path)
    after, new_binary = decode_glb(after_path)
    changed = changed_pointers(before, after)
    allowed = criterion.get("allowed_json_pointers")
    require(type(allowed) is list and all(type(path) is str and path.startswith("/") for path in allowed)
            and len(set(allowed)) == len(allowed), "Mutation criterion needs explicit non-root JSON paths")
    require(changed == row.get("changed_json_pointers")
            and all(any(path == prefix or path.startswith(prefix + "/") for prefix in allowed) for path in changed),
            "Artifact mutation changed unrelated source/object/geometry/history metadata")
    ranges = criterion.get("allowed_binary_ranges", [])
    require(type(ranges) is list and len(ranges) <= 100000, "Binary mutation ranges are unbounded")
    cursor = 0
    require(len(old_binary) == len(new_binary) or criterion.get("allow_binary_length_change") is True,
            "Artifact mutation unexpectedly changed binary length")
    for interval in ranges:
        require(type(interval) is list and len(interval) == 2 and all(type(value) is int for value in interval)
                and cursor <= interval[0] < interval[1] <= max(len(old_binary), len(new_binary)), "Binary mutation ranges overlap or escape the bytes")
        require(old_binary[cursor:interval[0]] == new_binary[cursor:interval[0]], "Unrelated binary geometry or animation bytes changed")
        cursor = interval[1]
    require(old_binary[cursor:] == new_binary[cursor:], "Unrelated trailing binary bytes changed")
    require(changed or old_binary != new_binary, "A corrupt-byte probe supplied unchanged bytes")
    require(row.get("baseline_artifact_sha256") == file_record(before_path)["sha256"]
            and row.get("mutated_artifact_sha256") == file_record(after_path)["sha256"], "Mutation observation has stale transport identities")
    return before, after


class Auditor:
    """Combine explicit current role evidence without treating labels as proof."""

    def __init__(self, evidence=None, *, repository=ROOT):
        self.repository = no_symlinks(repository)
        self.mapping = load_contract(self.repository)
        self.current = source_identity(self.repository)
        self.path = no_symlinks(evidence) if evidence is not None else None
        self.root = self.path.parent if self.path else None
        self.document = json_file(self.path) if self.path else None
        self.files, self.envelopes, self.context = {}, {}, {}
        self.tests, self.source_cases, self.protocol_records, self.probe_records = {}, {}, {}, {}
        self.captures = {}
        self.execution_starts = []
        self.repository_reviews = set()
        self.roles = self.document.get("roles", {}) if type(self.document) is dict else {}

    def file(self, record, *, base=None):
        needed(self.root is not None, "No retained release evidence root was supplied")
        base = self.root if base is None else Path(base)
        expected = normalize_record(record)
        path = identified(expected, base)
        name = path.relative_to(self.root).as_posix()
        require(name in self.files, "A referenced file is outside the complete member inventory: " + name)
        require(self.files[name] == {**expected, "path": name}, "A reference disagrees with the member inventory: " + name)
        return path

    def read(self, record, *, base=None):
        path = self.file(record, base=base)
        return json_file(path), path

    def role(self, name):
        require(type(self.roles) is dict and set(self.roles) <= set(ROLES), "Unknown or invalid release role")
        needed(name in self.roles, "No current " + name + " evidence was supplied")
        require(type(self.roles[name]) is dict, "A role must contain explicit evidence references")
        return self.roles[name]

    def field(self, record, name, context):
        needed(name in record, "Missing " + context + " " + name)
        return record[name]

    def closure(self):
        needed(self.document is not None, "No reach release evidence manifest was supplied")
        require(type(self.document) is dict and self.document.get("schema_version") == EVIDENCE_SCHEMA,
                "Unsupported release evidence schema")
        require(self.document.get("full_product_goal_completed") is False, "A finite reach gate cannot complete the full product")
        require(type(self.roles) is dict and set(self.roles) <= set(ROLES), "Unknown release role")
        needed(self.document.get("implementation") == self.current["implementation"], "Stale release implementation identity differs")
        needed(self.document.get("input_inventory_sha256") == self.current["input_inventory_sha256"],
               "Stale release evidence: eligible named inputs differ")
        require(normalize_record(self.document.get("mapping")) == file_record(self.repository / MAP_PATH, MAP_PATH),
                "Release evidence does not bind the exact literal mapping")
        records = self.document.get("files")
        require(type(records) is list and len(records) <= MAX_FILES, "A bounded member inventory is required")
        self.files = input_map(records)
        require(sum(row["byte_length"] for row in self.files.values()) <= MAX_TOTAL, "Evidence root exceeds its byte bound")
        found = set()
        for path in self.root.rglob("*"):
            no_symlinks(path)
            if path.is_file() and path != self.path and path.relative_to(self.root).as_posix() != "audit.json":
                name = path.relative_to(self.root).as_posix()
                require(not TRANSIENT.search(name), "A live database sidecar or compiled cache is not immutable release evidence")
                found.add(name)
        require(found == set(self.files), "Evidence manifest does not close over exactly the retained files")
        for name, record in self.files.items():
            identified(record, self.root)
        needed(bool(self.files), "No actual evidence members were retained")
        return {"files": len(self.files), "bytes": sum(row["byte_length"] for row in self.files.values()),
                "manifest_sha256": file_record(self.path)["sha256"], "mapping_sha256": MAPPING_SHA256}

    def source(self, source, *, context):
        require(type(source) is dict and source.get("committed_inputs_match") is True,
                context + " lacks committed eligible inputs")
        records = source.get("inputs")
        require(type(records) is list and source.get("input_inventory_sha256") == inventory_digest(records),
                context + " input digest differs from its named members")
        needed(source.get("implementation") == self.current["implementation"]
               and input_map(records) == input_map(self.current["inputs"]), context + " is stale for the current eligible inputs")
        git_record = source.get("git", {})
        verify_commit_inputs(git_record.get("commit"), git_record.get("tree"), records, self.repository)

    def execution(self, record, role, script, *, compatible_roles=()):
        path = self.file(record)
        key = (str(path), role, script)
        if key in self.envelopes:
            return self.envelopes[key]
        value = json_file(path)
        require(value.get("schema_version") == EXECUTION_SCHEMA and value.get("role") in (role, *compatible_roles),
                "Execution envelope belongs to another role or schema")
        require(value.get("provider") == {"kind": "local", "hosted_ci_claimed": False}, "Execution provider does not follow local policy")
        if value.get("executed") is not True:
            require(value.get("status") not in {"completed", "passed"}, "An unstarted command is falsely marked complete")
            raise MissingEvidence("Required command did not start")
        require(type(value.get("exit_code")) is int and value["exit_code"] == 0 and value.get("status") == "completed"
                and not value.get("timed_out") and not value.get("interrupted") and not value.get("failure"), "An executed required command failed or was interrupted")
        require(value.get("report_absent_before_execution") is True and not value.get("report_missing"),
                "A preexisting or missing report cannot establish this execution")
        start, finish = clock(value.get("started_at_utc")), clock(value.get("finished_at_utc"))
        require(start <= finish and type(value.get("elapsed_seconds")) in (float, int)
                and math.isfinite(value["elapsed_seconds"]) and value["elapsed_seconds"] >= 0, "Invalid execution duration")
        require(check_command(value["role"], value.get("command"), value.get("working_directory")) == script,
                "Execution did not invoke the expected component runner")
        self.source(value.get("source_before"), context="Execution before-state")
        self.source(value.get("source_after"), context="Execution after-state")
        require(value.get("inputs_stable") is True and stable_source(value["source_before"], value["source_after"]),
                "Execution changed source identity")
        self.execution_starts.append(start)
        members = input_map(value.get("members", []))
        needed(bool(members), "Execution has no retained outputs")
        found = set()
        for member in path.parent.rglob("*"):
            no_symlinks(member)
            if member.is_file() and member != path:
                found.add(member.relative_to(path.parent).as_posix())
        require(set(members) == found, "Execution output manifest is incomplete or names unproduced files")
        for member in members.values():
            self.file(member, base=path.parent)
        self.file(value.get("log"), base=path.parent)
        report_path = self.file(value.get("report"), base=path.parent)
        require(normalize_record(value["report"]) == members[normalize_record(value["report"])["path"]],
                "Report identity differs from actual execution output")
        result = json_file(report_path), report_path, value
        self.envelopes[key] = result
        return result

    def component(self, report, path, schema, *, passed="passed"):
        require(report.get("schema_version") == schema, "Unexpected component report schema")
        needed(report.get("status") not in {"running", "not_executed", "not_started"}, "Component report is unfinished")
        require(report.get("status") == passed and not report.get("failure"), "An executed component contradicts acceptance")
        require(report.get("full_product_goal_completed") is not True, "Component report overstates full-product completion")
        if "inputs_stable" in report:
            require(report["inputs_stable"] is True, "Component input bytes changed during execution")
        for key in ("members", "outputs"):
            for record in report.get(key, []):
                record = dict(record)
                if type(record.get("sha256")) is str and not record["sha256"].startswith("sha256:"):
                    record["sha256"] = "sha256:" + record["sha256"]
                self.file(record, base=path.parent)

    def review(self, record, schema, *, repository_bound=False):
        value, path = self.read(record)
        require(value.get("schema_version") == schema and type(value.get("reviewer")) is str and value["reviewer"].strip(),
                "Review requires its exact schema and an identified reviewer")
        needed(value.get("actual_review_performed") is True, "The required independent review has not been performed")
        require(value.get("independent_of_implementation") is True, "Independent review provenance is missing")
        clock(value.get("reviewed_at_utc"))
        require(value.get("status") == "passed" and value.get("defects") == [], "Actual review found an unresolved defect")
        require(type(value.get("observations")) is list and bool(value["observations"])
                and all(type(item) is str and item.strip() for item in value["observations"]), "Review needs concrete observations")
        if repository_bound:
            name = safe_name(value.get("repository_path"))
            require(name.startswith("docs/engineering/reach-release-criteria/"), "Reviewed criteria must be explicit eligible repository inputs")
            require(read_raw(relative_file(self.repository, name)) == read_raw(path), "Criteria review differs from its published repository bytes")
            # Publication is a separate observation: a file cannot contain the
            # hash of the commit that introduces those same bytes.
            self.repository_reviews.add(name)
        return value, path

    def input_closure(self):
        record = self.role("input_closure")
        review, _ = self.review(self.field(record, "mapping_review", "input closure"),
            "ontokin.reach-mapping-applicability/0.1", repository_bound=True)
        require(normalize_record(review.get("mapping")) == file_record(self.repository / MAP_PATH, MAP_PATH),
                "Mapping review identifies different literal rows")
        paths = {row["path"] for row in self.mapping["static_inventory_review"]["test_files"]}
        changes = adoption_implementation_changes(self.repository)
        reviewed_changes = unique_rows(review.get("adoption_implementation_changes", []), "path", "adoption implementation successor")
        needed(set(changes) == set(reviewed_changes), "The changed adopted executable needs explicit old/current applicability review")
        for name, expected in changes.items():
            row = reviewed_changes[name]
            require(normalize_record(row.get("previous")) == expected["previous"]
                    and normalize_record(row.get("current")) == expected["current"]
                    and row.get("previous_commit") == expected["previous_commit"]
                    and type(row.get("reason")) is str and row["reason"].strip(),
                    "Adoption executable successor review does not identify and explain the exact old/current bytes")
            paths.add(name)
        producers = review.get("probe_producers", {})
        require(type(producers) is dict and set(producers) <= {row["id"] for row in self.mapping["probe_records"]},
                "Mapping review contains unknown probe producers")
        for row in self.mapping["probe_records"]:
            selected = producers.get(row["id"], row.get("producer_functions", []))
            for literal in selected:
                require(type(literal) is str and literal.count("::") == 1, "Probe producer must be an exact path/function name")
                name, function = literal.split("::")
                require(safe_name(name).startswith("tools/") and name.endswith(".py"), "Probe producer is not a reviewed tool")
                tree = ast.parse(read_raw(relative_file(self.repository, name)))
                body = tree.body
                for part in function.split("."):
                    nodes = [node for node in body if isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == part]
                    require(len(nodes) == 1, "Mapped probe producer does not exist: " + literal)
                    body = nodes[0].body
                paths.add(name)
        members = input_map(review.get("reviewed_members", []))
        require(set(members) == paths, "Mapping applicability must name every actual mapped method and producer file")
        for row in members.values():
            identified(row, self.repository)
        publication, _ = self.read(self.field(record, "publication", "input closure"))
        require(publication.get("schema_version") == "ontokin.reach-publication-observation/0.1"
                and publication.get("repository") == "https://github.com/Omegapy/OntoKin"
                and type(publication.get("observed_ref")) is str and publication["observed_ref"].startswith("refs/")
                and publication.get("actual_remote_observation") is True, "Actual GitHub publication observation is absent")
        commit = publication.get("commit")
        require(type(commit) is str and COMMIT.fullmatch(commit), "Publication needs the full observed commit")
        require(git(["rev-parse", commit + "^{tree}"], self.repository).decode().strip() == publication.get("tree"),
                "Observed publication commit/tree disagree")
        require(git(["show", commit + ":" + MAP_PATH], self.repository) == read_raw(self.repository / MAP_PATH),
                "The published commit did not contain the literal mapping")
        require(git(["show", commit + ":" + review["repository_path"]], self.repository) == read_raw(self.repository / review["repository_path"]),
                "The mapped applicability review was not published with the acceptance mapping")
        self.context["mapping_publication"] = clock(publication.get("observed_at_utc"))
        self.context["publication_commit"] = commit
        self.context["mapping_review"] = review
        return {"adoption_sha256": ADOPTION_SHA256, "mapping_sha256": MAPPING_SHA256,
                "published_commit": commit, "mapped_methods": self.mapping["static_inventory_review"]["mapped_unique_test_methods"],
                "frozen_source_cases": 45, "probe_subtypes": 43, "fixed_protocol_steps": 42, "additional_protocol_records": 12}

    def compatibility(self):
        record = self.role("compatibility")
        executions = self.field(record, "executions", "compatibility")
        require(type(executions) is dict and set(executions) <= set(PYTHONS), "Unexpected Python compatibility version")
        inventories, outputs = [], set()
        mapped = {name for kind in ("requirements", "probes", "probe_records", "protocol_records", "additional_protocol_records", "source_cases")
                  for row in self.mapping[kind] for name in row.get("test_ids", [])}
        inherited = json_file(self.repository / "docs/language-design/force-v0.1/conformance-local-v0.1.json")
        mapped.update(inherited["regression_required_test_ids"])
        result = {}
        for version in (version for version in PYTHONS if version in executions):
            report, path, envelope = self.execution(executions[version], "compatibility", "tools/run_reach_regression.py")
            self.component(report, path, "ontokin.reach-regression-execution/0.1")
            require(report.get("executed") is True, "Regression did not execute")
            env = report.get("environment", {})
            require(env.get("python_implementation") == "CPython" and type(env.get("python")) is str
                    and ".".join(env["python"].split(".")[:2]) == version and env.get("verification_packages") == PYTHON_PINS,
                    "Regression interpreter or actual verification pins differ")
            require(type(env.get("executable")) is str and Path(env["executable"]).is_absolute()
                    and type(env.get("platform")) is str and env["platform"], "Regression interpreter/platform provenance is missing")
            normalize_record(env.get("executable_file"))
            names = json_file(relative_file(path.parent, "test-inventory.json")).get("test_ids")
            require(type(names) is list and names and len(names) == len(set(names)) and all(TEST_ID.fullmatch(name) for name in names),
                    "Regression inventory must contain unique literal test methods")
            require(mapped <= set(names), "Complete regression omitted inherited or mapped test obligations")
            rows = json_file(relative_file(path.parent, "test-results.json"))
            actual = exact_inventory(rows.get("tests"), "test_id", names, "actual regression method")
            require(rows.get("loader_errors") == [] and rows.get("fixture_errors") == [] and rows.get("unexpected_test_records") == [],
                    "Regression contains loader, fixture or unexpected execution errors")
            for name, row in actual.items():
                require(row.get("status") == "passed" and row.get("failures") == []
                        and type(row.get("elapsed_seconds")) in (float, int) and row["elapsed_seconds"] >= 0,
                        "A required regression method did not pass without exemptions: " + name)
                self.tests.setdefault(name, []).append("passed")
            require(report.get("test_count") == report.get("passed_count") == len(names)
                    and report.get("nonpassing_test_ids") == [], "Regression summary contradicts actual method records")
            require(str(path) not in outputs, "One regression execution was reused for different interpreters")
            outputs.add(str(path))
            inventories.append(set(names))
            result[version] = {"tests": len(names), "python": env["python"], "executable": env["executable_file"]}
        needed(set(executions) == set(PYTHONS), "CPython 3.11, 3.12 and 3.13 must all execute")
        require(all(names == inventories[0] for names in inventories), "Python versions executed different full inventories")
        return result

    def corpus(self, execution):
        report, path, _ = self.execution(execution, "source_execution", "tools/run_reach_source_corpus.py")
        self.component(report, path, "ontokin.reach-source-development-run/0.1")
        require(report.get("test_count") == report.get("passed_case_count") == 45
                and all(report.get(name) == 0 for name in ("failed_case_count", "failures", "errors", "skipped", "expected_failures", "unexpected_successes")),
                "Source cohort did not execute all 45 cases without exemptions")
        names = [name for row in self.mapping["source_cases"] for name in row["test_ids"]]
        inventory = json_file(relative_file(path.parent, "inventory.json"))
        require(type(inventory.get("test_ids")) is list and len(inventory["test_ids"]) == 45
                and set(inventory["test_ids"]) == set(names), "Source cohort method inventory differs from the frozen mapping")
        tests = json_file(relative_file(path.parent, "tests.json"))
        actual = exact_inventory(tests.get("results"), "test_id", names, "source test method")
        for name, row in actual.items():
            require(row.get("status") == "passed", "A source case assertion failed: " + name)
            self.tests.setdefault(name, []).append("passed")
        observations = json_file(relative_file(path.parent, "source-observations.json"))
        cases = exact_inventory(observations.get("cases"), "case_id", SOURCE_CASES, "source observation case")
        frozen = {row["id"]: row for row in self.mapping["source_cases"]}
        for name, row in cases.items():
            require(row.get("test_id") in frozen[name]["test_ids"], "Source observation belongs to a different test")
            requests = row.get("requests")
            require(type(requests) is list, "Source case omitted its actual request records")
            for request in requests:
                require(request.get("status") == "passed" and request.get("program_revision") == frozen[name]["program_revision"],
                        "An actual source request failed or used another frozen source")
                for count in ("construction_operations", "reach_operations"):
                    require(type(request.get(count)) is int and 0 <= request[count] <= 100000, "Source request exceeded its original work cap")
            needed(bool(requests) or type(row.get("construction_failure")) is dict, "A source case never actually executed")
            sample_requests = [request for request in requests if request.get("purpose", "").startswith("sample ")]
            require(len(sample_requests) == frozen[name]["sample_side_count"], "A source case omitted or duplicated frozen sample sides")
            self.source_cases[name] = "passed"
        return {"cases": 45, "sample_sides": sum(row["sample_side_count"] for row in frozen.values()),
                "report": file_record(path, path.relative_to(self.root).as_posix())}

    def applicability(self, record):
        decision = relative_file(self.repository, RATE_DECISION)
        require(file_record(decision)["sha256"] == RATE_DECISION_SHA256, "The adopted rate criterion changed")
        text = read_raw(decision).decode()
        original = {name: {"path": name, "byte_length": int(size), "sha256": "sha256:" + hashed}
                    for name, size, hashed in re.findall(r"\| `([^`]+)` \| (\d+) \| `([0-9a-f]{64})` \|", text)}
        require(original, "The reviewed rate applicability member table is absent")
        if all(file_record(relative_file(self.repository, name), name) == row for name, row in original.items()):
            return {"decision": file_record(decision, RATE_DECISION), "applicability": "identical_reviewed_members"}
        needed(record is not None, "Changed rate implementation requires an independently reviewed applicability successor")
        review, path = self.review(record, "ontokin.reach-rate-applicability/0.1", repository_bound=True)
        require(normalize_record(review.get("decision")) == file_record(decision, RATE_DECISION)
                and input_map(review.get("previous_members", [])) == original, "Rate successor does not retain the previous decision/member identities")
        current = input_map(review.get("reviewed_members", []))
        require(set(current) == set(original), "Rate successor omits a previously applicable numerical member")
        for row in current.values():
            identified(row, self.repository)
        require(review.get("comparison_rule") == "exact_Euclidean_interval_box_squared_distance_extrema"
                and review.get("new_constant_tolerance") is False
                and review.get("limits") == {"max_operations": 100000, "max_operand_bits": 32768, "max_cache_entries": 256},
                "Rate successor changed the frozen comparison or original limits")
        self.context["rate_review_time"] = clock(review["reviewed_at_utc"])
        return {"decision": file_record(decision, RATE_DECISION), "applicability_review": file_record(path, path.relative_to(self.root).as_posix())}

    def rates(self, execution, applicability):
        binding = self.applicability(applicability)
        report, path, envelope = self.execution(execution, "source_execution", "tools/reach_rate_inventory.py")
        self.component(report, path, "ontokin.reach-rate-inventory-proposal/0.1", passed="proved")
        require(report.get("criterion_status") == "proposed_not_adopted", "Historical rate producer metadata was rewritten")
        if "rate_review_time" in self.context:
            require(self.context["rate_review_time"] <= clock(envelope["started_at_utc"]), "Rate criterion review occurred after acceptance execution")
        planned = frozen_rate_inventory(self.repository)
        actual_plan = json_file(relative_file(path.parent, "inventory.json"))
        require(actual_plan == planned, "Actual rate inventory differs from all frozen source/time/side/carrier/field identities")
        rows = exact_inventory(report.get("requests"), "id", [row["id"] for row in planned], "fresh rate request")
        require(report.get("complete_frozen_rate_inventory") is True and report.get("request_count") == 362
                and report.get("frozen_field_count") == report.get("proved_frozen_fields") == 724, "Rate inventory counts contradict required closure")
        comparisons = 0
        for request in planned:
            row = rows[request["id"]]
            require(row.get("status") == "proved" and row.get("covered") is True and row.get("case_id") == request["case_id"]
                    and row.get("frozen_field_count") == len(request["frozen_fields"]), "A frozen rate request was not proved")
            result, _ = self.read(row.get("report"), base=path.parent)
            require(result.get("status") == "proved" and result.get("observation_provenance") == "fresh_compile_and_source_snapshot_in_this_call"
                    and result.get("source_snapshot_scope") == "selected_rates_with_complete_kinematic_finiteness"
                    and result.get("identified_inputs_stable_during_observation_and_reference") is True
                    and result.get("source", {}).get("program_revision") == request["program_revision"]
                    and rational_record(result.get("time")) == Fraction(request["time_seconds"])
                    and result.get("side") == request["side"], "Rate result is not the required fresh source observation")
            require(result.get("request_operation_limit") == result.get("reach_work_operation_limit") == 100000
                    and type(result.get("request_operations")) is int and 0 <= result["request_operations"] <= 100000
                    and type(result.get("reach_work_operations")) is int and 0 <= result["reach_work_operations"] <= 100000,
                    "Rate proof changed or exceeded the single shared request limit")
            require(result.get("methods", {}).get("comparison") == "exact_Euclidean_interval_box_squared_distance_extrema",
                    "Rate result used a different comparison criterion")
            module = ast.parse(read_raw(self.repository / "tools/reach_source_rates.py"))
            declarations = [node.value for node in module.body if isinstance(node, ast.Assign)
                            and any(isinstance(target, ast.Name) and target.id == "INPUT_GROUPS" for target in node.targets)]
            require(len(declarations) == 1, "Rate implementation input groups must have one literal declaration")
            groups = ast.literal_eval(declarations[0])
            fingerprints = result.get("input_hashes")
            require(type(fingerprints) is dict and set(fingerprints) == set(groups), "Rate implementation/derivation input closure changed")
            for group, names in groups.items():
                members = fingerprints[group].get("inputs")
                require(type(members) is list and [member.get("path") for member in members] == list(names), "Rate proof omitted a named implementation or derivation input")
                aggregate = hashlib.sha256()
                for member in members:
                    identified(member, self.repository)
                    aggregate.update((member["path"] + "\0" + member["sha256"][7:] + "\n").encode("ascii"))
                require(fingerprints[group].get("sha256") == "sha256:" + aggregate.hexdigest(), "Rate input group identity contradicts its named bytes")
            values = result.get("results")
            require(type(values) is list, "Rate result lacks individual actual vectors")
            keys = [(value.get("carrier"), value.get("field")) for value in values]
            expected = {(carrier, field) for carrier in request["carriers"] for field in ("velocity_m_per_s", "angular_velocity_rad_per_s")}
            require(len(keys) == len(set(keys)) and set(keys) == expected, "Rate result omits or duplicates a required carrier vector")
            for value in values:
                check_rate_comparison(value)
                comparisons += 1
        return {**binding, "fresh_requests": 362, "frozen_fields": 724, "independently_recomputed_vector_comparisons": comparisons}

    def diagnostics(self, record, source_report):
        review, _ = self.review(record, "ontokin.reach-diagnostic-review/0.1")
        require(normalize_record(review.get("source_execution")) == normalize_record(source_report), "Diagnostic review names a different source execution")
        expected = tuple(f"N{i:02}" for i in range(1, 16)) + ("P17", "L04")
        rows = exact_inventory(review.get("cases"), "case_id", expected, "diagnostic review case")
        for name, row in rows.items():
            require(row.get("status") == "passed" and row.get("source_span_checked") is True
                    and row.get("diagnostic_side_checked") is True and row.get("phase_and_code_checked") is True,
                    "Diagnostic primary span/side/phase/code obligations are unresolved: " + name)
            require(type(row.get("observed_diagnostic")) is dict and type(row.get("frozen_expectation")) is dict
                    and type(row.get("interpretation")) is str and row["interpretation"].strip(),
                    "Diagnostic review needs actual diagnostics, exact frozen references and explicit interpretation")
            observation, _ = self.read(row.get("observation"))
            require(pointer(observation, row.get("observation_pointer")) == row["observed_diagnostic"],
                    "Reviewed diagnostic differs from the actual retained source/Agent observation")
            expected_record = row.get("frozen_reference")
            frozen_path = identified(expected_record, self.repository)
            require(frozen_path.relative_to(self.repository).as_posix() in {
                BASE + "/acceptance.json", BASE + "/draft2-supplements/acceptance.json", BASE + "/draft2-supplements/protocol-cases.json"},
                "Diagnostic interpretation is not bound to an adopted expectation")
            require(pointer(json_file(frozen_path), row.get("frozen_pointer")) == row["frozen_expectation"],
                    "Reviewed diagnostic expectation differs from its frozen bytes")
            require(type(row["observed_diagnostic"].get("phase")) is str and type(row["observed_diagnostic"].get("code")) is str,
                    "Reviewed diagnostic omits its actual phase and code")
            require(row.get("valid_until_side_used_as_diagnostic_side") is False,
                    "A retained valid-prefix side cannot substitute for the diagnostic side")
        return {"individually_reviewed_diagnostics": len(rows)}

    def source_execution(self):
        record = self.role("source_execution")
        corpus = self.corpus(self.field(record, "corpus", "source execution"))
        rates = self.rates(self.field(record, "rates", "source execution"), record.get("rate_applicability"))
        diagnostics = self.diagnostics(self.field(record, "diagnostics", "source execution"), corpus["report"])
        return {"corpus": corpus, "rates": rates, "diagnostics": diagnostics}

    def agent(self, name):
        record = self.role(name)
        producer, producer_path, producer_envelope = self.execution(self.field(record, "producer", name), name,
            "tools/build_reach_agent_delivery.py", compatible_roles=("agent_workflow", "agent_delivery"))
        self.component(producer, producer_path, "ontokin.reach-agent-delivery-workflow/0.1")
        require(producer.get("protocol") == "ontokin.agent/0.6" and producer.get("target_contract") == "ontokin.glb/0.6"
                and producer.get("complete_agent_delivery_corpus") is True, "Actual Agent/0.6 workflow/delivery corpus is incomplete")
        rows = exact_inventory(producer.get("deliveries"), "case_id", AGENT_ARTIFACTS, "retrieved Agent artifact")
        audit, audit_path, audit_envelope = self.execution(self.field(record, "audit", name), name,
            "tools/audit_reach_agent_delivery.py", compatible_roles=("agent_workflow", "agent_delivery"))
        self.component(audit, audit_path, "ontokin.reach-agent-delivery-audit/0.1")
        require(audit.get("agent_transport_audited") is True and audit.get("frozen_protocol_step_count") == 42
                and audit.get("additional_sibling_source_reads") == 10
                and audit.get("q02_accepted_work_cancellation") == audit.get("q22_same_project_repair") == "passed"
                and set(audit.get("retrieved_cases", [])) == set(AGENT_ARTIFACTS), "Independent Agent audit omits mandatory actual work")
        require(clock(producer_envelope["finished_at_utc"]) <= clock(audit_envelope["started_at_utc"]),
                "Agent audit preceded completion of its producer")
        # Re-read all identities the independent transport reader actually consumed.
        # Their path base is the producer, never a substitute local artifact tree.
        members = audit.get("evidence_members")
        require(type(members) is list and members, "Agent audit did not retain its complete read member inventory")
        member_map = input_map(members)
        require("producer-record.json" in member_map and member_map["producer-record.json"]["sha256"] == file_record(producer_path)["sha256"],
                "Agent audit belongs to another actual producer record")
        for row in members:
            self.file(row, base=producer_path.parent)
        wanted = {row["id"] for row in self.mapping["protocol_records"]}
        require(set(audit.get("frozen_protocol_steps", [])) == wanted and len(audit["frozen_protocol_steps"]) == 42,
                "Independent audit omitted or duplicated a frozen LP step")
        for identity in wanted:
            self.protocol_records[identity] = "passed"
        for row in self.mapping["additional_protocol_records"]:
            self.protocol_records[row["id"]] = "passed"
        frozen = {row["id"]: row for row in self.mapping["source_cases"]}
        for case_id, row in rows.items():
            require(row.get("status") == "passed" and row.get("program_revision") == frozen[case_id]["program_revision"],
                    "An actual Agent artifact failed or changed frozen source")
            check_options(case_id, row.get("options"))
            artifact = self.file(row.get("artifact"), base=producer_path.parent)
            export, _ = self.read(row.get("export_report"), base=producer_path.parent)
            check_export(export, artifact, case_id, frozen[case_id]["program_revision"])
            for identity in ("project_id", "run_id", "artifact_id"):
                require(type(row.get(identity)) is str and row[identity], "Agent artifact lacks actual " + identity)
        self.context["agent_producer"] = (producer, producer_path)
        self.context["agent_rows"] = rows
        return {"actual_retrieved_artifacts": len(rows), "fixed_protocol_steps": 42, "additional_protocol_records": 12,
                "actual_exchanges": audit.get("actual_exchange_count"), "independent_audit": file_record(audit_path, audit_path.relative_to(self.root).as_posix())}

    def source_artifacts(self, execution):
        report, path, _ = self.execution(execution, "source_native", "tools/build_reach_source_artifacts.py")
        self.component(report, path, "ontokin.reach-source-delivery/0.1")
        require(report.get("source_kind") == "source_component" and report.get("complete_source_delivery_corpus") is True,
                "All required complete source recordings must actually pass")
        rows = exact_inventory(report.get("deliveries"), "case_id", SOURCE_ARTIFACTS, "source artifact")
        frozen = {row["id"]: row for row in self.mapping["source_cases"]}
        for case_id, row in rows.items():
            require(row.get("status") == "passed" and row.get("program_revision") == frozen[case_id]["program_revision"],
                    "A source recording failed or changed its frozen source")
            require(row.get("max_operations") == 100000 and type(row.get("operations")) is int
                    and 0 <= row["operations"] <= 100000 and type(row.get("work", {}).get("cache_entries")) is int
                    and 0 <= row["work"]["cache_entries"] <= 256, "A recording raised or exceeded its work/cache limit")
            check_options(case_id, row.get("options"))
            artifact = self.file(row.get("artifact"), base=path.parent)
            export, _ = self.read(row.get("export_report"), base=path.parent)
            check_export(export, artifact, case_id, frozen[case_id]["program_revision"])
        self.context["source_producer"] = (report, path)
        self.context["source_rows"] = rows
        return report, path

    def destination(self, name, *, agent=False):
        record = self.role(name)
        source_kind = "agent_retrieved_artifact" if agent else "source_component"
        cases = AGENT_ARTIFACTS if agent else SOURCE_ARTIFACTS
        native_name = "agent_native" if agent else "source_native"
        if not agent and "source_producer" not in self.context:
            native_record = self.role("source_native")
            self.source_artifacts(self.field(native_record, "producer", "source native"))
        needed(("agent_producer" if agent else "source_producer") in self.context,
               "Destination evidence needs its independently checked actual producer first")
        producer, producer_path = self.context["agent_producer" if agent else "source_producer"]
        producer_rows = self.context["agent_rows" if agent else "source_rows"]
        report, path, envelope = self.execution(self.field(record, "destination", name), name,
            "tools/verify_reach_destinations.py", compatible_roles=(native_name, "agent_browser" if agent else "source_browser"))
        self.component(report, path, "ontokin.reach-destination-run/0.1")
        require(report.get("source_kind") == source_kind and report.get("complete_native_corpus") is True
                and set(report.get("selected_cases", [])) == set(cases) and len(report["selected_cases"]) == len(cases),
                "Destination corpus is incomplete or has substituted provenance")
        producer_copy = relative_file(path.parent, "producer-record.json")
        require(read_raw(producer_copy) == read_raw(producer_path), "Destination used a different actual producer record")
        native, native_path = self.read(report.get("native_report"), base=path.parent)
        require(native.get("schema_version") == "ontokin.reach-native-validation/0.1" and native.get("status") == "passed"
                and native.get("failed_cases") == 0 and native.get("source_kind") == source_kind,
                "Actual native supplied-byte validation failed")
        native_env = native.get("execution", {})
        require(native_env.get("node", "").startswith("v22.")
                and native_env.get("dependencies") == {"three": "180", "gltf_validator": NODE_PINS["gltf-validator"]},
                "Actual Three/Khronos/Node versions do not match the verification pins")
        for relative, identity in native.get("implementation_inputs", {}).items():
            actual = file_record(relative_file(self.repository, relative), relative)
            require(actual["sha256"] == identity.get("sha256") and actual["byte_length"] == identity.get("bytes"),
                    "Native verifier used different implementation inputs")
        require(native.get("implementation_inputs"), "Native verifier implementation closure is missing")
        manifest_path = relative_file(path.parent, "native-input.json")
        manifest = json_file(manifest_path)
        require(native.get("manifest") == {"sha256": file_record(manifest_path)["sha256"], "bytes": manifest_path.stat().st_size},
                "Native report identifies another manifest")
        planned = exact_inventory(manifest.get("cases"), "case_id", cases, "native input artifact")
        actual = exact_inventory(native.get("cases"), "case_id", cases, "native result artifact")
        stage_rows = unique_rows(report.get("stages"), "path", "destination process stage")
        expected_stages = {"stages/native.json", *("stages/" + kind + "-" + case + ".json" for case in cases for kind in ("plan", "reference"))}
        if report.get("browser_requested") is True:
            expected_stages.add("stages/browser.json")
        require(set(stage_rows) == expected_stages, "Destination omitted or duplicated an actual process stage")
        for relative, stage_row in stage_rows.items():
            stage = json_file(relative_file(path.parent, relative))
            require(stage_row.get("returncode") == stage.get("returncode") == 0 and stage.get("provider") == "local"
                    and clock(stage.get("started_at")) <= clock(stage.get("finished_at")), "A destination subprocess failed or lacks execution provenance")
            self.file(stage.get("log"), base=(path.parent / relative).parent)
        frozen = frozen_cases(self.repository)
        result = {}
        for case_id in cases:
            item, row, produced = planned[case_id], actual[case_id], producer_rows[case_id]
            require(row.get("status") == "passed" and item.get("program_revision") == row.get("program_revision") == produced["program_revision"],
                    "Native result/source/artifact identities differ")
            artifact = self.file(item.get("artifact"), base=path.parent)
            require(file_record(artifact)["sha256"] == normalize_record(produced["artifact"])["sha256"]
                    and item["artifact"] == row.get("artifact") and item["reference"] == row.get("reference"),
                    "Native verification substituted different artifact/reference bytes")
            reference, reference_path = self.read(item.get("reference"), base=path.parent)
            require(reference.get("schema_version") == "ontokin.reach-native-reference/0.1"
                    and reference.get("artifact_sha256") == file_record(artifact)["sha256"], "Native reference is not bound to actual supplied bytes")
            source_units = frozen[case_id][1].get("source_units", frozen[case_id][1].get("source_manifest", {}).get("units"))
            expected_sources = {unit["source_id"]: unit["source_revision"] for unit in source_units}
            sources = unique_rows(item.get("sources"), "source_id", "native source unit")
            require(set(sources) == set(expected_sources), "Native source closure omitted or added a unit")
            for source_id, source in sources.items():
                unit_path = self.file(source, base=path.parent)
                require(file_record(unit_path)["sha256"] == expected_sources[source_id], "Native source bytes changed")
            expected = frozen[case_id][1].get("expected", frozen[case_id][1])
            nodes = unique_rows(reference.get("expected_nodes"), "path", "native source object")
            require(set(nodes) == set(expected["expected_object_paths"]), "Native reference dropped an expected source object")
            issues = row.get("khronos", {}).get("issues", {})
            require(issues.get("numErrors") == issues.get("numWarnings") == 0 and issues.get("truncated") in (None, False),
                    "Khronos errors, warnings or truncated results remain unexplained")
            check_native_samples(reference, artifact, frozen[case_id], endpoint(case_id))
            schedule = row.get("schedule", {})
            require(schedule.get("interiors_per_interval") == 8 and schedule.get("source_boundary_sides") == 2
                    and row.get("samples") == len(reference["samples"])
                    and row.get("geometry", {}).get("carriers") == len(nodes), "Native observation schedule or complete geometry closure differs")
            for observed, tolerance in (("max_position_error_upper_m", .001), ("max_rotation_error_upper_rad", .001),
                                        ("max_site_error_upper_m", .001), ("max_world_vertex_error_upper_m", .001),
                                        ("max_stored_clock_error_upper_s", .000001)):
                require(type(row.get(observed)) in (int, float) and 0 <= row[observed] <= tolerance,
                        "Actual native observations exceed their adopted limit: " + observed)
            result[case_id] = {"artifact_sha256": file_record(artifact)["sha256"], "samples": len(reference["samples"]), "carriers": len(nodes)}
        self.context[native_name] = (report, path, native, planned, result)
        return {"artifacts": len(result), "cases": result, "native_report": file_record(native_path, native_path.relative_to(self.root).as_posix())}

    def browser(self, name, *, agent=False):
        native_name = "agent_native" if agent else "source_native"
        self.destination(name, agent=agent)
        report, path, native, planned, details = self.context[native_name]
        require(report.get("browser_requested") is True and report.get("complete_browser_corpus") is True,
                "The complete browser corpus did not actually execute")
        browser, browser_path = self.read(report.get("browser_report"), base=path.parent)
        require(browser.get("schema_version") == "ontokin.reach-browser-validation/0.1" and browser.get("status") == "passed"
                and browser.get("complete_browser_corpus") is True, "Actual browser validation failed or is incomplete")
        expected = AGENT_BROWSER if agent else SOURCE_BROWSER
        cases = exact_inventory(browser.get("cases"), "case_id", expected, "actual browser case")
        playback = exact_inventory(browser.get("playback"), "case_id", expected, "browser playback case")
        env = browser.get("environment", {})
        require(env.get("node", "").startswith("v22.") and env.get("browser") == "141.0.7390.37"
                and env.get("dependencies") == {key: NODE_PINS[key] for key in ("three", "playwright", "esbuild")}
                and type(browser.get("webgl")) is dict, "Actual browser/renderer/tool pins are absent or changed")
        require(all(browser.get(key) == [] for key in ("page_errors", "console_errors", "failed_requests", "network_requests")),
                "Browser loading produced an error or unrecorded external request")
        captures = browser.get("captures")
        require(type(captures) is list and len(captures) == 3 * len(expected), "Required fresh browser captures are incomplete")
        seen = set()
        for capture in captures:
            key = (capture.get("case_id"), capture.get("view"))
            require(key not in seen and key[0] in cases and key[1] in {"front", "side", "intermediate"}, "Duplicate or unexpected browser capture")
            seen.add(key)
            image_path = relative_file(browser_path.parent, capture.get("path"))
            identity = file_record(image_path, image_path.relative_to(self.root).as_posix())
            require(identity["path"] in self.files and self.files[identity["path"]] == identity
                    and identity["sha256"] == capture.get("sha256") and read_raw(image_path)[:8] == b"\x89PNG\r\n\x1a\n",
                    "Browser capture bytes changed or are not an actual PNG")
            require(capture.get("program_revision") == planned[key[0]]["program_revision"]
                    and capture.get("artifact_sha256") == details[key[0]]["artifact_sha256"], "Capture identifies another source or artifact")
            capture_time = capture.get("time_seconds")
            require(type(capture_time) in (int, float) and 0 <= capture_time <= float(endpoint(key[0])), "Invalid captured playback clock")
            if key[1] == "intermediate":
                require(0 < capture_time < float(endpoint(key[0])), "Intermediate capture does not show intermediate playback")
                if key[0] == "L01":
                    require(.5 < capture_time < 1.5, "L01 intermediate capture must show the pause")
                if key[0] == "L02":
                    require(capture_time > .5, "L02 intermediate capture precedes the new owner")
                if key[0] in {"L03", "P16"}:
                    require(capture_time > 2, "Intermediate capture precedes the required handoff/release")
            self.captures[identity["path"]] = {"identity": identity, "record": capture,
                "report": file_record(browser_path, browser_path.relative_to(self.root).as_posix())}
        require(seen == {(case, view) for case in expected for view in ("front", "side", "intermediate")}, "Browser capture roles are incomplete")
        for case_id, row in cases.items():
            require(row.get("status") == "passed" and playback[case_id].get("stable_pause_across_frames") is True
                    and playback[case_id].get("stopped_at_seconds") == float(endpoint(case_id)), "Actual playback controls or end state failed")
            readback_path = self.file(row.get("readback"), base=browser_path.parent)
            lines = read_raw(readback_path).splitlines()
            require(len(lines) == row["readback"].get("samples") == len(row.get("comparisons", [])), "Browser actual readback closure differs")
            if case_id == "L01":
                needed(any(item.get("purpose") == "resumed moving action" and item.get("time_seconds", 0) > 1.5
                           for item in row.get("action_checks", [])), "L01 lacks its separately observed resumed moving check")
        native_descriptor = normalize_record(report["native_report"])
        require(browser.get("native_report") == {"sha256": native_descriptor["sha256"], "bytes": native_descriptor["byte_length"]}
                and browser.get("manifest") == native.get("manifest"), "Browser observations name different native evidence")
        for relative, identity in browser.get("implementation_inputs", {}).items():
            current = file_record(relative_file(self.repository, relative))
            require(identity == {"sha256": current["sha256"], "bytes": current["byte_length"]}, "Browser verifier input changed")
        needed(bool(browser.get("implementation_inputs")), "Browser implementation inventory is absent")
        return {"artifacts": len(cases), "actual_captures": len(captures), "actual_browser": env["browser"]}

    def hostile_inputs(self):
        record = self.role("hostile_inputs")
        criteria, _ = self.review(self.field(record, "criteria", "hostile input"),
            "ontokin.reach-hostile-criteria/0.1", repository_bound=True)
        needed("mapping_review" in self.context, "Hostile criteria need the published mapping applicability review")
        frozen = {row["id"]: row for row in self.mapping["probe_records"]}
        criterion_rows = exact_inventory(criteria.get("probes"), "id", frozen, "published probe criterion")
        report, path, execution = self.execution(self.field(record, "execution", "hostile input"),
            "hostile_inputs", "tools/run_reach_hostile_probes.py")
        self.component(report, path, "ontokin.reach-hostile-execution/0.1")
        require(clock(criteria["reviewed_at_utc"]) <= clock(execution["started_at_utc"]), "Hostile acceptance criteria were chosen after execution")
        actual = unique_rows(report.get("probes"), "id", "actual hostile subtype")
        require(set(actual) <= set(frozen), "Unknown hostile subtype cannot substitute for an adopted probe")
        issues = []
        for identity, row in actual.items():
            try:
                criterion, mapped = criterion_rows[identity], frozen[identity]
                binding = digest(canonical(mapped))
                require(criterion.get("mapping_record_sha256") == row.get("mapping_record_sha256") == binding,
                        "Actual hostile subtype is not bound to its exact adopted mapping row")
                producers = self.context["mapping_review"].get("probe_producers", {}).get(identity, mapped.get("producer_functions", []))
                needed(bool(producers), "This hostile subtype has no published actual release producer")
                require(criterion.get("producer_functions") == producers and row.get("producer_function") in producers,
                        "Hostile execution used an unreviewed producer")
                require(set(criterion.get("source_cases", [])) == set(mapped["source_cases"])
                        and row.get("case_id") in mapped["source_cases"], "Hostile execution substituted a different source case")
                needed(row.get("executed") is True, "Required hostile subtype did not execute")
                require(row.get("status") == "passed" and row.get("criterion_sha256") == digest(canonical(criterion)),
                        "An executed hostile subtype failed or changed its published criterion")
                observation, _ = self.read(row.get("observation"), base=path.parent)
                require(observation.get("schema_version") == "ontokin.reach-hostile-observation/0.1"
                        and observation.get("probe_record_id") == identity and observation.get("executed") is True,
                        "Probe result lacks its actual individual observation")
                compare_observation(observation, criterion.get("assertions"))
                kind = criterion.get("kind")
                require(kind in {"artifact_mutation", "identity_mutation", "protocol", "resource"}, "Unreviewed hostile probe kind")
                for member in row.get("members", []):
                    self.file(member, base=path.parent)
                needed(bool(row.get("members")), "Probe omitted its raw request/response or supplied-byte evidence")
                if kind in {"artifact_mutation", "resource"}:
                    baseline = self.file(row.get("baseline_artifact"), base=path.parent)
                    changed = self.file(row.get("mutated_artifact"), base=path.parent)
                    valid, _ = self.read(row.get("baseline_validation"), base=path.parent)
                    require(valid.get("schema_version") == "ontokin.reach-hostile-baseline/0.1"
                            and valid.get("status") == "passed" and valid.get("artifact_sha256") == file_record(baseline)["sha256"]
                            and valid.get("independent_supplied_byte_reader") == "ontokin.reach_conformance.validate_recording_evidence"
                            and valid.get("complete_source_object_geometry_history_closure") is True,
                            "Corrupt-byte probe did not begin with an independently valid identified artifact")
                    _, mutated = check_mutation(baseline, changed, observation, criterion)
                    require(type(criterion.get("expected_code")) is str and criterion["expected_code"]
                            and type(criterion.get("expected_stage")) is str and criterion["expected_stage"]
                            and observation.get("rejection_code") == criterion["expected_code"]
                            and observation.get("rejection_stage") == criterion["expected_stage"]
                            and observation.get("accepted") is False and observation.get("unrelated_failure") is False,
                            "Corrupt-byte probe failed at an unrelated parse/object/resource stage")
                    allocations = observation.get("allocation_counts")
                    require(type(allocations) is dict and allocations and all(type(value) is int and value >= 0 for value in allocations.values()),
                            "Required actual preflight allocation counts are missing")
                    if identity == "Q04.declared_10001_time_keys":
                        sampler = mutated["animations"][0]["samplers"][0]
                        require(mutated["accessors"][sampler["input"]]["count"] == 10001
                                and allocations.get("decoded_accessors") == 0, "Q04 did not reject 10001 declared keys before decoding")
                    if identity == "Q05.shared_97_by_3000_pose_expansion":
                        animation = mutated["animations"][0]
                        index = animation["samplers"][0]["input"]
                        require(len(mutated["nodes"]) == 97 and mutated["scenes"][0]["nodes"] == list(range(97))
                                and len(animation["channels"]) == 194 and mutated["accessors"][index]["count"] == 3000
                                and all(item["input"] == index for item in animation["samplers"])
                                and file_record(changed)["byte_length"] <= 64 * 1024 * 1024
                                and allocations.get("expanded_pose_copies") == 0 and observation.get("declared_baked_poses") == 291000,
                                "Q05 did not preserve the complete 97-object shared-accessor aggregate preflight")
                if identity.startswith(("Q01.", "Q02.")):
                    statuses = observation.get("observed_operation_statuses")
                    require(type(statuses) is list and "accepted" in statuses and "running" in statuses
                            and statuses[-1] == "cancelled" and statuses.index("accepted") < statuses.index("running")
                            and observation.get("effects_committed") is False and observation.get("accepted_source_unchanged") is True
                            and observation.get("prior_successes_unchanged") is True and observation.get("new_success_ids") == [],
                            "Cancellation was not observed after accepted/running work or committed a forbidden effect")
                self.probe_records[identity] = {"status": "passed", "observation": file_record(
                    self.file(row["observation"], base=path.parent), self.file(row["observation"], base=path.parent).relative_to(self.root).as_posix()),
                    "criterion_sha256": digest(canonical(criterion))}
            except MissingEvidence as error:
                self.probe_records[identity] = {"status": "pending", "issues": [str(error)]}
                issues.append(("pending", identity + ": " + str(error)))
            except (ValueError, KeyError, TypeError, IndexError, OSError) as error:
                self.probe_records[identity] = {"status": "failed", "issues": [str(error)]}
                issues.append(("failed", identity + ": " + str(error)))
        require(not any(state == "failed" for state, _ in issues), "; ".join(message for state, message in issues if state == "failed"))
        needed(set(actual) == set(frozen) and not issues, "Missing or unexecuted exact hostile subtypes: " +
               ", ".join(sorted(set(frozen) - set(actual)) + [message for _, message in issues]))
        return {"actual_probe_subtypes": len(actual), "probe_families": len(PROBES), "criteria": digest(canonical(criteria))}

    def visual_review(self):
        record = self.role("visual_review")
        value, _ = self.review(self.field(record, "review", "visual"), "ontokin.reach-visual-review/0.1")
        needed(len(self.captures) == 54, "Both complete browser roles must retain their 54 identified captures before review")
        rows = unique_rows(value.get("captures"), "path", "actual visual capture review")
        require(set(rows) <= set(self.captures), "A visual review names an unproduced or different image")
        for name, row in rows.items():
            captured = self.captures[name]
            require(normalize_record(row.get("image")) == captured["identity"]
                    and normalize_record(row.get("browser_report")) == captured["report"], "Visual review identifies different image/browser bytes")
            needed(row.get("actually_opened") is True, "A required PNG was never actually opened for review: " + name)
            require(row.get("status") == "passed" and row.get("defects") == []
                    and type(row.get("observations")) is str and row["observations"].strip()
                    and type(row.get("visibility_limits")) is list, "Visual review omits concrete observations, limits or unresolved defects")
            capture = captured["record"]
            require(all(row.get(key) == capture.get(key) for key in ("case_id", "source_kind", "view", "program_revision", "artifact_sha256", "time_seconds", "side")),
                    "Visual review substituted another source/artifact/view/time")
            require(clock(row.get("opened_at_utc")) <= clock(value["reviewed_at_utc"]), "Image review clock is inconsistent")
        needed(set(rows) == set(self.captures), "Not every fresh required source and Agent PNG has an actual review")
        return {"actually_opened_captures": len(rows), "reviewer": value["reviewer"], "reviewed_at_utc": value["reviewed_at_utc"]}

    def inherited_workflows(self):
        record = self.role("inherited_workflows")
        local, path, envelope = self.execution(self.field(record, "local", "inherited"), "inherited_workflows", "tools/check_local.py")
        self.component(local, path, "ontokin.local-checks/0.1")
        require("--full" in envelope["command"] and "--force-agent" in envelope["command"]
                and local.get("profile") == "full" and local.get("selected_roles") == ["core", "visual", "force-agent"]
                and local.get("source_unchanged") is True and local.get("remote_checks_executed") is False
                and local.get("not_executed_steps") == [], "Inherited full local workflows did not actually complete")
        wanted = {"force-agent-tools", "unit-tests", "source", "agent", "construction", "surface", "impulse", "documents",
                  "force-agent-tests", "force-agent-build", "force-agent-audit", "node-tools", "browser-ready", "prototype-build",
                  "prototype-format", "viewer-build", "visual-build", "visual-format", "visual-browser", "agent-demo-browser", "construction-demo-browser"}
        for prefix in ("surface-native", "surface-agent", "impulse-agent"):
            wanted.update(prefix + "-" + suffix for suffix in ("build", "format", "browser"))
        for prefix in ("agent-demo", "construction-demo"):
            wanted.update(prefix + "-" + suffix for suffix in ("build", "format"))
        steps = exact_inventory(local.get("steps"), "id", wanted, "inherited local step")
        require(set(local.get("planned_steps", [])) == wanted and len(local["planned_steps"]) == len(wanted), "Inherited planned workflow changed")
        for identity, step in steps.items():
            require(step.get("status") == "passed" and type(step.get("returncode")) is int and step["returncode"] == 0
                    and clock(step.get("started_at")) <= clock(step.get("finished_at")), "An executed inherited step failed: " + identity)
            log = {"path": step.get("log"), **step.get("log_identity", {})}
            self.file(log, base=path.parent)
            for report in step.get("reports", []):
                self.file(report, base=path.parent)
            if identity in {"unit-tests", "force-agent-tests"}:
                result = step.get("test_execution", {})
                passed = "complete_regression_passed" if identity == "unit-tests" else "complete_cohort_passed"
                require(result.get(passed) is True and result.get("skipped") == result.get("expected_failures") == 0
                        and type(result.get("tests_run")) is int and result["tests_run"] > 0, "Inherited tests used skips or exemptions")
        force, force_path, force_envelope = self.execution(self.field(record, "force", "inherited"),
            "inherited_workflows", "tools/run_force_conformance.py")
        require("audit" in force_envelope["command"], "Inherited force evidence was not independently audited")
        self.component(force, force_path, "ontokin.force-local-conformance/0.1")
        require(force.get("executed") is True and force.get("source_stable_during_audit") is True
                and force.get("summary", {}).get("full_force_release_complete") is True
                and force.get("summary", {}).get("all_required_roles_passed") is True,
                "Complete current inherited finite force release is not established")
        require(force.get("implementation") == self.current["implementation"], "Inherited force audit identifies another implementation")
        cases = exact_inventory(force.get("cases"), "id", [f"F{i:02}" for i in range(1, 13)], "inherited force case")
        require(all(row.get("status") == "passed" for row in cases.values()) and all(row.get("status") == "passed" for row in force.get("roles", [])),
                "An inherited force requirement or mandatory role remains unresolved")
        manifest_path = self.file(self.field(record, "force_manifest", "inherited"))
        require(file_record(manifest_path)["sha256"] == force.get("evidence_manifest_sha256"),
                "Retained inherited force manifest differs from the actual audited input")
        manifest = json_file(manifest_path)
        for member in manifest.get("files", []):
            self.file(member, base=manifest_path.parent)
        needed(bool(manifest.get("files")), "Inherited force audit omitted its retained read inputs")
        return {"actual_local_steps": len(steps), "actual_force_requirements": len(cases), "force_audit": file_record(force_path, force_path.relative_to(self.root).as_posix())}

    def final_closure(self):
        needed("mapping_publication" in self.context, "Acceptance mapping publication has not been independently observed")
        for start in self.execution_starts:
            require(self.context["mapping_publication"] <= start, "Acceptance executed before its mapping/criteria publication")
        commit = self.context["publication_commit"]
        for name in self.repository_reviews:
            require(git(["show", commit + ":" + name], self.repository) == read_raw(self.repository / name),
                    "A required applicability/criteria review was not published before acceptance: " + name)
        for member in self.files.values():
            identified(member, self.root)
        after = source_identity(self.repository)
        require(stable_source(self.current, after), "Eligible repository inputs changed during the independent audit")
        return after

    def integration(self):
        record = self.role("input_closure")
        result, _ = self.read(self.field(record, "integration", "resulting-main"))
        require(result.get("schema_version") == "ontokin.reach-integration-observation/0.1"
                and result.get("repository") == "https://github.com/Omegapy/OntoKin" and result.get("pull_request") == 27
                and result.get("actual_remote_observation") is True and result.get("observed_ref") == "refs/heads/main",
                "Integration lacks the actual protected PR/main observation")
        require(result.get("expected_head_protection_used") is True and result.get("lease_reconciled") is True,
                "Integration did not reconcile the required observed-head lease/protection")
        require(result.get("commit") == self.current["git"]["commit"] and result.get("tree") == self.current["git"]["tree"]
                and result.get("input_inventory_sha256") == self.current["input_inventory_sha256"],
                "Actual resulting main differs from the audited input bytes")
        observed = clock(result.get("observed_at_utc"))
        required = {"source": "tools/run_reach_source_corpus.py", "regression": "tools/run_reach_regression.py",
                    "agent": "tools/build_reach_agent_delivery.py", "agent_audit": "tools/audit_reach_agent_delivery.py",
                    "delivery": "tools/build_reach_source_artifacts.py", "source_native": "tools/verify_reach_destinations.py",
                    "agent_native": "tools/verify_reach_destinations.py"}
        executions = result.get("resulting_main_checks")
        require(type(executions) is dict and set(executions) <= set(required), "Unknown resulting-main check")
        checked = {key[0]: (key, value) for key, value in self.envelopes.items()}
        for name, reference in executions.items():
            path = self.file(reference)
            needed(str(path) in checked, "A resulting-main execution was not included in the independently checked role evidence")
            key, (_, _, envelope) = checked[str(path)]
            require(key[2] == required[name] and envelope["source_before"]["git"] == self.current["git"]
                    and envelope["source_after"]["git"] == self.current["git"]
                    and clock(envelope["started_at_utc"]) >= observed, "A relevant check was not freshly executed on actual resulting main")
            if name.endswith("native"):
                require(envelope["role"] in (name, name.replace("native", "browser")), "Resulting-main native provenance was substituted")
        needed(set(executions) == set(required), "Relevant resulting-main source/Agent/delivery/native/regression checks are incomplete")
        return {"commit": result["commit"], "tree": result["tree"], "fresh_resulting_main_checks": len(executions)}


def assessed(name, action):
    row = {"id": name, "status": "running", "executed_external_tools": False, "issues": []}
    try:
        row["details"] = action()
        row["status"] = "passed"
    except MissingEvidence as error:
        row.update(status="pending", reason_kind="missing_or_stale", issues=[str(error)])
    except Exception as error:
        row.update(status="failed", reason_kind="contradictory_or_invalid", issues=[f"{type(error).__name__}: {error}"])
    return row


def reconcile_rows(auditor, roles, closure, final):
    """Literal R/Q dependencies, never a wrapper/count/support-test shortcut."""
    by_role = {row["id"]: row["status"] for row in roles}
    common = [closure["status"], final["status"]]
    methods = lambda row: [combine(auditor.tests.get(name, [])) for name in row.get("test_ids", [])]
    sources = lambda row: [auditor.source_cases.get(name, "pending") for name in row.get("source_cases", [])]
    role_states = lambda row: [by_role.get(name, "pending") for name in row.get("roles", [])]
    probes = []
    for row in auditor.mapping["probe_records"]:
        actual = auditor.probe_records.get(row["id"], {"status": "pending", "issues": ["No actual required probe observation"]})
        probes.append({"id": row["id"], "probe_id": row["probe_id"], "mapping_record_sha256": digest(canonical(row)),
            "actual_observation": actual, "status": combine([*common, actual["status"], *methods(row), *sources(row), *role_states(row)])})
    by_probe = {row["id"]: row["status"] for row in probes}
    protocols = []
    for row in [*auditor.mapping["protocol_records"], *auditor.mapping["additional_protocol_records"]]:
        protocols.append({"id": row["id"], "mapping_record_sha256": digest(canonical(row)),
            "actual_observation_status": auditor.protocol_records.get(row["id"], "pending"),
            "status": combine([*common, auditor.protocol_records.get(row["id"], "pending"), *methods(row), *sources(row), *role_states(row)])})
    by_protocol = {row["id"]: row["status"] for row in protocols}
    families = []
    for row in auditor.mapping["probes"]:
        families.append({"id": row["id"], "mapping_record_sha256": digest(canonical(row)),
            "required_probe_records": row["probe_record_ids"], "status": combine([*common, *methods(row), *sources(row),
                *role_states(row), *(by_probe.get(name, "pending") for name in row["probe_record_ids"])])})
    by_family = {row["id"]: row["status"] for row in families}
    requirements = []
    for row in auditor.mapping["requirements"]:
        required_protocols = [name for name in by_protocol if any(name.startswith(case + ".") for case in row.get("required_protocol_cases", []))]
        requirements.append({"id": row["id"], "mapping_record_sha256": digest(canonical(row)), "required_roles": row["roles"],
            "required_tests": row["test_ids"], "required_probe_ids": row["probe_ids"], "required_protocol_records": required_protocols,
            "status": combine([*common, *methods(row), *sources(row), *role_states(row),
                *(by_family.get(name, "pending") for name in row["probe_ids"]), *(by_protocol[name] for name in required_protocols)])})
    return requirements, families, probes, protocols


def audit_release(evidence=None, *, repository=ROOT):
    auditor = Auditor(evidence, repository=repository)
    closure = assessed("artifact_closure", auditor.closure)
    actions = [("input_closure", auditor.input_closure), ("source_execution", auditor.source_execution),
        ("compatibility", auditor.compatibility), ("agent_workflow", lambda: auditor.agent("agent_workflow")),
        ("agent_delivery", lambda: auditor.agent("agent_delivery")), ("source_native", lambda: auditor.destination("source_native")),
        ("agent_native", lambda: auditor.destination("agent_native", agent=True)),
        ("source_browser", lambda: auditor.browser("source_browser")), ("agent_browser", lambda: auditor.browser("agent_browser", agent=True)),
        ("hostile_inputs", auditor.hostile_inputs), ("visual_review", auditor.visual_review), ("inherited_workflows", auditor.inherited_workflows)]
    roles = [assessed(name, action) for name, action in actions]
    final = assessed("publication_and_stable_bytes", auditor.final_closure)
    requirements, probes, records, protocols = reconcile_rows(auditor, roles, closure, final)
    state = combine([closure["status"], final["status"], *(row["status"] for row in [*roles, *requirements, *probes, *records, *protocols])])
    acceptance = state == "passed"
    integration = assessed("resulting_main", auditor.integration)
    complete = acceptance and integration["status"] == "passed"
    if integration["status"] == "failed":
        state = "failed"
        acceptance = False
    counts = dict(Counter(row["status"] for row in requirements))
    return {"schema_version": AUDIT_SCHEMA, "executed": True, "generated_at_utc": utc(), "status": state,
        "profile": "planar-reach-0.1", "language_contract": "OK-LANG-006/0.1.0", "agent_contract": "ontokin.agent/0.6",
        "export_contract": "ontokin.glb/0.6", "implementation": auditor.current["implementation"],
        "source_before": auditor.current, "source_after": final.get("details"), "source_stable_during_audit": final["status"] == "passed",
        "mapping_sha256": MAPPING_SHA256, "adoption_sha256": ADOPTION_SHA256,
        "evidence_manifest": None if auditor.path is None else file_record(auditor.path),
        "artifact_closure": closure, "roles": roles, "requirements": requirements, "probes": probes,
        "probe_records": records, "protocol_records": protocols, "final_closure": final, "integration": integration,
        "summary": {"requirements": 12, "requirement_counts": counts, "mandatory_roles": 12, "probe_families": 22,
            "required_probe_subtypes": 43, "fixed_protocol_records": 42, "additional_protocol_records": 12,
            "source_cases": 45, "source_artifacts": 28, "agent_artifacts": 10, "required_browser_captures": 54},
        "release_acceptance": acceptance, "finite_release_complete": complete, "full_product_goal_completed": False,
        "executed_external_tools": False,
        "limitations": ["Retained local execution records are reproducible evidence, not cryptographic remote attestation.",
            "Actual opened-image review is an identified observation, never inferred from screenshot creation or a machine pass label.",
            "Premerge acceptance permits protected integration; finite release completion additionally requires actual resulting-main checks.",
            "Broader authoring productivity and remaining GOAL domains are not certified by this finite release."]}


def evidence_template(*, repository=ROOT):
    mapping = load_contract(repository)
    current = source_identity(repository)
    return {"schema_version": EVIDENCE_SCHEMA, "implementation": current["implementation"],
        "input_inventory_sha256": current["input_inventory_sha256"], "mapping": file_record(Path(repository) / MAP_PATH, MAP_PATH),
        "roles": {}, "files": [], "release_acceptance": False, "full_product_goal_completed": False,
        "required_roles": mapping["mandatory_roles"], "required_probe_records": [row["id"] for row in mapping["probe_records"]]}
