# Retained reach release evidence

`reach_release.py` is an independent standard-library reader for the adopted
`ontokin.reach-release-evidence/0.1` gate. It imports no production solver,
sampler, exporter, Agent service or numerical reference. It reads identified
outputs and performs read-only Git identity checks. The other two entry points
separate actual process execution from immutable collection.

This tooling does not supply missing executions. In particular, the original
mapping contains 43 exact hostile subtypes, many of whose actual release
producers are still absent. Supporting tests, an aggregate pass count, an
unfinished process and a collected screenshot do not establish those roles.

## Execution and collection

Commit and publish the exact implementation, tools, mapping applicability and
numerical/probe criterion reviews before the final acceptance runs. The frozen
mapping and adoption documents retain their historical bytes. New applicable
reviews live under `docs/engineering/reach-release-criteria/`; their own
publication is recorded separately so a file need not contain its introducing
commit hash. Every file in that directory is an eligible input.

Execute an explicit complete component in a fresh external directory:

```sh
python tools/run_reach_release_role.py \
  --role compatibility --output-dir /tmp/reach-final-312 \
  --report run/report.json -- \
  python tools/run_reach_regression.py --output-dir /tmp/reach-final-312/run
```

The wrapper records the actual command, working directory, clocks, started
process flag, exit code, log, input identities and every output member. A zero
exit without a new report is a failure. Nonzero, interrupted and timed-out runs
remain failures, with their original partial outputs. Only the allowed literal
entry point for the specified role may run; case-filtered commands cannot
satisfy a complete role. Use the actual pinned interpreter/environment for each
run. The wrapper does not decide release acceptance.

A collection plan has schema
`ontokin.reach-evidence-collection-plan/0.1`, an explicit `copies` list of
`{source: absolute_path, destination: relative_posix_path}`, optional
`manifests: [{destination, value}]`, and `roles`. The only template operation is
`{"$file":"collected/path"}`. It inserts the collected member's actual SHA-256
and length. It does not manufacture status, clocks, observations or reviews.

```sh
python tools/build_reach_release_evidence.py \
  --plan /tmp/reach-collection-plan.json --output-dir /tmp/reach-final-evidence
python tools/audit_reach_release.py \
  --evidence /tmp/reach-final-evidence/evidence.json \
  --output /tmp/reach-final-evidence/audit.json
```

Collection preserves existing report bytes. Closed Agent SQLite files may be
copied and are still checked independently by the existing Agent reader.
Live WAL/SHM/journal files, symlinks, path traversal, overlapping trees and
destination collisions are rejected. New outputs never overwrite old runs.
An empty template may be written with `--template --output NEW`. Using
`--allow-pending` changes only the CLI exit policy, never the reported status.

## Role references

Every reference below is an actual file descriptor with `path`, `sha256` and
exactly one of `bytes` or `byte_length`. A role's `execution`, `producer`,
`destination`, `audit`, `corpus` and `rates` references identify the wrapper's
`execution.json`, not a detached component report. Component-relative references
keep the original directory structure when copied.

| Role | Required role fields |
| --- | --- |
| `input_closure` | `mapping_review`, `publication`; optional postmerge `integration` |
| `source_execution` | `corpus`, `rates`, `diagnostics`; `rate_applicability` when named reviewed numerical members differ |
| `compatibility` | `executions`, keyed exactly `3.11`, `3.12`, `3.13` |
| `agent_workflow` | `producer`, `audit` |
| `agent_delivery` | `producer`, `audit`; may share the same fully checked actual workflow |
| `source_native` | `producer`, `destination` |
| `agent_native` | `destination`, backed by the independently checked Agent producer |
| `source_browser` | `destination`, with actual browser execution |
| `agent_browser` | `destination`, with actual browser execution |
| `hostile_inputs` | `criteria`, `execution` |
| `visual_review` | `review` |
| `inherited_workflows` | `local`, `force`, `force_manifest` |

The complete source corpus is 45 cases. Exactly 28 complete source artifacts
and 10 retrieved Agent artifacts are required. P24 is not an obligatory source
GLB; L04 is the separate tenth recovered Agent artifact. The explicit P17
delivery ends at 2 seconds and its later 4-second request must still fail.
There are 362 fresh rate requests covering 724 frozen measurement fields.
The complete regression must execute on all three CPython minors with all six
pinned verification packages. Full native observations include every stored
key, eight distinct interior times per interval, both sides of every source
boundary, all frozen samples inside the prefix, phase neighbors, all carriers,
all promised sites and complete source geometry.

Nine source and nine Agent browser artifacts each require front, side and
intermediate PNG captures: 54 individually identified images. L01's separate
resumed-action numerical observation is additional to its paused capture.
Inherited local checks use `check_local.py --full --force-agent`; the current
complete F01–F12 force release must also be independently audited.

## Reviews and criteria

Each independent review states its exact schema, `reviewer`,
`actual_review_performed: true`, `independent_of_implementation: true`,
`reviewed_at_utc`, `status: passed`, empty `defects`, and a nonempty list of
concrete `observations`. These are actual review observations, not values the
collector creates. Repository-bound reviews additionally state
`repository_path` and must be byte-identical to that committed eligible file.

The mapping applicability schema is
`ontokin.reach-mapping-applicability/0.1`. It identifies the frozen `mapping`
and every mapped test/producer file in `reviewed_members`. Additive
`probe_producers` maps an exact subtype ID to a list of literal
`tools/file.py::Class.function` names. Every named method must exist in its
current AST; no wildcard or nonexistent producer satisfies coverage.

The proposal's 247-member inventory includes the historical implementation
helper `ontokin/json_limits.py`. Its old bytes were absent from the earlier
proposal commit; the exact adoption-recorded bytes are verified in recovered
published commit `f45f66e428cffe965dc6e50d0746c862b916263e`. A changed implementation additionally requires
`adoption_implementation_changes` in the mapping applicability review, with
its `path`, that `previous_commit`, exact `previous` and `current` file descriptors, and a concrete
`reason`. Its current file also belongs to `reviewed_members`. This explicit
implementation successor does not permit changing any frozen normative
document, fixture, schema, preparation tool or verification package pin.

The publication observation schema is
`ontokin.reach-publication-observation/0.1`. It records the actual GitHub
repository URL, `observed_ref`, full `commit` and `tree`,
`actual_remote_observation: true` and `observed_at_utc`. That observed commit
must contain the exact frozen mapping and every applicable repository review.
It must precede every final acceptance execution.

The rate applicability schema is `ontokin.reach-rate-applicability/0.1`. It
identifies the adopted `decision`, every `previous_members` entry from the
unchanged decision table, and the corresponding current `reviewed_members`.
Its `comparison_rule` remains
`exact_Euclidean_interval_box_squared_distance_extrema`,
`new_constant_tolerance` is false and `limits` remains
`{max_operations:100000,max_operand_bits:32768,max_cache_entries:256}`.
The historical producer label `proposed_not_adopted` is preserved; a separate
review binds that output to the adopted criterion. The retained auditor
independently recomputes every vector's exact minimum/maximum squared distance,
allowance square and resulting proved/contradicted/unresolved verdict.

The diagnostic review schema is `ontokin.reach-diagnostic-review/0.1`.
It names `source_execution` (the actual corpus report descriptor) and exactly
N01–N15, P17 and L04 in `cases`. Each row retains `observation` and its literal
`observation_pointer`, `observed_diagnostic`, a repository `frozen_reference`
with `frozen_pointer`, the exact `frozen_expectation`, and an explicit
`interpretation`. The reviewer checks the actual primary span, diagnostic side,
phase and code, with `source_span_checked`, `diagnostic_side_checked` and
`phase_and_code_checked` true. A prefix's last-valid side is not the diagnostic
side: `valid_until_side_used_as_diagnostic_side` must be false.

## Hostile producer interface

The future complete actual producer entry point is
`tools/run_reach_hostile_probes.py`; it does not become implemented merely by
being named here. Its report schema is
`ontokin.reach-hostile-execution/0.1`, with all 43 exact `probes` rows. The
role's separately reviewed and published criterion schema is
`ontokin.reach-hostile-criteria/0.1`, also with all 43 `probes` rows.

Each criterion row binds `id`, `mapping_record_sha256` (SHA-256 of canonical
JSON for the exact frozen mapping row), the exact reviewed
`producer_functions`, `source_cases`, and `kind`: `artifact_mutation`,
`identity_mutation`, `protocol` or `resource`. Its `assertions` list consists of
distinct literal `{pointer, equals}` assertions against the actual retained
observation. The expected values and intended stage must be chosen from the
adopted requirement before execution, not fitted to a received failure.

Each actual row binds `id`, `mapping_record_sha256`, `criterion_sha256`,
`producer_function`, `case_id`, `executed`, `status`, `observation`, and raw
`members`. An observation has schema
`ontokin.reach-hostile-observation/0.1`, the exact `probe_record_id`, and an
actual `executed` flag. A support test's success cannot supply this observation.

Corrupt-byte/resource rows additionally identify `baseline_artifact`,
`baseline_validation` and `mutated_artifact`. The baseline schema is
`ontokin.reach-hostile-baseline/0.1`: it records actual independent
`ontokin.reach_conformance.validate_recording_evidence` acceptance, its exact
`artifact_sha256`, and complete source/object/geometry/history closure.
The actual observation records both artifact hashes and exact sorted
`changed_json_pointers`. The reviewed criterion specifies only the intended
`allowed_json_pointers`, ordered nonoverlapping `allowed_binary_ranges`, and
an explicit `allow_binary_length_change` only if that mutation needs it.
The auditor decodes both actual GLBs, independently enumerates all JSON changes
and compares every binary byte outside those reviewed ranges.

The criterion's `expected_code` and `expected_stage` must match the actual
`rejection_code` and `rejection_stage`, with `accepted: false`,
`unrelated_failure: false` and nonempty actual integer `allocation_counts`.
Q04 must actually declare 10001 clock keys and report zero `decoded_accessors`.
Q05 must preserve all 97 source objects, 194 pose channels, one shared
3000-key accessor, 291000 declared baked poses, a file at most 64 MiB, and
zero `expanded_pose_copies` before rejection. A missing object, malformed
JSON or earlier unrelated resource failure does not meet those obligations.

Q01/Q02 retain `observed_operation_statuses` showing accepted, then running,
then cancelled; `effects_committed: false`, unchanged accepted source/prior
successes and no `new_success_ids`. Their actual raw requests, status polls,
terminal receipts and store/artifact reconciliation remain mandatory members.
The explicit assertions for every other subtype must cover that subtype's
complete adopted evidence, including all identity, rounding, history and
repair requirements. A criterion review is itself a mandatory independent
review of those assertions and current producer implementations.

## Visual and resulting-main observations

The visual review schema is `ontokin.reach-visual-review/0.1`. Its `captures`
list identifies all 54 actual global evidence paths. Each row has `image` and
`browser_report` descriptors, `actually_opened`, `opened_at_utc`, concrete
`observations`, `visibility_limits`, empty `defects`, and the exact case,
source-kind, view, source/artifact identities, time and side from the browser
capture. Capturing a PNG or checking a readback never substitutes for opening
and reviewing that specific image.

`release_acceptance: true` means all mandatory premerge roles and literal
R/Q/protocol obligations passed on the identified eligible inputs.
`finite_release_complete` additionally requires the actual protected merge,
resulting-main identity and fresh relevant checks. A postmerge
`ontokin.reach-integration-observation/0.1` record under
`input_closure.integration` names PR 27, repository, `refs/heads/main`, actual
commit/tree, input inventory, observed UTC clock, `actual_remote_observation`,
`expected_head_protection_used`, and `lease_reconciled`.

Its `resulting_main_checks` identifies already independently checked execution
envelopes for `source`, `regression`, `agent`, `agent_audit`, `delivery`,
`source_native` and `agent_native`. They must have actually run after that
main observation on the exact resulting-main commit/tree. No premerge process
is relabelled as a main execution. The broader programming-language goal
remains `full_product_goal_completed: false` in every result.
