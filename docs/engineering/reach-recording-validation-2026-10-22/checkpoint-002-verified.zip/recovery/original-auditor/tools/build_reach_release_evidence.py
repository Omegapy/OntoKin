#!/usr/bin/env python3
"""Collect existing reach evidence byte for byte, without executing or certifying it.

The explicit plan may add reference manifests using only {"$file": "path"}
placeholders. No report, status, clock or human observation is reconstructed.
Closed Agent stores may be retained as immutable bytes; live WAL/SHM/journal
files are rejected, and the independent Agent reader still checks the store.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tools import reach_release as release

PLAN_SCHEMA = "ontokin.reach-evidence-collection-plan/0.1"
RESERVED = {"evidence.json", "audit.json", "collection-plan.json", "collection.json"}
OMIT = {".git", "node_modules", "__pycache__", ".venv", "venv"}


def resolve_references(value, files):
    if type(value) is list:
        return [resolve_references(item, files) for item in value]
    if type(value) is dict:
        if "$file" in value:
            release.require(set(value) == {"$file"}, "A file placeholder has exactly one field")
            name = release.safe_name(value["$file"])
            release.require(name in files, "Reference names an uncollected file: " + name)
            return dict(files[name])
        release.require(not any(key.startswith("$") for key in value), "Unsupported collection template operation")
        return {key: resolve_references(item, files) for key, item in value.items()}
    return value


def copy_inventory(copies, output):
    release.require(type(copies) is list and copies, "Explicit copy inputs are required")
    records, excluded, names, total = [], [], set(), 0
    output = release.no_symlinks(output)
    for item in copies:
        release.require(type(item) is dict and set(item) == {"source", "destination"}, "Invalid copy descriptor")
        release.require(type(item["source"]) is str and Path(item["source"]).is_absolute(), "Copy sources must be absolute")
        source, destination = release.no_symlinks(item["source"]), release.safe_name(item["destination"])
        release.require(source.is_file() or source.is_dir(), "Missing collection input")
        release.require(source != output and source not in output.parents and output not in source.parents,
                        "Collection source and output overlap")
        paths = []
        if source.is_file():
            paths.append((source, destination))
        else:
            for directory, children, filenames in os.walk(source, followlinks=False):
                directory = Path(directory)
                for name in children:
                    release.no_symlinks(directory / name)
                for name in children[:]:
                    if name in OMIT:
                        excluded.append(str(directory / name))
                        children.remove(name)
                children.sort()
                for name in sorted(filenames):
                    path = release.no_symlinks(directory / name)
                    if path.suffix in {".pyc", ".pyo"}:
                        excluded.append(str(path))
                        continue
                    paths.append((path, destination + "/" + path.relative_to(source).as_posix()))
        for path, name in paths:
            name = release.safe_name(name)
            release.require(not release.TRANSIENT.search(name), "Live database state cannot be collected: " + name)
            release.require(name not in RESERVED and name not in names
                            and not any(name.startswith(other + "/") or other.startswith(name + "/") for other in names),
                            "Colliding or reserved collection destination: " + name)
            record = release.file_record(path, name)
            total += record["byte_length"]
            release.require(len(records) < release.MAX_FILES and total <= release.MAX_TOTAL, "Collection exceeds its finite bounds")
            records.append((path, record))
            names.add(name)
    return records, excluded


def collect(plan_path, output, *, repository=release.ROOT):
    plan_path, output = release.no_symlinks(plan_path), release.no_symlinks(output)
    raw = release.read_raw(plan_path)
    plan = release.json_bytes(raw)
    release.require(type(plan) is dict and set(plan) <= {"schema_version", "copies", "manifests", "roles"}
                    and plan.get("schema_version") == PLAN_SCHEMA, "Unsupported reach collection plan")
    release.require(type(plan.get("roles")) is dict and set(plan["roles"]) <= set(release.ROLES), "Unknown evidence role")
    release.require(not output.exists() and not output.is_relative_to(Path(repository).resolve()),
                    "Use a new collection directory outside the repository")
    before = release.source_identity(repository)
    release.load_contract(repository)
    planned, excluded = copy_inventory(plan.get("copies"), output)
    files = {record["path"]: record for _, record in planned}
    generated = []
    release.require(type(plan.get("manifests", [])) is list, "Reference manifests must be a list")
    for item in plan.get("manifests", []):
        release.require(type(item) is dict and set(item) == {"destination", "value"}, "Invalid reference manifest")
        name = release.safe_name(item["destination"])
        release.require(name not in RESERVED and name not in files
                        and not any(name.startswith(other + "/") or other.startswith(name + "/") for other in files),
                        "Colliding reference manifest")
        value = resolve_references(item["value"], files)
        data = release.canonical(value) + b"\n"
        release.require(len(data) <= release.MAX_JSON, "Generated reference manifest exceeds its byte bound")
        record = {"path": name, "sha256": release.digest(data), "byte_length": len(data)}
        generated.append((data, record))
        files[name] = record
    roles = resolve_references(plan["roles"], files)
    release.require(len(files) + 2 <= release.MAX_FILES
                    and sum(row["byte_length"] for row in files.values()) + len(raw) <= release.MAX_TOTAL,
                    "Complete collection exceeds its bounds")
    output.mkdir(parents=True)
    for source, record in planned:
        release.require(release.file_record(source, record["path"]) == record, "Collection input changed before copying")
        target = output / record["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        with source.open("rb") as incoming, target.open("xb") as outgoing:
            for chunk in iter(lambda: incoming.read(1024 * 1024), b""):
                outgoing.write(chunk)
        release.require(release.file_record(target, record["path"]) == record
                        and release.file_record(source, record["path"]) == record, "Collection changed during copying")
    for data, record in generated:
        target = output / record["path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open("xb") as stream:
            stream.write(data)
    release.require(release.read_raw(plan_path) == raw, "Collection plan changed")
    with (output / "collection-plan.json").open("xb") as stream:
        stream.write(raw)
    after = release.source_identity(repository)
    release.require(release.stable_source(before, after), "Eligible source inputs changed during collection")
    release.write_json(output / "collection.json", {"schema_version": "ontokin.reach-evidence-collection/0.1",
        "collected_at_utc": release.utc(), "source_before": before, "source_after": after,
        "copied_files": len(planned), "new_reference_manifests": len(generated), "excluded_transient_inputs": excluded,
        "reports_rewritten": False, "commands_executed": False, "visual_review_performed": False,
        "release_acceptance": False, "full_product_goal_completed": False})
    for name in ("collection-plan.json", "collection.json"):
        files[name] = release.file_record(output / name, name)
    release.require(sum(row["byte_length"] for row in files.values()) <= release.MAX_TOTAL, "Retained collection exceeds its bound")
    for name, record in files.items():
        release.require(release.file_record(output / name, name) == record, "Completed collection bytes changed")
    manifest = {"schema_version": release.EVIDENCE_SCHEMA, "implementation": before["implementation"],
        "input_inventory_sha256": before["input_inventory_sha256"],
        "mapping": release.file_record(Path(repository) / release.MAP_PATH, release.MAP_PATH),
        "roles": roles, "files": [files[name] for name in sorted(files)], "full_product_goal_completed": False}
    release.write_json(output / "evidence.json", manifest)
    return {"output": str(output), "files": len(files), "evidence": release.file_record(output / "evidence.json"),
            "release_acceptance": False, "full_product_goal_completed": False}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args(argv)
    try:
        result = collect(args.plan, args.output_dir)
    except (OSError, ValueError) as error:
        print(release.canonical({"status": "failed", "error": str(error), "release_acceptance": False}).decode(), file=sys.stderr)
        return 1
    print(release.canonical(result).decode())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
