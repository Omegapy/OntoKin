#!/usr/bin/env python3
"""Independently audit retained reach release evidence; never execute its commands."""
import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tools import reach_release as release


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evidence", type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--template", action="store_true", help="Write an explicitly empty pending evidence template")
    parser.add_argument("--allow-pending", action="store_true", help="Change only pending exit policy; never report acceptance")
    arguments = parser.parse_args(argv)
    try:
        release.require(not arguments.output.exists(), "Preserve existing audit output; choose a fresh path")
        result = release.evidence_template() if arguments.template else release.audit_release(arguments.evidence)
        release.write_json(arguments.output, result)
        print(release.canonical({key: result[key] for key in ("status", "release_acceptance", "finite_release_complete", "summary") if key in result}).decode())
        return 0 if arguments.template or result["status"] == "passed" or (arguments.allow_pending and result["status"] == "pending") else 1
    except (OSError, ValueError, KeyError, TypeError) as error:
        print(release.canonical({"status": "failed", "error": str(error), "release_acceptance": False,
                                 "full_product_goal_completed": False}).decode(), file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
