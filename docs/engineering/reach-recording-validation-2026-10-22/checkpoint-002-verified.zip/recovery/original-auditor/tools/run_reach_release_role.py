#!/usr/bin/env python3
"""Execute one explicit local acceptance command and retain its actual process record.

Example: --role compatibility --output-dir /tmp/reach-312 --report run/report.json
-- python tools/run_reach_regression.py --output-dir /tmp/reach-312/run

The report must be absent before execution and written inside the new output
directory. A failed process and any partial output are retained unchanged.
This wrapper never decides whether a complete release role passed.
"""
from __future__ import annotations

import argparse
import os
from pathlib import Path
import platform
import signal
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from tools import reach_release as release


def execute(role, output, report_name, command, *, timeout=3600, repository=release.ROOT):
    output = release.no_symlinks(output)
    report_name = release.safe_name(report_name)
    repository = release.no_symlinks(repository)
    release.check_command(role, command, str(repository))
    release.require(type(timeout) is int and 1 <= timeout <= 86400, "A bounded positive timeout is required")
    release.require(not output.exists() and not output.is_relative_to(repository)
                    and report_name not in {"execution.json", "execution.log", "inputs-before.json", "inputs-after.json"},
                    "Use a fresh external directory and a separate component report path")
    before = release.source_identity(repository)
    output.mkdir(parents=True)
    release.write_json(output / "inputs-before.json", before)
    envelope = {"schema_version": release.EXECUTION_SCHEMA, "role": role, "executed": False,
        "provider": {"kind": "local", "hosted_ci_claimed": False}, "status": "not_started",
        "command": command, "working_directory": str(repository), "started_at_utc": release.utc(),
        "source_before": before, "report_absent_before_execution": not (output / report_name).exists(),
        "wrapper_environment": {"python": platform.python_version(), "implementation": platform.python_implementation(),
            "executable": sys.executable, "platform": platform.platform()},
        "timeout_seconds": timeout, "release_acceptance": False, "full_product_goal_completed": False}
    started = time.monotonic()
    with (output / "execution.log").open("xb") as stream:
        try:
            process = subprocess.Popen(command, cwd=repository, stdin=subprocess.DEVNULL,
                                       stdout=stream, stderr=subprocess.STDOUT, start_new_session=os.name == "posix")
            envelope["executed"] = True
            try:
                code = process.wait(timeout=timeout)
            except (subprocess.TimeoutExpired, KeyboardInterrupt) as error:
                if os.name == "posix":
                    os.killpg(process.pid, signal.SIGKILL)
                else:
                    process.kill()
                code = process.wait()
                envelope["timed_out"] = isinstance(error, subprocess.TimeoutExpired)
                envelope["interrupted"] = isinstance(error, KeyboardInterrupt)
            envelope.update(exit_code=code, status="completed" if code == 0 and not envelope.get("timed_out") and not envelope.get("interrupted") else "failed")
        except (OSError, ValueError) as error:
            envelope.update(status="failed", failure={"type": type(error).__name__, "message": str(error)}, exit_code=None)
    envelope.update(finished_at_utc=release.utc(), elapsed_seconds=time.monotonic() - started)
    try:
        after = release.source_identity(repository)
        release.write_json(output / "inputs-after.json", after)
        envelope.update(source_after=after, inputs_stable=release.stable_source(before, after))
        release.require(envelope["inputs_stable"], "Eligible inputs changed during actual execution")
    except (OSError, ValueError) as error:
        envelope.update(status="failed", inputs_stable=False, input_failure=str(error))
    report = output / report_name
    if report.is_file():
        envelope["report"] = release.file_record(report, report_name)
    else:
        envelope.update(status="failed", report_missing=True)
    files, total = [], 0
    for path in sorted(output.rglob("*")):
        release.no_symlinks(path)
        if path.is_file():
            name = path.relative_to(output).as_posix()
            if release.TRANSIENT.search(name):
                envelope.update(status="failed", mutable_outputs_present=True)
            record = release.file_record(path, name)
            total += record["byte_length"]
            release.require(len(files) < release.MAX_FILES and total <= release.MAX_TOTAL, "Execution output exceeds evidence bounds")
            files.append(record)
    envelope["members"] = files
    envelope["log"] = release.file_record(output / "execution.log", "execution.log")
    release.write_json(output / "execution.json", envelope)
    return envelope


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--role", required=True, choices=tuple(release.ENTRYPOINTS))
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--report", required=True)
    parser.add_argument("--timeout", type=int, default=3600)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args(argv)
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    try:
        result = execute(args.role, args.output_dir, args.report, command, timeout=args.timeout)
    except (OSError, ValueError) as error:
        print(release.canonical({"status": "failed", "error": str(error), "release_acceptance": False}).decode(), file=sys.stderr)
        return 1
    print(release.canonical({key: result.get(key) for key in ("status", "executed", "exit_code", "inputs_stable", "report")}).decode())
    return 0 if result["status"] == "completed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
