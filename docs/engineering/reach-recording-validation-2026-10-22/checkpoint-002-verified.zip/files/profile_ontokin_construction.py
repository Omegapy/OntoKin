import collections
import json
import platform
from pathlib import Path
import sys
import traceback

ROOT = Path('/workspace/scratch/02a7d398adff/OntoKin')
sys.path.insert(0, str(ROOT))
from tools.reach_delivery_inventory import snapshot, source_files, write_json, utc
from ontokin.bundle import load_file_manifest
from ontokin.construction import ConstructionBudget, compile_construction

out = Path(sys.argv[1]); out.mkdir()
before = snapshot(); write_json(out / 'inputs-before.json', before)
rows, stacks, nodes = collections.Counter(), collections.Counter(), collections.Counter()
original = ConstructionBudget.tick
def tick(self, node=None, amount=1):
    result = original(self, node, amount)
    frame = sys._getframe(1)
    call_path = []
    while frame is not None and len(call_path) < 7:
        filename = Path(frame.f_code.co_filename).name
        call_path.append(f'{filename}:{frame.f_code.co_name}:{frame.f_lineno}')
        frame = frame.f_back
    rows[call_path[0]] += amount
    stacks[' <- '.join(call_path)] += amount
    if node is not None:
        nodes[(getattr(node, 'source_id', ''), getattr(node, 'kind', ''), getattr(node, 'start', ''), call_path[0])] += amount
    return result
ConstructionBudget.tick = tick
report = {'head': before['git']['commit'], 'tree': before['git']['tree'],
          'observational_profile': True, 'release_acceptance': False,
          'python': sys.version, 'platform': platform.platform(),
          'command': [sys.executable, *sys.argv], 'started_at': utc()}
try:
    compiler = compile_construction(load_file_manifest(ROOT / source_files('P23')), level='constructed')
    report.update(status='passed', budget=compiler.budget.report())
except Exception as error:
    report.update(status='failed', error=str(error), traceback=traceback.format_exc())
after = snapshot(); write_json(out / 'inputs-after.json', after)
report.update(inputs_stable=before == after, finished_at=utc(),
              rows=rows.most_common(), stacks=stacks.most_common(),
              nodes=[{'source_id': key[0], 'kind': key[1], 'start': key[2], 'caller': key[3], 'operations': value}
                     for key, value in nodes.most_common()])
write_json(out / 'report.json', report)
print(json.dumps({k: report[k] for k in ('head', 'status', 'inputs_stable', 'budget', 'rows')}, indent=2))
