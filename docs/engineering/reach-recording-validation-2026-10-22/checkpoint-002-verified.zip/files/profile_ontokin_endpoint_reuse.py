import argparse
import collections
import functools
import json
from pathlib import Path
import sys
import traceback
from fractions import Fraction

p=argparse.ArgumentParser()
p.add_argument('--repo',required=True); p.add_argument('--output',required=True)
p.add_argument('--compat-old-sampler',action='store_true')
p.add_argument('cases',nargs='+'); args=p.parse_args()
sys.path.insert(0,args.repo)
from tools.reach_delivery_inventory import snapshot, source_files, settings, write_json
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.gltf import export_glb
from ontokin.scene import ExportOptions
import ontokin.reach_export as exporter
if args.compat_old_sampler:
    # Diagnostic only: retain the pre-carrier sampler while its separately
    # developed optional proof argument is being integrated. No source/output
    # budget or numeric setting changes; this is not an acceptance execution.
    from ontokin.reach_runtime import ReachSimulator
    old_frames=ReachSimulator.recording_frames
    def frames(self,*a,recording_angular_proof=None,**kw):
        return old_frames(self,*a,**kw)
    ReachSimulator.recording_frames=frames

out=Path(args.output); out.mkdir()
before=snapshot(); write_json(out/'inputs-before.json',before)
rows=[]
for case in args.cases:
    built=compile_construction(load_file_manifest(Path(args.repo)/source_files(case)),level='constructed')
    work=built.reach_work
    counts=collections.Counter(); costs=collections.Counter()
    original_lookup=work.lookup
    def lookup(key):
        result=original_lookup(key)
        if key[0]=='reach_recording_arithmetic_v1' and key[1].startswith('endpoint_'):
            counts[(key[1], 'hit' if result is not None else 'miss')]+=1
        return result
    work.lookup=lookup
    originals={}
    for name in ('_endpoint_rounding','_position_rounding','_quaternion_rounding'):
        original=getattr(exporter,name); originals[name]=original
        def wrapped(*a,_original=original,_name=name,**kw):
            start=work.operations
            try: return _original(*a,**kw)
            finally: costs[_name]+=work.operations-start
        setattr(exporter,name,wrapped)
    row={'case':case}
    try:
        options=settings(case)
        result=export_glb(built.model,options=ExportOptions(**{**options,'end':Fraction(options['end'])}),
                          target_contract='ontokin.glb/0.6',work=work)
        row['status']='passed'
    except Exception as error:
        row.update(status='failed',error=str(error),traceback=traceback.format_exc())
    finally:
        for name, original in originals.items(): setattr(exporter,name,original)
    row.update(operations=built.budget.operations,costs=dict(costs),
               cache=[{'kind':key[0],'result':key[1],'count':value} for key,value in counts.items()])
    rows.append(row); write_json(out/(case+'.json'),row)
    print(json.dumps({k:v for k,v in row.items() if k!='traceback'}),flush=True)
after=snapshot(); write_json(out/'inputs-after.json',after)
write_json(out/'report.json',{'source_commit':before['git']['commit'],'inputs_stable':before==after,
    'observational_profile':True,'release_acceptance':False,'compat_old_sampler':args.compat_old_sampler,'rows':rows})
