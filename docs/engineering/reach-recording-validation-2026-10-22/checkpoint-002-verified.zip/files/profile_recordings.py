import argparse, json, sys, time, traceback
from fractions import Fraction
from pathlib import Path

p=argparse.ArgumentParser();p.add_argument('--repo',required=True);p.add_argument('--output',required=True);p.add_argument('cases',nargs='+');args=p.parse_args()
sys.path.insert(0,args.repo)
from tools.reach_delivery_inventory import snapshot,settings,source_files,write_json
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.gltf import export_glb
from ontokin.scene import ExportOptions
import ontokin.reach_export as exporter
import ontokin.reach_conformance as verifier
out=Path(args.output);out.mkdir()
before=snapshot();write_json(out/'inputs-before.json',before)
rows=[];active=None;current_work=None
stage_original=exporter.recording_stage
def stage(name,**kw):
    work=kw.get('work')
    if work is not None:active['stages'].append({'name':name,'operations':work.operations,'counts':dict(work.counts)})
    return stage_original(name,**kw)
exporter.recording_stage=stage
for name in ('validate_reach_export','_phase_tables','_verify_certificates','_geometry_bounds','_verify_metadata'):
    original=getattr(verifier,name)
    def wrapped(*a,_original=original,_name=name,**kw):
        active['stages'].append({'name':_name,'operations':current_work.operations,'counts':dict(current_work.counts)})
        return _original(*a,**kw)
    setattr(verifier,name,wrapped)
for case in args.cases:
    active={'case':case,'stages':[]};rows.append(active);built=None;start=time.monotonic()
    try:
        built=compile_construction(load_file_manifest(Path(args.repo)/source_files(case)),level='constructed')
        current_work=built.reach_work;options=settings(case)
        active['compiled_operations']=built.budget.operations
        result=export_glb(built.model,options=ExportOptions(**{**options,'end':Fraction(options['end'])}),target_contract='ontokin.glb/0.6',work=current_work)
        active['status']='passed';active['validation']=result.report['validation'];active['sampling']=result.report['sampling']
        (out/(case+'.glb')).write_bytes(result.data)
    except Exception as e:
        active.update(status='failed',error=str(e),traceback=traceback.format_exc())
        if hasattr(e,'diagnostic'):active['diagnostic']=str(e.diagnostic)
    active['seconds']=time.monotonic()-start
    if built:
        active.update(operations=built.budget.operations,work=built.reach_work.record())
    write_json(out/(case+'.json'),active)
    print(json.dumps({'case':case,'status':active['status'],'operations':active.get('operations'),'stages':[(x['name'],x['operations']) for x in active['stages']]}),flush=True)
after=snapshot();write_json(out/'inputs-after.json',after)
write_json(out/'report.json',{'source_commit':before['git']['commit'],'inputs_stable':before==after,'observational_profile':True,'complete_corpus_acceptance':False,'rows':rows})
