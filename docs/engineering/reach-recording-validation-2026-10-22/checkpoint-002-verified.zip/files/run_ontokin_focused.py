import argparse
import contextlib
import json
from pathlib import Path
import platform
import sys
import time
import unittest

parser = argparse.ArgumentParser()
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('modules', nargs='+')
args = parser.parse_args()
sys.path[:0] = [str(args.repo), str(args.repo / 'tests')]
from tools.reach_delivery_inventory import snapshot, write_json
args.output.mkdir()
before = snapshot()
write_json(args.output / 'inputs-before.json', before)
started = time.time()
with (args.output / 'unittest.log').open('w') as log:
    with contextlib.redirect_stdout(log), contextlib.redirect_stderr(log):
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(
            unittest.defaultTestLoader.loadTestsFromNames(args.modules))
after = snapshot()
write_json(args.output / 'inputs-after.json', after)
report = {'head': before['git']['commit'], 'tree': before['git']['tree'],
    'command': [sys.executable, *sys.argv], 'python': sys.version,
    'platform': platform.platform(), 'modules': args.modules,
    'tests': result.testsRun, 'failures': len(result.failures),
    'errors': len(result.errors), 'skipped': len(result.skipped),
    'seconds': time.time() - started, 'stable': before == after,
    'success': result.wasSuccessful() and before == after,
    'failure_details': [(str(a), b) for a, b in result.failures],
    'error_details': [(str(a), b) for a, b in result.errors]}
write_json(args.output / 'report.json', report)
print(json.dumps(report, indent=2))
raise SystemExit(0 if report['success'] else 1)
