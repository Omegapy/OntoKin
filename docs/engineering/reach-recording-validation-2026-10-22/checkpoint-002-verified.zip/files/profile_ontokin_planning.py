import functools
import json
from pathlib import Path
import traceback
from fractions import Fraction
import sys
sys.path.insert(0, '/workspace/scratch/02a7d398adff/OntoKin')
from tools.reach_delivery_inventory import snapshot, source_files, settings, write_json
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.gltf import export_glb
from ontokin.scene import ExportOptions
import ontokin.reach_runtime as runtime
import ontokin.reach_export as exporter
out = Path(sys.argv[1]); out.mkdir()
before = snapshot(); write_json(out / 'inputs-before.json', before)
compiler = compile_construction(load_file_manifest(Path(source_files('P23'))), level='constructed')
work = compiler.reach_work
rows, stack = {}, []
def observe(owner, name):
    original = getattr(owner, name)
    @functools.wraps(original)
    def call(*args, **kwargs):
        entry = [compiler.budget.operations, 0]; stack.append(entry)
        try:
            return original(*args, **kwargs)
        finally:
            stack.pop(); spent = compiler.budget.operations - entry[0]
            if stack:
                stack[-1][1] += spent
            row = rows.setdefault(name, {'calls': 0, 'inclusive': 0, 'exclusive': 0})
            row['calls'] += 1; row['inclusive'] += spent; row['exclusive'] += spent - entry[1]
    setattr(owner, name, call)
for name in ('_physical_observation', '_current', '_reach_map', '_validate_staged',
             '_resolve_kinematics', '_process_boundary', '_tip_base', '_world_target',
             '_latch', 'recording_boundary', '_bounded_projection', '_snapshot_data'):
    observe(runtime.ReachSimulator, name)
for name in ('measure_reach_json', 'reach_projection'):
    observe(runtime, name)
for name in ('recording_phase_bounds', 'reach_prefix_plan'):
    observe(exporter, name)
report = {'head': before['git']['commit'], 'observational_profile': True,
          'counter': 'compiler.budget.operations', 'release_acceptance': False, 'rows': rows}
try:
    options = settings('P23')
    export_glb(compiler.model, options=ExportOptions(**{**options, 'end': Fraction(options['end'])}),
               target_contract='ontokin.glb/0.6', work=work)
    report['status'] = 'passed'
except Exception as error:
    report.update(status='failed', error=str(error), traceback=traceback.format_exc())
after = snapshot(); write_json(out / 'inputs-after.json', after)
report.update(inputs_stable=before == after, operations=compiler.budget.operations, work=work.record())
write_json(out / 'report.json', report)
print(json.dumps({'status': report['status'], 'rows': dict(sorted(rows.items(), key=lambda x: -x[1]['exclusive']))}, indent=2))
