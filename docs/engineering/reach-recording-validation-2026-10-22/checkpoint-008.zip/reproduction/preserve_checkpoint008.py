"""Archive the identified continuation without relabeling prior evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

base = Path('/workspace/scratch/7fb5bc518974')
root = base / 'OntoKin'
evidence = base / 'evidence'
out = root / 'docs/engineering/reach-recording-validation-2026-10-22'
baseline = 'b1d102a5391721b3e420277526696aca65b11ea5'

def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args])

def read(path):
    return json.loads(path.read_text())

def encode(value):
    return (json.dumps(value, indent=2) + '\n').encode()

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

source = read(evidence / 'integrated-source002/report.json')
focused = read(evidence / 'integrated-focused003/report.json')
head = git('rev-parse', 'HEAD').decode().strip()
assert source['source_commit'] == focused['source_commit'] == head
assert source['inputs_stable'] and focused['inputs_stable']
assert focused['status'] == 'passed' and focused['raw_log_complete'] and focused['executed_ids_complete']
assert not git('status', '--porcelain=v1', '--untracked-files=all').strip()
older = {p.name: digest(p.read_bytes()) for p in out.glob('checkpoint-00[1-7]*') if p.is_file()}
members = {}
folders = ('integrated-source001', 'integrated-source002', 'integrated-focused001',
    'integrated-focused002', 'integrated-focused003', 'orientation-claims001',
    'reference-increment001', 'sampling-captured-001', 'sampling-captured-002',
    'sampling-p23-001', 'sampling-preflight-001', 'profile-integrated001',
    'profile-planning-facts001')
omitted = []
for name in folders:
    folder = evidence / name
    assert folder.is_dir(), name
    for path in sorted(folder.rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            raw = path.read_bytes()
            if path.suffix == '.zip':
                omitted.append({'path': str(path), 'bytes': len(raw), 'sha256': digest(raw),
                    'reason': 'Unidentified preflight temporary archive retained at its preserved local path.'})
                continue
            members['execution/' + path.relative_to(evidence).as_posix()] = raw
for path in sorted(evidence.glob('*.console.log')):
    members['execution/' + path.name] = path.read_bytes()
for name in ('run_focused_buffered.py', 'profile_pipeline.py', 'profile_planning_facts.py',
             'preserve_checkpoint008.py', 'recovered007-remote.json',
             'checkpoint-002-verified.zip.cTlwAF.json'):
    members['reproduction/' + name] = (evidence / name).read_bytes()

limitations = {
    'earlier_test_failures': 'integrated-focused001 ran137 with2 assertion failures in tests counting phase-root entries already created by P16 setup; exact-value assertions passed. The corrected test accounts for prior entries and integrated-focused002 passes137/137.',
    'preflight_rejections': 'sampling-captured-001 and a separate reference worker preflight executed no tests after detecting pre-existing untracked temporary archives. Exact artifacts remain preserved; no origin is established.',
    'omitted_preflight_archives': omitted,
    'profiles': 'Diagnostic wrappers retain real work limits; only separately executed source runs establish recording outcomes.',
    'acceptance': 'Focused methods are selected correctness checks. No complete current regression, compatibility, Agent, destination or release pass is claimed.',
}
members['reproduction/evidence-limitations.json'] = encode(limitations)

commits = {baseline, head}
def source_ids(value):
    if isinstance(value, dict):
        for name, item in value.items():
            if name in ('source_commit', 'commit') and type(item) is str and len(item) == 40:
                try:
                    if git('cat-file', '-t', item).strip() == b'commit':
                        commits.add(item)
                except subprocess.CalledProcessError:
                    pass
            elif isinstance(item, (dict, list)):
                source_ids(item)
    elif isinstance(value, list):
        for item in value:
            source_ids(item)
for name, raw in tuple(members.items()):
    if name.endswith('.json'):
        source_ids(json.loads(raw))
commits.update(git('rev-list', baseline + '..' + head).decode().splitlines())
members['source/changes-from-b1d102a.patch'] = git('diff', '--binary', baseline, head)
for commit in sorted(commits):
    members['source/commits/' + commit + '.txt'] = git('cat-file', 'commit', commit)
    if commit not in (baseline, head):
        members['source/scoped-inputs/' + commit + '.patch'] = git(
            'diff', '--binary', baseline, commit, '--', 'ontokin', 'tests', 'tools')

integrity = []
for folder in folders:
    for report_path in sorted((evidence / folder).rglob('report.json')):
        for row in read(report_path).get('deliveries', []):
            for role in ('artifact', 'export_report'):
                if role in row:
                    item = row[role]
                    raw = (report_path.parent / item['path']).read_bytes()
                    assert item['bytes'] == len(raw) and item['sha256'] == 'sha256:' + digest(raw)
                    integrity.append({'run': folder, 'case_id': row['case_id'], 'role': role, **item})
members['reproduction/artifact-integrity.json'] = encode({'status': 'passed', 'members': integrity})
archive = out / 'checkpoint-008.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, raw in sorted(members.items()):
        bundle.writestr(name, raw)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    assert len(bundle.namelist()) == len(set(bundle.namelist())) == len(members)
    assert set(bundle.namelist()) == set(members)
    for name, raw in members.items():
        assert bundle.read(name) == raw
manifest = {'schema_version': 'ontokin.checkpoint-archive/0.1', 'archive': archive.name,
    'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()), 'member_count': len(members),
    'members': [{'path': name, 'bytes': len(raw), 'sha256': digest(raw)} for name, raw in sorted(members.items())]}
(out / 'checkpoint-008.manifest.json').write_bytes(encode(manifest))
rows = [{key: row[key] for key in ('case_id', 'status', 'operations')} for row in source['deliveries']]
passed = sum(row['status'] == 'passed' for row in rows)
failed = [row['case_id'] for row in rows if row['status'] != 'passed']
assert len(rows) == 28
now = datetime.now(timezone.utc).isoformat()
checkpoint = {'schema_version': 'ontokin.reach-development-checkpoint/0.1', 'recorded_at': now,
    'baseline': baseline, 'source_commit': head, 'source_tree': source['source_tree'],
    'recovered_checkpoint007': {'local_commit': 'e4f51dbdb9ac9447a453e1a79f36e363108bd9af',
        'published_commit': baseline, 'identical_tree': '037849976437848c40b7cbbdf7e73ba60f4ada0d'},
    'full_source': {'status': source['status'], 'inputs_stable': source['inputs_stable'],
        'started_at': source['started_at'], 'finished_at': source['finished_at'], 'passed': passed,
        'total': len(rows), 'max_operations': 100000, 'cases': rows,
        'report_sha256': digest((evidence / 'integrated-source002/report.json').read_bytes())},
    'focused': {key: focused[key] for key in ('status', 'tests', 'failures', 'errors', 'skipped',
        'inputs_stable', 'elapsed_seconds', 'raw_log_complete', 'executed_ids_complete')},
    'archive': {key: manifest[key] for key in ('archive', 'bytes', 'sha256', 'member_count')},
    'artifacts_hash_verified': len(integrity), 'remaining_recordings': failed,
    'limitations': limitations, 'release_acceptance': False, 'full_product_goal_completed': False,
    'main_unchanged': '2bb4588e121fcfe99b4d42c734b15b38362f3642', 'pr': 27, 'pr_draft': True,
    'pending_roles': ['28/28 source recordings', '10 Agent artifacts', 'complete current regression and compatibility',
        'independent rate verification', 'native and browser destination checks', 'fresh image review',
        'hostile input and inherited gates', 'R01-R12/Q01-Q22 release audit', 'resulting-main verification']}
(out / 'checkpoint-008.json').write_bytes(encode(checkpoint))
case_text = ', '.join(failed)
l02 = next(row['operations'] for row in rows if row['case_id'] == 'L02')
section = f'''## Latest checkpoint 008: {focused['tests']} focused tests; {passed}/28 source recordings

The recovered local checkpoint `e4f51dbdb9ac9447a453e1a79f36e363108bd9af`
was published and read back at `{baseline}`. Its entire tree is exactly
`037849976437848c40b7cbbdf7e73ba60f4ada0d`; this also preserves the original
686-method and 20/28 historical evidence without relabeling it as current.

The new tested source is `{head}`, tree
`{source['source_tree']}`. Its full source run finished **{source['finished_at']}**,
passing **{passed}/28** at the unchanged **100,000-operation** limit, with stable
tracked inputs. Remaining failures: **{case_text}**. L02 uses **{l02:,} operations**.

The same integrated source passes **{focused['tests']}/{focused['tests']} focused methods**,
with no failures, errors or skips, in **{focused['elapsed_seconds']:.3f} seconds**.
Complete logs, method inventories, execution environment and before/after inputs
are retained. This selected cohort does not replace full regression or compatibility.

Changes include the recovered captured-graph sampler and independent phase-root
reuse, completed residual/square-root reuse, immutable source snapshot correctness
and original seed-failure propagation, exact repeated independent angular increments,
and complete orientation-claim inequality reuse. The existing numeric cache stays
bounded at256; current source, callback and operand checks remain mandatory.

[checkpoint-008.zip](checkpoint-008.zip) contains **{len(members)} raw members**,
**{manifest['bytes']:,} bytes**, SHA-256 `{manifest['sha256']}`.
The [manifest](checkpoint-008.manifest.json) and [checkpoint](checkpoint-008.json)
identify every execution and its source. All **{len(integrity)} artifact/report hashes**,
every member and ZIP CRC were verified. Earlier archives are unchanged.
The earlier two test-assertion failures and clean-checkout preflight rejections
remain visible with their precise limitations.

Coordinator `interactive-reach06-continue-20261022-7fb5bc` works on
`work/reach06-continue-20261022-7fb5bc`; child scopes are recorded in issue #26.
The next work is complete-phase captured sampling, unchanged boundary-graph
finiteness admission and further independent arithmetic reductions, then another
complete28 run. These pending candidates are not part of the current result.
Runtime, tests and archive creation remain serialized.

**Do not merge.** PR #27 remains draft; main stays
`2bb4588e121fcfe99b4d42c734b15b38362f3642`. Agent delivery, full current
regression/compatibility, independent rate verification, destination/browser and
visual checks, inherited/hostile roles and complete release audits remain pending.
No main lease or hosted job is claimed. Full GOAL remains open.

'''
readme = out / 'README.md'
text = readme.read_text()
text = text.replace('The latest complete run passes **20/28**; all eight remaining cases\nstill fail',
                    f'The latest complete run passes **{passed}/28**; the remaining cases\nstill fail', 1)
assert '## Latest checkpoint 007:' in text
text = text.replace('## Latest checkpoint 007:', section + '## Preserved checkpoint 007:', 1)
readme.write_text(text)
status = root / 'STATUS.md'
text = status.read_text()
start = text.index('Latest tested recording implementation is')
end = text.index('The historical rows below retain their original cuts and limits.', start)
replacement = f'''Latest tested recording implementation is `{head}`,
tree `{source['source_tree']}`. Recovered local checkpoint `e4f51db` is
published and verified at `{baseline}` with its exact tree and full evidence.
The newer implementation and results below form checkpoint008.

The [recording checkpoint](docs/engineering/reach-recording-validation-2026-10-22/README.md)
retains a fresh **{passed}/28** complete source run, finished **{source['finished_at']}**,
with stable inputs and the unchanged **100,000-operation** limit. L02 uses
**{l02:,} operations**. Remaining failures: **{case_text}**.

The same source passes **{focused['tests']}/{focused['tests']} focused methods**, with no
failures, errors or skips, complete raw logs and stable tracked inputs. This is
a selected correctness cohort, not full regression or compatibility. The recovered
686-method result remains separately identified historical evidence.

Checkpoint008 preserves **{len(members)} raw members**, including both current full
source runs, focused passes and failures, diagnostic profiles and exact source.
All **{len(integrity)} artifact/report hashes**, member identities and ZIP CRC passed.
Earlier evidence and unexplained temporary-file observations retain their limits.

Captured source sampling, independent phase roots, residual/square-root reuse,
exact angular increments and completed orientation claims remove duplicate work.
Immutable source snapshots and original error propagation correct two callback
edge cases. Source admissions, numeric/cancellation checks, the256-entry cache,
frozen fixtures, tolerances and all public limits remain unchanged.

The immediate target remains **28/28**. Continue complete-phase sampling and
boundary-graph finiteness reuse, then remaining independent verification costs.
Agent delivery, full regression/compatibility, independent rates, native/browser
checks, visual review, inherited/hostile roles and release audits remain pending.
PR #27 remains draft; **do not merge** until every mandatory gate passes.
The complete language and all GOAL domains remain in progress.

'''
text = text[:start] + replacement + text[end:]
first = text.index('Checkpoint: **') + len('Checkpoint: **')
last = text.index('**', first)
text = text[:first] + now + text[last:]
status.write_text(text)
for name, expected in older.items():
    assert digest((out / name).read_bytes()) == expected
print(json.dumps({k: checkpoint[k] for k in ('source_commit', 'full_source', 'focused', 'archive')}, indent=2))
