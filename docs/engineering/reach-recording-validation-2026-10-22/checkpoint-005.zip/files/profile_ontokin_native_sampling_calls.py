import argparse
from collections import defaultdict
from functools import wraps
import inspect
import json
from pathlib import Path
import runpy
import sys

parser=argparse.ArgumentParser()
parser.add_argument('--repo',required=True)
parser.add_argument('--output',required=True)
parser.add_argument('cases',nargs='+')
args=parser.parse_args()
sys.path.insert(0,args.repo)
import ontokin.reach_export as exporter
import ontokin.reach_runtime as runtime
import ontokin.reach_recording_fast as native
from ontokin.reach_pose import ReachPoseOps

active=False
case_index=-1
stack=[]
results={case:defaultdict(lambda:{'calls':0,'inclusive':0,'exclusive':0}) for case in args.cases}
original_stage=exporter.recording_stage
def stage(name,**kwargs):
    global active,case_index
    if name=='planning':
        case_index+=1
    active=name=='sampling'
    return original_stage(name,**kwargs)
exporter.recording_stage=stage

def instrument(function,name,work_of):
    @wraps(function)
    def measured(*positional,**keywords):
        if not active:
            return function(*positional,**keywords)
        work=work_of(positional,keywords)
        frame=[work.operations,0]
        stack.append(frame)
        try:
            return function(*positional,**keywords)
        finally:
            total=work.operations-frame[0]
            stack.pop()
            if stack:
                stack[-1][1]+=total
            row=results[args.cases[case_index]][name]
            row['calls']+=1
            row['inclusive']+=total
            row['exclusive']+=total-frame[1]
    return measured

for name,function in tuple(ReachPoseOps.__dict__.items()):
    if inspect.isfunction(function) and not name.startswith('__'):
        setattr(ReachPoseOps,name,instrument(function,'pose.'+name,lambda a,k:a[0].work))
for name,function in tuple(native.Binary64RecordingOps.__dict__.items()):
    if inspect.isfunction(function) and not name.startswith('__'):
        setattr(native.Binary64RecordingOps,name,instrument(function,'native.'+name,lambda a,k:a[0].work))
for name in ('sample_bounded_frames','sample_certified_frames','_sample_planar_frames','_planar_paths'):
    setattr(native,name,instrument(getattr(native,name),'native.'+name,lambda a,k:a[0].work))
for name,index in (('_checked_compare',2),('_upper_float',1)):
    setattr(native,name,instrument(getattr(native,name),'native.'+name,lambda a,k,index=index:a[index]))
native.recording_float_excess=instrument(native.recording_float_excess,'native.recording_float_excess',lambda a,k:k['work'])
exporter._recording_lift_relation=instrument(exporter._recording_lift_relation,'export.lift_relation',lambda a,k:k['work'])
for name in ('_coordinate','_pair','_advance_orientation','_dynamic_kinematics','_resolve_kinematics','recording_frames'):
    function=getattr(runtime.ReachSimulator,name)
    setattr(runtime.ReachSimulator,name,instrument(function,'runtime.'+name,lambda a,k:a[0].work))
runtime.recording_pair=instrument(runtime.recording_pair,'recording_pair',lambda a,k:k['work'])
runpy.run_path('/workspace/scratch/02a7d398adff/profile_recordings.py',run_name='__main__')
Path(args.output,'sampling-calls.json').write_text(json.dumps(results,indent=2)+'\n')
