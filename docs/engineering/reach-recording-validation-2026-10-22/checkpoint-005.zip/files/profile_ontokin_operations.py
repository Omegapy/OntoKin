"""Observe original charged work by existing stage and helper, without new budget."""
import argparse
from functools import wraps
from fractions import Fraction
import json
from pathlib import Path
import sys
import time
import traceback

parser = argparse.ArgumentParser()
parser.add_argument('--repo', required=True)
parser.add_argument('--output', required=True)
parser.add_argument('cases', nargs='+')
args = parser.parse_args()
sys.path.insert(0, args.repo)
from tools.reach_delivery_inventory import snapshot, settings, source_files, write_json
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.gltf import export_glb
from ontokin.scene import ExportOptions
import ontokin.reach_export as exporter
import ontokin.reach_conformance as reader
import ontokin.reach_reference as reference
import ontokin.reach_phase as phase
import ontokin.reach_runtime as runtime
import ontokin.reach_pose as pose
import ontokin.reach_recording_fast as native

output = Path(args.output)
output.mkdir()
before = snapshot()
write_json(output / 'inputs-before.json', before)
rows, stack = [], []
active = compiler = None
current_stage = 'construction'

def observe(owner, name, prefix):
    if not hasattr(owner, name):
        return
    original = getattr(owner, name)
    @wraps(original)
    def call(*values, **kwargs):
        if compiler is None:
            return original(*values, **kwargs)
        stage = current_stage
        entry = [compiler.budget.operations, 0]
        stack.append(entry)
        try:
            return original(*values, **kwargs)
        finally:
            stack.pop()
            used = compiler.budget.operations - entry[0]
            if stack:
                stack[-1][1] += used
            key = prefix + '.' + name
            row = active['functions'].setdefault(stage, {}).setdefault(
                key, {'calls': 0, 'inclusive': 0, 'exclusive': 0})
            row['calls'] += 1
            row['inclusive'] += used
            row['exclusive'] += used - entry[1]
    setattr(owner, name, call)

original_stage = exporter.recording_stage
def stage(name, **kwargs):
    global current_stage
    current_stage = name
    if compiler is not None:
        active['stages'].append({'name': name, 'operations': compiler.budget.operations,
                                 'counts': dict(compiler.reach_work.counts)})
    return original_stage(name, **kwargs)
exporter.recording_stage = stage

for owner, prefix, names in (
    (reference.ReachReference, 'Reference', ('_pose_map', '_coordinate', '_root_pose',
        '_recording_root_body', '_recording_attached_body', '_recording_hinge_body',
        '_recording_coordinate_recipe', '_recording_admit_receipts',
        'recording_pose_enclosures', 'recording_stationary_frames', 'phases',
        'point_phase', '_phase', '_source_basis', '_axial_derivatives',
        '_build', '_boundary_projection', 'boundary_states')),
    (reference._PoseArithmetic, 'IntervalPose', ('rotate', 'multiply', 'quaternion',
        'constant', 'compose', 'conjugate', 'hinge', 'spin', '_recording_sincos',
        '_recording_rotate_sincos', '_recording_body_orientation', 'make', 'vector')),
    (reader._Bounds, 'Bounds', ('value', 'cell', 'cells', 'op', 'compare',
        'root', '_root', 'normalize', 'difference', 'norm', '_cache_operand_domain')),
    (reader, 'Reader', ('clock_cell_contains', 'verify_retained_clocks',
        '_geometry_bounds', '_vertex_extrema', '_verify_metadata', '_phase_tables',
        '_verify_certificates', '_key_comparisons', '_recording_orientation_bound',
        '_recording_orientation_comparison', '_recording_position_bound',
        '_certified_stored_arc', '_endpoint_claim_limits', '_complete_inequality_values')),
    (runtime.ReachSimulator, 'Simulator', ('_resolve_kinematics', '_current',
        '_world_target', '_translated_source_slot', '_constant_pose', '_tip_base',
        'recording_boundary', '_bounded_projection', '_process_boundary')),
    (pose.ReachPoseOps, 'ExactPose', ('compose', 'ensure_finite', '_ensure_finite_field',
        '_expose', 'affine', 'multiply', 'rotate', 'recording_body_orientation')),
    (native.Binary64RecordingOps, 'NativePose', ('compose', 'make_recording', 'rotate',
        'multiply', 'affine', 'recording_body_orientation', 'recording_parent_origin',
        'spin', 'ballistic', '_project_rotation', '_rational_vector')),
    (phase, 'Phase', ('phase_bounds',)),
    (exporter, 'Exporter', ('reach_prefix_plan', 'recording_phase_bounds',
        '_endpoint_group_maxima', '_endpoint_group_axes', '_endpoint_group_maxima_exact')),
):
    for name in names:
        observe(owner, name, prefix)

for name in ('validate_reach_export', '_verify_metadata', '_geometry_bounds',
             '_phase_tables', '_verify_certificates'):
    original = getattr(reader, name)
    def begin(*values, _original=original, _name=name, **kwargs):
        global current_stage
        current_stage = _name
        active['stages'].append({'name': _name, 'operations': compiler.budget.operations,
                                 'counts': dict(compiler.reach_work.counts)})
        return _original(*values, **kwargs)
    setattr(reader, name, begin)

for case in args.cases:
    active = {'case': case, 'functions': {}, 'stages': []}
    rows.append(active)
    compiler, current_stage = None, 'construction'
    started = time.monotonic()
    try:
        compiler = compile_construction(load_file_manifest(Path(args.repo) / source_files(case)), level='constructed')
        active['compiled_operations'] = compiler.budget.operations
        request = settings(case)
        result = export_glb(compiler.model, options=ExportOptions(**{**request, 'end': Fraction(request['end'])}),
                            target_contract='ontokin.glb/0.6', work=compiler.reach_work)
        active.update(status='passed', validation=result.report['validation'], sampling=result.report['sampling'])
        (output / (case + '.glb')).write_bytes(result.data)
    except Exception as error:
        active.update(status='failed', error=str(error), traceback=traceback.format_exc())
    if compiler is not None:
        active.update(operations=compiler.budget.operations, work=compiler.reach_work.record())
    active['seconds'] = time.monotonic() - started
    write_json(output / (case + '.json'), active)
    print(json.dumps({'case': case, 'status': active['status'], 'operations': active.get('operations'),
                      'last_stage': current_stage}), flush=True)
after = snapshot()
write_json(output / 'inputs-after.json', after)
write_json(output / 'report.json', {'source_commit': before['git']['commit'],
    'inputs_stable': before == after, 'observational_profile': True,
    'complete_corpus_acceptance': False, 'counter': 'compiler.budget.operations', 'rows': rows})
