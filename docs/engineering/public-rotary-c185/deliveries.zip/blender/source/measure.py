"""Measure the inside-face clearances from the exported Blender GLBs, in glTF space."""
from collections import Counter
import json
from math import atan2, cos, pi, sin
from pathlib import Path
import struct
import sys


def read_scene(path):
    raw = path.read_bytes()
    assert raw[:4] == b"glTF" and struct.unpack_from("<I", raw, 4)[0] == 2
    json_length = struct.unpack_from("<I", raw, 12)[0]
    data = json.loads(raw[20:20 + json_length])
    binary = raw[28 + json_length:]

    def rows(index):
        accessor = data["accessors"][index]
        view = data["bufferViews"][accessor["bufferView"]]
        start = view.get("byteOffset", 0) + accessor.get("byteOffset", 0)
        width = {"SCALAR": 1, "VEC3": 3, "VEC4": 4}[accessor["type"]]
        kind = {5121: "B", 5123: "H", 5125: "I", 5126: "f"}[accessor["componentType"]]
        row = struct.Struct("<" + width * kind)
        stride = view.get("byteStride", row.size)
        return [row.unpack_from(binary, start + i * stride) for i in range(accessor["count"])]

    positions = {}
    for node in data["nodes"]:
        assert set(node) == {"mesh", "name"}, "Expected five untransformed root nodes"
        mesh = data["meshes"][node["mesh"]]
        assert mesh["name"] == node["name"]
        primitive, = mesh["primitives"]
        assert primitive.get("mode", 4) == 4, "Expected triangles"
        vertices = rows(primitive["attributes"]["POSITION"])
        indices = [i for i, in rows(primitive["indices"])]
        edges = Counter()
        for i in range(0, len(indices), 3):
            a, b, c = (vertices[j] for j in indices[i:i + 3])
            edges.update(((a, b), (b, c), (c, a)))
        assert all(count == 1 and edges[v, u] == 1 for (u, v), count in edges.items())
        positions[node["name"]] = set(vertices)
    animation, = data["animations"]
    motion = {}
    for channel in animation["channels"]:
        target = channel["target"]
        assert target["path"] == "rotation"
        sampler = animation["samplers"][channel["sampler"]]
        assert sampler["interpolation"] == "LINEAR"
        times = [t for t, in rows(sampler["input"])]
        angles = []
        for x, y, z, w in rows(sampler["output"]):
            assert abs(x) + abs(z) < 1e-7
            angles.append(2 * atan2(y, w))
        assert times[0] == 0 and times[-1] == 2
        assert all(abs(theta - t * pi / 4) < 1e-6 for t, theta in zip(times, angles))
        motion[data["nodes"][target["node"]]["name"]] = list(zip(times, angles))
    assert set(motion) == {"index_arm", "gauge_shoe"}
    assert motion["index_arm"] == motion["gauge_shoe"]
    return positions, motion


def measure(path):
    positions, motion = read_scene(path)
    for guard in ("east_guard", "north_guard"):
        east = guard == "east_guard"
        face = min(x if east else -z for x, _, z in positions[guard])
        best = (float("inf"),)
        for part, keyframes in motion.items():
            for x, _, z in positions[part]:
                a, b = (x, z) if east else (-z, x)
                critical = atan2(b, a)
                for (t0, q0), (t1, q1) in zip(keyframes, keyframes[1:]):
                    angles = [q0, q1]
                    if q0 < critical < q1:
                        angles.append(critical)
                    for theta in angles:
                        support = a * cos(theta) + b * sin(theta)
                        # A single-axis quaternion SLERP varies angle linearly between keys.
                        time = t0 + (theta - q0) * (t1 - t0) / (q1 - q0)
                        best = min(best, (face - support, time, part))
        gap, time, part = best
        print(f"{path.stem:10}  {guard:11}  {part:10}  {1000*gap:12.8f} mm"
              f"  {time:.8f} s  inward plane distance from origin {face:.9f} m")


if __name__ == "__main__":
    for name in sys.argv[1:]:
        measure(Path(name))
