"""Create the editable Blender baseline and export a Y-up, metre GLB."""
from itertools import product
from math import pi
from pathlib import Path
import sys

import bpy


# Each row gives the part ID, min and max in the glTF metre frame,
# linear RGB, and whether the part turns around the vertical origin.
PARTS = [
    ("mount", (-0.17, 0, -0.17), (0.17, 0.12, 0.17), (0.21, 0.26, 0.30), False),
    ("index_arm", (-0.04, 0.19, -0.035), (0.65, 0.24, 0.035), (0.17, 0.50, 0.54), True),
    ("gauge_shoe", (0.60, 0.16, -0.09), (0.80, 0.27, 0.09), (0.84, 0.60, 0.18), True),
    ("east_guard", (0.824, 0.12, -0.28), (0.864, 0.31, 0.28), (0.61, 0.25, 0.19), False),
    ("north_guard", (-0.28, 0.12, -0.838), (0.28, 0.31, -0.798), (0.61, 0.25, 0.19), False),
]

# Corner indices correspond to the lexicographic product of X, Y and Z bounds.
FACES = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1),
         (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]


def add_part(name, lower, upper, rgb, turns):
    # Convert the authored Y-up frame to Blender's Z-up frame.
    points = [(x, -z, y) for x, y, z in product(*zip(lower, upper))]
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata(points, [], FACES)
    mesh.update()
    obj = bpy.data.objects.new(name, mesh)
    bpy.context.collection.objects.link(obj)

    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    shader = mat.node_tree.nodes.get("Principled BSDF")
    shader.inputs["Base Color"].default_value = (*rgb, 1)
    shader.inputs["Metallic"].default_value = 0
    shader.inputs["Roughness"].default_value = 0.65
    obj.data.materials.append(mat)
    if turns:
        for frame, yaw in ((0, 0), (48, pi / 2)):
            obj.rotation_euler.z = yaw
            obj.keyframe_insert(data_path="rotation_euler", index=2, frame=frame)
        for curve in obj.animation_data.action.fcurves:
            for key in curve.keyframe_points:
                key.interpolation = "LINEAR"


def main():
    out = Path(sys.argv[sys.argv.index("--") + 1]).resolve()
    out.mkdir(parents=True, exist_ok=False)
    bpy.ops.wm.read_factory_settings(use_empty=True)
    scene = bpy.context.scene
    scene.unit_settings.system = "METRIC"
    scene.unit_settings.scale_length = 1
    scene.render.fps = 24
    scene.frame_start, scene.frame_end = 0, 48
    for part in PARTS:
        add_part(*part)
    scene.frame_set(0)
    bpy.ops.wm.save_as_mainfile(filepath=str(out / "indexer.blend"))
    bpy.ops.export_scene.gltf(
        filepath=str(out / "starter.glb"), export_format="GLB",
        export_yup=True, export_animations=True,
        export_animation_mode="ACTIVE_ACTIONS",
        export_nla_strips_merged_animation_name="index",
        export_force_sampling=True, export_frame_range=True,
        export_optimize_animation_size=True, export_extras=False,
    )


if __name__ == "__main__":
    main()
