# Editable Blender indexer

`indexer.blend` is the initial editable scene. The Python source builds it from the dimensions, linear colors and motion flags in `PARTS`. It converts glTF's Y-up coordinates into Blender's Z-up frame. The arm and shoe have the same pivot and a linear Euler angle from zero to 90 degrees over 48 frames at 24 frames per second. Blender's standard glTF exporter records the motion in one animation.

From this folder, run the following command with the official Blender 4.5.3 Linux x64 executable and a new output directory.

```bash
"$BLENDER" -b -t 2 --factory-startup --python-exit-code 1 \
    --python build_indexer.py -- /tmp/blender-indexer-build
```

The output contains `indexer.blend` and `starter.glb`. The copies beside this document preserve the initial state. Both the mesh data and the mesh-bearing objects carry the five semantic names.
