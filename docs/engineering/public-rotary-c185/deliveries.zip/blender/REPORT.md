# Blender rotary indexer repair

The `index_arm` carries the `gauge_shoe`. The starter’s north guard intersects the sweeping shoe by 7.047 mm at 1.857360 s. In both repairs, the shoe’s mounting face remains at local X = 600 mm and its outer face reaches X = 900 mm. Its vertical range is 160–270 mm. The long shoe is 180 mm wide and the wide-long shoe is 260 mm wide, both centred at Z = 0.

## Swept clearance on exported meshes

| Variant | Guard | Minimum inward gap (mm) | Time from start (s) | Guard displacement (mm) |
| --- | --- | ---: | ---: | ---: |
| Long | East | 15.000005 | 0.126902 | +95.489 X |
| Long | North | 15.000005 | 1.873098 | −121.489 Z |
| Wide long | East | 14.999972 | 0.182649 | +100.340 X |
| Wide long | North | 14.999972 | 1.817351 | −126.340 Z |

`source/measure.py` decodes each GLB’s vertex positions, triangle indices and quaternion keys. For every vertex of the shoe and arm it finds the largest projection toward the guard over each animation interval. Each projection has the form `a cos(θ) + b sin(θ)`. Testing both ends and the internal maximum gives the continuous minimum face gap. In every row, a shoe tip corner is closest. It passes opposite the middle of the finite guard span, vertically within the guard face. Both guard minima occur between animation keys.

## Rebuild or select one variant

From the submission directory, set `BLENDER` to the Blender 4.5.3 executable and choose a fresh output directory. The script opens the supplied editable scene separately for each selection. It writes an editable Blender scene and an animated GLB for each.

```bash
"$BLENDER" -b -t 2 --factory-startup --python-exit-code 1 \
  --python source/build_variants.py -- rebuilt --variant all
python3 source/measure.py rebuilt/long.glb rebuilt/wide-long.glb
```

The single selector `--variant` accepts `long`, `wide-long`, or `all` (both, the default). The original scene, starter GLB, original generator and starter README are preserved in `source/starter/`.

## Verification and run record

- Blender 4.5.3 LTS, Linux x64, build 67807e1800cc. The exporter identifies itself as Khronos glTF Blender I/O v4.5.48. Measurement used Python 3.12.14 and its standard library.
- The first native build succeeded. A second build into a fresh directory reproduced both GLBs byte for byte. SHA-256 for `long.glb` is `01e79bcde66ade5efa930a4a4a3611c115839df2d2073e1c54dafbb7fcc1c6d0`. For `wide-long.glb` it is `0d1bd0dc6c14578bfb38b1983a61d24f9dfacd81b6aac078bbc402fb6f923a04`.
- Checks against the starter passed for mount and arm vertices, material definitions, semantic names and motion keys. Each moving part has the same 49 linear quaternion keys over 0–2 s, with zero translation. Every part is a closed triangle mesh after welding identical corner positions. Both exports passed the dimension and rigid guard displacement checks.
- An AI author adapted the supplied Blender scene with Python and ran these checks. The coordinator supplied the pinned Blender executable and handles independent checking and common-viewer inspection. No modelling, export, measurement, or regeneration check failed during authoring.
