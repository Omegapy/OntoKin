# OntoKin rotary indexer repair

The teal `index_arm` carries the amber `gauge_shoe`. Both turn 90° about world +Y in 2 s. The shoe mounting face stays at local X = 0.600 m. Both variants extend its tip to X = 0.900 m and keep the Y range 0.160–0.270 m. The long shoe spans Z = ±0.090 m and the wide long shoe spans Z = ±0.130 m.

| Variant | Guard | Guard displacement | Minimum gap | Time after start |
| --- | --- | ---: | ---: | ---: |
| Long | East | +95.489 mm X | 15.000027 mm | 0.126902 s |
| Long | North | −121.489 mm Z | 15.000005 mm | 1.873098 s |
| Wide long | East | +100.340 mm X | 15.000023 mm | 0.182649 s |
| Wide long | North | −126.340 mm Z | 15.000001 mm | 1.817351 s |

The editable design sets each inner face 15 mm beyond the radius of an outer shoe corner. Only the guard placements move. The readback in `source/measure.py` calculates the gap from the GLB position, translation, rotation and time accessors. For every arm and shoe vertex, it evaluates both sweep endpoints and the stationary maximum of its projection toward each guard. It recovers the time from the surrounding quaternion keys. All four closest vertices are on the shoe, and their perpendicular projections land within the rectangular guard faces. The readback also checks directed triangle-edge closure, fixed positions and the constant-rate quarter turn. Full precision is in `measurements.json`.

## Regenerate

From the staged OntoKin route root, choose a new output directory. Use the supplied pinned `runtime` checkout with CPython 3.12.14. To rebuild both selections and repeat the measurement, run these commands.

```sh
../job/venv/bin/python -IB submission/source/build.py runtime rebuilt
../job/venv/bin/python -IB submission/source/measure.py rebuilt/long.glb rebuilt/wide-long.glb
```

To build a single variant, append `--variant long` or `--variant wide-long` to the first command. The selector changes the one return statement in `half_width_m()` in `source/main.ok`. Both dimensions and guard placements are computed in the OntoKin source. The preserved editable starter is in `starter/`.

## Export and checks

One AI author adapted the supplied starter and wrote the Python build and measurement scripts. A separate coordinator supplied the runtime, common viewer and independent checks. The development build used the first command above with `dev-build` as the output directory. Both variants passed native export on the first run. Both passed the measurement check on its first run. No formal-check feedback was used to author these files.

The native exporter was OntoKin reference 0.4.0, language 0.22, profile `torque-0.1`. The build requested 12 fps. The native recorder emitted 57 key times for the long shoe and 58 for the wide long shoe, from 0 to 2 s in each case. GLB rotation and translation channels use LINEAR interpolation.

The exporter gives all five meshes the name `extrusion`. The build copies each stable node name onto its mesh. Each `native/<variant>/` folder retains the generated native source, original GLB, execution report and a comparison recording both SHA-256 hashes. The complete binary chunks match byte for byte, and every other parsed JSON field matches.
