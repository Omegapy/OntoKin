# Editable OntoKin indexer

`main.ok` defines the five baseline solids, their materials and the two-second turn. The block helper extrudes a rectangle. Each class places its extrusion in the object's local frame. Both turning parts share the world origin and start with the same angular velocity. Their collision-disabled sphere bodies supply only the rotational motion in this example.

Use the pinned OntoKin checkout and its CPython 3.12.14 environment. From this folder, run the following command with a new output directory.

```bash
"$JOB/venv/bin/python" -IB export.py "$JOB/checkout" /tmp/ok-indexer-build
```

The output contains `starter.glb` and the execution report, `export.json`. The copy of `starter.glb` beside this document preserves the initial export. The five semantic names appear on the nodes that carry the meshes.
