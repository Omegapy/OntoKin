"""Export main.ok with the pinned OntoKin runtime."""
import argparse
import json
from pathlib import Path
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkout", type=Path, help="restored OntoKin source root")
    parser.add_argument("output", type=Path, help="new output directory")
    args = parser.parse_args()
    sys.path.insert(0, str(args.checkout.resolve()))
    from ontokin.budget_runtime import execute_torque_export
    from ontokin.execution_budget import HostPolicy
    from ontokin.scene import ExportOptions
    from ontokin.texture_bundle import load_texture_bundle

    entry = Path(__file__).with_name("main.ok")
    bundle = load_texture_bundle({
        "schema_version": "ontokin.bundle/0.2",
        "entry": {"filename": entry.name, "source": entry.read_text(encoding="utf-8")},
        "modules": [], "assets": [],
    })
    args.output.mkdir(parents=True, exist_ok=False)
    result = execute_torque_export(
        bundle, policy=HostPolicy(max_operations=1_000_000, max_elapsed_ms=80_000),
        caller_caps={"max_operations": 1_000_000, "max_elapsed_ms": 80_000},
        options=ExportOptions(end="2", fps=12, helpers=False),
    )
    (args.output / "export.json").write_text(json.dumps(result.report, indent=2) + "\n")
    if result.data is None:
        raise SystemExit("Export failed. See export.json.")
    (args.output / "starter.glb").write_bytes(result.data)


if __name__ == "__main__":
    main()
