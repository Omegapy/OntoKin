"""Export one or both rotary indexer variants using the pinned OntoKin runtime."""

import argparse
import hashlib
import json
from pathlib import Path
import struct
import sys


SELECTORS = {"long": "long_half_width_m", "wide-long": "wide_long_half_width_m"}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def split_glb(data):
    magic, version, total, json_length, json_tag = struct.unpack_from("<4sIII4s", data)
    if (magic, version, total, json_tag) != (b"glTF", 2, len(data), b"JSON"):
        raise ValueError("Unexpected GLB header.")
    return json.loads(data[20:20 + json_length]), data[20 + json_length:]


def name_meshes(data):
    """Use each mesh owner's stable name; preserve all native geometry and animation."""
    document, binary_chunks = split_glb(data)
    for node in document["nodes"]:
        if "mesh" in node:
            document["meshes"][node["mesh"]]["name"] = node["name"]

    encoded = json.dumps(document, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    encoded += b" " * (-len(encoded) % 4)
    header = struct.pack("<4sIII4s", b"glTF", 2, 20 + len(encoded) + len(binary_chunks), len(encoded), b"JSON")
    final = header + encoded + binary_chunks

    native_doc, native_chunks = split_glb(data)
    final_doc, final_chunks = split_glb(final)
    names = []
    for old, new in zip(native_doc["meshes"], final_doc["meshes"], strict=True):
        names.append([old["name"], new["name"]])
        new["name"] = old["name"]
    if final_doc != native_doc or final_chunks != native_chunks:
        raise ValueError("GLB naming step changed data outside the mesh names.")
    return final, {"mesh_name_pairs": names, "native_sha256": digest(data),
                   "final_sha256": digest(final), "binary_chunks_sha256": digest(final_chunks),
                   "binary_chunks_identical": True, "other_json_fields_identical": True}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runtime", type=Path, help="pinned OntoKin checkout")
    parser.add_argument("output", type=Path, help="new directory; must not already exist")
    parser.add_argument("--variant", choices=["both", *SELECTORS], default="both")
    args = parser.parse_args()
    sys.path.insert(0, str(args.runtime.resolve()))
    from ontokin.budget_runtime import execute_torque_export
    from ontokin.execution_budget import HostPolicy
    from ontokin.scene import ExportOptions
    from ontokin.texture_bundle import load_texture_bundle

    default_source = Path(__file__).with_name("main.ok").read_text(encoding="utf-8")
    default_choice = "    return long_half_width_m();"
    if default_source.count(default_choice) != 1:
        raise ValueError("Expected one variant selection in half_width_m().")
    args.output.mkdir(parents=True, exist_ok=False)
    variants = SELECTORS if args.variant == "both" else [args.variant]
    for variant in variants:
        source = default_source.replace(default_choice, f"    return {SELECTORS[variant]}();")
        audit = args.output / "native" / variant
        audit.mkdir(parents=True)
        (audit / "main.ok").write_text(source, encoding="utf-8")
        bundle = load_texture_bundle({
            "schema_version": "ontokin.bundle/0.2",
            "entry": {"filename": "main.ok", "source": source},
            "modules": [], "assets": [],
        })
        result = execute_torque_export(
            bundle, policy=HostPolicy(max_operations=1_000_000, max_elapsed_ms=80_000),
            caller_caps={"max_operations": 1_000_000, "max_elapsed_ms": 80_000},
            options=ExportOptions(end="2", fps=12, helpers=False),
        )
        (audit / "export.json").write_text(json.dumps(result.report, indent=2) + "\n")
        if result.data is None:
            raise SystemExit(f"{variant} export failed; inspect {audit / 'export.json'}")
        (audit / f"{variant}.glb").write_bytes(result.data)
        final, comparison = name_meshes(result.data)
        (args.output / f"{variant}.glb").write_bytes(final)
        (audit / "comparison.json").write_text(json.dumps(comparison, indent=2) + "\n")
        print(f"{variant}: {len(final):,} bytes; {comparison['final_sha256']}")


if __name__ == "__main__":
    main()
