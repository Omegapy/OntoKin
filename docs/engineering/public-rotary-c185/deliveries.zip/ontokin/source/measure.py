"""Recover continuous guard clearance from the five exported meshes and their animation."""

import argparse
from bisect import bisect_right
from collections import Counter
import json
import math
from pathlib import Path
import struct


def measure(path):
    raw = path.read_bytes()
    length = struct.unpack_from("<I", raw, 12)[0]
    doc = json.loads(raw[20:20 + length])
    binary = memoryview(raw)[28 + length:]

    def accessor(index):
        acc = doc["accessors"][index]
        view = doc["bufferViews"][acc["bufferView"]]
        size = {"SCALAR": 1, "VEC3": 3, "VEC4": 4}[acc["type"]]
        layout = struct.Struct("<" + str(size) + {5126: "f", 5125: "I", 5123: "H", 5121: "B"}[acc["componentType"]])
        offset = view.get("byteOffset", 0) + acc.get("byteOffset", 0)
        stride = view.get("byteStride", layout.size)
        return [layout.unpack_from(binary, offset + stride * i) for i in range(acc["count"])]

    nodes = doc["nodes"]
    assert all("children" not in n and "matrix" not in n and "scale" not in n for n in nodes)
    animation, = doc["animations"]
    tracks = {n["name"]: {} for n in nodes}
    for channel in animation["channels"]:
        target = channel["target"]
        sampler = animation["samplers"][channel["sampler"]]
        assert sampler["interpolation"] == "LINEAR"
        times = [t for t, in accessor(sampler["input"])]
        tracks[nodes[target["node"]]["name"]][target["path"]] = (times, accessor(sampler["output"]))

    parts = {}
    for node in nodes:
        name = node["name"]
        mesh = doc["meshes"][node["mesh"]]
        assert mesh["name"] == name
        primitive, = mesh["primitives"]
        assert primitive.get("mode", 4) == 4
        positions = accessor(primitive["attributes"]["POSITION"])
        indices = [i for i, in accessor(primitive["indices"])]
        directed = Counter()
        for i in range(0, len(indices), 3):
            a, b, c = (positions[k] for k in indices[i:i + 3])
            directed.update([(a, b), (b, c), (c, a)])
        assert len(indices) == 36 and all(n == directed[b, a] == 1 for (a, b), n in directed.items())

        _, translations = tracks[name]["translation"]
        assert len(set(translations)) == 1
        offset = translations[0]
        times, rotations = tracks[name]["rotation"]
        assert times[0] == 0 and times[-1] == 2 and all(b > a for a, b in zip(times, times[1:]))
        assert all(q[0] == q[2] == 0 for q in rotations)
        yaw = [2 * math.atan2(q[1], q[3]) for q in rotations]
        if name in {"gauge_shoe", "index_arm"}:
            assert offset == (0, 0, 0) and all(b > a for a, b in zip(yaw, yaw[1:]))
            assert max(abs(a - t * math.pi / 4) for t, a in zip(times, yaw)) < 2e-6
        else:
            assert yaw == [0] * len(yaw)
        parts[name] = (sorted(set(positions)), offset, times, yaw)

    results = {}
    for guard in ("east_guard", "north_guard"):
        east = guard == "east_guard"
        static, offset, _, _ = parts[guard]
        guard_vertices = [tuple(a + b for a, b in zip(p, offset)) for p in static]
        face = min(p[0] if east else -p[2] for p in guard_vertices)
        widest_projection = -math.inf
        for mover in ("index_arm", "gauge_shoe"):
            vertices, _, times, yaw = parts[mover]
            for x, y, z in vertices:
                # Projection onto the guard normal is A cos(yaw) + B sin(yaw).
                a, b = (x, z) if east else (-z, x)
                peak = math.atan2(b, a)
                candidates = [yaw[0], yaw[-1]]
                if yaw[0] <= peak <= yaw[-1]:
                    candidates.append(peak)
                for angle in candidates:
                    projection = a * math.cos(angle) + b * math.sin(angle)
                    if projection <= widest_projection:
                        continue
                    widest_projection = projection
                    i = min(bisect_right(yaw, angle) - 1, len(yaw) - 2)
                    s = (angle - yaw[i]) / (yaw[i + 1] - yaw[i])
                    time = times[i] + s * (times[i + 1] - times[i])
                    closest = (x * math.cos(angle) + z * math.sin(angle), y,
                               -x * math.sin(angle) + z * math.cos(angle))
                    winner = (mover, time, closest)
        mover, time, closest = winner
        for i in ([1, 2] if east else [0, 1]):
            assert min(p[i] for p in guard_vertices) <= closest[i] <= max(p[i] for p in guard_vertices)
        gap = face - widest_projection
        assert abs(gap - 0.015) < 0.0005
        results[guard] = {"minimum_mm": round(gap * 1000, 9), "time_s": round(time, 9),
                          "nearest_part": mover, "inner_face_distance_m": face,
                          "moving_corner_world_m": closest}
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("glbs", type=Path, nargs="+")
    args = parser.parse_args()
    print(json.dumps({p.name: measure(p) for p in args.glbs}, indent=2))
