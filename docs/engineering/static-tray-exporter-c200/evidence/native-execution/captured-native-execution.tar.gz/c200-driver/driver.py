"""Observe one approved C200 coordinator invocation; never retry it."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import signal
import subprocess
import time

repo = Path('/workspace/scratch/ef5ae272e66e/ontokin')
lock_path = repo / 'docs/engineering/static-tray-exporter-c200/EXECUTABLE-INPUTS.json'
approval_path = lock_path.with_suffix('.approval.json')
lock_hash = hashlib.sha256(lock_path.read_bytes()).hexdigest()
approval_hash = hashlib.sha256(approval_path.read_bytes()).hexdigest()
assert lock_hash == 'e22d12703926740c2c4cb8596781192b9f0412836e3fba7c6f353bedfc60e0e0'
assert approval_hash == 'aa9c5234b666b5f4a79924502f3074dada274ff1135b78b11a8d83a560ceae2a'
lock = json.loads(lock_path.read_text())
approval = json.loads(approval_path.read_text())
assert approval['decision'] == 'APPROVED_FOR_NATIVE'
assert approval['input_lock_sha256'] == lock_hash
assert not Path(lock['schedule_root']).exists()
assert not Path(lock['qualification_revision']['invocation_receipt']).exists()
directory = Path('/workspace/scratch/ef5ae272e66e/c200-native-driver')
directory.mkdir(exist_ok=False)
(directory / 'driver.py').write_bytes(Path(__file__).read_bytes())
command = {'schema': 'ontokin.c200.driver-command/0.1', 'argv': lock['coordinator_command'],
           'environment': lock['coordinator_environment'], 'cwd': str(repo),
           'input_lock': str(lock_path), 'input_lock_sha256': lock_hash,
           'approval': str(approval_path), 'approval_sha256': approval_hash,
           'outer_observer_timeout_seconds': 1600, 'automatic_retry_permitted': False,
           'scope': 'One exact approved coordinator invocation; every inner stage keeps its locked limits'}
(directory / 'COMMAND.json').write_text(json.dumps(command, indent=2, sort_keys=True) + '\n')
started = time.monotonic()
record = {'schema': 'ontokin.c200.driver-completed/0.1',
          'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'input_lock_sha256': lock_hash, 'approval_sha256': approval_hash,
          'automatic_retry_permitted': False, 'outer_timeout': False}
with (directory / 'stdout.log').open('w') as stdout, (directory / 'stderr.log').open('w') as stderr:
    process = subprocess.Popen(command['argv'], cwd=repo, env=command['environment'],
                               stdout=stdout, stderr=stderr, start_new_session=True)
    record.update(pid=process.pid, process_group=process.pid)
    (directory / 'STARTED.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
    try:
        code = process.wait(timeout=1600)
    except subprocess.TimeoutExpired:
        record['outer_timeout'] = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        code = 124
    record['process_reaped'] = process.returncode is not None
record.update(returncode=code, stdout_closed=stdout.closed, stderr_closed=stderr.closed,
              finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              elapsed_seconds=time.monotonic() - started)
(directory / 'COMPLETED.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps(record, sort_keys=True))
print((directory / 'stdout.log').read_text()[-8000:])
if code:
    print((directory / 'stderr.log').read_text()[-4000:])
raise SystemExit(code)
