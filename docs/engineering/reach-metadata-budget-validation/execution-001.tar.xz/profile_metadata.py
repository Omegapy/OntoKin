from pathlib import Path
from fractions import Fraction
from collections import Counter
from contextlib import ExitStack
from unittest.mock import patch
import hashlib
import json
import subprocess
import sys
import time
import traceback

root, output, endpoint = Path(sys.argv[1]), Path(sys.argv[2]), Fraction(sys.argv[3])
output.mkdir(parents=True, exist_ok=False)
sys.path.insert(0, str(root))
from ontokin import gltf, json_limits, reach_conformance, reach_export
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.scene import ExportOptions

def hashes():
    return {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (root / 'ontokin').glob('*.py')}

source = hashes()
(output / 'changes.patch').write_bytes(subprocess.check_output(['git', '-C', str(root), 'diff', 'HEAD']))
compiler = compile_construction(load_file_manifest(root / 'docs/language-design/planar-reach-v0.1/p01.files.json'))
stages, measurements = [], []
original_measure = json_limits.measure_json

def measure(value, **kwargs):
    caller = sys._getframe(1).f_code.co_name
    before = compiler.budget.operations
    check = kwargs.get('check')
    texts, sites = Counter(), Counter()
    def checkpoint():
        frame = sys._getframe(1)
        sites[frame.f_code.co_name] += 1
        if frame.f_code.co_name == 'string_size':
            kind = 'key' if frame.f_back.f_code.co_name == 'object_keys' else 'value'
            texts[kind, frame.f_locals['text']] += 1
        if check is not None:
            check()
    kwargs['check'] = checkpoint
    result = None
    try:
        result = original_measure(value, **kwargs)
        return result
    finally:
        measurements.append({'caller': caller, 'before': before, 'after': compiler.budget.operations,
                             'result': result, 'callbacks': dict(sites),
                             'text_callbacks': [{'kind': k, 'text': t, 'count': n}
                                                for (k, t), n in texts.most_common()]})

def wrap(module, name):
    original = getattr(module, name)
    def invoke(*args, **kwargs):
        before, started = compiler.budget.operations, time.monotonic()
        result = None
        try:
            result = original(*args, **kwargs)
            if name == '_encode':
                (output / 'unvalidated-artifact.glb').write_bytes(result[0])
            return result
        finally:
            stages.append({'function': name, 'before': before, 'after': compiler.budget.operations,
                           'elapsed_seconds': time.monotonic() - started})
    return invoke

error = result = None
started = time.monotonic()
with ExitStack() as stack:
    stack.enter_context(patch.object(gltf, 'measure_json', measure))
    for module, names in ((gltf, ['_encode', 'read_glb']), (reach_conformance, ['validate_reach_export']),
                          (reach_export, ['reach_prefix_plan', 'interval_certificates'])):
        for name in names:
            stack.enter_context(patch.object(module, name, wrap(module, name)))
    try:
        result = gltf.export_glb(compiler.model, options=ExportOptions(end=endpoint, fps=int(sys.argv[4]) if len(sys.argv) > 4 else 2, helpers=False),
                                 target_contract='ontokin.glb/0.6', work=compiler.reach_work)
        (output / 'artifact.glb').write_bytes(result.data)
    except BaseException:
        error = traceback.format_exc()
report = {'source_commit': subprocess.check_output(['git', '-C', str(root), 'rev-parse', 'HEAD']).decode().strip(),
          'source_hashes': source, 'source_hashes_after': hashes(), 'operations': compiler.budget.operations,
          'work': compiler.reach_work.record(), 'stages': stages, 'measurements': measurements,
          'status': 'failed' if error else 'passed', 'error': error,
          'elapsed_seconds': time.monotonic() - started, 'report': result.report if result else None}
(output / 'report.json').write_text(json.dumps(report, indent=2))
print(json.dumps({key: report[key] for key in ('status', 'operations', 'stages', 'elapsed_seconds')}, indent=2))
for item in measurements:
    print(json.dumps({key: item[key] for key in ('caller', 'before', 'after', 'result', 'callbacks')}, indent=2))
    print(json.dumps(item['text_callbacks'][:30], indent=2))
if error:
    print(error[-2000:])
