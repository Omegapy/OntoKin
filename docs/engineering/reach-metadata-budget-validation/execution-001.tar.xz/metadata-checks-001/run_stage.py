from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/46d8ba619503/OntoKin-destination')
OUT = Path(__file__).resolve().parent
def sha(raw): return 'sha256:' + hashlib.sha256(raw).hexdigest()
def git(*args): return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()
def inputs():
    names = git('ls-files').splitlines()
    return {name: sha((ROOT / name).read_bytes()) for name in names
            if (name.startswith(('ontokin/', 'tools/', 'docs/', 'tests/')) and Path(name).suffix in {'.py', '.mjs', '.json', '.md', '.ok'}
                or name in {'tests/test_reach_native_reference_bridge.py', 'tests/reach_native_resources.mjs', 'tests/reach_viewer_resources.mjs'})}
name, command = sys.argv[1], sys.argv[2:]
report = {'stage': name, 'command': command, 'cwd': str(ROOT), 'started_at': datetime.now(timezone.utc).isoformat(),
          'git': {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'), 'status': git('status', '--porcelain=v1')},
          'python_launcher': sys.version, 'launcher_sha256': sha(Path(__file__).read_bytes()), 'inputs_before': inputs()}
started = time.monotonic()
with (OUT / (name + '.log')).open('xb') as stream:
    try:
        result = subprocess.run(command, cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT, timeout=960)
        report['returncode'] = result.returncode
    except Exception as error:
        report['failure'] = {'type': type(error).__name__, 'message': str(error)}
        report['returncode'] = -1
report.update(elapsed_seconds=time.monotonic() - started, finished_at=datetime.now(timezone.utc).isoformat(), inputs_after=inputs())
report['inputs_stable'] = report['inputs_before'] == report['inputs_after']
report['log_sha256'] = sha((OUT / (name + '.log')).read_bytes())
with (OUT / (name + '.json')).open('x') as stream: json.dump(report, stream, indent=2)
print(json.dumps({key: report[key] for key in ('stage', 'returncode', 'elapsed_seconds', 'inputs_stable')}))
print((OUT / (name + '.log')).read_text())
raise SystemExit(report['returncode'] if report['inputs_stable'] else 1)
