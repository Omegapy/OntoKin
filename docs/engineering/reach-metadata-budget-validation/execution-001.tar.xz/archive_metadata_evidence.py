from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import platform
import subprocess
import sys
import tarfile
import io

root = Path('/workspace/scratch/46d8ba619503/reach-checks')
repository = Path('/workspace/scratch/46d8ba619503/OntoKin-destination')
destination = repository / 'docs/engineering/reach-metadata-budget-validation'
paths = [root / 'profile_metadata.py', Path(__file__)]
for name in ('profile-metadata-001', 'profile-metadata-002', 'profile-metadata-003',
             'profile-metadata-004', 'metadata-checks-001'):
    paths.extend(sorted((root / name).rglob('*')))
paths = sorted(path for path in paths if path.is_file())
if any(path.is_symlink() for path in paths):
    raise ValueError('No symlink inputs')
records = [{'path': str(path.relative_to(root)), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in paths]
manifest = {'schema': 'ontokin.reach-metadata-budget-evidence/0.1',
            'source_commit': subprocess.check_output(['git', '-C', str(repository), 'rev-parse', 'HEAD'], text=True).strip(),
            'created_at': datetime.now(timezone.utc).isoformat(), 'python': sys.version,
            'platform': platform.platform(), 'files': records,
            'runtime_release_acceptance': False}
raw = (json.dumps(manifest, indent=2) + '\n').encode()
archive = destination / 'execution-001.tar.xz'
with tarfile.open(archive, 'x:xz', format=tarfile.PAX_FORMAT) as output:
    for path in paths:
        output.add(path, arcname=str(path.relative_to(root)), recursive=False)
    item = tarfile.TarInfo('MANIFEST.json')
    item.size = len(raw)
    output.addfile(item, io.BytesIO(raw))
with tarfile.open(archive, 'r:xz') as supplied:
    if len(supplied.getmembers()) != len(records) + 1:
        raise ValueError('Unexpected archive membership')
    for row in records:
        raw = supplied.extractfile(row['path']).read()
        if len(raw) != row['bytes'] or hashlib.sha256(raw).hexdigest() != row['sha256']:
            raise ValueError('Archived bytes differ')
summary = {'source_commit': manifest['source_commit'], 'regular_files': len(records) + 1,
           'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'all_member_bytes_verified': True}
(destination / 'archive.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
