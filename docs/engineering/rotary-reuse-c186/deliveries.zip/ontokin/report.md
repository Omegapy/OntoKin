# OntoKin indexer reuse

The `medium-long` selection adds a 220 mm wide shoe to the accepted C185 design. Its mounting face is at local X = 600 mm, and its tip is at X = 900 mm. The solid spans Y = 160–270 mm and Z = −110 to +110 mm. The arm and shoe share the original two-second, 90° turn about world +Y.

## Clearances from the exported solids

| Selection | Shoe width (mm) | East minimum (mm) | East time (s) | North minimum (mm) | North time (s) |
| --- | ---: | ---: | ---: | ---: | ---: |
| long | 180 | 15.000027 | 0.126902 | 15.000005 | 1.873098 |
| medium-long | 220 | 15.000024 | 0.154850 | 15.000002 | 1.845150 |
| wide-long | 260 | 15.000023 | 0.182649 | 15.000001 | 1.817351 |

For the new selection the design sets each guard’s inner face at a distance of √(900² + 110²) + 15 = 921.6973 mm from the rotation axis. The east guard moves 97.6973 mm along +X from the original starter, and the north guard moves 123.6973 mm along −Z. Each guard then remains fixed throughout the turn.

The C185 readback script takes actual triangle positions and animation keys from each GLB. It finds the maximum projection of every shoe and arm vertex onto each guard normal, testing the endpoints and the interior maximum of the sinusoidal projection. It interpolates the time from the rotation keys and verifies that the closest corner projects inside the finite guard face. In all six cases the closest moving part is the shoe. Detailed readings are in `measurements.json`.

## Rebuild

Run from the staged OntoKin route root with the supplied CPython 3.12.14 interpreter and pinned runtime. Each invocation requires a fresh output directory.

```sh
../job/venv/bin/python -IB delivery/source/build.py staged/runtime reproduce/long --variant long
../job/venv/bin/python -IB delivery/source/build.py staged/runtime reproduce/medium-long --variant medium-long
../job/venv/bin/python -IB delivery/source/build.py staged/runtime reproduce/wide-long --variant wide-long
```

A single run can build and check all three.

```sh
../job/venv/bin/python -IB delivery/source/build.py staged/runtime build --variant all
../job/venv/bin/python -IB delivery/source/measure.py build/long.glb build/medium-long.glb build/wide-long.glb
../job/venv/bin/python -IB delivery/checks/verify.py c185-design build
```

## Changes and checks

- `source/main.ok` adds a named 0.110 m half-width. The existing centered extrusion and guard-position formula both read this selection.
- `source/build.py` maps `medium-long` to that function and accepts `all` for all three selections. The existing `both` option still selects the two C185 variants. The original measurement script and the supplied `starter/` are retained.
- `checks/verify.py` adds a regression check. The complete embedded binary payload and every glTF JSON field outside application-specific `extras` match the C185 exports for `long` and `wide-long`. OntoKin records the edited source revision in its metadata. For the new selection the check reads the shoe bounds directly from the position buffer, verifies the five named parts and their material assignments, and compares materials with C185. Output is in `checks/regression.json`.
- The three standalone GLBs are at the top level. The original naming step copies the stable node identifiers onto the five meshes. Each `native/<selection>/` directory includes the runtime input, native GLB, execution report and a comparison confirming that the naming step changed only mesh names. `source/measure.py` also checked triangle closure, static guards, and the constant-rate common-axis turn for every export.
- One AI participant edited the accepted C185 design and ran its build, measurement and regression checks. The coordinator furnished the pinned interpreter, runtime, common Delft viewer and a separate checker. The C185 source and measurement method were reused. No failed native export or participant geometry check occurred.
- All three individual rebuild commands completed and their GLBs matched the three files from the combined build byte for byte. This is the first formal submission. The coordinator conducts the fixed Delft viewer review and independent checks on the sealed GLBs.
