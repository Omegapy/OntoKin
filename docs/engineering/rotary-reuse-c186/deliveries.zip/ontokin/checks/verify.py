"""Check reuse against the accepted C185 GLBs and measure the new shoe from vertices."""

import argparse
import hashlib
import json
from pathlib import Path
import struct


def read_glb(path):
    data = path.read_bytes()
    size = struct.unpack_from("<I", data, 12)[0]
    document = json.loads(data[20:20 + size], object_hook=lambda obj: {k: v for k, v in obj.items() if k != "extras"})
    length, kind = struct.unpack_from("<I4s", data, 20 + size)
    binary = data[28 + size:]
    assert kind == b"BIN\x00" and length == len(binary)
    assert len(document["buffers"]) == 1 and "uri" not in document["buffers"][0]
    return document, binary


def check(accepted, rebuilt):
    results = {}
    for name in ("long", "wide-long"):
        document, binary = read_glb(rebuilt / f"{name}.glb")
        original_document, original_binary = read_glb(accepted / f"{name}.glb")
        assert document == original_document and binary == original_binary, name
        results[name] = {"glTF_fields_excluding_extras_identical": True, "binary_payload_identical": True,
                         "binary_payload_sha256": hashlib.sha256(binary).hexdigest()}

    doc, binary = read_glb(rebuilt / "medium-long.glb")
    assert doc["materials"] == original_document["materials"]
    nodes = {n["name"]: n for n in doc["nodes"]}
    assert set(nodes) == {"mount", "index_arm", "gauge_shoe", "east_guard", "north_guard"}
    for name, node in nodes.items():
        mesh = doc["meshes"][node["mesh"]]
        assert mesh["name"] == name
        primitive, = mesh["primitives"]
        assert primitive["material"] == original_document["meshes"][node["mesh"]]["primitives"][0]["material"]
    primitive, = doc["meshes"][nodes["gauge_shoe"]["mesh"]]["primitives"]
    acc = doc["accessors"][primitive["attributes"]["POSITION"]]
    assert (acc["type"], acc["componentType"]) == ("VEC3", 5126)
    view = doc["bufferViews"][acc["bufferView"]]
    offset = view.get("byteOffset", 0) + acc.get("byteOffset", 0)
    stride = view.get("byteStride", 12)
    points = [struct.unpack_from("<3f", binary, offset + i * stride) for i in range(acc["count"])]
    bounds_mm = [[min(axis) * 1000, max(axis) * 1000] for axis in zip(*points)]
    for measured, expected in zip(bounds_mm, ((600, 900), (160, 270), (-110, 110))):
        assert all(abs(a - b) <= 0.2 for a, b in zip(measured, expected))
    results["medium-long"] = {"local_shoe_bounds_mm_xyz": bounds_mm, "part_identities_and_materials_match": True}
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("accepted", type=Path)
    parser.add_argument("rebuilt", type=Path)
    args = parser.parse_args()
    print(json.dumps(check(args.accepted, args.rebuilt), indent=2))
