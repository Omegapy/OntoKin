"""Generate the repaired rotary indexer from its editable, unmodified Blender starter."""
import argparse
from math import atan2, cos, pi, sin
from pathlib import Path
import sys

import bpy


STARTER = Path(__file__).resolve().parent / "starter" / "indexer.blend"
HALF_WIDTH_M = {"long": 0.090, "medium-long": 0.110, "wide-long": 0.130}
EXTENSION_M = 0.100
GAP_M = 0.015
END_ANGLE = pi / 2


def furthest_support(objects, axis):
    """Largest positive projection of any vertex over the continuous quarter turn."""
    projections = []
    for obj in objects:
        for vertex in obj.data.vertices:
            x, y, _ = obj.matrix_world @ vertex.co
            # In Blender's Z-up frame, the east and north directions are +X and +Y.
            a, b = (x, -y) if axis == 0 else (y, x)
            angles = [0.0, END_ANGLE]
            stationary = atan2(b, a)
            if 0 < stationary < END_ANGLE:
                angles.append(stationary)
            projections.extend(a * cos(t) + b * sin(t) for t in angles)
    return max(projections)


def build(variant, out):
    bpy.ops.wm.open_mainfile(filepath=str(STARTER))
    scene = bpy.context.scene
    scene.frame_set(0)
    shoe = scene.objects["gauge_shoe"]
    arm = scene.objects["index_arm"]
    tip_x = max(v.co.x for v in shoe.data.vertices)
    for vertex in shoe.data.vertices:
        if vertex.co.x == tip_x:
            vertex.co.x += EXTENSION_M
        vertex.co.y = HALF_WIDTH_M[variant] if vertex.co.y > 0 else -HALF_WIDTH_M[variant]
    shoe.data.update()

    for axis, name in enumerate(("east_guard", "north_guard")):
        guard = scene.objects[name]
        inner_face = min(v.co[axis] for v in guard.data.vertices)
        offset = furthest_support((shoe, arm), axis) + GAP_M - inner_face
        for vertex in guard.data.vertices:
            vertex.co[axis] += offset
        guard.data.update()

    bpy.ops.wm.save_as_mainfile(filepath=str(out / f"{variant}.blend"))
    bpy.ops.export_scene.gltf(
        filepath=str(out / f"{variant}.glb"), export_format="GLB",
        export_yup=True, export_animations=True,
        export_animation_mode="ACTIVE_ACTIONS",
        export_nla_strips_merged_animation_name="index",
        export_force_sampling=True, export_frame_range=True,
        export_optimize_animation_size=True, export_extras=False,
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(__doc__)
    parser.add_argument("output_dir", type=Path)
    parser.add_argument("--variant", choices=("all", *HALF_WIDTH_M), default="all")
    options = parser.parse_args(sys.argv[sys.argv.index("--") + 1:])
    dest = options.output_dir.resolve()
    dest.mkdir(parents=True, exist_ok=True)
    for selection in HALF_WIDTH_M if options.variant == "all" else (options.variant,):
        build(selection, dest)
