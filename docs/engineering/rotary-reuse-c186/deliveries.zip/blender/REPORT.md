# Third shoe width for the rotary indexer

The new `medium-long` shoe on the `index_arm` occupies X = 600 to 900 mm, Y = 160 to 270 mm and Z = −110 to +110 mm in the exported metre-based, Y-up frame. Its mounting face and centreline therefore stay in place. Relative to the starter, the east guard moves +97.697318 mm in X and the north guard moves −123.697340 mm in Z.

## Continuous clearance on exported geometry

| Selection | East minimum (mm) | Time (s) | North minimum (mm) | Time (s) |
| --- | ---: | ---: | ---: | ---: |
| `long` | 15.000005 | 0.126902 | 15.000005 | 1.873098 |
| `medium-long` | 14.999980 | 0.154850 | 14.999980 | 1.845150 |
| `wide-long` | 14.999972 | 0.182649 | 14.999972 | 1.817351 |

The inherited `source/measure.py` reads the moving vertices and quaternion keys from each GLB. For each key interval it tests the endpoints and the internal maximum of each vertex's projection onto the guard normal. For the new width, the outside shoe corner peaks at a radius of about 906.697 mm. Its projection onto either inside guard face lies on the transverse centreline, within the face's ±280 mm span. The shoe’s height also lies within the 120–310 mm guard height.

## Regeneration

From this delivery directory, set `BLENDER` to the Blender 4.5.3 executable. These three commands independently produce an editable scene and an animated GLB per selection. Use a fresh output directory.

```bash
"$BLENDER" -b -t 2 --factory-startup --python-exit-code 1 --python source/build_variants.py -- rebuilt --variant long
"$BLENDER" -b -t 2 --factory-startup --python-exit-code 1 --python source/build_variants.py -- rebuilt --variant medium-long
"$BLENDER" -b -t 2 --factory-startup --python-exit-code 1 --python source/build_variants.py -- rebuilt --variant wide-long
python3 source/measure.py rebuilt/long.glb rebuilt/medium-long.glb rebuilt/wide-long.glb
```

Use `--variant all` to generate all three in one process.

## Changes and checks

- The only edit to the accepted design source is one entry for a 0.110 m half-width in `source/build_variants.py`. The editable starter, its generator and the measurement script were carried over unchanged. This report and the new selection's two output files are new to this exercise. All three pairs of GLB and Blender files were generated from the edited source.
- Blender 4.5.3 LTS, build `67807e1800cc`, exported all three selections on the first run. Running each documented selector independently in a fresh directory reproduced all three GLBs byte for byte.
- The regenerated `long.glb` and `wide-long.glb` match their accepted C185 files byte for byte. Their SHA-256 values begin `01e79bcde66ade5e` and `0d1bd0dc6c14578b`, respectively. The new GLB SHA-256 is `5883ab262f5e77e5e692ea28ba271f932078dba28d599fb36c88fe5b2240241c`.
- On the new export, author checks confirmed embedded mesh data, five stable mesh and node names, original materials and assignments, identical mount and arm vertices, and the eight specified shoe corners. Differences between corresponding old and new guard vertices were constant along the prescribed axis and zero along the other two. Wound triangle edges paired in both directions on all five solids. The arm and shoe share the accepted 49 linear quaternion keys about Y over 0–2 s.
- No authoring, export, rebuild or measurement attempt failed. An AI participant edited the Blender selector, ran Blender and checked the GLBs with Python. The coordinator supplied the pinned executable and staged public files, and conducts the common fixed Delft viewer review and independent acceptance check.
