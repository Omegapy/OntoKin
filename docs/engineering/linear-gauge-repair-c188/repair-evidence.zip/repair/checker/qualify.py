#!/usr/bin/env python3
"""Reproduce frozen C187 qualification and the C188 fault-injection controls."""
import argparse
from copy import deepcopy
import json
from pathlib import Path
import subprocess
import sys

from measure import DESIGN, HERE, OLD, check, compare, digest
from make_controls import build


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def main(out, regenerate):
    out.mkdir(parents=True, exist_ok=True)
    old = json.loads(OLD.read_text())
    new = json.loads(DESIGN.read_text())
    expected = deepcopy(old)
    left = next(p for p in expected["parts"] if p["id"] == "left_shoe")
    assert left["worldBoundsAt0Mm"][0][0] == 80
    left["worldBoundsAt0Mm"][0][0] = 50
    if expected != new:
        raise ValueError("C188 design differs from C187 beyond the prescribed rear face")
    subprocess.run([sys.executable, "qualify.py", "--out", str((out / "c187-qualification.json").resolve())],
                   cwd=HERE / "frozen", check=True)
    frozen_bytes = (HERE / "frozen/qualification.json").read_bytes()
    frozen_exact = (out / "c187-qualification.json").read_bytes() == frozen_bytes
    hashes = {}
    for line in (HERE / "frozen/SHA256SUMS").read_text().splitlines():
        hashed, name = line.split(maxsplit=1)
        hashes[name] = digest(HERE / "frozen" / name) == hashed
    forward, both = deepcopy(old), deepcopy(new)
    next(p for p in forward["parts"] if p["id"] == "left_shoe")["worldBoundsAt0Mm"][1][0] += 30
    next(p for p in both["parts"] if p["id"] == "right_shoe")["worldBoundsAt0Mm"][0][0] -= 30
    cases = []
    for route in ("ontokin", "blender"):
        path = HERE / "originals" / (route + ".glb")
        cases.append(("original-" + route, path, None, "left_shoe: world bounds error 30", True))
    for name, spec, reason in [("rear-extension", new, None),
                               ("front-extension", forward, "left_shoe: world bounds error 30"),
                               ("both-shoes", both, "right_shoe: world bounds error 30")]:
        path = HERE / "controls" / (name + ".glb")
        generated = build(spec, "good")
        if regenerate:
            path.write_bytes(generated)
        if not path.exists():
            raise FileNotFoundError(path)
        cases.append((name, path, generated, reason, False))
    controls = []
    for name, path, generated, reason, original in cases:
        r = check(path, DESIGN)
        write(out / (name + ".json"), r)
        starter = check(path, OLD)
        if original:
            write(out / (name + "-c187.json"), starter)
        source_pass = starter["pass"]
        matches = r["pass"] if reason is None else (not r["pass"] and reason in r.get("reason", ""))
        expected_old = original
        controls.append({"case": name, "sha256": digest(path), "expectedC188Pass": reason is None,
                         "observedC188Pass": r["pass"], "observedC187Pass": source_pass,
                         "expectedC187Pass": expected_old, "reason": r.get("reason"),
                         "reproducesBytes": path.read_bytes() == generated if generated is not None else None,
                         "verified": bool(matches and source_pass == expected_old
                                          and (generated is None or path.read_bytes() == generated))})
    synthetic = compare(HERE / "frozen/controls/good.glb", HERE / "controls/rear-extension.glb")
    write(out / "positive-comparison.json", synthetic)
    # A within-spec discrepancy can pass the frozen design yet differ from its own baseline.
    # These controls exercise that second-stage comparison, including the unchanged sibling lane.
    isolation = []
    for change in ("subtolerance-stop", "subtolerance-color", "subtolerance-travel"):
        design, mode = deepcopy(new), "good"
        stop = next(p for p in design["parts"] if p["id"] == "right_stop")
        if change == "subtolerance-stop":
            for corner in stop["worldBoundsAt0Mm"]:
                corner[0] += .05
        elif change == "subtolerance-color":
            stop["baseColorLinearRGB"][0] += .001
        else:
            mode = "good_design_rounding"
        generated = build(design, mode)
        path = HERE / "controls" / (change + ".glb")
        if regenerate:
            path.write_bytes(generated)
        control = check(path, DESIGN)
        delta = compare(HERE / "frozen/controls/good.glb", path)
        changed = sorted(k for k, v in delta["parts"].items() if not v["withinRoundoff"])
        expected = (["left_carriage", "left_shoe", "right_carriage", "right_shoe"]
                    if change == "subtolerance-travel" else ["right_stop"])
        isolation.append({"case": change, "sha256": digest(path), "frozenDesignPass": control["pass"],
                          "changedParts": changed, "expectedChangedParts": expected,
                          "reproducesBytes": path.read_bytes() == generated,
                          "verified": control["pass"] and changed == expected and generated == path.read_bytes()})
    result = {"version": "C188.1", "frozenC187ReceiptsByteIdentical": frozen_exact,
              "frozenC187ManifestEntriesVerified": sum(hashes.values()), "frozenC187ManifestEntries": len(hashes),
              "c187DesignSha256": digest(OLD), "c188DesignSha256": digest(DESIGN),
              "onlyDesignDelta": {"id":"left_shoe", "face":"minimum X", "fromMm":80, "toMm":50},
              "positiveComparisonPassed": synthetic["allPartsWithinRoundoff"], "controls": controls,
              "unchangedComparisonControls": isolation,
              "pass": all(hashes.values()) and frozen_exact and synthetic["allPartsWithinRoundoff"]
                      and all(c["verified"] for c in controls + isolation)}
    write(out / "qualification.json", result)
    return result["pass"]


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--regenerate-controls", action="store_true")
    args = p.parse_args()
    raise SystemExit(0 if main(args.out, args.regenerate_controls) else 1)
