# C188.1 two-carriage gauge inspection

The original left shoe ran from 80 to 180 mm along X. The C188 design moves its rear face to 50 mm, keeping its front face at 180 mm. The other six parts, both motion paths, and both shoe-to-stop gaps are unchanged.

## Reproduce

Use Python 3.9 or newer with NumPy. Run from this directory. The measurement command returns 0 when both the design check and the comparison to the chosen route's original pass. It returns 1 for a failed check.

```sh
sha256sum -c SHA256SUMS
python qualify.py --out /tmp/c188-qualification
python measure.py ontokin /path/candidate.glb --out /tmp/c188-ontokin.json
python measure.py blender /path/candidate.glb --out /tmp/c188-blender.json
```

The qualifier independently regenerates each synthetic specimen in memory and compares its bytes to the preserved GLB. To regenerate the files themselves, add `--regenerate-controls`. Positives and faults are generated from the two numeric design tables using the frozen C187 specimen generator. Neither route's editable source is required.

## Evidence

- `frozen/` is the incoming C187 checker. Its original 40 SHA-256 entries are verified by the C188 qualifier. Its original qualification receipt, covering four positives, 26 negatives and three swept-intersection tests, reproduces byte for byte.
- `assembly.json` is the incoming C188 numeric design. Qualification verifies that the rear coordinate of the left shoe is the sole change from the frozen C187 document.
- `originals/ontokin.glb` came from `gauge/deliveries/ontokin/build/starter.glb` in C187. `originals/blender.glb` came from `gauge/deliveries/blender/gauge.glb`. The receipts record SHA-256 for both files and preserve each original's pass under C187 and rejection under C188.
- `controls/` includes a correct rear extension, an incorrect forward extension and incorrect extension of both shoes. It also includes three deliberately small changes that pass the design tolerance and fail the route comparison, covering world geometry, color and motion.
- `receipts/qualification.json` identifies each control, its expected and observed result, and the first failed part where applicable. The full numerical positive receipt includes both gaps over the clip.

## Reading a submission receipt

The frozen checker certifies seven named, closed, axis-aligned cuboids. It verifies coverage, winding, solid colors, clip duration, piecewise-linear world travel, swept intersections for all 21 pairs and the time and size of each minimum gap. See `frozen/README.md` for the glTF profile and numerical bounds. Exporter compatibility and general glTF conformance are outside this inspection.

The additional route comparison uses the route's original GLB and the candidate. It checks each of the six world-space cuboid faces at the start, the stable node and mesh IDs, the color of every primitive, and the relative world displacement at every key time in either clip. Between those key times both translations are affine. Since the first stage certifies a complete rectangular shell in both exports, the six planes determine the occupied shape. The expected start-plane displacement for the rear face is −30 mm. For every other face it is zero. The comparison uses 0.0001 mm and 0.0000001 linear RGB to accommodate numeric roundoff. The design's 0.2 mm bound and 0.005 RGB bound are checked separately.

For each part the receipt also compares SHA-256 digests of logical mesh-attribute/index values and primitive topology, per-primitive material fields, node and ancestor static pose fields, and all ancestral animation tracks (typed time and value arrays plus interpolation). These exact comparisons ignore buffer placement, padding and node numbering. They are descriptive, since an equivalent GLB can use another tessellation or key grid. A false field-match flag can therefore coexist with a passing physical comparison.
