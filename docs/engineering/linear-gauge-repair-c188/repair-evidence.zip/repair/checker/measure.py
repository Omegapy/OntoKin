#!/usr/bin/env python3
"""Measure a C188 submission and compare it with its own frozen C187 route."""
import argparse
import hashlib
import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "frozen"))
from check import check
from gltf import Scene

DESIGN = HERE / "assembly.json"
OLD = HERE / "frozen/assembly.json"
IDS = {p["id"] for p in json.loads(DESIGN.read_text())["parts"]}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def signature(value):
    data = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()
    return hashlib.sha256(data).hexdigest()


def accessor(scene, i):
    """Hash the typed logical elements. Buffer placement, stride and padding are immaterial."""
    a = scene.doc["accessors"][i]
    bv = scene.doc["bufferViews"][a["bufferView"]]
    width = {"SCALAR": 1, "VEC2": 2, "VEC3": 3, "VEC4": 4}[a["type"]]
    dtype = np.dtype({5120: "i1", 5121: "u1", 5122: "<i2", 5123: "<u2",
                      5125: "<u4", 5126: "<f4"}[a["componentType"]])
    row = width * dtype.itemsize
    arr = np.ndarray((a["count"], width), dtype, scene.bin,
                     bv.get("byteOffset", 0) + a.get("byteOffset", 0),
                     (bv.get("byteStride", row), dtype.itemsize))
    return [a["componentType"], a["type"], a.get("normalized", False), a["count"],
            hashlib.sha256(arr.tobytes(order="C")).hexdigest()]


def fields(scene, name):
    node = scene.parts[name][0]
    mesh = scene.doc["meshes"][scene.nodes[node]["mesh"]]
    primitives = mesh["primitives"]
    mesh_data = []
    for prim in primitives:
        attrs = {k: accessor(scene, v) for k, v in prim["attributes"].items()}
        mesh_data.append({"mode": prim.get("mode", 4), "attributes": attrs,
                          "indices": accessor(scene, prim["indices"]) if "indices" in prim else None})
    ancestry = []
    i = node
    while i is not None:
        ancestry.append(i)
        i = scene.parent[i]
    # Compare by ancestor depth and name to ignore changes in node numbering.
    poses = [{k: scene.nodes[i][k] for k in ("name", "translation", "rotation", "scale", "matrix")
              if k in scene.nodes[i]} for i in ancestry]
    animation = scene.doc["animations"][0]
    tracks = {}
    for chan in animation["channels"]:
        target = chan["target"]
        if target["node"] in ancestry:
            key = f"{ancestry.index(target['node'])}/{target['path']}"
            sampler = animation["samplers"][chan["sampler"]]
            tracks[key] = [sampler.get("interpolation", "LINEAR"), accessor(scene, sampler["input"]),
                           accessor(scene, sampler["output"])]
    return {"meshAttributesAndIndices": signature(mesh_data),
            "perPrimitiveMaterials": signature([scene.doc["materials"][p["material"]] for p in primitives]),
            "nodeAndAncestryPoseFields": signature(poses), "ancestralAnimationTracks": signature(tracks)}


def compare(old_path, new_path):
    a, b = Scene(old_path, IDS), Scene(new_path, IDS)
    times = np.union1d(a.knots, b.knots)
    worlds = [s.transforms(times)[0] for s in (a, b)]
    result = {}
    for name in sorted(IDS):
        surfaces, motions, palettes = [], [], []
        for scene, frames in zip((a, b), worlds):
            i, local, colors = scene.parts[name]
            matrix = frames[i]
            tri = 1000 * (local @ matrix[0, :3, :3].T + matrix[0, :3, 3])
            surfaces.append(np.stack((tri.min(axis=(0, 1)), tri.max(axis=(0, 1)))))
            motions.append(1000 * (matrix[:, :3, 3] - matrix[0, :3, 3]))
            palettes.append(np.unique(colors, axis=0))
        # Every route baseline has a single solid color per part. Check all candidate primitives.
        if len(palettes[0]) != 1:
            raise ValueError(f"{name}: baseline is not a single solid color")
        color_delta = float(np.max(np.abs(palettes[1] - palettes[0][0])))
        delta = surfaces[1] - surfaces[0]
        expected_delta = np.zeros((2, 3))
        if name == "left_shoe":
            expected_delta[0, 0] = -30.
        geometry_error = float(np.abs(delta - expected_delta).max())
        motion_error = float(np.abs(motions[1] - motions[0]).max())
        f0, f1 = fields(a, name), fields(b, name)
        result[name] = {
            "role": "rear-only extension" if name == "left_shoe" else "unchanged",
            "stableNodeAndMeshId": name,
            "boundsDeltaAt0Mm": delta.tolist(),
            "maxExpectedWorldFaceDeltaErrorMm": geometry_error,
            "maxRelativeMotionDifferenceMmAtUnionKnots": motion_error,
            "maxBaseColorDifference": color_delta,
            "fieldDigests": {"original": f0, "candidate": f1},
            "exactDecodedFieldMatch": {k: f0[k] == f1[k] for k in f0},
            "withinRoundoff": geometry_error <= 0.0001 and motion_error <= 0.0001 and color_delta <= 1e-7,
        }
    return {"comparison": "Certified rectangular shells at rest plus affine world translations at every union knot",
            "unionKnotCount": len(times), "worldRoundoffMm": 0.0001, "colorRoundoff": 1e-7,
            "unchangedParts": sorted(IDS - {"left_shoe"}), "parts": result,
            "allPartsWithinRoundoff": all(x["withinRoundoff"] for x in result.values())}


def measure(original, candidate):
    baseline = check(original, OLD)
    repaired = check(candidate, DESIGN)
    result = {"version": "C188.1", "originalSha256": digest(original),
              "candidateSha256": digest(candidate), "designSha256": digest(DESIGN),
              "originalDesignPass": baseline["pass"], "c188": repaired, "pass": False}
    if not baseline["pass"]:
        result["reason"] = baseline["reason"]
    elif repaired["pass"]:
        result["comparison"] = compare(original, candidate)
        result["pass"] = result["comparison"]["allPartsWithinRoundoff"]
    return result


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("route", choices=("blender", "ontokin"))
    p.add_argument("candidate", type=Path)
    p.add_argument("--out", type=Path, required=True)
    args = p.parse_args()
    r = measure(HERE / "originals" / (args.route + ".glb"), args.candidate)
    args.out.write_text(json.dumps(r, indent=2, allow_nan=False) + "\n")
    raise SystemExit(0 if r["pass"] else 1)
