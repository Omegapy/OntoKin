# C188 Blender repair

Open `gauge.blend` to edit the native scene or play frames 0–48 at 24 frames per second. `gauge.glb` is the standalone file written directly by Blender's bundled glTF exporter. The four original C187 files are in the accompanying `starter/` directory.

## Source change

In `build.py`, the instance-size override assigns 130 × 50 × 80 mm to `left_shoe` in glTF X, Y, Z order. The vertex calculation derives rear X by subtracting the instance length from the original local front X of 100 mm. The left shoe's local rear X therefore moves from 0 to −30 mm. Its object origin, parent and front face retain their C187 coordinates. At time zero the shoe spans X = 50 to 180 mm. The right shoe uses the shared 100 mm length and spans X = 80 to 180 mm.

## Clean build

From the directory containing this README, run the following with Blender 4.5.3 LTS on the executable search path.

```sh
mkdir -p tmp
TMPDIR="$PWD/tmp" blender -b -t 2 --factory-startup --python-exit-code 1 --python build.py -- rebuilt
python3 measure.py rebuilt/gauge.glb
```

The measured build used executable `/workspace/scratch/e7fbfa81c224/replay-work/blender-4.5.3-linux-x64/blender`, build hash `67807e1800cc`. The output directory was `submission` for the delivered files. A second independent build into an empty directory produced identical GLB bytes.

## Measurements

| Lane | Gap at 0 s (mm) | Minimum gap (mm) | Time (s) |
| --- | ---: | ---: | ---: |
| Left | 314.999998 | 14.999993 | 2.000000 |
| Right | 314.999998 | 14.999993 | 2.000000 |

`measure.py` reads vertex positions and translation tracks from the GLB, adds parent translations and subtracts each shoe's maximum X from the matching stop's minimum X. It verifies overlap in Y and Z at every animation key. Linear translation between keys means the smallest sampled gap is also the continuous minimum.

A comparison against the C187 GLB found four distinct geometric corners moved. All four are on the left shoe's rear face. Outside its position buffer and position accessor's minimum X, the binary payload and parsed JSON match the starter. Both the node and mesh IDs come from their Blender names. No export naming step was used. Native and delivered GLB SHA-256 is `6b7ff8fe451d9628df25c020f1112eecf3e4cf64d0adf3843575ebf8158445d1`.

## Trial record

The first C188 local native build succeeded. The second was the clean reproducibility check. Failed C188 local repair trials: zero. Formal handoff: submission 1. The coordinator supplied the participant brief, numeric assembly table, C187 starter and executable path. The author implemented the repair and measured the GLB independently.
