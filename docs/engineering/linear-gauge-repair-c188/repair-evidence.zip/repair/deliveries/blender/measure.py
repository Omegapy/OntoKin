"""Measure clearance from the Blender export's vertices and translation tracks."""
import json
from pathlib import Path
import struct
import sys


def measure(path):
    data = path.read_bytes()
    magic, version, total, size, kind = struct.unpack_from("<4s4I", data)
    assert (magic, version, total, kind) == (b"glTF", 2, len(data), 0x4E4F534A)
    model = json.loads(data[20:20 + size])
    payload = memoryview(data)[28 + size:]

    def floats(index):
        acc = model["accessors"][index]
        assert acc["componentType"] == 5126
        layout = struct.Struct("<" + "f" * {"SCALAR": 1, "VEC3": 3}[acc["type"]])
        view = model["bufferViews"][acc["bufferView"]]
        start = view.get("byteOffset", 0) + acc.get("byteOffset", 0)
        stride = view.get("byteStride", layout.size)
        return [layout.unpack_from(payload, start + i * stride) for i in range(acc["count"])]

    nodes = model["nodes"]
    by_name = {node["name"]: i for i, node in enumerate(nodes)}
    parents = {c: i for i, node in enumerate(nodes) for c in node.get("children", [])}
    animation, = model["animations"]
    tracks = {}
    times = None
    for channel in animation["channels"]:
        sampler = animation["samplers"][channel["sampler"]]
        assert channel["target"]["path"] == "translation" and sampler["interpolation"] == "LINEAR"
        samples = [t for t, in floats(sampler["input"])]
        assert times is None or samples == times
        times = samples
        tracks[channel["target"]["node"]] = floats(sampler["output"])

    def bounds(i, sample):
        primitive, = model["meshes"][nodes[i]["mesh"]]["primitives"]
        points = floats(primitive["attributes"]["POSITION"])
        offset = [0, 0, 0]
        while i is not None:
            node = nodes[i]
            assert not {"matrix", "rotation", "scale"}.intersection(node)
            translation = tracks[i][sample] if i in tracks else node.get("translation", (0, 0, 0))
            offset = [x + y for x, y in zip(offset, translation)]
            i = parents.get(i)
        return [(1000 * (min(v) + t), 1000 * (max(v) + t)) for v, t in zip(zip(*points), offset)]

    for lane in ("left", "right"):
        gaps = []
        for sample, time in enumerate(times):
            shoe = bounds(by_name[lane + "_shoe"], sample)
            stop = bounds(by_name[lane + "_stop"], sample)
            for axis in (1, 2):
                assert min(shoe[axis][1], stop[axis][1]) > max(shoe[axis][0], stop[axis][0])
            gaps.append((stop[0][0] - shoe[0][1], time))
        minimum, time = min(gaps)
        print(f"{lane}: initial {gaps[0][0]:.6f} mm, minimum {minimum:.6f} mm at {time:.6f} s")


if __name__ == "__main__":
    measure(Path(sys.argv[1]))
