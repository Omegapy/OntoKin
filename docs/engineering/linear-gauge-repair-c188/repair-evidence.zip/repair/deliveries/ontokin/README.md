# C188 OntoKin left-shoe repair

Open `build/repaired.glb` for the finished assembly. The editable source is `main.ok`. The supplied C187 starter remains alongside this directory at `../starter/`.

In `scene Slide`, the `left_shoe` object overrides `length_x` to 130 mm and sets its placement X to 50 mm. The shoe origin is its minimum corner, so its forward face remains at X = 180 mm. The right shoe inherits the 100 mm class default and spans X = 80 to 180 mm. Both carriage and shoe pairs use the original 150 mm/s velocity for two seconds.

## Rebuild and measurement

From the entrant directory, run the following with a fresh output directory. The environment used CPython 3.12.14 and OntoKin reference 0.4.0 for language 0.22, profile torque-0.1. The runtime source digest is `3e6ef2df6a7e8837050abb949075bff9b65f6a4aa4a9f1587850d7ddd59bce56`.

```sh
python3.12 -IB submission/build.py /dev/shm/ontokin-188/tools/ok/runtime rebuilt
python3.12 -IB submission/measure.py rebuilt/repaired.glb
```

| Lane | Initial gap (mm) | Minimum gap (mm) | Time (s) |
| --- | ---: | ---: | ---: |
| Left | 315.000009 | 15.000015 | 2.000 |
| Right | 315.000005 | 15.000008 | 2.000 |

The measurement reads the GLB position buffers and all 25 world-translation keys. Shoe and stop overlap in Y and Z at each key. Every rotation is the identity, and both gaps decrease across all 24 linear intervals, so the last key is the global minimum. Full precision and both initial shoe bounds are in `measurements.json`.

## Native output

`build/native.glb` is the untouched export and `build/export.json` is its native validation report. OntoKin names each occurrence node correctly and uses `extrusion` for each mesh. The supplied builder copies the seven node names into their associated mesh names. The output filename changes from `starter.glb` to `repaired.glb`. The field-level record in `build/export-diff.json` identifies all seven replacements and the binary payload hash. Applying its replacements to the native JSON reproduced the repaired JSON exactly. Both files contain the same 11,552-byte binary payload.

## Trials and assistance

The starter documents the instance override and supplies the build wrapper. The coordinator supplied the task, assembly table, original package and pinned runtime. The author used those materials and a local Python reader. No other author or outside design assistance contributed.

The first native build passed. One local comparison initially failed because it included the material provenance field `extras.ontokin.program_revision`, which changes when the source changes. After excluding that field, all seven material definitions matched. The index and normal buffers matched, as did the six unaffected position buffers and every animation track except the left shoe's translation. The repaired model required no further edits. The starter checksum check passed for all eight supplied files.

Formal submission 1 consists of this source, its build output and the measurements above.
