"""Place the six signed-model playback captures and two matched starter/repair crops."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

root = Path(__file__).resolve().parents[1]
shots = root / "evidence/c188/playback"
starter = root / "evidence/c187/playback"
paper = Image.new("RGB", (1536, 1040), "#11212b")
draw = ImageDraw.Draw(paper)


def text(x, y, value, size, color="#eaf0f3", bold=False):
    family = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
    draw.text((x, y), value, font=ImageFont.truetype(family, size), fill=color)


text(36, 20, "ONTOKIN   /   C188", 17, "#9dd2c7", True)
text(34, 46, "A longer left shoe, the same stopping clearance", 38, bold=True)
text(36, 101, "The upper lane in this view contains the repaired shoe. Both lanes advance 300 mm over two seconds.", 22)
columns = (36, 534, 1032)
for x, time, gap in zip(columns, ("0 s", "1 s", "2 s"), (315, 165, 15)):
    text(x, 154, time, 23, bold=True)
    text(x + 60, 158, f"{gap} mm gap", 19, "#a2d5c7")
for label, route, y in (("Blender / Python", "blender", 197), ("OntoKin", "ontokin", 502)):
    text(36, y, label, 19, bold=True)
    for t, x in enumerate(columns):
        with Image.open(shots / f"{route}-{t}.png") as frame:
            paper.paste(frame.convert("RGB").resize((468,267), Image.Resampling.LANCZOS), (x, y+29))

draw.line((36,814,1500,814), fill="#3a515f", width=1)
text(36, 846, "Left shoe at 0 s", 26, bold=True)
text(36, 894, "Matched crops from the Blender captures.", 18)
text(36, 924, "The gold shoe extends toward the teal carriage.", 18)
text(36, 954, "Its forward face stays at X = 180 mm.", 18, "#a2d5c7")
for x, label, directory in ((646,"C187  /  100 mm",starter),(1083,"C188  /  130 mm",shots)):
    text(x, 834, label, 19, bold=True)
    with Image.open(directory / "blender-0.png") as image:
        area = image.crop((238, 28, 427, 110))
        paper.paste(area.resize((378,164), Image.Resampling.NEAREST), (x, 864))
paper.save(root / "repair/comparison.png", optimize=True)
