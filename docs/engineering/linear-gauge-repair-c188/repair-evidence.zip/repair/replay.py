"""Replay the C188 controls, six measurements, source audit and recorded playback evidence."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from tempfile import TemporaryDirectory

HERE = Path(__file__).resolve().parent
KIT = HERE.parent
CHECKER = HERE / 'checker'
EVIDENCE = KIT / 'evidence/c188'
sys.path.insert(0, str(CHECKER))
from measure import measure


def read(path):
    return json.loads(path.read_bytes())


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def verify_seal(root, path):
    sealed = read(path)['files']
    files = {str(p.relative_to(root)): p for p in root.rglob('*') if p.is_file()}
    assert files.keys() == sealed.keys(), path
    for name, p in files.items():
        assert sha(p) == sealed[name]['sha256'] and p.stat().st_size == sealed[name]['bytes'], name


def replay():
    dispatch = read(EVIDENCE / 'dispatch.json')
    assert dispatch['checkerManifestSha256'] == sha(CHECKER / 'SHA256SUMS')
    for line in (CHECKER / 'SHA256SUMS').read_text().splitlines():
        digest, name = line.split(maxsplit=1)
        assert sha(CHECKER / name) == digest, name
    assert (HERE / 'assembly.json').read_bytes() == (CHECKER / 'assembly.json').read_bytes()
    with TemporaryDirectory() as tmp:
        subprocess.run([sys.executable, '-B', str(CHECKER / 'qualify.py'), '--out', tmp],
                       check=True, stdout=subprocess.DEVNULL, env={**os.environ, 'PYTHONDONTWRITEBYTECODE':'1'})
        q = read(Path(tmp) / 'qualification.json')
        assert q == read(CHECKER / 'receipts/qualification.json') and q['pass']
    audit = json.loads(subprocess.check_output([sys.executable, '-IB', str(EVIDENCE / 'source-review/audit.py')]))
    assert audit == read(EVIDENCE / 'source-review/field-audit.json') and audit['pass']
    report = read(EVIDENCE / 'source-review/khronos.json')
    frames = read(EVIDENCE / 'playback/frames.json')
    pixels = read(EVIDENCE / 'playback/pixel-comparison.json')['views']
    assert len(pixels) == len(frames['shots']) == 6 and not frames['errors']
    routes = {}
    for route, final_name, starter_name in [('blender', 'gauge.glb', 'gauge.glb'),
                                             ('ontokin', 'build/repaired.glb', 'build/starter.glb')]:
        final_dir = HERE / 'deliveries' / route
        old_dir = KIT / 'gauge/deliveries' / route
        final = final_dir / final_name
        baseline = old_dir / starter_name
        verify_seal(final_dir, EVIDENCE / f'seals/{route}-1.json')
        verify_seal(old_dir, KIT / f'evidence/c187/seals/{route}-1.json')
        assert sha(baseline) == sha(CHECKER / f'originals/{route}.glb')
        auth = dispatch['routes'][route]
        for name, digest in auth['inputSha256'].items():
            file = old_dir / name[8:] if name.startswith('starter/') else HERE / name
            assert sha(file) == digest, file
        measurement = measure(baseline, final)
        assert measurement['pass'] and measurement == read(EVIDENCE / f'measurements/{route}-submitted.json')
        builds = []
        for i in (1, 2):
            rebuilt = EVIDENCE / f'rebuilt/{route}-{i}.glb'
            assert sha(rebuilt) == sha(final)
            assert measure(baseline, rebuilt) == measurement == read(EVIDENCE / f'measurements/{route}-rebuild-{i}.json')
            builds.append(sha(rebuilt))
            if route == 'ontokin':
                assert sha(EVIDENCE / f'rebuilt/ontokin-{i}-native.glb') == sha(final_dir / 'build/native.glb')
        shots = [f for f in frames['shots'] if f['route'] == route]
        assert [f['time'] for f in shots] == [0, 1, 2]
        for shot in shots:
            match, = [p for p in pixels if p['route'] == route and p['timeS'] == shot['time']]
            assert sha(EVIDENCE / 'playback' / shot['file']) == match['sha256C188']
            assert shot['sha'] == sha(final) and shot['meshCount'] == 7 and shot['duration'] == 2
            assert shot['eye'] == [.46,.90,.96] and shot['target'] == [.19,.014,.09]
            assert shot['registration'] == 'identity' and shot['fov'] == 34
        c = measurement['c188']
        comparison = measurement['comparison']
        other = [comparison['parts'][p] for p in comparison['unchangedParts']]
        routes[route] = {'formalAttempts': auth['formalAttempts'], 'submittedSha256': sha(final),
                         'rebuildSha256': builds, 'leftRearDeltaMm': comparison['parts']['left_shoe']['boundsDeltaAt0Mm'][0][0],
                         'leftFrontDeltaMm': comparison['parts']['left_shoe']['boundsDeltaAt0Mm'][1][0],
                         'gaps': c['gaps'], 'unchangedParts': len(other), 'parts': len(c['parts']),
                         'otherPartsMaxFaceChangeMm': max(v['maxExpectedWorldFaceDeltaErrorMm'] for v in other),
                         'otherPartsMaxMotionChangeMm': max(v['maxRelativeMotionDifferenceMmAtUnionKnots'] for v in other),
                         'otherPartsMaxColorChange': max(v['maxBaseColorDifference'] for v in other),
                         'certifiedIntervals': c['trajectory']['certifiedIntervals'],
                         'nonpenetratingPairs': c['clearance']['certifiedNonoverlapPairs'],
                         'reviewedFrames': [f['file'] for f in shots]}
        assert report[route]['sha256'] == sha(final)
    assert report['ontokin-native']['sha256'] == sha(HERE / 'deliveries/ontokin/build/native.glb')
    counts = {k: {s: v['report']['issues'][s] for s in ('numErrors','numWarnings','numInfos','numHints')}
              for k,v in report.items()}
    assert not any(n for r in counts.values() for n in r.values())
    return {'checkpoint':'C188', 'pass':True, 'task':'Extend only the rear of the left shoe by 30 mm',
            'routes':routes, 'c188Controls':len(q['controls']) + len(q['unchangedComparisonControls']),
            'frozenC187QualificationReproduced':q['frozenC187ReceiptsByteIdentical'],
            'glTFValidator':counts, 'nativeFieldAuditPassed':True,
            'camera':{'browser':frames['browser'],'threeRevision':frames['shots'][0]['three'],'posesS':[0,1,2]}}


if __name__ == '__main__':
    print(json.dumps(replay(), indent=2, allow_nan=False))
