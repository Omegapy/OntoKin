const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const [modulePath, output] = process.argv.slice(2);
const validator = require(path.resolve(modulePath));
async function main(){
  const deliveries = path.join(__dirname,'../deliveries');
  const reports = {};
  for(const [id,file] of [['blender','blender/gauge.glb'],['ontokin','ontokin/build/repaired.glb'],['ontokin-native','ontokin/build/native.glb']]){
    const bytes = fs.readFileSync(path.join(deliveries,file));
    const report = await validator.validateBytes(new Uint8Array(bytes),{uri:file,writeTimestamp:false});
    reports[id] = {sha256:crypto.createHash('sha256').update(bytes).digest('hex'),report};
  }
  fs.writeFileSync(output,JSON.stringify(reports,null,2)+'\n');
  if(Object.values(reports).some(r=>r.report.issues.numErrors)) process.exitCode=1;
}
main().catch(e=>{console.error(e);process.exitCode=1});
