#!/usr/bin/env bash
set -euo pipefail
site=$1
shift
log=$(mktemp)
python3 -u -m http.server 0 --bind 127.0.0.1 --directory "$site" >"$log" 2>&1 &
srv=$!
trap 'kill "$srv" 2>/dev/null || true; rm -f "$log"' EXIT
for attempt in {1..100}; do
  port=$(sed -n 's/.* port \([0-9][0-9]*\) .*/\1/p' "$log" | head -1)
  if [[ -n $port ]]; then break; fi
  sleep 0.1
done
[[ -n $port ]]
node "$1" "$2" "http://127.0.0.1:$port/" "${@:3}"
