# C189 · Drive the left carriage at two speeds

The left lane needs a slower feed. The service technician wants to set the speed on the left carriage and have its attached shoe follow. The right lane must keep its original speed. Start from your route’s accepted C188 repair. Keep the original sources and export intact.

Derive the left shoe’s motion from the carriage in your editable native design. Use one source of motion per lane. For the first export, set the left carriage to 125 mm/s. Make the second export by changing that one left-drive setting to 100 mm/s. Keep the right carriage at 150 mm/s in both. Use the same two-second clip, starting positions, part IDs, colors, seven solids and repaired shoe dimensions as C188. Each shoe must retain its original position relative to its carriage throughout the clip. The dimension and speed tables specify both settings.

Deliver the editable native design, both standalone GLBs, clean build commands, minimum gaps and times, and the diff between the two settings. Identify the source relationship that makes the shoe follow its carriage. If the native profile cannot express that relationship, preserve the diagnostic or a minimal reproducer. Report synchronized independent bodies separately. Include any raw native GLB and a field-level record for post-export changes, plus your trials and assistance.
