#!/usr/bin/env python3
"""Reproduce the scope and post-export audit on the sealed C188 files (stdlib)."""
import hashlib
import json
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
ORIG = ROOT / "gauge/deliveries"
NEW = ROOT / "repair/deliveries"
IDS = sorted(("base", "left_carriage", "left_shoe", "left_stop",
              "right_carriage", "right_shoe", "right_stop"))


def sha(b):
    return hashlib.sha256(b).hexdigest()


def load(path):
    raw = path.read_bytes()
    assert struct.unpack_from("<4sII", raw) == (b"glTF", 2, len(raw))
    n, tag = struct.unpack_from("<I4s", raw, 12)
    assert tag == b"JSON"
    m, tag = struct.unpack_from("<I4s", raw, 20 + n)
    assert tag == b"BIN\0" and m + n + 28 == len(raw)
    return json.loads(raw[20:20 + n]), raw[28 + n:]


def differences(a, b, path=()):
    if type(a) is not type(b):
        yield path
    elif isinstance(a, dict):
        for key in sorted(a.keys() | b.keys()):
            if key in a and key in b:
                yield from differences(a[key], b[key], path + (key,))
            else:
                yield path + (key,)
    elif isinstance(a, list):
        if len(a) != len(b):
            yield path + ("length",)
        for i, (x, y) in enumerate(zip(a, b)):
            yield from differences(x, y, path + (i,))
    elif a != b:
        yield path


def ptr(path):
    return "/" + "/".join(str(i).replace("~", "~0").replace("/", "~1") for i in path)


def name_audit(native, final):
    a, b0 = load(native)
    b, b1 = load(final)
    changes = list(differences(a, b))
    assert changes == [("meshes", i, "name") for i in range(7)] and b0 == b1
    names = {n["mesh"]: n["name"] for n in b["nodes"] if "mesh" in n}
    assert sorted(names.values()) == IDS
    pairs = []
    for i, name in sorted(names.items()):
        assert b["meshes"][i]["name"] == name and a["meshes"][i]["name"] == "extrusion"
        pairs.append({"field": ptr(("meshes", i, "name")), "before": "extrusion", "after": name})
    return {"nativeSha256": sha(native.read_bytes()), "finalSha256": sha(final.read_bytes()),
            "onlyJsonDifferences": pairs, "binaryChunkByteIdentical": True,
            "binaryChunkSha256": sha(b0), "binaryLength": len(b0)}


def binary_changes(d, e, b0, b1):
    # These two exports retain their original layouts. Check every changed byte.
    assert d["bufferViews"] == e["bufferViews"] and len(b0) == len(b1)
    altered = {i for i, (before, after) in enumerate(zip(b0, b1)) if before != after}
    owners = {}
    for mesh in d["meshes"]:
        for p in mesh["primitives"]:
            for attribute, i in p["attributes"].items():
                owners.setdefault(i, []).append([mesh["name"], attribute])
            owners.setdefault(p["indices"], []).append([mesh["name"], "indices"])
    anim = d["animations"][0]
    for ch in anim["channels"]:
        node = d["nodes"][ch["target"]["node"]]["name"]
        s = anim["samplers"][ch["sampler"]]
        for role in ("input", "output"):
            owners.setdefault(s[role], []).append([node, ch["target"]["path"], role])
    seen, results = set(), []
    for i, a in enumerate(d["accessors"]):
        view = d["bufferViews"][a["bufferView"]]
        start = view.get("byteOffset", 0) + a.get("byteOffset", 0)
        width = {"VEC3": 3, "VEC4": 4, "SCALAR": 1}[a["type"]]
        size = {5123: 2, 5125: 4, 5126: 4}[a["componentType"]]
        stride = view.get("byteStride", width * size)
        components = set()
        for j in range(a["count"]):
            for k in range(width):
                offset = start + j * stride + k * size
                hit = altered.intersection(range(offset, offset + size))
                if hit:
                    seen.update(hit)
                    components.add(k)
        if components:
            results.append({"accessor": i, "owners": owners[i], "changedComponents": sorted(components)})
    assert seen == altered
    return results


def scope(route, original, final):
    d, b0 = load(original)
    e, b1 = load(final)
    assert [m["name"] for m in d["meshes"]] == [m["name"] for m in e["meshes"]]
    assert sorted(m["name"] for m in e["meshes"]) == IDS
    assert d["meshes"] == e["meshes"] and d["animations"] == e["animations"]
    material_paths = list(differences(d["materials"], e["materials"]))
    assert set(material_paths) == ({(i, "extras", "ontokin", "program_revision") for i in range(7)}
                                  if route == "ontokin" else set())
    positions = binary_changes(d, e, b0, b1)
    expected = [[["left_shoe", "POSITION"]]]
    if route == "ontokin":
        expected += [[["left_shoe", "translation", "output"]]]
    assert [p["owners"] for p in positions] == expected
    assert all(p["changedComponents"] == [0] for p in positions)
    associated = {}
    for mesh in e["meshes"]:
        p = mesh["primitives"][0]
        mat = e["materials"][p["material"]]
        associated[mesh["name"]] = {"index": p["material"], "name": mat["name"],
                                    "pbrMetallicRoughness": mat["pbrMetallicRoughness"]}
    record = {"originalSha256": sha(original.read_bytes()), "finalSha256": sha(final.read_bytes()),
              "changedBinaryFields": positions, "allChangedBinaryBytesAccountedFor": True,
              "materialFieldDifferences": [ptr(("materials",) + p) for p in material_paths],
              "unchangedMaterialAssignmentsAndPbrByPart": associated,
              "allMeshDescriptorsIncludingPrimitiveExtrasIdentical": True,
              "allAnimationDescriptorsIdentical": True}
    if route == "ontokin":
        before = d["extras"]["ontokin"]["program"]["revision"]
        after = e["extras"]["ontokin"]["program"]["revision"]
        assert before != after
        assert all(x["extras"]["ontokin"]["program_revision"] == rev for doc, rev in ((d,before),(e,after))
                   for x in doc["materials"])
        record.update({"materialOldProgramRevision": before, "materialNewProgramRevision": after})
    return record


def run():
    seals = {}
    for route in ("ontokin","blender"):
        seal = json.loads((ROOT / "evidence/c188/seals" / f"{route}-1.json").read_text())
        seals[route] = len(seal["files"])
        for key, value in seal["files"].items():
            data = (NEW / route / key).read_bytes()
            assert len(data) == value["bytes"] and sha(data) == value["sha256"], key
    final = NEW / "ontokin/build/repaired.glb"
    records = {"sealedFileCounts": seals,
               "nativeToDelivered": name_audit(NEW / "ontokin/build/native.glb", final),
               "originalToRepaired": {
                  "ontokin": scope("ontokin", ORIG / "ontokin/build/starter.glb", final),
                  "blender": scope("blender", ORIG / "blender/gauge.glb", NEW / "blender/gauge.glb")}}
    return {"pass": True, **records}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
