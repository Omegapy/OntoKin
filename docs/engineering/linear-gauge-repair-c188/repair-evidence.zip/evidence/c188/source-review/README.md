# C188 source and export review

**OntoKin.** The public `Shoe` class still defines a 100 mm length. Only the `left_shoe` instance overrides it to 130 mm and moves its minimum-X origin from 80 to 50 mm. The front face therefore stays at 180 mm at rest. The right shoe inherits the 100 mm default. The builder's only source change renames its output file. The existing naming step replaces the seven native mesh names `extrusion` with their corresponding node IDs. The audit compares every decoded JSON field and all 11,552 bytes of the binary chunk between the sealed native and final GLBs.

**Blender.** The existing per-instance dimension table gains one record for `left_shoe`. The common cuboid constructor anchors its front face at the default length and uses `default_length - instance_length` for the rear. This changes the behavior of future size overrides. With the present table, the other six objects receive the same vertices as before. The file retains the original origins, materials, keyframes and parentage. Every changed binary byte is in X coordinates of the left-shoe position accessor.

**Material hashes.** OntoKin records a program revision in each exported material. All seven material records changed only at `extras.ontokin.program_revision`. The new value matches the new program revision in the GLB. No other material field changed. Every mesh descriptor, including its primitive material references, stable IDs and `region_key` extras, compares equal. Node provenance also records the new source revision and shifted source-byte offsets where applicable. These node fields are outside the material digest. In OntoKin's encoded binary data, only `left_shoe` changed, in its local vertex X values and its animation's absolute X translations. The latter follow the revised instance origin. The separate world-space checker measures displacement from that origin.

**Scope.** The GLB checker certifies commanded motion and swept geometric clearance of the visible rectangular shells over two seconds. The OntoKin source disables collisions for the moving sphere proxies. Blender uses keyframed carriage motion. The results do not measure contact response, load capacity, friction, or manufacturing tolerance.

## Reproduce the field audit

Run from this directory with a standard Python 3 interpreter and the extracted handoff at its original relative paths.

```sh
python audit.py > /tmp/c188-field-audit.json
cmp field-audit.json /tmp/c188-field-audit.json
```

The script verifies the seals, traverses all decoded native-to-final JSON fields, compares binary chunks directly, enumerates each material-field change and maps every changed binary byte against the original route's accessor layout. The three patch files here show the complete build-source changes.
