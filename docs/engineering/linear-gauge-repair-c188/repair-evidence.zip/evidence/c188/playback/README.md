# Repaired gauge playback

The [six-frame comparison](../../../repair/comparison.png) shows both repaired exports at 0, 1 and 2 seconds. In the upper lane, the gold left shoe reaches farther back over the teal carriage. The two close-ups use the same crop from the original and repaired Blender frames at time zero. The forward edge holds its position relative to the base.

Viewed across each row, the two carriages move together toward the fixed red stops. At the end both shoes retain a visible gap. The entire base and both stops remain in frame in all six images. The column labels show world-space clearances rounded to millimetres. The perspective view shows the operation and its location. The independent geometry checks provide the dimensions and continuous-motion evidence.

The [browser receipt](frames.json) identifies the two loaded GLBs by SHA-256. It records their seven meshes and two-second clips, the shared camera and the absence of page errors. Each capture used the C187 Three.js r186 viewer with identity registration. The camera was at (0.46, 0.90, 0.96) m, looking at (0.19, 0.014, 0.09) m, with a vertical field of view of 34°. Chromium captured the 720 × 410 canvas in 720 × 411 PNGs. The playback clock advanced for both models.

The [pixel comparison](pixel-comparison.json) compares RGB values with each route’s original C187 frame at the same time. Between 656 and 762 pixels changed per frame. At every pose the differences were confined to the upper shoe’s region. The lower lane, stops and surrounding view matched that route’s original image outside that region. The per-image hashes identify both sides of each comparison.

Rebuild the contact sheet from the unmodified PNGs with `python3 repair/contact_sheet.py` from the extracted handoff. The six full frames are scaled to fit. The two matched detail crops are enlarged twofold.
