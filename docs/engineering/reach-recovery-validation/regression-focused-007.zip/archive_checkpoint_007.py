from pathlib import Path
import hashlib, json, zipfile

root=Path('/workspace/scratch/35e163a07cce')
base=Path('/tmp')
dest=root/'OntoKin/docs/engineering/reach-recovery-validation'
groups={
    'regression-focused-007': (
        'ontokin-integrated-regression-007','ontokin-recurrence-focused-001',
        'ontokin-identity-focused-001','ontokin-identity-focused-002',
        'ontokin-finiteness-focused-001','ontokin-finiteness-focused-002',
        'ontokin-identity-stage-001'),
    'recording-rotation-007': ('ontokin-recurrence-artifacts-001',),
    'recording-identity-007': ('ontokin-identity-artifacts-001',),
    'recording-finiteness-007': ('ontokin-finiteness-artifacts-001',),
}
for name,directories in groups.items():
    entries=[]
    for directory in directories:
        folder=base/directory
        assert folder.is_dir(),folder
        report=json.loads((folder/'report.json').read_text())
        assert report.get('finished_at') and report.get('status') in ('passed','failed'),folder
        entries.extend((p,directory+'/'+p.relative_to(folder).as_posix())
                       for p in sorted(folder.rglob('*')) if p.is_file())
        log=base/(directory+'.log')
        if log.is_file():entries.append((log,directory+'.log'))
    if name=='regression-focused-007':
        entries.extend((root/driver,driver) for driver in
                       ('run_focused.py','run-source-stage-probes.py','archive_checkpoint_007.py'))
    assert len({member for _,member in entries})==len(entries)
    archive=dest/(name+'.zip')
    manifest=[]
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as handle:
        for path,member in sorted(entries,key=lambda row:row[1]):
            assert not path.is_symlink(),path
            before=path.stat();raw=path.read_bytes();after=path.stat()
            assert (before.st_size,before.st_mtime_ns,before.st_ino)==(after.st_size,after.st_mtime_ns,after.st_ino)
            handle.writestr(member,raw)
            manifest.append({'path':member,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    sources={member:path for path,member in entries}
    with zipfile.ZipFile(archive) as handle:
        assert handle.testzip() is None
        assert set(handle.namelist())=={row['path'] for row in manifest}
        for row in manifest:
            raw=handle.read(row['path'])
            assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256']
            assert raw==sources[row['path']].read_bytes()
    record={'schema_version':'ontokin.raw-evidence-archive/0.1',
            'archive':archive.name,'bytes':archive.stat().st_size,
            'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':manifest}
    with (dest/(name+'.members.json')).open('x') as output:
        output.write(json.dumps(record,indent=2)+'\n')
    print(json.dumps({key:value for key,value in record.items() if key!='members'}
                    |{'member_count':len(manifest)}))
