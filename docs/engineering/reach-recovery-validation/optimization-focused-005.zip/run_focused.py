from pathlib import Path
import argparse, json, platform, sys, time, traceback

p=argparse.ArgumentParser()
p.add_argument('--repo',type=Path,required=True)
p.add_argument('--output',type=Path,required=True)
p.add_argument('modules',nargs='+')
a=p.parse_args()
sys.path.insert(0,str(a.repo.resolve()))
from tools.reach_delivery_inventory import snapshot,write_json,utc,descriptor,finish_inputs
from ontokin import construction_conformance,surface_conformance

a.output.mkdir(parents=True,exist_ok=False)
before=snapshot()
write_json(a.output/'inputs-before.json',before)
report={'schema_version':'ontokin.focused-execution/0.1','status':'running',
        'started_at':utc(),'source_commit':before['git']['commit'],
        'source_tree':before['git']['tree'],'command':[sys.executable,*sys.argv],
        'python':platform.python_version(),'platform':platform.platform(),
        'driver':descriptor(Path(__file__)),'release_acceptance':False}
try:
    all_names=surface_conformance.discover_test_ids()
    names=[name for name in all_names if name.split('.')[0] in a.modules]
    assert set(a.modules)==set(name.split('.')[0] for name in names), 'Missing module'
    assert len(names)==len(set(names))
    write_json(a.output/'test-inventory.json',{'test_ids':names})
    result=construction_conformance._run_tests(names)
    write_json(a.output/'test-results.json',result)
    report.update(status='passed' if surface_conformance._execution_passes(result,names) else 'failed',
        tests=len(names),outcomes=result['outcomes'],
        nonpassing=[r for r in result['tests'] if r['status']!='passed'])
except Exception as e:
    report.update(status='failed',error=str(e),traceback=traceback.format_exc())
finish_inputs(a.output,before,report)
report['finished_at']=utc()
report['members']=[descriptor(f,relative_to=a.output) for f in sorted(a.output.iterdir()) if f.is_file()]
write_json(a.output/'report.json',report)
print(json.dumps({k:v for k,v in report.items() if k in ['status','tests','outcomes','nonpassing','error','inputs_stable']},indent=2))
raise SystemExit(0 if report['status']=='passed' else 1)
