"""Observe the existing P23 work ledger without changing a budget or callback.

Run only with the team's exclusive execution slot. The checkout must be clean.
All before/after identities and the original failure are retained separately.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from contextlib import contextmanager
from datetime import datetime, timezone
from functools import wraps
import hashlib
import json
from pathlib import Path
import platform
import sys
import traceback


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    output = args.output_dir.resolve()
    if output.exists() or output.is_relative_to(root):
        raise ValueError("Use a fresh output directory outside the checkout")
    output.mkdir(parents=True)
    sys.path.insert(0, str(root))
    from tools.reach_delivery_inventory import snapshot, settings, source_files
    from ontokin.bundle import load_file_manifest
    from ontokin import construction, linker, reach_source, reach_runtime, reach_export
    from ontokin.scene import ExportOptions
    from ontokin.gltf import export_glb
    from fractions import Fraction

    before = snapshot()
    (output / "inputs-before.json").write_text(json.dumps(before, indent=2) + "\n")
    active = []
    inclusive, exclusive, calls = Counter(), Counter(), Counter()
    sites = defaultdict(Counter)
    events = []
    budget = None
    report = {
        "scope": "development profile only; original work/callback/operand limits unchanged",
        "command": [sys.executable, *sys.argv],
        "root": str(root),
        "started_at": datetime.now(timezone.utc).isoformat(),
        "execution": {"python": sys.version, "executable": sys.executable,
                      "platform": platform.platform()},
        "source": before["git"],
    }

    original_tick = construction.ConstructionBudget.tick

    def measured_tick(self, *arguments, **keywords):
        nonlocal budget
        budget = self
        old = self.operations
        try:
            return original_tick(self, *arguments, **keywords)
        finally:
            used = self.operations - old
            # Each entry identifies the original immediate charging function.
            # Reach charge kinds distinguish generic budget callback sites.
            frame = sys._getframe(1)
            filename = Path(frame.f_code.co_filename)
            relative = str(filename.relative_to(root)) if filename.is_relative_to(root) else filename.name
            location = relative + ":" + str(frame.f_lineno) + ":" + frame.f_code.co_name
            if frame.f_code.co_name == "charge" and filename.name == "reach_numeric.py":
                location += ":" + str(frame.f_locals.get("kind", "?"))
            label = active[-1] if active else "unscoped"
            sites[label][location] += used
            exclusive[label] += used
            for name in set(active):
                inclusive[name] += used

    construction.ConstructionBudget.tick = measured_tick

    @contextmanager
    def stage(label, *, details=None, retain=False):
        start = budget.operations if budget is not None else 0
        calls[label] += 1
        active.append(label)
        try:
            yield
        finally:
            end = budget.operations if budget is not None else 0
            active.pop()
            if retain:
                if len(events) >= 10000:
                    raise RuntimeError("Development profile event limit exceeded")
                events.append({"stage": label, "start": start, "end": end,
                               "cost": end - start, **(details or {})})

    def wrap(owner, name, *, retain=False, clock_index=None):
        original = getattr(owner, name)
        label = owner.__name__ + "." + name

        @wraps(original)
        def measured(*arguments, **keywords):
            details = {}
            if clock_index is not None:
                details["clock"] = str(arguments[clock_index])
            if name == "_resolve_kinematics":
                simulator, clock, state = arguments[:3]
                cache_clock = None if not state.dynamic and not state.claims else clock
                cached = simulator._pose_cache.get((id(state), cache_clock))
                details.update(cached_matching_graph=cached is not None and cached[0] is state,
                               selected_frames=keywords.get("selected_frames") is not None,
                               pose_only=keywords.get("pose_only", False),
                               recording_only=keywords.get("recording_only", False))
            with stage(label, details=details, retain=retain):
                return original(*arguments, **keywords)
        setattr(owner, name, measured)

    for name in ("bind", "check_static_types", "_register_tree", "_ensure_collection",
                 "scene_fields", "resolve_objects", "action_value", "assertions",
                 "relation_validation", "event_blocks", "_attach_provenance"):
        wrap(construction.ConstructionCompiler, name)
    for owner, name in ((linker, "link_program"), (construction, "materialize_surface"),
                        (reach_source, "bind_reaches")):
        wrap(owner, name)
    for name in ("__init__", "_resolve_kinematics", "_event", "_latch", "_aggregate",
                 "_process_boundary", "_validate_staged", "recording_boundary", "_reach_map",
                 "_physical_observation", "_tip_base", "_world_target", "_bounded_projection"):
        clock_index = (1 if name in {"_resolve_kinematics", "_process_boundary", "_validate_staged",
                                    "recording_boundary", "_reach_map"} else
                       2 if name in {"_event", "_latch", "_aggregate", "_physical_observation",
                                    "_tip_base", "_world_target"} else None)
        wrap(reach_runtime.ReachSimulator, name,
             retain=name in {"__init__", "_resolve_kinematics", "_process_boundary",
                             "_validate_staged", "recording_boundary", "_reach_map"},
             clock_index=clock_index)
    for owner, name in ((reach_runtime, "boundary_history_bound"),
                        (reach_export, "recording_phase_bounds")):
        wrap(owner, name, retain=True)
    original_recording_stage = reach_export.recording_stage

    @wraps(original_recording_stage)
    def recording_stage(name, **keywords):
        events.append({"stage": "recording_stage", "name": name,
                       "operations": budget.operations})
        return original_recording_stage(name, **keywords)

    reach_export.recording_stage = recording_stage
    try:
        with stage("compile", retain=True):
            compiler = construction.compile_construction(load_file_manifest(root / source_files("P23")))
        report["compiled_operations"] = compiler.budget.operations
        report["model_counts"] = {name: len(getattr(compiler.model, name))
                                  for name in ("objects", "sites", "joints", "follows", "actions")}
        options = settings("P23", fps=1)
        options["end"] = Fraction(options["end"])
        with stage("export", retain=True):
            result = export_glb(compiler.model, options=ExportOptions(**options),
                                target_contract="ontokin.glb/0.6", work=compiler.reach_work)
        report.update(status="passed", artifact_bytes=len(result.data),
                      artifact_sha256=hashlib.sha256(result.data).hexdigest())
    except Exception as error:
        report.update(status="failed", error={"type": type(error).__name__, "message": str(error)},
                      traceback=traceback.format_exc())
    finally:
        report["operations"] = None if budget is None else budget.operations
        report["max_operations"] = None if budget is None else budget.limits["max_operations"]
        report["stages"] = [dict(stage=label, calls=calls[label], exclusive=exclusive[label],
                                 inclusive=inclusive[label], charge_sites=dict(sites[label]))
                            for label in sorted(set(calls) | set(exclusive))]
        report["events"] = events
        after = snapshot(require_clean=False)
        (output / "inputs-after.json").write_text(json.dumps(after, indent=2) + "\n")
        report["inputs_stable"] = before == after
        report["finished_at"] = datetime.now(timezone.utc).isoformat()
        (output / "report.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: report.get(key) for key in
                      ("status", "compiled_operations", "operations", "inputs_stable")}, indent=2))


if __name__ == "__main__":
    main()
