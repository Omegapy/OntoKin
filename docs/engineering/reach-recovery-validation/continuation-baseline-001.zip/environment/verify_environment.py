"""Verify restored dependency bytes against the actual downloaded archives.

This is an installation integrity check. It executes no OntoKin program, test,
Agent workflow, native artifact validator, or browser page.
"""
from pathlib import Path, PurePosixPath
import base64
import hashlib
import importlib.metadata
import json
import platform
import sys
import tarfile
import zipfile


ROOT = Path(__file__).resolve().parents[1]
NODE = Path('/tmp/ontokin-reach-node22-bdfa/bin/node')
BROWSERS = Path('/tmp/ontokin-reach-browser-bdfa')
BROWSER_DOWNLOADS = Path('/tmp/ontokin-reach-downloads-bdfa')
REPORT = ROOT / 'receipts/environment-integrity.json'
report = {
    'schema_version': 'ontokin.local-verification-environment/0.1',
    'status': 'running',
    'scope': 'installed_dependency_byte_integrity_only',
    'runtime_validation_executed': False,
    'python': {'executable': sys.executable, 'version': sys.version,
               'implementation': platform.python_implementation()},
    'platform': platform.platform(),
    'archives': [], 'checked_files': [], 'generated_files': [],
}


def digest(stream, algorithm='sha256'):
    value = hashlib.new(algorithm)
    length = 0
    while block := stream.read(1024 * 1024):
        value.update(block)
        length += len(block)
    return value.hexdigest(), length


def checked(path, expected=None, size=None, *, kind='package_member'):
    path = Path(path)
    before = path.stat()
    with path.open('rb') as stream:
        actual, length = digest(stream)
    after = path.stat()
    assert (before.st_ino, before.st_size, before.st_mtime_ns) == (
        after.st_ino, after.st_size, after.st_mtime_ns), f'File changed: {path}'
    assert length == before.st_size, f'Incomplete read: {path}'
    assert expected is None or actual == expected, f'Content mismatch: {path}'
    assert size is None or length == size, f'Length mismatch: {path}'
    value = {'path': str(path), 'sha256': actual, 'bytes': length, 'kind': kind}
    report['checked_files'].append(value)
    return value


def safe_relative(name):
    value = PurePosixPath(name)
    assert not value.is_absolute() and '..' not in value.parts, name
    return value


def archive_member(stream, path, size):
    expected, count = digest(stream)
    assert count == size, f'Incomplete archive member: {path}'
    checked(path, expected, size)


def node():
    name = 'node-v22.23.3-linux-x64.tar.xz'
    manifest = ROOT / 'downloads/SHASUMS256.txt'
    records = [line.split() for line in manifest.read_text().splitlines()]
    expected = [value for value, member in records if member == name]
    assert len(expected) == 1
    package = ROOT / 'downloads' / name
    receipt = checked(package, expected[0], kind='official_node_archive')
    report['archives'].append(receipt)
    checked(manifest, kind='official_node_checksum_manifest')
    with tarfile.open(package, 'r:xz') as archive:
        member = archive.getmember('node-v22.23.3-linux-x64/bin/node')
        archive_member(archive.extractfile(member), NODE, member.size)
    report['node'] = {'version_from_official_distribution': '22.23.3',
                      'executable': str(NODE),
                      'archive_source': 'https://nodejs.org/dist/v22.23.3/' + name}


def npm():
    lock_path = ROOT / 'npm/package-lock.json'
    lock = json.loads(lock_path.read_text())
    checked(lock_path, kind='repository_npm_lockfile')
    checked(ROOT / 'npm/package.json', kind='repository_npm_manifest')
    installed = {}
    for key, entry in lock['packages'].items():
        if not key or not (ROOT / 'npm' / key).is_dir():
            continue
        assert key.startswith('node_modules/')
        algorithm, encoded = entry['integrity'].split('-', 1)
        expected = base64.b64decode(encoded).hex()
        package = (ROOT / 'npm-cache/_cacache/content-v2' / algorithm /
                   expected[:2] / expected[2:4] / expected[4:])
        with package.open('rb') as stream:
            actual, _ = digest(stream, algorithm)
        assert actual == expected, f'Npm cache integrity mismatch: {key}'
        receipt = checked(package, kind='lockfile_integrity_verified_npm_archive')
        receipt.update(package=key, integrity=entry['integrity'],
                       resolved=entry['resolved'], version=entry['version'])
        report['archives'].append(receipt)
        with tarfile.open(package, 'r:gz') as archive:
            for member in archive:
                if not member.isfile():
                    continue
                relative = safe_relative(member.name)
                assert relative.parts[0] == 'package', member.name
                target = ROOT / 'npm' / key / Path(*relative.parts[1:])
                archive_member(archive.extractfile(member), target, member.size)
        installed[key.removeprefix('node_modules/')] = entry['version']
    assert installed == {
        '@esbuild/linux-x64': '0.25.10', 'esbuild': '0.25.10',
        'gltf-validator': '2.0.0-dev.3.10', 'playwright': '1.56.1',
        'playwright-core': '1.56.1', 'three': '0.180.0',
    }, installed
    report['npm_packages'] = installed


def python_packages():
    report_path = ROOT / 'receipts/pip-install.json'
    install = json.loads(report_path.read_text())
    checked(report_path, kind='pip_download_report')
    cached = {}
    for path in (ROOT / 'pip-cache').rglob('*.body'):
        with path.open('rb') as stream:
            value, _ = digest(stream)
        cached[value] = path
    requested = {}
    for entry in install['install']:
        download = entry['download_info']
        expected = download['archive_info']['hashes']['sha256']
        package = cached[expected]
        receipt = checked(package, expected, kind='pip_report_verified_wheel')
        receipt.update(source=download['url'], name=entry['metadata']['name'],
                       version=entry['metadata']['version'])
        report['archives'].append(receipt)
        with zipfile.ZipFile(package) as archive:
            assert archive.testzip() is None
            for member in archive.infolist():
                if member.is_dir():
                    continue
                relative = safe_relative(member.filename)
                assert not any(part.endswith('.data') for part in relative.parts), member.filename
                target = ROOT / 'python-packages' / Path(*relative.parts)
                if relative.name == 'RECORD' and relative.parent.name.endswith('.dist-info'):
                    report['generated_files'].append(checked(target, kind='pip_updated_RECORD'))
                    continue
                with archive.open(member) as stream:
                    archive_member(stream, target, member.file_size)
        requested[entry['metadata']['name'].lower().replace('_', '-')] = entry['metadata']['version']
    expected = {}
    requirements = ROOT / 'receipts/force-agent-verification-requirements.txt'
    checked(requirements, kind='repository_python_requirements')
    for line in requirements.read_text().splitlines():
        if line and not line.startswith('#'):
            name, version = line.split('==')
            expected[name.lower().replace('_', '-')] = version
    actual = {d.metadata['Name'].lower().replace('_', '-'): d.version
              for d in importlib.metadata.distributions(path=[str(ROOT / 'python-packages')])}
    assert requested == expected == actual, (requested, expected, actual)
    report['python_packages'] = actual
    observed = {row['path'] for row in report['checked_files']}
    for path in (ROOT / 'python-packages').rglob('*'):
        if path.is_file() and str(path) not in observed:
            report['generated_files'].append(checked(path, kind='pip_generated_file'))


def browsers():
    manifest = ROOT / 'npm/node_modules/playwright-core/browsers.json'
    metadata = json.loads(manifest.read_text())
    revisions = {row['name']: row for row in metadata['browsers']}
    assert revisions['chromium-headless-shell']['revision'] == '1194'
    assert revisions['chromium-headless-shell']['browserVersion'] == '141.0.7390.37'
    assert revisions['ffmpeg']['revision'] == '1011'
    for name, folder, source in (
        ('chromium-headless-shell-linux.zip', 'chromium_headless_shell-1194',
         'https://playwright.download.prss.microsoft.com/dbazure/download/playwright/builds/chromium/1194/chromium-headless-shell-linux.zip'),
        ('ffmpeg-linux.zip', 'ffmpeg-1011',
         'https://playwright.download.prss.microsoft.com/dbazure/download/playwright/builds/ffmpeg/1011/ffmpeg-linux.zip'),
    ):
        package = BROWSER_DOWNLOADS / name
        receipt = checked(package, kind='pinned_playwright_browser_archive')
        receipt.update(source=source, browser_directory=folder)
        report['archives'].append(receipt)
        with zipfile.ZipFile(package) as archive:
            assert archive.testzip() is None
            for member in archive.infolist():
                if member.is_dir():
                    continue
                relative = safe_relative(member.filename)
                target = BROWSERS / folder / Path(*relative.parts)
                with archive.open(member) as stream:
                    archive_member(stream, target, member.file_size)
    report['browser_cache'] = str(BROWSERS)
    report['browser_versions_from_pinned_distribution'] = {
        'chromium_headless_shell': '141.0.7390.37', 'chromium_build': '1194',
        'ffmpeg_build': '1011',
    }


def main():
    assert not REPORT.exists(), 'Use a fresh report path for every integrity attempt'
    try:
        node()
        npm()
        python_packages()
        browsers()
        report['status'] = 'passed'
    except Exception as error:
        report['status'] = 'failed'
        report['error'] = f'{type(error).__name__}: {error}'
        raise
    finally:
        REPORT.write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({'status': report['status'], 'report': str(REPORT),
                          'checked_files': len(report['checked_files']),
                          'archives': len(report['archives'])}))


if __name__ == '__main__':
    main()
