"""Run official source artifacts and observe original stage boundaries only.

The actual request/callback/operation/operand limits are unmodified. This
development sidecar records current counters at existing stage calls, and at
the independent supplied-byte checker. It does not replace either implementation.
"""
from __future__ import annotations

import argparse
from functools import wraps
import json
from pathlib import Path
import platform
import sys


parser = argparse.ArgumentParser()
parser.add_argument("--repo", required=True, type=Path)
parser.add_argument("--output", required=True, type=Path)
parser.add_argument("--case", action="append", required=True)
arguments = parser.parse_args()
probe_command = [sys.executable, *sys.argv]
root, output = arguments.repo.resolve(), arguments.output.resolve()
if output.exists() or output.is_relative_to(root):
    raise ValueError("Use a fresh evidence directory outside the source checkout")
sys.path.insert(0, str(root))

from tools import build_reach_source_artifacts as official
from tools.reach_delivery_inventory import descriptor, frozen_cases, utc, write_json
from ontokin import construction, gltf, reach_export

case_by_revision = {row["program_revision"]: case for case, row in frozen_cases().items()
                    if case in arguments.case}
observations = {}
work_cases = {}
original_compile = construction.compile_construction


@wraps(original_compile)
def compile_observed(*args, **kwargs):
    result = original_compile(*args, **kwargs)
    case = case_by_revision[result.model.program_revision]
    work_cases[id(result.reach_work)] = (case, result)
    observations[case] = [{"stage": "compiled", "operations": result.budget.operations,
                           "reach_operations": result.reach_work.operations}]
    return result


def observe(work, stage, **details):
    if id(work) not in work_cases:
        return
    case, compiler = work_cases[id(work)]
    observations[case].append({"stage": stage, "operations": compiler.budget.operations,
        "reach_operations": work.operations,
        "recording_samples": work.counts.get("recording_sample", 0),
        "recording_keys": work.counts.get("recording_key", 0),
        "cache_evictions": work.counts.get("cache_evict", 0), **details})


original_stage = reach_export.recording_stage


@wraps(original_stage)
def stage_observed(name, **kwargs):
    work = kwargs.get("work")
    observe(work, name)
    return original_stage(name, **kwargs)


original_validate = gltf.validate_export


@wraps(original_validate)
def validate_observed(*args, **kwargs):
    work = kwargs.get("work")
    observe(work, "independent_validation_start")
    try:
        result = original_validate(*args, **kwargs)
    except BaseException as error:
        observe(work, "independent_validation_failed", exception=type(error).__name__)
        raise
    observe(work, "independent_validation_completed")
    return result


construction.compile_construction = compile_observed
reach_export.recording_stage = stage_observed
gltf.validate_export = validate_observed

started_at = utc()
original_arguments = sys.argv
sys.argv = [str(Path(official.__file__).resolve()), "--output-dir", str(output)]
for case in arguments.case:
    sys.argv.extend(("--case", case))
try:
    report = official.build(output, tuple(arguments.case), 1)
finally:
    sys.argv = original_arguments
for _, (case, compiler) in work_cases.items():
    observe(compiler.reach_work, "request_finished")
write_json(output / "stage-observations.json", {
    "schema_version": "ontokin.source-stage-observations/0.1",
    "scope": "Observational development sidecar; all original request work and guards unchanged",
    "command": probe_command, "driver": descriptor(Path(__file__)),
    "underlying_builder": descriptor(Path(official.__file__)),
    "python": platform.python_version(), "platform": platform.platform(),
    "source_commit": report["source_commit"], "source_tree": report["source_tree"],
    "inputs_stable": report["inputs_stable"],
    "started_at": started_at, "finished_at": utc(), "cases": observations})
print(json.dumps({"status": report["status"], "inputs_stable": report["inputs_stable"],
                  "cases": [{"case_id": row["case_id"], "status": row["status"],
                              "operations": row.get("operations")} for row in report["deliveries"]]}, indent=2))
raise SystemExit(0 if report["status"] == "passed" else 1)
