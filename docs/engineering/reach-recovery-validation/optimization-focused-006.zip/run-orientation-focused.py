from pathlib import Path
import json
import platform
import sys
import time
import unittest

repo = Path('/workspace/scratch/35e163a07cce/OntoKin-reference')
sys.path[:0] = [str(repo), str(repo / 'tests')]
from tools.reach_delivery_inventory import descriptor, finish_inputs, fresh_output, snapshot, utc, write_json
from ontokin.construction_conformance import _run_tests

out = fresh_output(Path(sys.argv[1]))
before = snapshot()
write_json(out / 'inputs-before.json', before)
modules = ['test_reach_orientation_proof_reuse', 'test_reach_conformance',
           'test_reach_recording_reuse', 'test_reach_recording_budget',
           'test_reach_export_arithmetic', 'test_reach_destination_resources']
loader = unittest.TestLoader()
def names(suite):
    for test in suite:
        if isinstance(test, unittest.TestSuite):
            yield from names(test)
        else:
            yield test.id()
selected = [name for module in modules for name in names(loader.loadTestsFromName(module))]
report = {'scope':'guarded independent orientation proof focused checks', 'source_commit':before['git']['commit'],
          'source_tree':before['git']['tree'], 'started_at':utc(), 'python':sys.version,
          'platform':platform.platform(), 'command':[sys.executable, *sys.argv],
          'driver':descriptor(Path(__file__)), 'selected_modules':modules,
          'test_count':len(selected), 'release_acceptance':False}
write_json(out / 'test-inventory.json', {'test_ids':selected})
started = time.monotonic()
execution = _run_tests(selected)
write_json(out / 'test-results.json', execution)
report.update(finished_at=utc(),elapsed_seconds=time.monotonic()-started,
              outcomes=execution['outcomes'],
              passed_count=sum(row['status']=='passed' for row in execution['tests']),
              nonpassing=[row for row in execution['tests'] if row['status']!='passed'],
              loader_errors=execution['loader_errors'], fixture_errors=execution['fixture_errors'],
              unexpected_test_records=execution['unexpected_test_records'])
finish_inputs(out,before,report)
report['status']='passed' if (report['passed_count']==len(selected) and report['inputs_stable']
    and not report['loader_errors'] and not report['fixture_errors'] and not report['unexpected_test_records']) else 'failed'
write_json(out / 'report.json',report)
print(json.dumps({k:report[k] for k in ['status','test_count','passed_count','inputs_stable','outcomes','nonpassing']},indent=2))
raise SystemExit(0 if report['status']=='passed' else 1)
