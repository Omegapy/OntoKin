"""Record actual reader costs without changing any operation or callback limit."""
from collections import Counter
from contextlib import contextmanager
from fractions import Fraction
from functools import wraps
import json
from pathlib import Path
import platform
import sys
import time
import traceback

repo = Path('/workspace/scratch/35e163a07cce/OntoKin-reference')
sys.path.insert(0, str(repo))
from tools.reach_delivery_inventory import (
    descriptor, finish_inputs, fresh_output, settings, snapshot, source_files, utc, write_json,
)
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.scene import ExportOptions
from ontokin import gltf, reach_export, reach_reference, reach_conformance

out = fresh_output(Path(sys.argv[1]))
cases = sys.argv[2:] or ['P01', 'P02', 'P07', 'P13', 'P18', 'P19']
before = snapshot()
write_json(out / 'inputs-before.json', before)
report = {'scope':'development profile; all actual work/callback/operand limits unchanged',
          'source_commit':before['git']['commit'], 'source_tree':before['git']['tree'],
          'started_at':utc(), 'python':sys.version, 'platform':platform.platform(),
          'command':[sys.executable, *sys.argv], 'driver':descriptor(Path(__file__)),
          'release_acceptance':False, 'rows':[]}
current, compiler, stack = None, None, []
calls, inclusive, exclusive, sites = Counter(), Counter(), Counter(), Counter()

def operations():
    return compiler.budget.operations if compiler is not None else 0

@contextmanager
def measured(label, details=None, retain=False):
    frame = {'start':operations(), 'children':0}
    calls[label] += 1
    stack.append(frame)
    try:
        yield
    finally:
        cost = operations() - frame['start']
        stack.pop()
        inclusive[label] += cost
        exclusive[label] += cost - frame['children']
        if stack:
            stack[-1]['children'] += cost
        if retain:
            if len(current['events']) >= 10000:
                raise RuntimeError('Development profile event cap exceeded')
            current['events'].append({'stage':label, 'start':frame['start'],
                'end':operations(), 'cost':cost, **(details or {})})

def wrap(owner, name, *, retain=False, clock_index=None):
    original = getattr(owner, name)
    label = owner.__name__ + '.' + name
    @wraps(original)
    def wrapper(*args, **kwargs):
        details = {} if clock_index is None else {'clock':str(args[clock_index])}
        if name == '_pose_map':
            details.update(ideal=kwargs.get('ideal'), pose_only=kwargs.get('pose_only', False),
                           selected=kwargs.get('selected') is not None)
        with measured(label, details, retain):
            return original(*args, **kwargs)
    setattr(owner, name, wrapper)

for name in ('build_reference',):
    wrap(reach_reference, name, retain=True)
for name in ('_initialize', '_build', '_finish', '_release', '_impulse', '_coordinate', '_root_pose',
             '_joint_path', '_source_basis', '_phase', 'sample'):
    wrap(reach_reference.ReachReference, name)
for name in ('boundary_states',):
    wrap(reach_reference.ReachReference, name, retain=True)
for name in ('_pose_map', '_boundary_projection'):
    wrap(reach_reference.ReachReference, name, retain=True, clock_index=1)
for name in ('compose', 'rotate', 'hinge', 'multiply', 'spin'):
    wrap(reach_reference._PoseArithmetic, name)
for name in ('validate_reach_export', 'verify_retained_clocks', '_geometry_bounds', '_phase_tables',
             '_boundary_allowances', '_verify_certificates'):
    wrap(reach_conformance, name, retain=True)
for name in ('_key_comparisons',):
    wrap(reach_conformance, name, retain=True, clock_index=3)
for name in ('_recording_orientation_comparison', '_stored_arc'):
    wrap(reach_conformance, name)
for name in ('normalize', '_normalize', 'difference', 'root', '_root'):
    wrap(reach_conformance._Bounds, name)
for name in ('read_glb', '_validate_geometry'):
    wrap(gltf, name, retain=True)

original_tick = reach_reference._Arithmetic.tick
@wraps(original_tick)
def counted_tick(arithmetic):
    start = operations()
    frame = sys._getframe(1)
    site = frame.f_code.co_name
    if 'kind' in frame.f_locals:
        site += ':' + str(frame.f_locals['kind'])
    try:
        return original_tick(arithmetic)
    finally:
        sites[site] += operations() - start
reach_reference._Arithmetic.tick = counted_tick

original_stage = reach_export.recording_stage
@wraps(original_stage)
def recording_stage(name, **kwargs):
    current['producer_stages'].append({'name':name, 'operations':operations()})
    return original_stage(name, **kwargs)
reach_export.recording_stage = recording_stage

for case in cases:
    compiler = None
    calls.clear(); inclusive.clear(); exclusive.clear(); sites.clear()
    current = {'case_id':case, 'events':[], 'producer_stages':[], 'started_at':utc(), 'max_operations':100000}
    report['rows'].append(current)
    started = time.monotonic()
    try:
        compiler = compile_construction(load_file_manifest(repo / source_files(case)))
        current['compiled_operations'] = operations()
        options = settings(case, fps=1)
        current['options'] = options
        with measured('export', retain=True):
            result = gltf.export_glb(compiler.model,
                options=ExportOptions(**{**options, 'end':Fraction(options['end'])}),
                target_contract='ontokin.glb/0.6', work=compiler.reach_work)
        directory = out / case
        directory.mkdir()
        (directory / 'scene.glb').write_bytes(result.data)
        write_json(directory / 'export-report.json', result.report)
        current.update(status='passed', artifact=descriptor(directory / 'scene.glb', relative_to=out))
    except Exception as error:
        current.update(status='failed', failure={'type':type(error).__name__, 'message':str(error)},
                       traceback=traceback.format_exc())
    current.update(operations=operations(), elapsed_seconds=time.monotonic()-started,
                   finished_at=utc(), stages=[{'stage':name, 'calls':calls[name],
                       'inclusive_operations':inclusive[name], 'exclusive_operations':exclusive[name]}
                       for name in sorted(calls)], independent_tick_sites=dict(sites))
    if compiler is not None:
        current['work'] = compiler.reach_work.record()
    write_json(out / (case + '-profile.json'), current)
    print(case, current['status'], current['operations'], flush=True)
finish_inputs(out, before, report)
report['finished_at'] = utc()
report['status'] = 'passed' if report['inputs_stable'] and all(row['status']=='passed' for row in report['rows']) else 'failed'
write_json(out / 'report.json', report)
raise SystemExit(0 if report['status']=='passed' else 1)
