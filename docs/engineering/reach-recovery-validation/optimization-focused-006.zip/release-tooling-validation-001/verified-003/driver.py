from pathlib import Path
import json
import sys
import time
import unittest
sys.dont_write_bytecode = True
sys.path.insert(0, str(Path.cwd()))
from tools import reach_release as r

out = Path(sys.argv[1]); out.mkdir()
before = r.source_identity(); r.write_json(out / 'inputs-before.json', before)
(out / 'driver.py').write_bytes(Path(__file__).read_bytes())
patterns = ['test_reach_release_evidence.py', 'test_force_evidence_collection.py', 'test_force_conformance.py']
suite = unittest.TestSuite()
for pattern in patterns:
    suite.addTests(unittest.defaultTestLoader.discover('tests', pattern=pattern))
def names(s):
    for test in s:
        if isinstance(test, unittest.TestSuite):
            yield from names(test)
        else:
            yield test.id()
inventory = list(names(suite)); r.write_json(out / 'inventory.json', {'test_ids': inventory, 'patterns': patterns})
rows = []
class Result(unittest.TextTestResult):
    def startTest(self, test):
        self.t0 = time.monotonic(); super().startTest(test)
    def note(self, test, status, error=None):
        rows.append({'test_id': test.id(), 'status': status, 'elapsed_seconds': time.monotonic() - self.t0,
                     'error': None if error is None else self._exc_info_to_string(error, test)})
    def addSuccess(self, test):
        self.note(test, 'passed'); super().addSuccess(test)
    def addFailure(self, test, error):
        self.note(test, 'failed', error); super().addFailure(test, error)
    def addError(self, test, error):
        self.note(test, 'error', error); super().addError(test, error)
    def addSkip(self, test, reason):
        self.note(test, 'skipped'); super().addSkip(test, reason)
    def addSubTest(self, test, subtest, error):
        if error is not None:
            self.note(test, 'failed', error)
        super().addSubTest(test, subtest, error)
started = r.utc(); clock = time.monotonic()
with (out / 'tests.log').open('x') as log:
    result = unittest.TextTestRunner(stream=log, verbosity=2, resultclass=Result).run(suite)
after = r.source_identity(); r.write_json(out / 'inputs-after.json', after)
passed = result.wasSuccessful() and not result.skipped and result.testsRun == len(inventory) and r.stable_source(before, after)
report = {'schema_version': 'ontokin.reach-release-tooling-focused/0.1', 'status': 'passed' if passed else 'failed',
    'started_at_utc': started, 'finished_at_utc': r.utc(), 'elapsed_seconds': time.monotonic() - clock,
    'python': sys.version, 'executable': sys.executable, 'command': [sys.executable, *sys.argv],
    'driver': r.file_record(out / 'driver.py'), 'patterns': patterns, 'test_count': result.testsRun, 'results': rows,
    'failures': len(result.failures), 'errors': len(result.errors), 'skipped': len(result.skipped),
    'inputs_stable': r.stable_source(before, after), 'release_acceptance': False, 'full_product_goal_completed': False}
r.write_json(out / 'report.json', report)
print(json.dumps({key: report[key] for key in ('status', 'test_count', 'failures', 'errors', 'skipped', 'inputs_stable', 'elapsed_seconds')}), flush=True)
for row in rows:
    if row['status'] != 'passed':
        print(row['test_id'], row['error'], flush=True)
raise SystemExit(0 if passed else 1)
