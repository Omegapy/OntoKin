"""Development-only counters; unchanged source work, callbacks and limits."""
from collections import Counter, defaultdict
from contextlib import contextmanager
from fractions import Fraction
from functools import wraps
import json
from pathlib import Path
import platform
import sys
import time
import traceback

repo = Path('/tmp/ontokin-reader-proof-20261021-2331')
sys.path.insert(0, str(repo))
from tools.reach_delivery_inventory import (
    descriptor, finish_inputs, fresh_output, settings, snapshot, source_files, utc, write_json,
)
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.scene import ExportOptions
from ontokin import gltf, reach_reference, reach_conformance
from ontokin.reach_numeric import ReachExecutionWork

out = fresh_output(Path(sys.argv[1]))
before = snapshot()
write_json(out / 'inputs-before.json', before)
report = dict(scope='Development profile only; original work/callback/cache/operand limits unchanged',
              source_commit=before['git']['commit'], source_tree=before['git']['tree'],
              started_at=utc(), python=sys.version, platform=platform.platform(),
              driver=descriptor(Path(__file__)), command=[sys.executable, *sys.argv],
              release_acceptance=False, rows=[])
compiler = current = None
stages = defaultdict(Counter)
bounds = defaultdict(Counter)
reference = defaultdict(Counter)
domain = defaultdict(Counter)
seen_bounds = set()
seen_reference = set()
seen_domain = set()
stack = []

def operations():
    return 0 if compiler is None else compiler.budget.operations

def reference_kind(key):
    return 'pose:' + str(key[3]) if key and key[0] == 'reference_pose' else str(key[0])

@contextmanager
def measured(label, retain=False, clock=None):
    frame = {'start': operations(), 'children': 0}
    stack.append(frame)
    stages[label]['calls'] += 1
    try:
        yield
    finally:
        cost = operations() - frame['start']
        stack.pop()
        stages[label]['inclusive_operations'] += cost
        stages[label]['exclusive_operations'] += cost - frame['children']
        if stack:
            stack[-1]['children'] += cost
        if retain:
            current['key_events'].append({'stage': label, 'clock': clock,
                'start': frame['start'], 'end': operations(), 'operations': cost})

def wrap(owner, name, *, retain=False, clock_index=None):
    original = getattr(owner, name)
    label = owner.__name__ + '.' + name
    @wraps(original)
    def wrapped(*args, **kwargs):
        clock = None if clock_index is None else str(args[clock_index])
        with measured(label, retain, clock):
            return original(*args, **kwargs)
    setattr(owner, name, wrapped)

original_reuse = reach_conformance._Bounds.reuse
def counted_reuse(arithmetic, key, calculate):
    kind = str(key[0])
    row = bounds[kind]
    row['calls'] += 1
    called = False
    start = operations()
    def observed():
        nonlocal called
        called = True
        row['misses'] += 1
        if key in seen_bounds:
            row['repeated_after_eviction'] += 1
        return calculate()
    try:
        result = original_reuse(arithmetic, key, observed)
        if not called:
            row['hits'] += 1
        seen_bounds.add(key)
        return result
    finally:
        row['inclusive_operations'] += operations() - start
reach_conformance._Bounds.reuse = counted_reuse

original_lookup = reach_reference._Arithmetic.lookup
def counted_lookup(arithmetic, key):
    row = reference[reference_kind(key)]
    row['calls'] += 1
    result = original_lookup(arithmetic, key)
    if result is None:
        row['misses'] += 1
        if (id(arithmetic), key) in seen_reference:
            row['repeated_after_eviction'] += 1
    else:
        row['hits'] += 1
    seen_reference.add((id(arithmetic), key))
    return result
reach_reference._Arithmetic.lookup = counted_lookup

original_remember = reach_reference._Arithmetic.remember
def counted_remember(arithmetic, key, value):
    evicted = (next(iter(arithmetic.cache)) if key not in arithmetic.cache
               and len(arithmetic.cache) >= reach_reference.MAX_CACHE else None)
    result = original_remember(arithmetic, key, value)
    if evicted is not None:
        reference[reference_kind(evicted)]['evicted'] += 1
    return result
reach_reference._Arithmetic.remember = counted_remember

original_work_remember = ReachExecutionWork.remember
def counted_work_remember(work, key, value):
    evicted = (next(iter(work._cache)) if key not in work._cache
               and len(work._cache) >= work.max_cache_entries else None)
    result = original_work_remember(work, key, value)
    if evicted and evicted[0] == 'reach_independent_bounds_v1':
        bounds[str(evicted[2])]['evicted'] += 1
    return result
ReachExecutionWork.remember = counted_work_remember

def counted_domain(name):
    original = getattr(reach_conformance._Bounds, name)
    @wraps(original)
    def wrapped(arithmetic, value, *args, **kwargs):
        label = name + ':' + sys._getframe(1).f_code.co_name
        row = domain[label]
        row['calls'] += 1
        if name == 'norm' and type(value) in (tuple, list):
            key = (label, tuple(value))
        elif name == 'cell' and hasattr(value, 'lo') and hasattr(value, 'hi'):
            key = (label, value.lo, value.hi)
        else:
            key = (label, type(value), value)
        try:
            if key in seen_domain:
                row['duplicates'] += 1
            seen_domain.add(key)
        except TypeError:
            pass
        start = operations()
        try:
            return original(arithmetic, value, *args, **kwargs)
        finally:
            row['inclusive_operations'] += operations() - start
    setattr(reach_conformance._Bounds, name, wrapped)

for name in ('cell', 'value', 'norm'):
    counted_domain(name)
for name in ('validate_reach_export', '_verify_certificates', '_geometry_bounds',
             '_recording_orientation_comparison', '_stored_arc'):
    wrap(reach_conformance, name)
wrap(reach_conformance, '_key_comparisons', retain=True, clock_index=3)
for name in ('recording_pose_enclosures', 'recording_stationary_frames', '_pose_map'):
    wrap(reach_reference.ReachReference, name)

for case in sys.argv[2:] or ['P07', 'P18']:
    compiler = None
    stages.clear(); bounds.clear(); reference.clear(); domain.clear()
    seen_bounds.clear(); seen_reference.clear(); seen_domain.clear()
    current = dict(case_id=case, max_operations=100000, key_events=[], started_at=utc())
    report['rows'].append(current)
    started = time.monotonic()
    try:
        compiler = compile_construction(load_file_manifest(repo / source_files(case)))
        options = settings(case, fps=1)
        current['options'] = options
        current['compiled_operations'] = operations()
        result = gltf.export_glb(compiler.model,
            options=ExportOptions(**{**options, 'end':Fraction(options['end'])}),
            target_contract='ontokin.glb/0.6', work=compiler.reach_work)
        (out / (case + '.glb')).write_bytes(result.data)
        write_json(out / (case + '-export-report.json'), result.report)
        current.update(status='passed', artifact=descriptor(out / (case + '.glb'), relative_to=out))
    except Exception as error:
        current.update(status='failed', failure={'type':type(error).__name__, 'message':str(error)},
                       traceback=traceback.format_exc())
    current.update(operations=operations(), elapsed_seconds=time.monotonic()-started,
                   stages=dict(stages), bounds=dict(bounds), reference=dict(reference), domains=dict(domain),
                   finished_at=utc())
    if compiler is not None:
        current['work'] = compiler.reach_work.record()
    write_json(out / (case + '-profile.json'), current)
    print(case, current['status'], current['operations'], flush=True)
finish_inputs(out, before, report)
report['finished_at'] = utc()
report['status'] = 'passed' if report['inputs_stable'] and all(row['status']=='passed' for row in report['rows']) else 'failed'
write_json(out / 'report.json', report)
raise SystemExit(0 if report['status']=='passed' else 1)
