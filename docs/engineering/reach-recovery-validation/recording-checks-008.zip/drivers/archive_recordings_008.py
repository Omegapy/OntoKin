from pathlib import Path
import hashlib
import json
import zipfile

base = Path('/tmp')
dest = base / 'ontokin-recordings-20261021-2205/docs/engineering/reach-recovery-validation'
groups = {
    'recordings-recovered-008': (
        'ontokin-recordings-recovered-2205-001',
        'ontokin-recordings-recovered-2205-002',
    ),
    'recording-checks-008': (
        'ontokin-recording-focused-2205-001',
        'ontokin-recording-cache-focused-2205-002',
        'ontokin-phase-mounts-focused-2205-001',
        'ontokin-recording-cursor-focused-2205-001',
        'ontokin-reader-vector-focused-2205-001',
        'ontokin-recording-profile-2205-001',
        'ontokin-recording-profile-2205-002',
        'ontokin-reader-reuse-profile-2331-001',
    ),
}
for name, directories in groups.items():
    if (dest / (name + '.members.json')).is_file():
        continue
    entries = []
    for directory in directories:
        folder = base / directory
        report = json.loads((folder / 'report.json').read_text())
        assert report.get('finished_at') and report.get('status') in ('passed', 'failed'), folder
        entries.extend((p, directory + '/' + p.relative_to(folder).as_posix())
                       for p in sorted(folder.rglob('*')) if p.is_file())
        log = base / (directory + '.log')
        if log.is_file():
            entries.append((log, directory + '.log'))
    if name == 'recording-checks-008':
        for path in (base / 'ontokin_run_focused.py',
                     base / 'profile-recordings-2205.py',
                     base / 'profile-reader-reuse-20261021.py', Path(__file__)):
            entries.append((path, 'drivers/' + path.name))
    assert len({member for _, member in entries}) == len(entries)
    archive = dest / (name + '.zip')
    manifest = []
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as handle:
        for path, member in sorted(entries, key=lambda row: row[1]):
            assert not path.is_symlink(), path
            before = path.stat()
            raw = path.read_bytes()
            after = path.stat()
            assert (before.st_size, before.st_mtime_ns, before.st_ino) == (
                after.st_size, after.st_mtime_ns, after.st_ino)
            handle.writestr(member, raw)
            manifest.append({'path': member, 'bytes': len(raw),
                             'sha256': hashlib.sha256(raw).hexdigest()})
    sources = {member: path for path, member in entries}
    with zipfile.ZipFile(archive) as handle:
        assert handle.testzip() is None
        assert set(handle.namelist()) == {row['path'] for row in manifest}
        for row in manifest:
            raw = handle.read(row['path'])
            assert len(raw) == row['bytes']
            assert hashlib.sha256(raw).hexdigest() == row['sha256']
            assert raw == sources[row['path']].read_bytes()
    record = {'schema_version': 'ontokin.raw-evidence-archive/0.1',
              'archive': archive.name, 'bytes': archive.stat().st_size,
              'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': manifest}
    with (dest / (name + '.members.json')).open('x') as output:
        output.write(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: value for key, value in record.items() if key != 'members'}
                     | {'member_count': len(manifest)}))
