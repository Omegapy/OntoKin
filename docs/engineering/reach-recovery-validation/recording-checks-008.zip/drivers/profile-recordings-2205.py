"""Record actual reader costs without changing any operation or callback limit."""
from collections import Counter
from contextlib import contextmanager
from fractions import Fraction
from functools import wraps
import json
from pathlib import Path
import platform
import sys
import time
import traceback

repo = Path('/tmp/ontokin-recordings-20261021-2205')
sys.path.insert(0, str(repo))
from tools.reach_delivery_inventory import (
    descriptor, finish_inputs, fresh_output, settings, snapshot, source_files, utc, write_json,
)
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.scene import ExportOptions
from ontokin import gltf, reach_export, reach_reference, reach_conformance, reach_pose, reach_runtime

out = fresh_output(Path(sys.argv[1]))
cases = sys.argv[2:] or ['P01', 'P02', 'P07', 'P13', 'P18', 'P19']
before = snapshot()
write_json(out / 'inputs-before.json', before)
report = {'scope':'development profile; all actual work/callback/operand limits unchanged',
          'source_commit':before['git']['commit'], 'source_tree':before['git']['tree'],
          'started_at':utc(), 'python':sys.version, 'platform':platform.platform(),
          'command':[sys.executable, *sys.argv], 'driver':descriptor(Path(__file__)),
          'release_acceptance':False, 'rows':[]}
current, compiler, stack = None, None, []
calls, inclusive, exclusive, sites = Counter(), Counter(), Counter(), Counter()

def operations():
    return compiler.budget.operations if compiler is not None else 0

@contextmanager
def measured(label, details=None, retain=False):
    frame = {'start':operations(), 'children':0}
    calls[label] += 1
    stack.append(frame)
    try:
        yield
    finally:
        cost = operations() - frame['start']
        stack.pop()
        inclusive[label] += cost
        exclusive[label] += cost - frame['children']
        if stack:
            stack[-1]['children'] += cost
        if retain:
            if len(current['events']) >= 10000:
                raise RuntimeError('Development profile event cap exceeded')
            current['events'].append({'stage':label, 'start':frame['start'],
                'end':operations(), 'cost':cost, **(details or {})})

def wrap(owner, name, *, retain=False, clock_index=None):
    original = getattr(owner, name)
    label = owner.__name__ + '.' + name
    @wraps(original)
    def wrapper(*args, **kwargs):
        details = {} if clock_index is None else {'clock':str(args[clock_index])}
        if name == '_pose_map':
            details.update(ideal=kwargs.get('ideal'), pose_only=kwargs.get('pose_only', False),
                           selected=kwargs.get('selected') is not None)
        with measured(label, details, retain):
            return original(*args, **kwargs)
    setattr(owner, name, wrapper)

for name in ('reach_prefix_plan', 'recording_phase_bounds', 'node_geometry_bounds', 'reach_timeline',
             'interval_certificates', '_endpoint_rounding', '_certificate_quantities'):
    wrap(reach_export, name, retain=name in ('reach_prefix_plan', 'recording_phase_bounds', 'interval_certificates'))
for name in ('_resolve_kinematics', 'recording_frames', 'recording_boundary', '_coordinate', '_exact_coordinate',
             '_dynamic_kinematics', '_constant_pose', '_pose_slot', '_tip_base', '_reach_output', '_incoming'):
    if hasattr(reach_runtime.ReachSimulator, name):
        wrap(reach_runtime.ReachSimulator, name, retain=name in ('recording_frames', 'recording_boundary'))
for name in ('compose', 'compose_recording', 'compose_recording_fast', 'rotate', 'multiply', '_expose',
             '_unit_projection', '_vector_projection', '_rotation', 'recording_axis_rotation',
             'recording_advance_orientation', 'axis_rotation', '_sincos', '_rescale', 'ensure_finite',
             '_integer_planar_product', '_integer_axis_rotate', '_rotation_factors',
             'make_recording', '_rounded_vector', '_vector', 'affine', 'scale'):
    if hasattr(reach_pose.ReachPoseOps, name):
        wrap(reach_pose.ReachPoseOps, name)
for name in ('validate_reach_export', '_geometry_bounds', '_verify_certificates'):
    wrap(reach_conformance, name, retain=True)
for name in ('read_glb', '_validate_geometry'):
    wrap(gltf, name, retain=True)

original_tick = reach_reference._Arithmetic.tick
@wraps(original_tick)
def counted_tick(arithmetic):
    start = operations()
    frame = sys._getframe(1)
    site = frame.f_code.co_name
    if 'kind' in frame.f_locals:
        site += ':' + str(frame.f_locals['kind'])
    try:
        return original_tick(arithmetic)
    finally:
        sites[site] += operations() - start
reach_reference._Arithmetic.tick = counted_tick

original_stage = reach_export.recording_stage
@wraps(original_stage)
def recording_stage(name, **kwargs):
    current['producer_stages'].append({'name':name, 'operations':operations()})
    return original_stage(name, **kwargs)
reach_export.recording_stage = recording_stage

for case in cases:
    compiler = None
    calls.clear(); inclusive.clear(); exclusive.clear(); sites.clear()
    current = {'case_id':case, 'events':[], 'producer_stages':[], 'started_at':utc(), 'max_operations':100000}
    report['rows'].append(current)
    started = time.monotonic()
    try:
        compiler = compile_construction(load_file_manifest(repo / source_files(case)))
        current['compiled_operations'] = operations()
        options = settings(case, fps=1)
        current['options'] = options
        with measured('export', retain=True):
            result = gltf.export_glb(compiler.model,
                options=ExportOptions(**{**options, 'end':Fraction(options['end'])}),
                target_contract='ontokin.glb/0.6', work=compiler.reach_work)
        directory = out / case
        directory.mkdir()
        (directory / 'scene.glb').write_bytes(result.data)
        write_json(directory / 'export-report.json', result.report)
        current.update(status='passed', artifact=descriptor(directory / 'scene.glb', relative_to=out))
    except Exception as error:
        current.update(status='failed', failure={'type':type(error).__name__, 'message':str(error)},
                       traceback=traceback.format_exc())
    current.update(operations=operations(), elapsed_seconds=time.monotonic()-started,
                   finished_at=utc(), stages=[{'stage':name, 'calls':calls[name],
                       'inclusive_operations':inclusive[name], 'exclusive_operations':exclusive[name]}
                       for name in sorted(calls)], independent_tick_sites=dict(sites))
    if compiler is not None:
        current['work'] = compiler.reach_work.record()
    write_json(out / (case + '-profile.json'), current)
    print(case, current['status'], current['operations'], flush=True)
finish_inputs(out, before, report)
report['finished_at'] = utc()
report['status'] = 'passed' if report['inputs_stable'] and all(row['status']=='passed' for row in report['rows']) else 'failed'
write_json(out / 'report.json', report)
raise SystemExit(0 if report['status']=='passed' else 1)
