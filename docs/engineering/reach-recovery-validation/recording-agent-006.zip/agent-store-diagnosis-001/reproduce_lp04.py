"""One exact LP04.01 request, isolated local store, unchanged retained source."""
from __future__ import annotations

import datetime
import hashlib
import json
import pathlib
import platform
import sqlite3
import subprocess
import sys
import traceback

SOURCE = pathlib.Path('/tmp/ontokin-agent-source-diagnosis-001')
OUTPUT = pathlib.Path('/tmp/ontokin-agent-store-diagnosis-001')
REQUEST = pathlib.Path('/workspace/scratch/35e163a07cce/integrated-agent-001/exchanges/00044.request.json')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def snapshot():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(SOURCE), *args]).decode().strip()
    names = subprocess.check_output(['git', '-C', str(SOURCE), 'ls-files', '-z']).split(b'\0')
    digest = hashlib.sha256()
    for name in names:
        if name:
            digest.update(name + b'\0')
            digest.update(hashlib.sha256((SOURCE / name.decode()).read_bytes()).digest())
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain'), 'tracked_content_sha256': digest.hexdigest()}


OUTPUT.mkdir(exist_ok=False)
raw = REQUEST.read_bytes()
(OUTPUT / 'request.json').write_bytes(raw)
record = {'command': [sys.executable, *sys.argv], 'source_path': str(SOURCE),
          'output_path': str(OUTPUT), 'store_path': str(OUTPUT / 'service-store'),
          'started': now(), 'python': sys.version, 'platform': platform.platform(),
          'sqlite_version': sqlite3.sqlite_version,
          'request_sha256': hashlib.sha256(raw).hexdigest(), 'inputs_before': snapshot()}
sys.path.insert(0, str(SOURCE))
from ontokin.program_agent import ProgramAgentService

service = None
try:
    service = ProgramAgentService(OUTPUT / 'service-store', protocol='ontokin.agent/0.6')
    record['implementation'] = service.implementation
    response = service.handle(json.loads(raw))
    (OUTPUT / 'response.json').write_text(json.dumps(response, indent=2) + '\n')
    record['response_status'] = response['status']
    record['achieved_level'] = response.get('achieved_level')
    record['passed'] = response['status'] == 'succeeded' and response.get('achieved_level') == 'constructed'
except BaseException as exc:
    record['exception'] = {'type': type(exc).__name__, 'message': str(exc), 'traceback': traceback.format_exc()}
    record['passed'] = False
finally:
    if service is not None:
        service.close()

db_path = OUTPUT / 'service-store' / 'planar-reach-program-agent.sqlite3'
record['database_sha256'] = hashlib.sha256(db_path.read_bytes()).hexdigest()
record['sidecars_after_close'] = [x.name for x in db_path.parent.iterdir() if x != db_path]
with sqlite3.connect(db_path.as_uri() + '?mode=ro&immutable=1', uri=True) as db:
    db.row_factory = sqlite3.Row
    record['integrity_check'] = [r[0] for r in db.execute('PRAGMA integrity_check')]
    record['retained_requests'] = [dict(r) for r in db.execute('SELECT sequence, project_id, id, operation, state FROM requests')]
    record['retained_sources'] = [dict(r) for r in db.execute('SELECT project_id, revision, accepted_once FROM sources')]
record['inputs_after'] = snapshot()
record['inputs_stable'] = record['inputs_before'] == record['inputs_after']
record['finished'] = now()
(OUTPUT / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
raise SystemExit(0 if record['passed'] and record['inputs_stable'] else 1)
