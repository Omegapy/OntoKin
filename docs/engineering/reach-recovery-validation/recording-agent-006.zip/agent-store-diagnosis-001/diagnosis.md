# Agent store diagnosis — 2026-10-21

The LP04 failure in `integrated-agent-001` followed a loss of already committed database history. The exact LP04.01 request succeeds from the same clean source revision in a fresh local `/tmp` store. The immediate TypeError is a dereference of an absent request row; it does not explain how that row and earlier committed work disappeared.

## Observed evidence

The original run used source `39107f2206c2041610cb7e9d33a8007110c4ed47` and reported stable inputs. The failing database is `integrated-agent-001/service-store/planar-reach-program-agent.sqlite3`.

- Read-only inspection used SQLite URI `mode=ro&immutable=1` after the service had closed and no WAL sidecar was present. Both `integrity_check` and `quick_check` returned `ok`. The database hash, inode, size, mtime and ctime were unchanged by inspection. See `retained-db-readonly.json`.
- Persisted response 00038 reports successful LP03.01 creation. The retained database has that request at sequence 37 but in `unknown_outcome`, and its program has `accepted_once=0` with no accepted project revision. Service closure can fence a still-running row into `unknown_outcome`; it cannot revert a succeeded row into a running row.
- Four subsequent distinct LP03 requests, LP03.02 through LP03.05, have persisted terminal responses but no database rows. The repeated LP03.02 request at exchange 00043 is another observation of the same missing identity. LP04.01 and its project are also entirely absent.
- LP05.01 then occupies database sequence 38. The earlier LP03 requests had been submitted and completed before LP04 started, so the missing history includes the request sequence allocator as well as request, source-acceptance and project state.
- Later N06 export uses project `reach-reconstruction-lp03`. Its `OKL-E-REVISION` rejection follows directly from that project's reverted `accepted_once=0` state.
- `missing-receipts.json` records these comparisons. Its separate `delivery/changed-request-id` status mismatch is intentional protocol behavior: a changed retry is rejected while the original successful receipt remains retained. It is not evidence of history loss.

## Code and environment investigation

Static inspection of `agent.py`, `agent_store.py`, `program_agent.py`, `program_store.py` and the official producer found no deletion of request rows or replacement of the store file. Recovery and service closure change ownership/state but retain the rows. The `_Check` callback can observe a missing row and cancel before `_finish`, whose `_commit_task` assumes the row still exists.

Read-only process inventory found no surviving OntoKin runtime or test worker after the failed run. The captured inventory includes the short Python process performing the inventory itself. The environment also runs `/usr/local/scripts/sync_share.sh` and an rsync daemon with writable module `scratch` mapped to `/workspace/scratch`. The synchronization script uses delayed updates and excludes Git and temporary transfer files, but has no SQLite/WAL exclusion. See `process-inventory.json` for the observed process names, script identity, selected configuration lines and module paths; no credentials were collected.

**Inference:** replacing a live database or its WAL with an older synchronized snapshot is consistent with the coherent rollback across several tables and the sequence allocator. No inode-change trace was running at the moment of failure, so file synchronization is a plausible cause rather than a proven one. A SQL integrity check can pass on a coherent older snapshot.

No system configuration, process, original evidence or runtime source was changed during this diagnosis.

## Exact LP04 reproduction

The sole runtime reproduction used a clean detached local clone at `39107f2206c2041610cb7e9d33a8007110c4ed47`, Python 3.12.14 and SQLite 3.53.1. It replayed the byte-identical `00044.request.json` request through `ProgramAgentService.handle`, with the service store and all live output under `/tmp/ontokin-agent-store-diagnosis-001`.

The request succeeded at `constructed`, its request row remained `succeeded`, its source had `accepted_once=1`, and integrity checking returned `ok`. Tracked source hashes, tree, head and clean status matched before and after. The run lasted from 19:03:32.521307 to 19:03:34.455826 UTC. The closed, immutable output was then copied into `lp04-reproduction`; the driver is `reproduce_lp04.py`.

This verifies the narrow LP04 create operation. It does not replace the failed complete Agent acceptance run. A fresh complete run should keep live SQLite/workflow output in `/tmp` and archive it only after the service closes.
