"""Install exact upstream Python archives and compare every installed member."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import tarfile
import traceback

BASE = Path(__file__).resolve().parents[1]
REPORT = BASE / 'receipts/runtime-integrity.json'
assert not REPORT.exists()
report = {'schema_version': 'ontokin.python-matrix-environment-integrity/0.1',
          'started_at': datetime.now(timezone.utc).isoformat(), 'status': 'running',
          'distribution': 'Astral python-build-standalone', 'release': '20261003',
          'release_metadata_url': 'https://api.github.com/repos/astral-sh/python-build-standalone/releases/tags/20261003',
          'command': [sys.executable, str(Path(__file__).resolve())],
          'full_suite_executed': False, 'release_acceptance': False, 'runtimes': []}


def digest(path):
    with path.open('rb') as stream:
        return 'sha256:' + hashlib.file_digest(stream, 'sha256').hexdigest()


try:
    metadata_path = BASE / 'receipts/release-metadata.json'
    metadata = json.loads(metadata_path.read_bytes())
    report['release_metadata'] = {'path': str(metadata_path), 'bytes': metadata_path.stat().st_size,
                                  'sha256': digest(metadata_path)}
    for short, version in [('311', '3.11.17'), ('313', '3.13.16')]:
        filename = f'cpython-{version}+20261003-x86_64-unknown-linux-gnu-install_only_stripped.tar.gz'
        archive_path = BASE / 'downloads' / filename
        asset = next(item for item in metadata['assets'] if item['name'] == filename)
        assert archive_path.stat().st_size == asset['size'] and digest(archive_path) == asset['digest']
        destination = BASE / ('python' + short)
        assert not destination.exists()
        destination.mkdir()
        row = {'version': version, 'destination': str(destination), 'archive': {
            'path': str(archive_path), 'bytes': asset['size'], 'sha256': asset['digest'],
            'upstream_asset_url': asset['browser_download_url']}, 'members': [], 'status': 'installing'}
        report['runtimes'].append(row)
        with tarfile.open(archive_path, 'r:gz') as archive:
            members = archive.getmembers()
            assert len(members) <= 20000 and sum(member.size for member in members) <= 256 * 1024 * 1024
            names = set()
            for member in members:
                relative = PurePosixPath(member.name)
                assert relative.parts[0] == 'python' and not relative.is_absolute()
                assert all(part not in ('.', '..') for part in relative.parts)
                relative = Path(*relative.parts[1:])
                assert relative.parts and str(relative) not in names and (member.isfile() or member.issym())
                names.add(str(relative))
                target = destination / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                if member.isfile():
                    source = archive.extractfile(member)
                    expected, count = hashlib.sha256(), 0
                    with target.open('xb') as output:
                        for block in iter(lambda: source.read(1024 * 1024), b''):
                            assert output.write(block) == len(block)
                            count += len(block)
                            expected.update(block)
                        output.flush()
                        os.fsync(output.fileno())
                    assert count == member.size
                    target.chmod(member.mode & 0o777)
                    row['members'].append({'path': str(relative), 'bytes': count,
                                           'sha256': 'sha256:' + expected.hexdigest(), 'type': 'regular'})
                else:
                    assert not Path(member.linkname).is_absolute()
                    assert (target.parent / member.linkname).resolve().is_relative_to(destination.resolve())
                    target.symlink_to(member.linkname)
                    row['members'].append({'path': str(relative), 'target': member.linkname, 'type': 'symlink'})
        for item in row['members']:
            target = destination / item['path']
            if item['type'] == 'regular':
                assert not target.is_symlink() and target.stat().st_size == item['bytes'] and digest(target) == item['sha256'], item
            else:
                assert target.is_symlink() and os.readlink(target) == item['target'], item
        executable = destination / 'bin' / ('python' + '.'.join(version.split('.')[:2]))
        probe = ('import json,platform,ssl,sqlite3,sys,sysconfig; '
                 'print(json.dumps({"python":platform.python_version(),"executable":sys.executable,'
                 '"platform":platform.platform(),"openssl":ssl.OPENSSL_VERSION,"sqlite":sqlite3.sqlite_version,'
                 '"soabi":sysconfig.get_config_var("SOABI")}))')
        actual = json.loads(subprocess.check_output([str(executable), '-I', '-B', '-c', probe], text=True))
        assert actual['python'] == version and actual['executable'] == str(executable)
        row.update(status='verified', installed_member_count=len(row['members']), environment=actual)
        print(json.dumps({'python': version, 'installed_member_count': len(row['members']),
                          'status': row['status'], 'archive_sha256': asset['digest']}), flush=True)
    report['status'] = 'passed'
except Exception as error:
    report.update(status='failed', failure={'type': type(error).__name__, 'message': str(error)}, traceback=traceback.format_exc())
finally:
    report['finished_at'] = datetime.now(timezone.utc).isoformat()
    with REPORT.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': report['status'], 'report': str(REPORT), 'failure': report.get('failure')}), flush=True)
raise SystemExit(0 if report['status'] == 'passed' else 1)
