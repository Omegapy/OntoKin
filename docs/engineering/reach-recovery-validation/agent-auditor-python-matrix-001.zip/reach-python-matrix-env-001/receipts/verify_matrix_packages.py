"""Verify wheel provenance, installed bytes and imports for both matrix Pythons."""
import base64
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys
import traceback
from urllib.parse import unquote, urlsplit
import zipfile

BASE = Path(__file__).resolve().parents[1]
REPORT = BASE / 'receipts/package-integrity.json'
assert not REPORT.exists()
report = {'schema_version': 'ontokin.python-matrix-package-integrity/0.1',
          'status': 'running', 'started_at': datetime.now(timezone.utc).isoformat(),
          'command': [sys.executable, str(Path(__file__).resolve())],
          'full_suite_executed': False, 'release_acceptance': False, 'environments': []}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def receipt(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': 'sha256:' + digest(path)}


try:
    requirement_file = BASE / 'receipts/force-agent-verification-requirements.txt'
    expected = {}
    for line in requirement_file.read_text().splitlines():
        if line and not line.startswith('#'):
            name, version = line.split('==')
            expected[name.lower().replace('_', '-')] = version
    report['requirements'] = receipt(requirement_file)
    runtime_report = json.loads((BASE / 'receipts/runtime-integrity.json').read_bytes())
    assert runtime_report['status'] == 'passed'
    for short, version in [('311', '3.11.17'), ('313', '3.13.16')]:
        packages = BASE / ('python' + short + '-packages')
        executable = BASE / ('python' + short) / 'bin' / ('python' + '.'.join(version.split('.')[:2]))
        installation = json.loads((BASE / f'receipts/pip{short}-install.json').read_bytes())
        environment = {'python': version, 'executable': str(executable), 'packages_directory': str(packages),
                       'install_report': receipt(BASE / f'receipts/pip{short}-install.json'),
                       'archives': [], 'verified_wheel_members': [], 'pip_generated_members': []}
        report['environments'].append(environment)
        installed, checked = {}, set()
        for item in installation['install']:
            name, item_version = item['metadata']['name'], item['metadata']['version']
            normalized = name.lower().replace('_', '-')
            assert expected[normalized] == item_version
            installed[normalized] = item_version
            source = urlsplit(item['download_info']['url'])
            assert source.scheme == 'file'
            wheel = Path(unquote(source.path))
            assert wheel.parent == BASE / 'downloads/wheels'
            pypi_name = 'typing_extensions' if normalized == 'typing-extensions' else normalized
            pypi_path = BASE / f'receipts/pypi-{pypi_name}-{item_version}.json'
            release = json.loads(pypi_path.read_bytes())
            remote = next(entry for entry in release['urls'] if entry['filename'] == wheel.name)
            sha = digest(wheel)
            assert sha == remote['digests']['sha256'] == item['download_info']['archive_info']['hashes']['sha256']
            assert wheel.stat().st_size == remote['size']
            environment['archives'].append({**receipt(wheel), 'upstream_url': remote['url'],
                                             'pypi_release_metadata': receipt(pypi_path)})
            with zipfile.ZipFile(wheel) as archive:
                assert archive.testzip() is None
                for member in archive.infolist():
                    if member.is_dir():
                        continue
                    relative = PurePosixPath(member.filename)
                    assert not relative.is_absolute() and all(part not in ('.', '..') and not part.endswith('.data') for part in relative.parts)
                    target = packages / Path(*relative.parts)
                    if relative.name == 'RECORD' and relative.parent.name.endswith('.dist-info'):
                        continue
                    raw = archive.read(member)
                    assert target.is_file() and not target.is_symlink() and target.read_bytes() == raw
                    checked.add(target.relative_to(packages).as_posix())
                    environment['verified_wheel_members'].append(receipt(target))
        actual = {dist.metadata['Name'].lower().replace('_', '-'): dist.version
                  for dist in importlib.metadata.distributions(path=[str(packages)])}
        assert actual == installed == expected
        for path in sorted(packages.rglob('*')):
            if not path.is_file() or path.relative_to(packages).as_posix() in checked:
                continue
            relative = path.relative_to(packages)
            assert not path.is_symlink()
            assert (path.parent.name.endswith('.dist-info') and path.name in ('RECORD', 'INSTALLER', 'REQUESTED')) or relative.as_posix() == 'bin/jsonschema', relative
            if path.name == 'INSTALLER':
                assert path.read_bytes() == b'pip\n'
            elif path.name == 'REQUESTED':
                assert path.read_bytes() == b''
            environment['pip_generated_members'].append(receipt(path))
        for record in packages.glob('*.dist-info/RECORD'):
            for name, hash_value, size in csv.reader(record.read_text().splitlines()):
                target = packages / (name[6:] if name.startswith('../../bin/') else name)
                assert target.resolve().is_relative_to(packages.resolve())
                if not hash_value:
                    assert target == record and size == ''
                    continue
                algorithm, encoded = hash_value.split('=', 1)
                assert algorithm == 'sha256' and target.stat().st_size == int(size)
                assert base64.urlsafe_b64encode(bytes.fromhex(digest(target))).decode().rstrip('=') == encoded
        runtime = next(row for row in runtime_report['runtimes'] if row['version'] == version)
        for member in runtime['members']:
            target = Path(runtime['destination']) / member['path']
            if member['type'] == 'regular':
                assert not target.is_symlink() and target.stat().st_size == member['bytes'] and 'sha256:' + digest(target) == member['sha256']
            else:
                assert target.is_symlink() and os.readlink(target) == member['target']
        env = {**os.environ, 'PYTHONPATH': str(packages), 'PYTHONDONTWRITEBYTECODE': '1'}
        probe = ('import importlib.metadata,json,platform,sys,jsonschema,referencing,rpds,attrs,typing_extensions; '
                 'from jsonschema import Draft202012Validator; '
                 'Draft202012Validator({"type":"object"}).validate({}); '
                 'assert rpds.HashTrieMap({"checked":True})["checked"]; '
                 'print(json.dumps({"python":platform.python_version(),"executable":sys.executable,'
                 '"packages":{d.metadata["Name"].lower().replace("_","-"):d.version for d in importlib.metadata.distributions(path=[sys.argv[1]])},'
                 '"rpds_module":rpds.__file__}))')
        observed = json.loads(subprocess.check_output([str(executable), '-s', '-B', '-c', probe, str(packages)], env=env, text=True))
        assert observed['python'] == version and observed['packages'] == expected
        environment.update(status='passed', package_import_probe=observed,
                           verified_runtime_members=len(runtime['members']), installed_packages=actual)
        print(json.dumps({'python': version, 'status': 'passed', 'packages': len(actual),
                          'verified_wheel_members': len(environment['verified_wheel_members']),
                          'verified_runtime_members': len(runtime['members'])}), flush=True)
    report['status'] = 'passed'
except Exception as error:
    report.update(status='failed', failure={'type': type(error).__name__, 'message': str(error)}, traceback=traceback.format_exc())
finally:
    report['finished_at'] = datetime.now(timezone.utc).isoformat()
    with REPORT.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'status': report['status'], 'report': str(REPORT), 'failure': report.get('failure')}), flush=True)
raise SystemExit(0 if report['status'] == 'passed' else 1)
