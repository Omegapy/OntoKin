source /workspace/scratch/bdfa0406bd65/reach-verification-env-001/activate.sh
export REACH_PYTHON=/workspace/scratch/bdfa0406bd65/reach-python-matrix-env-001/python311/bin/python3.11
export PYTHONPATH=/workspace/scratch/bdfa0406bd65/reach-python-matrix-env-001/python311-packages
export PYTHONDONTWRITEBYTECODE=1
