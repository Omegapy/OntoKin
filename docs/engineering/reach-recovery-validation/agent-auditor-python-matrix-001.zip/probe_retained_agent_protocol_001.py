"""Diagnostic component probe of retained evidence across named source cuts.

This is deliberately not the official Agent audit. It does not call input_cut,
does not grant source equivalence, and does not certify delivery/store/release.
Both original and diagnostic cuts and all observed component failures are kept.
"""
import argparse
import json
from pathlib import Path
import platform
import subprocess
import sys
import time
import traceback

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', type=Path, required=True)
parser.add_argument('--workflow', type=Path, required=True)
parser.add_argument('--output-dir', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.repo.resolve()))
from tools import audit_reach_agent_delivery as audit
from tools.reach_delivery_inventory import descriptor, finish_inputs, fresh_output, snapshot, utc, write_json

output = fresh_output(args.output_dir)
report = {
    'schema_version': 'ontokin.reach-agent-retained-protocol-diagnostic/0.1',
    'status': 'running', 'diagnostic_only': True,
    'scope': 'Corrected reader component checks against an earlier retained producer cut',
    'command': [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
    'driver': descriptor(Path(__file__).resolve()), 'started_at': utc(),
    'environment': {'python': platform.python_version(), 'executable': sys.executable,
                    'platform': platform.platform()},
    'official_audit_executed': False, 'source_equivalence_accepted': False,
    'agent_transport_audited': False, 'complete_delivery_corpus_accepted': False,
    'closed_store_audited': False, 'native_validation': 'not_executed',
    'browser_validation': 'not_executed', 'release_acceptance': False,
    'full_product_goal_completed': False, 'components': [],
}
reader, before = None, None
started = time.monotonic()


def component(name, callback):
    row = {'name': name, 'started_at': utc()}
    try:
        callback()
        row['status'] = 'passed_component_only'
    except Exception as error:
        row.update(status='failed', failure={'type': type(error).__name__, 'message': str(error)},
                   traceback=traceback.format_exc())
    row['finished_at'] = utc()
    report['components'].append(row)
    print(json.dumps(row, sort_keys=True), flush=True)
    return row['status'] == 'passed_component_only'


try:
    before = snapshot()
    write_json(output / 'diagnostic-inputs-before.json', before)
    reader = audit.Reader(args.workflow)
    reader.record = reader.read('producer-record.json')
    original_before = reader.read('inputs-before.json')
    original_after = reader.read('inputs-after.json')
    report['producer_source_cut'] = {key: reader.record['source_' + key] for key in ('commit', 'tree')}
    report['diagnostic_reader_source_cut'] = {key: before['git'][key] for key in ('commit', 'tree')}
    report['producer_record'] = descriptor(args.workflow / 'producer-record.json')
    report['producer_observed_status'] = reader.record['status']
    report['producer_input_snapshots_equal'] = original_before == original_after
    report['source_cuts_equal'] = report['producer_source_cut'] == report['diagnostic_reader_source_cut']
    report['tracked_changed_paths_between_cuts'] = subprocess.check_output(
        ['git', '-C', str(args.repo), 'diff', '--name-status',
         report['producer_source_cut']['commit'], report['diagnostic_reader_source_cut']['commit']],
        text=True).splitlines()
    audit.require(original_before == original_after, 'Original retained producer inputs changed')
    audit.require(reader.record['implementation'] == reader.implementation,
                  'Diagnostic reader and retained producer runtime implementation differ')
    report['runtime_implementation_identity_matches'] = True
    report['implementation'] = reader.implementation
    for name, field in (('protocol-cases.json', 'protocol_inputs'), ('release-probes.json', 'release_probe_inputs')):
        path = audit.DATA / 'draft2-supplements' / name
        audit.require(reader.record[field] == audit.descriptor(path.read_bytes(), path.relative_to(audit.ROOT).as_posix()),
                      'Frozen protocol/probe bytes differ')
    report['frozen_protocol_and_probe_descriptors_match'] = True
    traced = component('all_actual_exchange_schema_and_state_trace', lambda: reader.trace(reader.record['exchanges']))
    report['traced_exchange_count'] = len(reader.exchanges)
    if traced:
        component('42_frozen_LP_steps_and_LP02_Q03_LP05_components', reader.protocol)
        if hasattr(reader, 'protocol_steps'):
            report['frozen_protocol_steps'] = reader.protocol_steps
            report['frozen_protocol_step_count'] = len(reader.protocol_steps)
            report['q03_complete_response_entries'] = reader.q03_entries
            component('Q22_same_project_patch_and_history_component', reader.q22)
        component('retained_frozen_source_snapshots', reader.snapshots)
        component('retained_run_records', reader.retained_runs)
    else:
        report['not_executed_due_to_trace_failure'] = ['protocol', 'q22', 'snapshots', 'retained_runs']
    report['complete_projection_schema_checks'] = reader.projections
    report['verification_packages'] = reader.schemas.packages
    report['schema_hashes'] = reader.schemas.hashes
    report['unexecuted_official_audit_gates'] = ['input_cut', 'deliveries', 'delivery_failures', 'q02', 'store', 'complete_exchange_usage']
    report['status'] = 'diagnostic_components_complete' if all(
        row['status'] == 'passed_component_only' for row in report['components']) else 'diagnostic_component_failure'
except Exception as error:
    report.update(status='diagnostic_setup_failure', failure={'type': type(error).__name__, 'message': str(error)},
                  traceback=traceback.format_exc())
finally:
    if reader is not None:
        for name, receipt in reader.files.items():
            actual = audit.descriptor(audit.read_raw(audit.safe_path(reader.root, name)), name)
            if actual != receipt:
                report.update(status='diagnostic_evidence_changed', changed_member=name)
        report['retained_evidence_members'] = [reader.files[name] for name in sorted(reader.files)]
    finish_inputs(output, before, report)
    report.update(finished_at=utc(), elapsed_seconds=time.monotonic() - started)
    write_json(output / 'report.json', report)
    print(json.dumps({key: report.get(key) for key in ('status', 'traced_exchange_count',
        'frozen_protocol_step_count', 'complete_projection_schema_checks', 'inputs_stable', 'failure')}, sort_keys=True), flush=True)
raise SystemExit(0 if report['status'] == 'diagnostic_components_complete' else 1)
