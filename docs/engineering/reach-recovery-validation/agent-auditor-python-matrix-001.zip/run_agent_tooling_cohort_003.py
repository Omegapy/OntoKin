"""Record the 15 Agent auditor and six producer integrity test methods."""
import argparse
import contextlib
import importlib.metadata
from pathlib import Path
import platform
import sys
import time
import traceback
import unittest

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--repo', required=True, type=Path)
parser.add_argument('--output-dir', required=True, type=Path)
args = parser.parse_args()
sys.path.insert(0, str(args.repo.resolve()))
sys.path.insert(0, str(args.repo.resolve() / 'tests'))
from tools.reach_delivery_inventory import descriptor, finish_inputs, fresh_output, snapshot, utc, write_json
from ontokin.construction_conformance import _run_tests
from ontokin.surface_conformance import _execution_passes
from ontokin.force_conformance import verification_pins

output = fresh_output(args.output_dir)
report = {
    'schema_version': 'ontokin.reach-agent-tooling-tests/0.1', 'status': 'running',
    'scope': '15 independent auditor and 6 producer integrity methods only',
    'command': [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
    'driver': descriptor(Path(__file__).resolve()), 'started_at': utc(),
    'environment': {'python': platform.python_version(), 'executable': sys.executable,
                    'platform': platform.platform()},
    'release_acceptance': False, 'full_product_goal_completed': False,
}
before = None
started = time.monotonic()


def flatten(suite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item.id()


try:
    before = snapshot()
    write_json(output / 'inputs-before.json', before)
    report.update(source_commit=before['git']['commit'], source_tree=before['git']['tree'])
    pins = verification_pins()
    actual = {name: importlib.metadata.version(name) for name in pins}
    assert actual == pins
    report['environment']['verification_packages'] = actual
    loader = unittest.TestLoader()
    modules = {'test_reach_agent_delivery_audit': 15, 'test_reach_agent_producer': 6}
    names = []
    for module, count in modules.items():
        selected = sorted(flatten(loader.loadTestsFromName(module)))
        assert len(selected) == count, (module, selected)
        names.extend(selected)
    assert not loader.errors and len(names) == len(set(names)) == 21
    write_json(output / 'test-inventory.json', {'test_ids': names, 'module_counts': modules})
    with (output / 'execution.log').open('x') as stream:
        with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
            execution = _run_tests(names)
    write_json(output / 'test-results.json', execution)
    report.update(status='passed' if _execution_passes(execution, names) else 'failed',
                  test_count=len(names), outcomes=execution['outcomes'],
                  nonpassing_test_ids=[r['test_id'] for r in execution['tests'] if r['status'] != 'passed'])
except Exception as error:
    report.update(status='failed', failure={'type': type(error).__name__, 'message': str(error)},
                  traceback=traceback.format_exc())
finally:
    finish_inputs(output, before, report)
    report.update(finished_at=utc(), elapsed_seconds=time.monotonic() - started)
    report['members'] = [descriptor(p, relative_to=output) for p in sorted(output.iterdir()) if p.is_file()]
    write_json(output / 'report.json', report)
    print({key: report.get(key) for key in ('status', 'test_count', 'outcomes', 'inputs_stable', 'failure')}, flush=True)
raise SystemExit(0 if report['status'] == 'passed' else 1)
