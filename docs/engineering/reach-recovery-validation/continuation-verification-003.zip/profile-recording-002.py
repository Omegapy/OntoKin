import json,sys,functools,traceback
from pathlib import Path
from fractions import Fraction
root=Path('/workspace/scratch/bdfa0406bd65/OntoKin');sys.path.insert(0,str(root))
from tools.reach_delivery_inventory import snapshot,settings,source_files
from ontokin.bundle import load_file_manifest
from ontokin.construction import compile_construction
from ontokin.scene import ExportOptions
from ontokin.gltf import export_glb
from ontokin import reach_runtime as runtime,reach_export as delivery,reach_reference as reference,reach_conformance as conformance
rows=[];current=None;compiler=None

def measured(owner,name):
 original=getattr(owner,name)
 @functools.wraps(original)
 def wrapper(*args,**kwargs):
  start=compiler.budget.operations if compiler else None
  entry={'stage':name,'start':start}
  counts=dict(compiler.reach_work.counts) if compiler else {}
  if name in {'recording_frames','recording_boundary','phase_bounds','_validate_staged','_reach_map','_process_boundary'}: entry['clock']=str(args[1])
  try:return original(*args,**kwargs)
  finally:
   entry['end']=compiler.budget.operations if compiler else None
   entry['cost']=None if start is None else entry['end']-start
   entry['counts']={key:value-counts.get(key,0) for key,value in compiler.reach_work.counts.items() if value!=counts.get(key,0)} if compiler else {}
   current['calls'].append(entry)
 setattr(owner,name,wrapper)
for owner,name in [(runtime.ReachSimulator,'_validate_staged'),(runtime.ReachSimulator,'_reach_map'),(runtime.ReachSimulator,'_process_boundary'),(runtime.ReachSimulator,'recording_frames'),(runtime.ReachSimulator,'recording_boundary'),(runtime.ReachSimulator,'phase_bounds'),(delivery,'reach_prefix_plan'),(delivery,'interval_certificates'),(reference,'build_reference'),(reference.ReachReference,'boundary_states'),(conformance,'validate_reach_export')]: measured(owner,name)
original=delivery.recording_stage
def stage(name,**kwargs):
 current['stages'].append({'name':name,'operations':compiler.budget.operations});return original(name,**kwargs)
delivery.recording_stage=stage
before=snapshot()
for case in ['P02','P05','P11','P16','P23','L02']:
 current={'case':case,'stages':[],'calls':[]};rows.append(current);compiler=None
 try:
  compiler=compile_construction(load_file_manifest(root/source_files(case)))
  current['compiled_operations']=compiler.budget.operations
  opts=settings(case,fps=1);opts['end']=Fraction(opts['end'])
  result=export_glb(compiler.model,options=ExportOptions(**opts),target_contract='ontokin.glb/0.6',work=compiler.reach_work)
  current['status']='passed'
 except Exception as error:
  current.update(status='failed',error=str(error),traceback=traceback.format_exc())
 current['operations']=compiler.budget.operations if compiler else None
 print(case,current['status'],current['operations'],current['stages'],flush=True)
after=snapshot();out={'scope':'development profile only; original operations/callback/operand bounds unchanged','inputs_before':before,'inputs_after':after,'inputs_stable':before==after,'rows':rows}
Path('/workspace/scratch/bdfa0406bd65/profile-recording-002.json').write_text(json.dumps(out,indent=2)+'\n')
