import datetime,hashlib,json,pathlib,subprocess
base=pathlib.Path('/workspace/scratch/3be6d4d9437a')
root=base/'OntoKin'
tree=json.loads((base/'recovery/remote-tree.json').read_text())['tree']
commit=json.loads((base/'recovery/remote-commit.json').read_text())
def git(*args,input=None):
    return subprocess.check_output(['git','-C',str(root),*args],input=input)
if not (root/'.git').exists(): git('init','-q')
git('config','user.name','Alexander S. Ricciardi')
git('config','user.email','alex.omegapy@gmail.com')
materialized=[]; missing=[]
for entry in tree:
    if entry['type']!='blob': continue
    p=root/entry['path']
    if p.exists():
        raw=p.read_bytes(); actual=git('hash-object','-w','--stdin',input=raw).decode().strip()
        assert actual==entry['sha'], (entry['path'],actual,entry['sha'])
        materialized.append({'path':entry['path'],'git_blob':actual,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
    else: missing.append(entry)
dirs={'':commit['tree']['sha']}
dirs.update({e['path']:e['sha'] for e in tree if e['type']=='tree'})
for directory,expected in sorted(dirs.items(),key=lambda kv:len(pathlib.PurePosixPath(kv[0]).parts),reverse=True):
    entries=[e for e in tree if str(pathlib.PurePosixPath(e['path']).parent).replace('.','',1)==directory] if not directory else [e for e in tree if str(pathlib.PurePosixPath(e['path']).parent)==directory]
    raw=''.join(f"{e['mode']} {e['type']} {e['sha']}\t{pathlib.PurePosixPath(e['path']).name}\n" for e in entries).encode()
    actual=git('mktree','--missing',input=raw).decode().strip()
    assert actual==expected,(directory,actual,expected)
def person(label,entry):
    epoch=int(datetime.datetime.fromisoformat(entry['date'].replace('Z','+00:00')).timestamp())
    return f"{label} {entry['name']} <{entry['email']}> {epoch} +0000\n"
header=f"tree {commit['tree']['sha']}\n"+''.join('parent '+p['sha']+'\n' for p in commit['parents'])+person('author',commit['author'])+person('committer',commit['committer'])+'\n'
offsets=['+0000','-0000']+[f"{'+' if n>=0 else '-'}{abs(n)//60:02}{abs(n)%60:02}" for n in range(-840,841,15)]
found=None
for author_offset in offsets:
    if found: break
    for committer_offset in offsets:
        if found: break
        lines=header.splitlines(keepends=True)
        lines=[line[:-6]+(author_offset if line.startswith('author ') else committer_offset)+'\n' if line.startswith(('author ','committer ')) else line for line in lines]
        for suffix in ('','\n','\n\n'):
            raw=(''.join(lines)+commit['message']+suffix).encode()
            actual=hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
            if actual==commit['sha']: found=raw; break
if found is None: raise ValueError('Cannot reconstruct exact remote commit')
git('hash-object','-t','commit','-w','--stdin',input=found)
(root/'.git/shallow').write_text(commit['sha']+'\n')
branch='work/reach06-recordings-20261023-7of9-3be6'
git('update-ref','refs/heads/'+branch,commit['sha'])
git('symbolic-ref','HEAD','refs/heads/'+branch)
git('read-tree',commit['sha'])
if missing: git('update-index','--skip-worktree','-z','--stdin',input=b''.join(e['path'].encode()+b'\0' for e in missing))
status=git('status','--porcelain=v1','--untracked-files=all').decode()
assert status=='',status
receipt={'schema_version':'ontokin.repository-recovery/0.1','source_commit':commit['sha'],'source_tree':commit['tree']['sha'],'exact_commit_reconstructed':True,'all_tree_objects_verified':True,'tracked_file_count':len(materialized)+len(missing),'materialized_files':materialized,'omitted_files':missing,'git_status':status,'release_input_closure':False,'release_acceptance':False}
(base/'recovery/receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k not in ('materialized_files','omitted_files')},indent=2))
print('Materialized:',len(materialized),'Omitted:',len(missing))
