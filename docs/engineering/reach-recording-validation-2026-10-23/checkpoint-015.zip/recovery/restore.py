import base64,hashlib,json,pathlib,sys
root=pathlib.Path('/workspace/scratch/3be6d4d9437a/OntoKin')
restored=[]
for arg in sys.argv[1:]:
    for item in json.loads(pathlib.Path(arg).read_text()):
        ent=item['entry']; content=item['content']
        data=base64.b64decode(content) if item.get('encoding')=='base64' else content.encode('utf-8')
        actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        if actual!=ent['sha']:
            raise ValueError((ent['path'],actual,ent['sha'],len(data),ent.get('size')))
        p=root/ent['path']
        if '..' in pathlib.PurePosixPath(ent['path']).parts or p.is_symlink(): raise ValueError(ent['path'])
        p.parent.mkdir(parents=True,exist_ok=True)
        p.write_bytes(data)
        p.chmod(0o755 if ent['mode']=='100755' else 0o644)
        restored.append(ent['path'])
print(json.dumps({'restored':len(restored)}))
