import hashlib,json,pathlib,zipfile
base=pathlib.Path('/workspace/scratch/3be6d4d9437a')
folder=base/'OntoKin/docs/engineering/reach-recording-validation-2026-10-23'
out=base/'evidence/recovered'
out.mkdir(parents=True,exist_ok=True)
receipts=[]
for number in (12,14):
    manifest=json.loads((folder/f'checkpoint-{number:03}-manifest.json').read_text())
    payload=[]
    for part in manifest['parts']:
        data=(folder/part['path']).read_bytes()
        assert len(data)==part['bytes'] and hashlib.sha256(data).hexdigest()==part['sha256']
        payload.append(data)
    data=b''.join(payload)
    assert len(data)==manifest['archive']['bytes'] and hashlib.sha256(data).hexdigest()==manifest['archive']['sha256']
    archive=out/f'checkpoint-{number:03}.zip';archive.write_bytes(data)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(set(z.namelist()))
        members={r['path']:r for r in manifest['members']}
        assert set(z.namelist())==set(members)
        for name in z.namelist():
            p=pathlib.PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts
            raw=z.read(name);m=members[name]
            assert len(raw)==m['bytes'] and hashlib.sha256(raw).hexdigest()==m['sha256']
            if name.startswith('driver/') or name=='execution/combined-recordings-018/report.json':
                target=out/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
    receipts.append({'checkpoint':number,'archive_sha256':manifest['archive']['sha256'],'members_verified':len(members),'zip_crc_verified':True})
(out/'restoration.json').write_text(json.dumps(receipts,indent=2)+'\n')
print(json.dumps(receipts))
