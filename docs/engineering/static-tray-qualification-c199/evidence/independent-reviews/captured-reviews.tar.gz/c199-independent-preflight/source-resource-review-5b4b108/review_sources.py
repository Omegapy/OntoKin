"""Independent final source guard review. CPU only, real Popen forbidden."""
from pathlib import Path
from unittest.mock import patch
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import unittest

BASE=Path('/workspace/scratch/801d9d641f68')
ROOT=BASE/'c199-reader'
OUT=BASE/'c199-independent-preflight/source-resource-review-5b4b108'
sys.path.insert(0,str(ROOT))
from prototypes.static_tray_v01.sources import lower_source
from prototypes.static_tray_v01.errors import PROFILE,TrayError
from tests import test_static_tray_source_v01 as original
from tests import test_static_tray_source_resources_v01 as resources

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
checks=[]
def check(name,ok,detail=None):
    checks.append({'name':name,'passed':bool(ok),'detail':detail})
    if not ok:raise AssertionError(name)
check('isolated reviewer',sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode)
files={name:{'sha256':sha(ROOT/name),'bytes':(ROOT/name).stat().st_size} for name in [
    'prototypes/static_tray_v01/sources.py','prototypes/static_tray_v01/canonical.py',
    'tests/test_static_tray_source_v01.py','tests/test_static_tray_source_resources_v01.py',
    'docs/engineering/static-tray-qualification-c199/SOURCE-ADMISSION.md',
    'docs/engineering/static-tray-mapping-c198/CONTROLS.json',
    'docs/engineering/static-tray-mapping-c198/canonical-record.schema.json']}
check('requested repaired source bytes',files['prototypes/static_tray_v01/sources.py']['sha256']=='c785153c1b7a92441c59cbfae1daf7da4fbc6101e7c7e67a3da0c3b0bfdc546e')
for name in files:
    dst=OUT/'snapshot'/name
    dst.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/name,dst)
os.environ['ONTOKIN_STATIC_TRAY_CAPTURE']=str(OUT/'existing-source-controls')
os.environ['ONTOKIN_STATIC_TRAY_RESOURCE_CAPTURE']=str(OUT/'resource-controls')
suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(original),unittest.defaultTestLoader.loadTestsFromModule(resources)])
expected=suite.countTestCases()
started=time.monotonic()
with (OUT/'CPU-TESTS.log').open('w') as log,patch.object(subprocess,'Popen',side_effect=AssertionError('A real child is forbidden in this review')):
    result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
    probe=BASE/'c199-independent-preflight/source-resource-review-c585a72/slice-assignment-growth/source.json'
    observed=None
    try:lower_source('direct-python',probe,PROFILE)
    except TrayError as exc:observed=exc.to_dict()
elapsed=time.monotonic()-started
check('all original and resource controls pass',result.testsRun==expected==31 and result.wasSuccessful() and not result.skipped,
      {'tests':result.testsRun,'errors':len(result.errors),'failures':len(result.failures),'skipped':len(result.skipped),'seconds':elapsed})
check('exact independent slice-growth probe now rejects',observed is not None and observed.get('code')=='OTRAY-E-SHAPE',observed)
for name,binding in files.items():check('stable exact bytes:'+name,sha(ROOT/name)==binding['sha256'])
report={'schema':'ontokin.c199.independent-source-resource-review/0.1','decision':'SOURCE_RESOURCE_REPAIRS_PASS',
        'reviewer':'/root/repo_status','reviewed_commit':'5b4b108','files':files,'checks':checks,'passed_checks':len(checks),
        'cpu_methods':result.testsRun,'elapsed_seconds':elapsed,'log_sha256':sha(OUT/'CPU-TESTS.log'),
        'reviewer_script_sha256':sha(__file__),'controlled_child_starts':0,'native_starts':0,
        'review_summary':['Bounded opened-file reads and three-entry inventory bound happen before source execution.',
                          'Guarded arithmetic, numeric limb work, materialization/reduction, methods and value traversal share the source counter/deadline.',
                          'Simple item assignment preserves RHS-object-key evaluation order and validates bounded list/dict mutation.',
                          'Slice writes, deletion, starred and nested mutation targets reject before execution.',
                          'Original source controls/fixtures and canonical arithmetic remain unchanged; actual source pairs, exact orientation twins and diagnostics pass.',
                          'The independently reproduced earlier discarded-intermediate bypass is preserved and rejected by the repaired bytes.'],
        'limits':['No general Python sandbox claim is made. This is a versioned finite source surface.',
                  'No process lifecycle, native export, import, render or artifact promotion is qualified by these CPU controls.',
                  'This source-specific review does not approve the final native executable lock.']}
(OUT/'REVIEW.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'decision':report['decision'],'tests':result.testsRun,'file':str(OUT/'REVIEW.json'),'sha256':sha(OUT/'REVIEW.json')}))
