"""Independent static review; imports no worker, receiver, bpy, or mathutils."""
from pathlib import Path
from datetime import datetime, timezone
from itertools import product
from collections import Counter
import ast
import hashlib
import json
import shutil
import sys

BASE=Path('/workspace/scratch/801d9d641f68')
ROOT=BASE/'ontokin'
PKG=ROOT/'prototypes/static_tray_v01'
OUT=BASE/'c199-independent-preflight/worker-receiver-review'
GLTF=BASE/'deps/blender-4.5.3-linux-x64/4.5/scripts/addons_core/io_scene_gltf2'
checks=[]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def check(name,ok,details=None):
    checks.append({'name':name,'passed':bool(ok),'details':details})
    if not ok: raise AssertionError(name)
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def cross(a,b): return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def mv(m,v): return tuple(dot(row,v) for row in m)
def mt(m): return tuple(zip(*m))
def mm(a,b): return tuple(tuple(dot(r,c) for c in mt(b)) for r in a)
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def determinant(m): return dot(m[0],cross(m[1],m[2]))
def quat(q):
    w,x,y,z=q
    return ((1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)),
            (2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)),
            (2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)))
check('review uses isolated no-site no-bytecode host Python',sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode)
(OUT/'snapshot').mkdir(exist_ok=True)
files={}
for name in ['worker.py','receiver.py','export-settings.json','import-settings.json','delivery-rules.json']:
    path=PKG/name
    shutil.copyfile(path,OUT/'snapshot'/name)
    files[path.relative_to(ROOT).as_posix()]={'sha256':sha(path),'bytes':path.stat().st_size}
worker=ast.parse((OUT/'snapshot/worker.py').read_text())
receiver=ast.parse((OUT/'snapshot/receiver.py').read_text())
def assigned(tree,name):
    return next(n.value for n in ast.walk(tree) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
C=ast.literal_eval(assigned(worker,'C').args[0])
check('worker uses declared proper basis',C==((1,0,0),(0,0,-1),(0,1,0)) and determinant(C)==1)
I=((1,0,0),(0,1,0),(0,0,1))
check('basis inverse is transpose',mm(mt(C),C)==I and mm(C,mt(C))==I)
C4=ast.literal_eval(assigned(receiver,'C').args[0])
check('receiver uses same affine basis',C4==((1,0,0,0),(0,0,-1,0),(0,1,0,0),(0,0,0,1)))
catalog=[(1,0,0,0),(0,1,0,0),(0,0,1,0),(0,0,0,1)]+[(.5,.5*x,.5*y,.5*z) for x,y,z in product((1,-1),repeat=3)]
point=(.03125,-.0625,.125)
offset=(.015625,.125,-.25)
translation=(-.5,.25,.75)
for index,q in enumerate(catalog):
    R=quat(q)
    RB=mm(mm(C,R),mt(C))
    expected=add(mv(R,add(point,offset)),translation)
    native=add(mv(RB,add(mv(C,point),mv(C,offset))),mv(C,translation))
    check('finite orientation round trip '+str(index),determinant(R)==1 and mm(R,mt(R))==I and mv(mt(C),native)==expected)
box=next(n for n in worker.body if isinstance(n,ast.FunctionDef) and n.name=='box')
quads=ast.literal_eval(assigned(box,'quads'))
source_expression=ast.Expression(body=assigned(box,'source'))
vertices=eval(compile(source_expression,'<reviewed finite literal box expression>','eval'),{'__builtins__':{}},{'sx':1,'sy':2,'sz':3})
triangles=[t for a,b,c,d in quads for t in ((a,b,c),(a,c,d))]
native_vertices=[mv(C,p) for p in vertices]
edges=Counter()
for t in triangles:
    for a,b in zip(t,t[1:]+t[:1]):edges[(a,b)]+=1
check('box has eight actual corners and twelve triangles',len(vertices)==8 and len(set(vertices))==8 and len(triangles)==12)
check('triangle surface closes with opposite oriented edge pairs',all(n==1 and edges[(b,a)]==1 for (a,b),n in edges.items()))
for i,(a,b,c) in enumerate(triangles):
    for frame,verts in [('source',vertices),('native',native_vertices)]:
        normal=cross(sub(verts[b],verts[a]),sub(verts[c],verts[a]))
        center=tuple(sum(verts[t][axis] for t in (a,b,c))/3 for axis in range(3))
        check('outward winding '+frame+' triangle '+str(i),dot(normal,center)>0)
volume=sum(dot(vertices[a],cross(vertices[b],vertices[c]))/6 for a,b,c in triangles)
check('positive exact cuboid volume',volume==48)
property_map=json.loads((BASE/'c199-independent-preflight/BLENDER-OPERATOR-PROPERTIES.json').read_bytes())
operator_results={}
for name in ['export','import']:
    values=json.loads((OUT/'snapshot'/f'{name}-settings.json').read_bytes())
    props=property_map[name]
    check(name+' complete static declared operator coverage',set(values)==set(props))
    for key,row in props.items():
        value=values[key]
        typ=row['property_type']
        literals={k:v['literal'] for k,v in row['keywords'].items() if v.get('is_literal')}
        valid={'BoolProperty':lambda:type(value)is bool,'IntProperty':lambda:type(value)is int,
               'FloatProperty':lambda:type(value)in(int,float),'StringProperty':lambda:type(value)is str,
               'CollectionProperty':lambda:value==[],'EnumProperty':lambda:type(value)is str}[typ]()
        if typ=='EnumProperty' and 'items' in literals:valid=valid and value in [x[0] for x in literals['items'] if x is not None]
        if typ in ('IntProperty','FloatProperty'):
            valid=valid and ('min' not in literals or value>=literals['min']) and ('max' not in literals or value<=literals['max'])
        check(name+' static type/range/enum '+key,valid)
    operator_results[name]={'explicit_property_count':len(values),'dynamic_RNA_coverage':'Required inside first authorized native slot; never observed by this review'}
rules=json.loads((OUT/'snapshot/delivery-rules.json').read_bytes())
parts=('back','base','front','left-wall','payload','right-wall')
children=['equipment-tray/pair/'+side+'/'+part for side in ('left','right') for part in parts]
expected_nodes=children[:6]+['equipment-tray/pair/left']+children[6:]+['equipment-tray/pair/right']
check('frozen delivery child-before-root order',rules['node_order']==expected_nodes and rules['scene_nodes']==[6,13])
check('frozen delivery mesh order and finite inventory',rules['mesh_order']==[n+'/mesh' for n in children] and rules['nodes']==14 and rules['meshes']==12 and rules['triangles_per_mesh']==12 and rules['primitives_per_mesh']==1)
check('frozen fixed material values',(rules['material_order'],rules['metallic'],rules['roughness'],rules['alpha_mode'],rules['double_sided'])==(['tray','payload'],0,.75,'OPAQUE',False))
check('frozen actual accessor component types',(rules['index_component_type'],rules['position_component_type'],rules['normal_component_type'])==(5123,5126,5126))
sources={str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in [
    GLTF/'__init__.py',GLTF/'blender/exp/tree.py',GLTF/'blender/exp/exporter.py',
    GLTF/'blender/exp/nodes.py',GLTF/'blender/exp/primitives.py',GLTF/'blender/exp/primitive_extract.py',
    GLTF/'blender/com/extras.py',GLTF/'blender/imp/material.py',
    OUT/'blender-v4.5.3-idprop_py_api.cc']}
report={'schema':'ontokin.c199.independent-native-static-review/0.1','decision':'STATIC_REVIEW_WITH_ONE_RECEIPT_GAP',
        'reviewed_at_utc':datetime.now(timezone.utc).isoformat(),'reviewer':'/root/repo_status',
        'reviewer_runtime_authorship':'No runtime implementation edits; packaging tools only',
        'files':files,'supporting_primary_source_bytes':sources,'checks':checks,'passed_checks':len(checks),
        'operator_maps':operator_results,'reviewer_script_sha256':sha(__file__),
        'manual_findings':[
            {'id':'F01','status':'PASS_STATIC','finding':'Constructor uses one parent root pose and one part offset, with C on local vertices, offsets and translation and C R C transpose for root rotation. Ownership metadata does not add a transform.'},
            {'id':'F02','status':'PASS_STATIC','finding':'Pinned exporter nodes.py and primitive_extract.py perform the inverse location/vertex swizzle once when export_yup is true. Complete dynamic output remains a native qualification gate.'},
            {'id':'F03','status':'PASS_STATIC','finding':'Pinned exporter traverses children before referencing parent nodes; tree.py preserves named child collection iteration and exporter traverses attributes recursively. The proposed fixed order is consistent with deterministic creation/name order, to be verified on actual bytes.'},
            {'id':'F04','status':'PASS_STATIC','finding':'String-list custom properties use Blender IDP_IDPARRAY conversion. idp_sequence_type accepts mapping-protocol strings and array insertion calls idp_from_PyObject, which explicitly supports Unicode; getters and glTF extras code preserve the list. Source inspected at Blender v4.5.3 tag; no Blender execution.'},
            {'id':'F05','status':'PASS_STATIC','finding':'Constructor uses exactly two linear RGBA materials, metallic 0, roughness .75, alpha 1, backface culling, flat triangles, no animation/physics creation. Metadata contains fixed identity/owner/role/follow IDs and no route/source hash.'},
            {'id':'F06','status':'PASS_STATIC','finding':'Receiver hashes sealed inputs, opens native scene with scripts disabled, measures actual vertices/triangles/world transforms/materials, clears it, imports the actual GLB, then measures again. It does not reconstruct/export geometry.'},
            {'id':'F07','status':'OPEN_RECEIPT_GAP','finding':'C198 receiving plan requires exact camera/settings. Current render receipt omits effective clip planes, resolution percentage/pixel aspect, threads, image color/alpha settings, shading flags/background, world color and color management. Parent was asked to pin relevant defaults and record effective settings before final native lock.'}],
        'source_url':'https://github.com/blender/blender/blob/v4.5.3/source/blender/python/generic/idprop_py_api.cc',
        'remaining_gates':['Resolve F07 before freezing the final executable closure.',
                           'Review final pipeline and independent-reader bytes, exact launcher/environment and dependency closure.',
                           'Dynamic bpy operator RNA, actual exporter/importer, rendering and output checks must run only in their assigned authorized native slots.',
                           'Inspect each actual review image and retain findings before overall profile qualification.'],
        'limits':['This is an early static scope review, not native approval or proof that Blender export/import/render succeeds.',
                  'No Blender, controlled child, receiving import, exporter or renderer was started.',
                  'Mathematical probes use exact simple host arithmetic and inspect literal worker topology; they do not claim native float32 measurements.',
                  'Files are snapshotted because other agents may continue implementation before final lock.']}
(OUT/'REVIEW.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'decision':report['decision'],'checks':len(checks),'report':str(OUT/'REVIEW.json'),'sha256':sha(OUT/'REVIEW.json'),'files':files}))
