"""Independent no-child checks of transaction integration repairs."""
from pathlib import Path
from copy import deepcopy
from unittest.mock import patch
import hashlib
import json
import os
import signal
import sys
import time
import unittest

BASE=Path('/workspace/scratch/801d9d641f68')
ROOT=BASE/'ontokin'
OUT=BASE/'c199-independent-preflight/pipeline-review-1202bc8'
OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT))
from prototypes.static_tray_v01 import transaction as tx, supervisor
from prototypes.static_tray_v01.supervisor import Clock, Stop
from tests import test_static_tray_transaction_v01 as seams
from tests import test_static_tray_finalization_v01 as final_tests
checks=[]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def check(name,ok,detail=None):
    checks.append({'name':name,'passed':bool(ok),'detail':detail})
    if not ok:raise AssertionError(name)
check('isolated no-site no-bytecode reviewer',sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode)
files={str(p.relative_to(ROOT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in [
    ROOT/'prototypes/static_tray_v01/transaction.py',ROOT/'prototypes/static_tray_v01/supervisor.py',
    ROOT/'prototypes/static_tray_v01/store.py',ROOT/'tests/test_static_tray_transaction_v01.py',
    ROOT/'tests/test_static_tray_finalization_v01.py']}
check('qualified supervisor unchanged',files['prototypes/static_tray_v01/supervisor.py']['sha256']=='c47b84ab464e89d4c8673d7541679a45ddf3fc4816a906aff4546e074b4c5a10')
check('qualified store unchanged',files['prototypes/static_tray_v01/store.py']['sha256']=='d0006497ff6fc13ff0b563cdb58445789cd1a26c489ac4ce2a84e77a03607bd0')
suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(seams),unittest.defaultTestLoader.loadTestsFromModule(final_tests)])
expected_tests=suite.countTestCases()
if (OUT/'CPU-TESTS.log').exists():
    (OUT/'CPU-TESTS.log').rename(OUT/'CPU-TESTS-before-count-correction.log')
with (OUT/'CPU-TESTS.log').open('w') as log, patch.object(supervisor.subprocess,'Popen',side_effect=AssertionError('Actual child forbidden during independent review')):
    result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
check('all currently assigned preparation CPU tests pass',result.testsRun==expected_tests and result.wasSuccessful() and not result.skipped,{'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skipped':len(result.skipped),'prior_review_assertion':'Earlier run passed 22 tests; stale reviewer count expected 20. Its passing log is retained separately.'})

# Repeat the independent real-alarm/fake-process fault path with the new wrapper.
stage=OUT/'alarm-during-cleanup'
stage.mkdir(exist_ok=False)
writers=[]
class FakeProcess:
    def __init__(self):
        self.pid=424242;self.returncode=None
        r,w=os.pipe();self.stdout=os.fdopen(r,'rb',buffering=0);writers.append(w)
        r,w=os.pipe();self.stderr=os.fdopen(r,'rb',buffering=0);writers.append(w)
    def poll(self):return self.returncode
    def wait(self,timeout=None):return self.returncode
class FakeLibc:
    def prctl(self,*args):return 0
fake=FakeProcess();signals=[]
def signal_fake(pid,sig):
    signals.append({'pid':pid,'signal':int(sig)})
    if sig==signal.SIGKILL:fake.returncode=-9
clock=Clock();failure=None;record=None
try:
    with patch.object(supervisor.subprocess,'Popen',return_value=fake),patch.object(supervisor.ctypes,'CDLL',return_value=FakeLibc()), \
         patch.object(supervisor.os,'killpg',side_effect=signal_fake),patch.object(supervisor,'group_exists',side_effect=lambda pid:fake.returncode is None):
        try:
            with tx.alarm_until(clock,clock.started+.05):
                with tx.supervised_process_clock():
                    supervisor.run_process(['fake-only-no-native'],stage=stage,label='fault-probe',clock=clock,
                        stage_end=clock.started+.05,env={},cancel_after_ms=0)
        except Stop as e:
            failure=e.as_dict();record=getattr(e,'process_record',None)
finally:
    for w in writers:os.close(w)
check('stage alarm cannot interrupt mandatory kill', [s['signal'] for s in signals]==[int(signal.SIGTERM),int(signal.SIGKILL)],signals)
check('original cancellation preserves complete cleanup receipt',failure['state']=='CANCELLED' and record['cleanup']['passed'] and record['cleanup']['reaped'] and record['handles_closed'] and record['cancellation_completion_ms']<=2000,{'failure':failure,'cleanup':record['cleanup']})
check('outer alarm restored to original inactive state',signal.getitimer(signal.ITIMER_REAL)==(0.,0.))

# Lost ACCEPTED ledger fsync reply: actual durable bytes may exist, but marker gates must stop.
fixture=seams.TransactionSeamTests();fixture.setUp()
try:
    original=tx.append_event
    def lost_reply(path,event,*,clock):
        original(path,event,clock=clock)
        if event['state']=='ACCEPTED':raise OSError('Independent simulated lost terminal fsync reply')
    with patch.object(tx,'append_event',side_effect=lost_reply),patch.object(supervisor.subprocess,'Popen',side_effect=AssertionError('No actual child')):
        outcome=fixture.run_one()
    check('lost terminal reply returns UNKNOWN',outcome['state']=='UNKNOWN')
    check('pending and stop markers retained after uncertain accepted ledger',
          (fixture.schedule/'N01.finalization-pending.json').is_file() and (fixture.schedule/'finalization-stop.json').is_file())
    next_row=deepcopy(fixture.row);next_row['slot']='N02';fixture.lock['slots'].append(next_row)
    stopped=False
    try:tx.check_order(fixture.lock,next_row,'locked-input-hash')
    except Stop:stopped=True
    check('uncertain terminal cannot authorize following standalone slot',stopped)
    observation={'returned_state':outcome['state'],'ledger':tx.read_ledger(fixture.schedule),
                 'retained_result':json.loads(Path(fixture.row['result']).read_bytes()),
                 'pending':json.loads((fixture.schedule/'N01.finalization-pending.json').read_bytes()),
                 'stop':json.loads((fixture.schedule/'finalization-stop.json').read_bytes())}
    (OUT/'LOST-TERMINAL-REPLY.json').write_text(json.dumps(observation,indent=2,sort_keys=True)+'\n')
finally:fixture.doCleanups()
for relative,binding in files.items():check('reviewed bytes stayed stable:'+relative,sha(ROOT/relative)==binding['sha256'])
report={'schema':'ontokin.c199.independent-transaction-repair-review/0.1','decision':'TRANSACTION_REPAIRS_PASS',
        'reviewer':'/root/repo_status','files':files,'checks':checks,'passed_checks':len(checks),
        'controlled_child_starts':0,'native_starts':0,'reviewer_script_sha256':sha(__file__),
        'cpu_log_sha256':sha(OUT/'CPU-TESTS.log'),
        'limits':['The test runner and independent probes prohibit real Popen; process behavior uses explicit fakes.',
                  'This approves the reviewed integration repairs, not the final native lock.',
                  'Pending host/bootstrap/source/reader lock changes still require final closure verification.']}
(OUT/'REVIEW.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'decision':report['decision'],'checks':len(checks),'file':str(OUT/'REVIEW.json'),'sha256':sha(OUT/'REVIEW.json')}))
