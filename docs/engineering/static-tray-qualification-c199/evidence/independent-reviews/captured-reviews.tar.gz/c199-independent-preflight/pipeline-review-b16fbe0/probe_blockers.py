"""Two production-integration fault probes. No real Popen/child is permitted."""
from pathlib import Path
from unittest.mock import patch
import hashlib
import importlib.util
import io
import json
import os
import signal
import sys

BASE=Path('/workspace/scratch/801d9d641f68')
ROOT=BASE/'ontokin'
OUT=BASE/'c199-independent-preflight/pipeline-review-b16fbe0'
sys.path.insert(0,str(ROOT))
from prototypes.static_tray_v01 import supervisor
from prototypes.static_tray_v01.supervisor import Clock, Stop

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('prototypes.static_tray_v01.transaction_review_b16fbe0',OUT/'snapshot/transaction.py')
transaction=importlib.util.module_from_spec(spec)
spec.loader.exec_module(transaction)
assert sys.flags.isolated and sys.flags.no_site and sys.dont_write_bytecode

schedule=OUT/'accepted-ledger-without-final-result'
schedule.mkdir(exist_ok=False)
events=[{'slot':'N01','state':state,'input_lock_sha256':'review-lock'}
        for state in ['RESERVED','STARTED','BUILT_PENDING_RECEIVING','RECEIVING','ACCEPTED']]
(schedule/'attempts.jsonl').write_text(''.join(json.dumps(x)+'\n' for x in events))
lock={'schedule_root':str(schedule),'slots':[{'slot':'N01','result':str(schedule/'missing-N01.json')},{'slot':'N02'}],
      'delivered_controls':[]}
failure=None
try:transaction.check_order(lock,lock['slots'][1],'review-lock')
except Exception as e:failure=repr(e)
first={'name':'accepted ledger without durable predecessor result','expected':'Reject before any later start',
       'observed':'Allowed' if failure is None else failure,'reproduced':failure is None,
       'missing_result':str(schedule/'missing-N01.json')}

stage=OUT/'alarm-during-cleanup'
stage.mkdir(exist_ok=False)
writers=[]
class FakeProcess:
    def __init__(self):
        self.pid=424242
        self.returncode=None
        r,w=os.pipe();self.stdout=os.fdopen(r,'rb',buffering=0);writers.append(w)
        r,w=os.pipe();self.stderr=os.fdopen(r,'rb',buffering=0);writers.append(w)
    def poll(self):return self.returncode
    def wait(self,timeout=None):return self.returncode
class FakeLibc:
    def prctl(self,*args):return 0
signals=[]
fake=FakeProcess()
failure=None
record=None
clock=Clock()
try:
    with patch.object(supervisor.subprocess,'Popen',return_value=fake), \
         patch.object(supervisor.ctypes,'CDLL',return_value=FakeLibc()), \
         patch.object(supervisor.os,'killpg',side_effect=lambda pid,sig:signals.append({'pid':pid,'signal':int(sig)})), \
         patch.object(supervisor,'group_exists',return_value=True):
        try:
            with transaction.alarm_until(clock,clock.started+.05):
                supervisor.run_process(['fake-only-no-native'],stage=stage,label='fault-probe',clock=clock,
                    stage_end=clock.started+.05,env={},cancel_after_ms=0)
        except Stop as e:
            failure=e.as_dict()
            record=getattr(e,'process_record',None)
finally:
    for w in writers:os.close(w)
second={'name':'production stage alarm interrupts owned-group cleanup grace',
        'expected':'Mandatory kill and reaping continue despite stage deadline',
        'observed_signals':signals,'failure':failure,'process_record':record,
        'reproduced':any(x['signal']==int(signal.SIGTERM) for x in signals) and not any(x['signal']==int(signal.SIGKILL) for x in signals),
        'method':'Real one-shot 50 ms SIGALRM around unchanged run_process; Popen, killpg and group existence replaced by in-memory fakes. No child exists or signal reaches a process group.'}
assert first['reproduced'] and second['reproduced']
report={'schema':'ontokin.c199.independent-pipeline-blocker-probes/0.1',
        'decision':'BLOCKED_BEFORE_NATIVE_LOCK','snapshot_commit':'b16fbe0',
        'transaction_sha256':sha(OUT/'snapshot/transaction.py'),
        'supervisor_sha256':sha(ROOT/'prototypes/static_tray_v01/supervisor.py'),
        'reviewer_script_sha256':sha(__file__),'findings':[first,second],
        'actual_controlled_starts':0,'actual_native_starts':0,
        'limits':['These fault probes explain integration defects. They do not consume or qualify lifecycle/native slots.',
                  'Qualified supervisor/store runtime was not modified. Parent is repairing transaction.py.']}
(OUT/'BLOCKERS.json').write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
print(json.dumps({'file':str(OUT/'BLOCKERS.json'),'sha256':sha(OUT/'BLOCKERS.json'),'reproduced':2,'actual_child_starts':0}))
