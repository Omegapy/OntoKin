#!/usr/bin/env python3
"""Freeze and verify only this directory's static analysis artifacts."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import zipfile

ROOT=Path(__file__).resolve().parent
MEMBERS=[
 'SOURCE-INVENTORY.json','DEFAULT-DISCOVERY-INVENTORY.json','PREDICATES.json',
 'METHOD-PREDICATE-MAP.json','PRESERVATION-DISPOSITIONS.json',
 'DEPENDENCY-INVENTORY.json','KNOWN-CALLBACKS.json','SCOPED-EXCLUSIONS.json',
 'STATIC-VALIDATION.json','SUPERSEDED-PACKAGES.json','build_inventory.py','annotate_dispositions.py','freeze_evidence.py']
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(path,value):(ROOT/path).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

inputs={name:(ROOT/name).read_bytes() for name in sorted(MEMBERS)}
def archive_bytes():
 stream=io.BytesIO()
 with zipfile.ZipFile(stream,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
  for name,raw in inputs.items():
   entry=zipfile.ZipInfo(name,(1980,1,1,0,0,0))
   entry.create_system=3
   entry.external_attr=(0o100644<<16)
   entry.compress_type=zipfile.ZIP_DEFLATED
   archive.writestr(entry,raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
 return stream.getvalue()

payload=archive_bytes()
assert payload==archive_bytes(),'Archive bytes were not deterministic'
path=ROOT/'MAP-EVIDENCE.zip'
path.write_bytes(payload)
with zipfile.ZipFile(io.BytesIO(path.read_bytes())) as archive:
 names=archive.namelist()
 assert archive.testzip() is None,'ZIP integrity failure'
 assert names==sorted(inputs) and len(names)==len(set(names)),'Member inventory differs'
 for name in names:
  member=PurePosixPath(name)
  assert not member.is_absolute() and '..' not in member.parts and '\\' not in name,'Unsafe member path'
  assert archive.read(name)==inputs[name],'Member bytes differ'

graph=json.loads(inputs['METHOD-PREDICATE-MAP.json'])
checks=json.loads(inputs['STATIC-VALIDATION.json'])
suite=json.loads(inputs['DEFAULT-DISCOVERY-INVENTORY.json'])
preservation=json.loads(inputs['PRESERVATION-DISPOSITIONS.json'])
assert checks['passed'] is True
assert len(graph['methods'])==7
callback='prototypes/static_tray_v01/format_check.py::run_check.started'
assert all(callback in m['source_reachability_nodes'] for m in graph['methods'] if '.ReadbackCoordinatorSeams.' in m['original_default_discovery_id'])
assert graph['proposed_operational_graph']['status']=='unimplemented-design-only'
assert all(m['original_default_discovery_id']==m['proposed_default_discovery_id'] for m in graph['methods'])
manifest={'schema':'ontokin.c271.p05-map-evidence-manifest/1',
 'source_commit':graph['source_commit'],'source_tree':graph['source_tree'],
 'archive':{'path':'MAP-EVIDENCE.zip','size_bytes':len(payload),'sha256':sha(payload)},
 'member_count':len(inputs),'total_uncompressed_bytes':sum(len(x) for x in inputs.values()),
 'members':[{'path':name,'size_bytes':len(raw),'sha256':sha(raw)} for name,raw in inputs.items()],
 'verification':{'crc_integrity':True,'safe_relative_paths':True,'unique_names':True,
                 'exact_member_inventory':True,'all_member_sizes_hashes_and_bytes':True,
                 'deterministic_reconstruction':True,'all_four_seam_callback_closures':True},
 'zip_format':{'timestamp':'1980-01-01T00:00:00','mode':'0o100644','order':'lexicographic','compression':'deflate-9'},
 'purpose':'Static source/design evidence; no executable runtime implementation, test result, qualification or integration claim.'}
manifest['superseded_packages']=json.loads(inputs['SUPERSEDED-PACKAGES.json'])['packages']
dump('MAP-EVIDENCE-MANIFEST.json',manifest)
summary={'schema':'ontokin.c271.p05-map-summary/1','status':'complete-static-map-awaiting-independent-acceptance',
 'source_commit':graph['source_commit'],'source_tree':graph['source_tree'],
 'archive':manifest['archive'],'manifest':{'path':'MAP-EVIDENCE-MANIFEST.json','sha256':sha((ROOT/'MAP-EVIDENCE-MANIFEST.json').read_bytes())},
 'human_map':{'path':'REVIEWABLE-MAP.md','sha256':sha((ROOT/'REVIEWABLE-MAP.md').read_bytes())},
 'counts':{**checks['counts'],'preservation_groups':len(preservation['groups']),
           'target_reachable_nodes':len({n for m in graph['methods'] for n in m['source_reachability_nodes']})},
 'original_default_method_ids':[m['original_default_discovery_id'] for m in graph['methods']],
 'static_generated_method_count':suite['static_generated_count'],
 'static_checks_passed':checks['passed'],'archive_verification':manifest['verification'],
 'declared_execution_counts':{'project_imports':0,'test_methods':0,'Node':0,'ldd':0,'installs':0,'native':0,'full_routine':0},
 'remaining_gates':['Independent design acceptance','Separate implementation and actual new source identities',
                    'Eligible-host/provider qualification','Actual runtime discovery and full routine with R03 acceptance',
                    'R04 integration and R05 final delivery/closure'],
 'limitations':['Static AST inventory is not runtime discovery or branch coverage.',
                'JavaScript anchors are exact manually reviewed line/segment hashes; no JS parser or execution was used.',
                'The external library/runtime internals are bounded by immutable inventories, not exhaustively authored predicates.',
                'Coordinator seams mock the designated production callees; CPU audit uses measurement-only defaults.',
                'No existing repository source, helper, test, pin, runtime or historical evidence was modified.']}
summary['superseded_package_sha256']=[row['archive_sha256'] for row in manifest['superseded_packages']]
dump('MAP-SUMMARY.json',summary)
print(json.dumps({'archive_bytes':len(payload),'archive_sha256':sha(payload),'member_count':len(inputs),
 'total_uncompressed_bytes':manifest['total_uncompressed_bytes'],'verification':'passed'},sort_keys=True))
