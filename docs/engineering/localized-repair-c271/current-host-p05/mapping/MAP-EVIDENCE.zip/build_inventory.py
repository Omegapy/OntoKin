#!/usr/bin/env python3
"""C271 P05 static source inventory. Never imports project code or runs tests.

This analysis program reads bytes, parses Python ASTs, and writes only into its
own directory. It does not execute Node, ldd, Git, package managers, test discovery,
test methods, project modules, native applications, or source programs.
"""
from __future__ import annotations

import ast
from collections import Counter
import fnmatch
import hashlib
import json
from pathlib import Path
import platform
import sys
import tarfile

OUT = Path(__file__).resolve().parent
REPO = OUT.parent / "OntoKin"
COMMIT = "743409619a8663682750b0ca29c50547a25dde41"
TREE = "8202185735f50aa91078a9206c351d917084ed16"
TARGET = "tests/test_static_tray_readback_v01.py"
FORMAT = "prototypes/static_tray_v01/format_check.py"
JS = "prototypes/static_tray_v01/readback.mjs"
SUP = "prototypes/static_tray_v01/supervisor.py"
LOCK = "prototypes/static_tray_v01/lock.py"
CAN = "prototypes/static_tray_v01/canonical.py"
TX = "prototypes/static_tray_v01/transaction.py"
STORE = "prototypes/static_tray_v01/store.py"
TESTREADER = "tests/test_static_tray_reader_v01.py"
READER = "tools/static_tray_reader_v01/reader.py"
GLB = "tools/static_tray_reader_v01/glb.py"
EXPECTED = "tools/static_tray_reader_v01/expected.py"
CORRUPT = "tools/static_tray_reader_v01/corrupt.py"
AUDITCLI = "tools/static_tray_reader_v01/audit.py"
ERRORS = "prototypes/static_tray_v01/errors.py"
HELPER = "docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py"
DRIVER = "tools/check_local.py"
EXTERNAL = "docs/engineering/static-tray-qualification-c199/EXTERNAL-INPUTS.json"
HOST = "docs/engineering/static-tray-qualification-c199/evidence/preflight/HOST-RUNTIME-INVENTORY.json"
CONTROLS = "docs/engineering/static-tray-mapping-c198/CONTROLS.json"
ARCHIVE = "docs/engineering/ownership-recovery-c195/evidence/recorded-evidence.tar.xz"

PYTHON_SOURCES = [TARGET, TESTREADER, FORMAT, SUP, LOCK, CAN, TX, STORE, READER,
                  GLB, EXPECTED, CORRUPT, AUDITCLI, ERRORS, HELPER, DRIVER]
STATIC_INPUTS = [JS, EXTERNAL, HOST, CONTROLS, ARCHIVE,
    "prototypes/static_tray_v01/delivery-rules.json",
    "prototypes/static_tray_v01/export-settings.json",
    "prototypes/static_tray_v01/import-settings.json",
    "docs/engineering/static-tray-mapping-c198/canonical-record.schema.json",
    "docs/language-design/force-v0.1/acceptance.json",
    "docs/language-design/force-v0.1/reviewed-acceptance.json",
    "docs/language-design/force-v0.1/source-errata.json",
    "docs/engineering/localized-repair-c271/runtime-recovery-p04/CURRENT-HOST-QUALIFICATION-PROPOSAL.md",
    "tools/static_tray_reader_v01/README.md"]


def digest(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def encode(value) -> bytes:
    return (json.dumps(value, indent=2, sort_keys=True, ensure_ascii=True, allow_nan=False) + "\n").encode()


def save(name, value):
    (OUT / name).write_bytes(encode(value))


def binding(relative):
    path = REPO / relative
    raw = path.read_bytes()
    return {"path": relative, "size_bytes": len(raw), "sha256": digest(raw),
            "line_count": len(raw.splitlines()), "mode": oct(path.stat().st_mode & 0o777),
            "git_blob_sha1_computed_from_bytes": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest(),
            "source_commit": COMMIT, "source_tree": TREE}


raws = {p: (REPO / p).read_bytes() for p in PYTHON_SOURCES}
texts = {p: raw.decode() for p, raw in raws.items()}
trees = {p: ast.parse(texts[p], filename=p) for p in PYTHON_SOURCES}
functions, nodes, calls, ast_by_function = {}, [], [], {}


def source_segment(path, node):
    return ast.get_source_segment(texts[path], node) or ast.unparse(node)


def source_anchor(path, node):
    raw = source_segment(path, node)
    return {"path": path, "source_sha256": digest(raws[path]), "line": node.lineno,
            "end_line": node.end_lineno, "column": node.col_offset,
            "end_column": node.end_col_offset,
            "ast_type": type(node).__name__,
            "ast_sha256": digest(ast.dump(node, include_attributes=False).encode()),
            "source_segment_sha256": digest(raw.encode())}


INTERESTING = (ast.If, ast.IfExp, ast.While, ast.For, ast.AsyncFor, ast.comprehension,
               ast.Compare, ast.BoolOp, ast.Assert, ast.Raise, ast.Try,
               ast.ExceptHandler, ast.With, ast.AsyncWith, ast.Return,
               ast.Assign, ast.AugAssign, ast.AnnAssign, ast.Call,
               ast.Yield, ast.YieldFrom, ast.Delete)


class Capture(ast.NodeVisitor):
    def __init__(self, path):
        self.path, self.stack = path, ["<module>"]
        self.counters = Counter()
        self.new_scope("<module>", trees[path])

    @property
    def fid(self):
        return self.path + "::" + ".".join(self.stack[1:] or self.stack)

    def new_scope(self, name, node):
        fid = self.fid
        if isinstance(node, ast.Module):
            functions[fid] = {"id": fid, "kind": "module-import", "path": self.path,
                              "line": 1, "end_line": len(texts[self.path].splitlines()),
                              "source_sha256": digest(raws[self.path]), "predicate_ids": [],
                              "call_ids": [], "decorators": []}
        else:
            item = {"id": fid, "kind": type(node).__name__, **source_anchor(self.path, node),
                    "predicate_ids": [], "call_ids": [],
                    "decorators": [ast.unparse(d) for d in getattr(node, "decorator_list", [])]}
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                lines = texts[self.path].splitlines(keepends=True)
                # Full original def, including docstring, body, whitespace and comments.
                block = "".join(lines[node.lineno - 1:node.end_lineno])
                item["function_line_block_sha256"] = digest(block.encode())
                item["body_ast_sha256"] = digest(ast.dump(ast.Module(body=node.body, type_ignores=[]), include_attributes=False).encode())
                ast_by_function[fid] = node
            functions[fid] = item

    def visit_FunctionDef(self, node):
        for decorator in node.decorator_list:
            self.visit(decorator)
        for value in [*node.args.defaults, *(x for x in node.args.kw_defaults if x is not None)]:
            self.visit(value)
        self.stack.append(node.name)
        self.new_scope(node.name, node)
        for child in node.body:
            self.visit(child)
        self.stack.pop()

    visit_AsyncFunctionDef = visit_FunctionDef

    def visit_ClassDef(self, node):
        for decorator in node.decorator_list:
            self.visit(decorator)
        self.stack.append(node.name)
        self.new_scope(node.name, node)
        for child in node.body:
            self.visit(child)
        self.stack.pop()

    def generic_visit(self, node):
        if isinstance(node, INTERESTING):
            # comprehension has no own source coordinates: its child comparisons
            # and generator Call/For expressions are captured separately.
            if hasattr(node, "lineno"):
                label = type(node).__name__
                key = (self.fid, node.lineno, node.col_offset, label)
                self.counters[key] += 1
                pid = f"{self.fid}@{node.lineno}:{node.col_offset}:{label}:{self.counters[key]}"
                item = {"id": pid, "owner": self.fid, **source_anchor(self.path, node),
                        "expression": ast.unparse(node)}
                if isinstance(node, (ast.If, ast.While, ast.IfExp, ast.Assert)):
                    item["condition"] = ast.unparse(node.test)
                if isinstance(node, ast.Call):
                    item["callee_text"] = ast.unparse(node.func)
                    item["assertion"] = isinstance(node.func, ast.Attribute) and (
                        node.func.attr.startswith("assert") or node.func.attr == "fail")
                    calls.append(item)
                    functions[self.fid]["call_ids"].append(pid)
                else:
                    nodes.append(item)
                    functions[self.fid]["predicate_ids"].append(pid)
        super().generic_visit(node)


for source_path in PYTHON_SOURCES:
    Capture(source_path).visit(trees[source_path])

def fid(path, name):
    value = path + "::" + name
    if value not in functions:
        raise ValueError("Unknown source function: " + value)
    return value


edges = []


def edge(source, destination, role="source-call", note=None):
    item = {"from": source, "to": destination, "kind": role}
    if note:
        item["note"] = note
    if item not in edges:
        edges.append(item)


def connect(path, source, targets, role="source-call", note=None):
    for target_path, names in targets:
        for name in names.split():
            edge(fid(path, source), fid(target_path, name), role, note)


# Explicit cross-module edges, plus local lexical calls below, form the bounded
# graph. These are source possibilities, never a claim of executed coverage.
connect(TARGET, "ReadbackCoordinatorSeams.run_seam", [(FORMAT,"run_check"), (CAN,"json_bytes"),
    (SUP,"sha256_file"), (TX,"write_new"), (TARGET,"ReadbackCoordinatorSeams.run_seam.child ReadbackCoordinatorSeams.run_seam.writer ReadbackCoordinatorSeams.run_seam.unlink")])
connect(TARGET, "ReadbackCoordinatorSeams.run_seam.writer", [(TX,"write_new")])
connect(TARGET, "ReadbackCoordinatorSeams.run_seam.child", [(CAN,"json_bytes")])
for name in ("test_result_write_failure_leaves_predecessor_gate_blocked", "test_host_alarm_cannot_interrupt_supervisor_cleanup",
             "test_success_finalization_uses_remaining_outer_alarm", "test_uncertain_marker_removal_recreates_pending"):
    connect(TARGET, "ReadbackCoordinatorSeams." + name, [(TARGET,"ReadbackCoordinatorSeams.run_seam")])
for name in ("test_result_write_failure_leaves_predecessor_gate_blocked", "test_uncertain_marker_removal_recreates_pending"):
    connect(TARGET, "ReadbackCoordinatorSeams." + name, [(FORMAT,"verify_predecessors")])
for name in ("test_q01_actual_synthetic_meshes_load_in_both_libraries", "test_q03_actual_synthetic_rotations_load_in_both_libraries", "test_three_rejects_changed_synthetic_reference"):
    connect(TARGET, "ReadbackCPUControls." + name, [(TARGET,"ReadbackCPUControls.check_case")])
    connect(TARGET, "ReadbackCPUControls." + name, [(TARGET,"ReadbackCPUControls.setUpClass ReadbackCPUControls.tearDownClass")], "unittest-class-lifecycle")
connect(TARGET, "ReadbackCPUControls.setUpClass", [(FORMAT,"build_manifest verify_manifest")])
connect(TARGET, "ReadbackCPUControls.check_case", [(TESTREADER,"synthetic"), (READER,"audit"),
    (CAN,"json_bytes"), (SUP,"sha256_file Clock.__init__ run_process")])
connect(TESTREADER, "synthetic", [(TESTREADER,"source_table synthetic.add"), (GLB,"pack")])
connect(FORMAT, "build_manifest", [(FORMAT,"_alias"), (LOCK,"file_binding read_json"),
    (CAN,"json_bytes"), (SUP,"sha256_file")])
connect(FORMAT, "verify_manifest", [(FORMAT,"_alias"), (LOCK,"read_json check_file"), (SUP,"sha256_file")])
connect(FORMAT, "run_check", [(SUP,"Clock.__init__ Clock.check Clock.elapsed_ms inventory sha256_file"),
    (TX,"alarm_until supervised_process_clock write_new")])
connect(FORMAT, "run_check", [(FORMAT,"run_check.started")], "bound-on-start-callback",
    "run_check L164-170 passes started as on_started; supervisor L189-190 invokes it after a real Popen; the original seam substitutes a mock child.")
connect(TARGET, "ReadbackCoordinatorSeams.run_seam.child", [(FORMAT,"run_check.started")], "mock-child-invokes-real-callback",
    "Original seam child L50 calls kw['on_started'](process); real callback increments checker_starts and writes started.json.")
connect(FORMAT, "run_check.started", [(TX,"write_new")])
connect(FORMAT, "run_check", [(FORMAT,"verify_manifest"), (LOCK,"check_file"), (SUP,"run_process"),
    (TX,"_prior_result"), (STORE,"verify_candidate")], "real-production-call-mocked-in-four-seams",
    "The target seam helper patches this callee. Source predicates remain preserved but these methods do not qualify the real implementation.")
connect(FORMAT, "verify_predecessors", [(LOCK,"read_json")])
connect(LOCK, "read_json", [(CAN,"strict_json")])
connect(LOCK, "file_binding", [(SUP,"sha256_file")])
connect(CAN, "strict_json", [(CAN,"strict_json.pairs"), (ERRORS,"TrayError.__init__")])
connect(CAN, "json_bytes", [(ERRORS,"TrayError.__init__")])
connect(TX, "write_new", [(CAN,"json_bytes")])
connect(TX, "alarm_until", [(TX,"alarm_until.expired")], "signal-handler")
connect(TX, "_prior_result", [(LOCK,"read_json"), (STORE,"verify_candidate"), (SUP,"sha256_file")])
connect(STORE, "verify_candidate", [(SUP,"inventory sha256_file")])
connect(SUP, "run_process", [(SUP,"Clock.check inventory group_exists terminate_group json_bytes Stop.__init__ Stop.as_dict")])
connect(SUP, "terminate_group", [(SUP,"group_exists _reap Stop.__init__")])
connect(SUP, "inventory", [(SUP,"Clock.check Stop.__init__")])
connect(SUP, "Clock.check", [(SUP,"Stop.__init__")])
connect(READER, "audit", [(EXPECTED,"expected_case geometry root_name transpose metadata mat_vec"),
    (GLB,"read_json_file read_bytes parse accessor integer"),
    (READER,"Findings.__init__ Findings.add validate_delivery_rules validate_document check_nonsemantic_metadata check_delivery_layout scene_graph stable_bytes serial matrix check_matrix transform sub box_measurement material tray_measurements")])
connect(READER, "validate_delivery_rules", [(EXPECTED,"root_name"), (GLB,"InvalidGLB.__init__")])
connect(READER, "check_delivery_layout", [(GLB,"integer"), (READER,"Findings.add check_delivery_layout.equal")])
connect(READER, "check_delivery_layout.equal", [(READER,"Findings.add")])
connect(READER, "check_nonsemantic_metadata", [(READER,"Findings.add")])
connect(READER, "number", [(GLB,"finite")])
connect(READER, "vector", [(READER,"number"), (GLB,"InvalidGLB.__init__")])
connect(READER, "matrix", [(READER,"vector"), (GLB,"InvalidGLB.__init__")])
connect(READER, "stable_bytes", [(READER,"serial")])
connect(READER, "Findings.measure", [(READER,"Findings.add")])
connect(READER, "check_rigid", [(READER,"Findings.measure dot cross")])
connect(READER, "check_matrix", [(READER,"check_rigid Findings.measure")])
connect(READER, "validate_document", [(GLB,"integer accessor finite InvalidGLB.__init__"), (READER,"vector")])
connect(READER, "scene_graph", [(GLB,"integer InvalidGLB.__init__"), (READER,"scene_graph.visit")])
connect(READER, "scene_graph.visit", [(READER,"matrix multiply scene_graph.visit"), (GLB,"InvalidGLB.__init__")])
connect(READER, "material", [(GLB,"integer finite InvalidGLB.__init__"), (READER,"Findings.add")])
connect(READER, "box_measurement", [(READER,"Findings.add Findings.measure dot cross sub"), (EXPECTED,"mat_vec")])
connect(READER, "tray_measurements", [(EXPECTED,"root_name"), (READER,"Findings.add Findings.measure")])
connect(EXPECTED, "geometry", [(EXPECTED,"scalar rotation")])
connect(EXPECTED, "rotation", [(EXPECTED,"scalar")])
connect(GLB, "strict_json", [(GLB,"pairs reject_constant InvalidGLB.__init__")])
connect(GLB, "read_json_file", [(GLB,"strict_json InvalidGLB.__init__")])
connect(GLB, "parse", [(GLB,"strict_json integer InvalidGLB.__init__")])
connect(GLB, "accessor", [(GLB,"integer InvalidGLB.__init__")])
for function in ("pairs", "reject_constant", "integer", "finite", "read_bytes", "pack"):
    connect(GLB, function, [(GLB,"InvalidGLB.__init__")])

# Detect direct lexical function calls; do not infer arbitrary attribute dispatch.
for call in calls:
    path, qual = call["owner"].split("::", 1)
    name = call["callee_text"]
    candidates = [path + "::" + name]
    if "." not in name:
        outer = qual.split(".")
        for count in range(len(outer), 0, -1):
            candidates.append(path + "::" + ".".join(outer[:count]) + "." + name)
    for candidate in candidates:
        if candidate in functions:
            role = "direct-script-only-not-import-reachable" if qual == "<module>" and name == "main" else "lexical-call"
            edge(call["owner"], candidate, role, "Static lexical resolution; not an execution observation.")
            break

# Exact source-addressable JS segments; no JavaScript parser or interpreter runs.
js_text = (REPO / JS).read_text()
js_lines = js_text.splitlines(keepends=True)
JS_SEGMENTS = [
    ("JS01",1,16,"imports-sha-canonicalization","Preserve standard Node imports, SHA-256 and recursively sorted object comparison; arrays retain order."),
    ("JS02",17,27,"bounded-input","lstat regular files; maximum byte check before and after bounded read; finally closes descriptor."),
    ("JS03",28,33,"exclusive-output","JSON output <= 4 MiB; wx create; write and fsync; finally close."),
    ("JS04",34,37,"numerical-helpers","Finite-number vector predicate and column-major Matrix4 to row-major conversion."),
    ("JS05",39,47,"job-report","Exactly --job FILE; job <= 32768 bytes; schema/slot/case/input hashes/runtime/non-native scope in result."),
    ("JS06",48,53,"historical-runtime-bootstrap","Exact v24.22.1; manifest <=1 MiB and digest; historical manifest schema. New version must separately authenticate new schema, source and runtime closure."),
    ("JS07",54,59,"input-reference-binding","Artifact <=8 MiB, audit <=4 MiB; both hashes; passed independent audit binds artifact and case."),
    ("JS08",60,71,"khronos","External fetch/resource rejection; actual validator v2.0.0-dev.3.10; format glb, no timestamp, maxIssues 1000; zero errors, zero warnings, not truncated."),
    ("JS09",73,81,"three-import","Actual Three and GLTFLoader imports; package <= 32768 bytes; version 0.186.1 / revision 186; URL resolution refusal; one scene, no animations/cameras; updateMatrixWorld."),
    ("JS10",82,102,"identity-and-comparators","Exact canonical comparison; finite actual+expected and <=threshold near comparison; measurement/finding retention; semantic-id arrays joined; duplicate/unbound rejection; inventory and 14 nodes."),
    ("JS11",103,118,"hierarchy-and-matrices","No lights/cameras/skinning/morph targets; original name, complete extras, sorted children, parent; all16 matrix entries, translation tolerance 5e-6, others 1e-6."),
    ("JS12",119,127,"mesh-layout","Roots empty; one mesh/material per reference mesh; POSITION/NORMAL/index present; <=4096 vertices; equal normals; 36 indices; reference vertex count."),
    ("JS13",128,140,"actual-geometry","Read every actual vertex/normal; finite; transform to world; world positions 5e-6 and normals 1e-6; exact actual triangle indices."),
    ("JS14",141,146,"materials","Exact material name/color/opacity/metalness/roughness/alpha/double-sided; all seven listed texture maps absent."),
    ("JS15",147,154,"world-bounds","Actual and reference per-axis min/max/size; each <=5e-6; retain positions/normals/vertices/indices/material/bounds."),
    ("JS16",155,161,"reader-result","Exactly 12 meshes; stable findings sorting; pass iff zero findings; measurements/nodes/counts/tolerances/naming scope retained."),
    ("JS17",162,168,"preservation-failure-exit","Reread and rehash GLB+audit; pass iff both readers and preservation pass; catch retains delivery error; exclusive result; summary; exit0/1.")]
js_records = []
for key, start, end, label, meaning in JS_SEGMENTS:
    segment = "".join(js_lines[start-1:end])
    js_records.append({"id": key,"path":JS,"line":start,"end_line":end,"source_sha256":digest((REPO/JS).read_bytes()),
                       "segment_sha256":digest(segment.encode()),"anchor_kind":"manual-source-syntax-range-no-JS-AST-parser-executed",
                       "label":label,"meaning":meaning,"source":segment})
    functions["js:" + key] = {"id":"js:"+key,"kind":"JavaScript-source-range","predicate_ids":["js:"+key],
                             "call_ids":[],"path":JS,"line":start,"end_line":end,"source_sha256":digest((REPO/JS).read_bytes())}
    edge(fid(TARGET,"ReadbackCPUControls.check_case"), "js:"+key, "launched-reader-source",
         "Historical argv comes from manifest. Actual future execution and per-branch coverage are not claimed.")

# Register environment/API boundaries without claiming their internal predicates.
external_boundaries = [
    {"id":"external:node-and-system-runtime","owned_internals_mapped":False,"binding":"DEPENDENCY-INVENTORY.json historical_runtime / separately selected current-host closure",
     "reason":"OS loader, libc, Node and standard modules are execution dependencies; version/digest/path/mode/aliases/closure and qualification bind them, not a claim that their internals are authored here."},
    {"id":"external:khronos-three-loader","owned_internals_mapped":False,"binding":"DEPENDENCY-INVENTORY.json retained_dependency_files (24 exact files)",
     "reason":"All retained dependency bytes, including loader and transitive Three modules, remain exact; their imported APIs/results are checked by owned JS predicates. No equivalence inferred from versions alone."},
    {"id":"external:python-stdlib-unittest","owned_internals_mapped":False,"binding":"new actual-host interpreter/platform/stdlib inventory required before qualification",
     "reason":"Path/tempfile/unittest/mock/signal/subprocess/selectors/ctypes/json/Fraction and OS operations keep language/API behavior; no runtime execution occurred during this AST analysis."}]
for b in external_boundaries:
    functions[b["id"]] = {"id":b["id"],"kind":"immutable-dependency-boundary","predicate_ids":[],"call_ids":[]}
edge(fid(SUP,"run_process"),"external:node-and-system-runtime","system-process-dependency")
for key in ("JS08","JS09"):
    edge("js:"+key,"external:khronos-three-loader","immutable-library-call")
edge(fid(TARGET,"<module>"),"external:python-stdlib-unittest","framework-boundary")

# Constants and import-time guards are part of source provenance. These edges
# preserve their predicates without claiming every module-level branch executes.
for function_id in list(functions):
    if "::" not in function_id or function_id.endswith("::<module>"):
        continue
    path = function_id.split("::",1)[0]
    if path in (TARGET, TESTREADER, FORMAT, SUP, LOCK, CAN, TX, STORE, READER, GLB, EXPECTED, ERRORS):
        edge(function_id, fid(path,"<module>"), "module-constants-and-import-context",
             "Static constants/defaults and import-time predicates; not an execution/coverage claim.")
edge(fid(TESTREADER,"<module>"),fid(CORRUPT,"<module>"),"import-time-bytecode-guard",
     "The support module imports corrupt; its import-time cache guard is distinct from uncalled corruption functions.")

adjacency = {}
for e in edges:
    adjacency.setdefault(e["from"],set()).add(e["to"])


def reachable(roots, include_mocked=True):
    rejected = {(e["from"], e["to"]) for e in edges if e["kind"] == "real-production-call-mocked-in-four-seams"}
    script_only = {(e["from"], e["to"]) for e in edges if e["kind"] == "direct-script-only-not-import-reachable"}
    seen, pending = set(), list(roots)
    while pending:
        item = pending.pop()
        if item in seen:
            continue
        seen.add(item)
        pending += [x for x in adjacency.get(item,()) if (item,x) not in script_only and (include_mocked or (item,x) not in rejected)]
    return sorted(seen)


method_rows = []
class_targets = {"ReadbackCoordinatorSeams":"preserve-byte-identical-method-and-shared-helper",
                 "ReadbackCPUControls":"preserve-byte-identical-method-and-check_case; explicit-versioned-provider-in-class-setup-and-run_process-import-alias-only"}
for cls, policy in class_targets.items():
    for function_id, item in functions.items():
        if item.get("path") != TARGET or not function_id.startswith(TARGET+"::"+cls+".test_"):
            continue
        method = function_id.rsplit(".",1)[-1]
        closure = reachable([function_id])
        actual_source_closure = reachable([function_id], include_mocked=False)
        predicates = sorted({p for x in closure for p in functions[x]["predicate_ids"] + functions[x]["call_ids"]})
        direct = [x["id"] for x in calls if x["owner"] == function_id and x["assertion"]]
        shared = [x["id"] for x in calls if x["owner"] in closure and x["assertion"]]
        row = {"original_default_discovery_id":"test_static_tray_readback_v01."+cls+"."+method,
               "explicit_import_alias_id":"tests.test_static_tray_readback_v01."+cls+"."+method,
               "proposed_default_discovery_id":"test_static_tray_readback_v01."+cls+"."+method,
               "method_source":function_id,"original_function_line_block_sha256":item["function_line_block_sha256"],
               "original_body_ast_sha256":item["body_ast_sha256"],"line":item["line"],"end_line":item["end_line"],
               "mapping_cardinality":"1 original method -> 1 same named operational method",
               "preservation_policy":policy,"direct_assertion_ids":direct,"all_reachable_assertion_ids":shared,
               "source_reachability_nodes":closure,"source_reachability_excluding_mocked_callees":actual_source_closure,
               "transitive_predicate_and_call_ids":predicates,"execution_observation":"not-run-P05"}
        if cls == "ReadbackCPUControls":
            row["provider_disposition"] = "New provider entrypoints only; preserve old format_check and readback files. Missing/unqualified explicit provider must fail preparation visibly; never successful skip or replacement-only case."
            row["input_case"] = "Q03" if "q03" in method else "Q01"
            row["changed_reference"] = method == "test_three_rejects_changed_synthetic_reference"
            row["class_gate_anchor"] = {"path":TARGET,"line":104,"source":texts[TARGET].splitlines()[103]}
        else:
            row["provider_disposition"] = "Historical coordinator remains used directly; child/manifest/predecessor/candidate seams stay mocked exactly as in original run_seam."
        method_rows.append(row)

# Static default discovery inventory, including inherited methods and the only
# source-detected top-level setattr-generated suite. No imports are performed.
test_paths = sorted(p.relative_to(REPO).as_posix() for p in (REPO/"tests").glob("*.py"))
test_trees = {p:ast.parse((REPO/p).read_bytes(),filename=p) for p in test_paths}
module_paths = {Path(p).stem:p for p in test_paths}
class_defs, imports = {}, {}
for path, tree in test_trees.items():
    module = Path(path).stem
    imports[module] = {}
    for stmt in tree.body:
        if isinstance(stmt,ast.ClassDef):
            class_defs[(module,stmt.name)] = stmt
        if isinstance(stmt,ast.ImportFrom):
            mod = (stmt.module or "").removeprefix("tests.")
            if mod in module_paths:
                for alias in stmt.names:
                    imports[module][alias.asname or alias.name] = (mod, alias.name)


def resolve_class(module, name):
    if (module,name) in class_defs:
        return (module,name)
    return imports.get(module,{}).get(name)


def is_test_class(key, seen=None):
    seen = set() if seen is None else seen
    if key in seen or key not in class_defs:
        return False
    seen.add(key)
    for base in class_defs[key].bases:
        b = ast.unparse(base)
        if b in ("unittest.TestCase","TestCase"):
            return True
        resolved = resolve_class(key[0],b)
        if resolved and is_test_class(resolved,seen):
            return True
    return False


def inherited_methods(key, seen=None):
    seen = set() if seen is None else seen
    if key in seen or key not in class_defs:
        return {}
    seen.add(key)
    result = {}
    # These source classes have no conflicting test-bearing multiple inheritance.
    for base in reversed(class_defs[key].bases):
        resolved = resolve_class(key[0],ast.unparse(base))
        if resolved:
            result.update(inherited_methods(resolved,set(seen)))
    for n in class_defs[key].body:
        if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.name.startswith("test"):
            result[n.name] = (key,n)
    return result


suite_modules, suite_methods, imported_classes = [], [], []
for path in sorted(p for p in test_paths if fnmatch.fnmatch(Path(p).name,"test*.py")):
    module = Path(path).stem
    class_map = {name:(module,name) for mod,name in class_defs if mod==module and is_test_class((mod,name))}
    for alias,key in imports[module].items():
        if is_test_class(key):
            class_map[alias] = key
            imported_classes.append({"discovering_module":module,"alias":alias,"class_origin":list(key)})
    mids = []
    for alias,key in sorted(class_map.items()):
        node = class_defs[key]
        for name,(defined_key,method) in sorted(inherited_methods(key).items()):
            defining_path = module_paths[defined_key[0]]
            block = "".join((REPO/defining_path).read_text().splitlines(keepends=True)[method.lineno-1:method.end_lineno])
            mid = key[0]+"."+key[1]+"."+name
            row = {"id":mid,"discovered_via_module":module,"module_path":path,"class_alias":alias,
                   "source_defining_class":list(defined_key),"source_path":defining_path,"line":method.lineno,"end_line":method.end_lineno,
                   "function_line_block_sha256":digest(block.encode()),
                   "body_ast_sha256":digest(ast.dump(ast.Module(body=method.body,type_ignores=[]),include_attributes=False).encode()),
                   "class_decorators":[ast.unparse(x) for x in node.decorator_list],
                   "method_decorators":[ast.unparse(x) for x in method.decorator_list],
                   "generation":"declared-or-inherited-AST","execution":"not-run"}
            suite_methods.append(row); mids.append(mid)
    suite_modules.append({**binding(path),"default_module_name":module,"method_ids":mids,
                          "has_load_tests":any(isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)) and x.name=="load_tests" for x in test_trees[path].body)})

force_path = "tests/test_force_source.py"
force_raw = (REPO/force_path).read_text()
force_tree = test_trees[force_path]
generator = next(x for x in force_tree.body if isinstance(x,ast.FunctionDef) and x.name=="source_test")
generated = []
for corpus,extra,anchor in (("docs/language-design/force-v0.1/acceptance.json",False,214),
                            ("docs/language-design/force-v0.1/reviewed-acceptance.json",True,216)):
    data = json.loads((REPO/corpus).read_bytes())
    for case in {x["id"]:x for x in data["source_cases"]}.values():
        name = "test_"+case["id"]+"_"+case["name"].replace("-","_")
        mid = "test_force_source.ForceSourceCases."+name
        row = {"id":mid,"discovered_via_module":"test_force_source","module_path":force_path,"class_alias":"ForceSourceCases",
               "source_path":force_path,"line":generator.lineno,"end_line":generator.end_lineno,
               "generator_install_line":anchor,"generator_ast_sha256":digest(ast.dump(generator,include_attributes=False).encode()),
               "generation":"statically-expanded-source_test-with-frozen-JSON","corpus":binding(corpus),
               "case_id":case["id"],"case_name":case["name"],"extra":extra,"execution":"not-run"}
        suite_methods.append(row); generated.append(row)
        next(m for m in suite_modules if m["path"]==force_path)["method_ids"].append(mid)

# Inventory import-time dynamic hazards separately from calls inside methods.
class TopLevelHazards(ast.NodeVisitor):
    def __init__(self): self.rows=[]
    def visit_FunctionDef(self,n):
        for d in n.decorator_list:self.visit(d)
    visit_AsyncFunctionDef=visit_FunctionDef
    def visit_Lambda(self,n):pass
    def visit_ClassDef(self,n):
        for d in n.decorator_list:self.visit(d)
        for s in n.body:
            if not isinstance(s,(ast.FunctionDef,ast.AsyncFunctionDef)):self.visit(s)
    def visit_If(self,n):
        if ast.unparse(n.test) in ("__name__ == '__main__'","'__main__' == __name__"):return
        self.generic_visit(n)
    def visit_Call(self,n):
        name=ast.unparse(n.func)
        if name in ("setattr","exec","eval","globals","type") or name.endswith((".update",".append")):
            self.rows.append({"line":n.lineno,"callee":name,"expression":ast.unparse(n)})
        self.generic_visit(n)

hazards=[]
for path,tree in test_trees.items():
    if not fnmatch.fnmatch(Path(path).name,"test*.py"):continue
    visitor=TopLevelHazards();visitor.visit(tree)
    for row in visitor.rows:hazards.append({"path":path,**row})

all_paths = set(PYTHON_SOURCES + STATIC_INPUTS + test_paths)
inventory = [binding(p) for p in sorted(all_paths)]
source_table = {x["path"]:x for x in inventory}
original_manifest=json.loads((REPO/EXTERNAL).read_bytes())
prefix=original_manifest["dependencies_root"]+"/"
dependency_files=[{"relative_path":path[len(prefix):],"historical_absolute_path":path,**b}
                  for path,b in sorted(original_manifest["files"].items()) if path.startswith(prefix)]
external_inventory={"schema":"ontokin.c271.p05-dependency-inventory/1","source":binding(EXTERNAL),
    "historical_host_inventory":binding(HOST),"retained_dependency_file_count":len(dependency_files),
    "retained_dependency_files":dependency_files,"historical_runtime":original_manifest["runtime"],
    "reader_entry_roles":{key:original_manifest[key] for key in ("validator_entry","three_entry","three_package","gltf_loader_entry","module_loader","probe")},
    "scientific_and_process_constants":{key:original_manifest[key] for key in ("environment","limits","validator_version","three_version","validator_options","three_options","profile","scope")},
    "historical_slot_records":original_manifest["slots"],"external_boundaries":external_boundaries,
    "qualification_status":"No current-host closure observed or qualified by this worker; historical data retained as immutable provenance, never current attestation."}
loader_member = "c195-validation/receiving/tools/three_loader.mjs"
with tarfile.open(REPO / ARCHIVE) as archive:
    member = archive.getmember(loader_member)
    loader_raw = archive.extractfile(member).read()
loader_expected = next(x for x in dependency_files if x["relative_path"] == "tools/three_loader.mjs")
external_inventory["archive"] = binding(ARCHIVE)
external_inventory["inspected_loader_member"] = {"member":loader_member,"sha256":digest(loader_raw),"size_bytes":len(loader_raw),
    "archive_mode":oct(member.mode),"matches_historical_binding":digest(loader_raw)==loader_expected["sha256"] and len(loader_raw)==loader_expected["size_bytes"],
    "source":loader_raw.decode(),"predicate_note":"Resolve bare three, three/webgpu and three/tsl to fixed relative indexer-view/three paths; delegate other resolution. Keeping the exact archive-relative layout permits relocation without editing loader bytes.",
    "inspection":"Read one regular archive member in memory; no extraction, installation or JS execution."}

save("SOURCE-INVENTORY.json",{"schema":"ontokin.c271.p05-source-inventory/1","source_commit":COMMIT,"source_tree":TREE,
    "identity_authority":"Director-supplied reconciled repository identity; this worker computed file bytes/hashes and did not run Git.",
    "file_count":len(inventory),"files":inventory,"toolchain":{"python":sys.version,"executable":sys.executable,"platform":platform.platform()},
    "method":"Static filesystem reads + Python ast.parse; no project import or execution.",
    "full_prose_source_read_paths":PYTHON_SOURCES+[JS,"tools/static_tray_reader_v01/README.md",
        "docs/engineering/localized-repair-c271/runtime-recovery-p04/CURRENT-HOST-QUALIFICATION-PROPOSAL.md"],
    "nonclaim":"Whole default suite source is enumerated by AST; only the selected readback closure is substantively predicate-mapped."})
save("PREDICATES.json",{"schema":"ontokin.c271.p05-predicates/1","source_commit":COMMIT,"source_tree":TREE,
    "definition":"Every selected Python AST condition, comparison, boolean operation, assertion, rejection, loop, exception/context boundary, return, assignment and call is enumerated with original AST and source hash. Noncalled functions are retained as inspection context, not claimed executed.",
    "python_predicates":nodes,"python_calls":calls,"javascript_segments":js_records,
    "javascript_line_inventory":[{"line":i+1,"text":line.rstrip("\n"),"sha256":digest(line.encode())} for i,line in enumerate(js_lines)],
    "javascript_limit":"No JS AST parser is installed. Node is prohibited in P05. JavaScript anchors are exact manual syntax ranges and every original line hash, not a claimed parsed JS AST.",
    "execution":"not-run"})
save("METHOD-PREDICATE-MAP.json",{"schema":"ontokin.c271.p05-method-predicate-map/1","source_commit":COMMIT,"source_tree":TREE,
    "methods":sorted(method_rows,key=lambda x:x["original_default_discovery_id"]),"nodes":list(functions.values()),"edges":edges,
    "source_call_graph_limits":["Graph records source possibilities, not branch coverage or a future implementation.",
        "Arbitrary Python/JavaScript dispatch is not proven. All original raw call expressions remain separately addressable in PREDICATES.json.",
        "Mocked production callees are explicitly labelled; default coordinator seam execution cannot qualify those real callees.",
        "CPU audit defaults delivery_rules=None and baseline_right=None; optional layout/baseline branches are preserved but not exercised by Q01/Q03.",
        "Original test file module has historical decorator and path bindings. Proposed provider adaptation is design only; original source bytes are unchanged."],
    "original_file":source_table[TARGET],"future_implementation_hashes":None,
    "future_hash_reason":"No operational source implementation exists in this design-only phase; new hashes must be filled from the separately reviewed implementation, never invented."})
save("DEFAULT-DISCOVERY-INVENTORY.json",{"schema":"ontokin.c271.p05-static-default-discovery/1","source_commit":COMMIT,"source_tree":TREE,
    "command_as_source":["python","-B","-m","unittest","discover","-s","tests","-v"],
    "command_anchor":{"path":DRIVER,"line":308,"insert_B_at_lines":[301,302]},
    "method":"AST inventory plus source-derived static expansion of force source cases; no unittest discovery/import/execution.",
    "module_count":len(suite_modules),"method_occurrence_count":len(suite_methods),"unique_method_id_count":len({x['id'] for x in suite_methods}),
    "declared_and_inherited_count":len(suite_methods)-len(generated),"static_generated_count":len(generated),
    "modules":suite_modules,"methods":sorted(suite_methods,key=lambda x:(x["discovered_via_module"],x["id"])),
    "imported_TestCase_class_aliases":imported_classes,"top_level_dynamic_hazards":hazards,
    "load_tests_hooks":[m["path"] for m in suite_modules if m["has_load_tests"]],
    "limits":["Static inventory is not actual discovery, import success, assertion coverage, or test outcome.",
        "Runtime import failures can produce _FailedTest entries; skip decorators can depend on host paths; neither is evaluated here.",
        "Default module IDs use file stem because -s tests has no explicit -t; tests.<stem> is a separately recorded explicit-import alias for the seven focal methods.",
        "No dynamically assigned test names other than test_force_source.py L213-L216 were found by the stated top-level AST hazard scan; arbitrary import/decorator side effects are not proved impossible.",
        "Candidate implementation must regenerate static inventory and compare actual loader IDs and every method outcome; retain duplicates/import aliases and all newly added cases.",
        "No exclusion/filter/skip/xfail, aggregate-only substitution or replacement suite can close the actual full-routine gate."],
    "execution":"not-run"})
save("DEPENDENCY-INVENTORY.json",external_inventory)

checks={
    "target_method_count_is_seven":len(method_rows)==7,
    "target_mapping_is_bijective":len({x['original_default_discovery_id'] for x in method_rows})==7 and all(x['original_default_discovery_id']==x['proposed_default_discovery_id'] for x in method_rows),
    "every_graph_endpoint_exists":all(e['from'] in functions and e['to'] in functions for e in edges),
    "retained_dependencies_are_24":len(dependency_files)==24,
    "historical_runtime_bindings_are_10":len(original_manifest['runtime']['files'])==10,
    "historical_runtime_aliases_are_10":len(original_manifest['runtime']['aliases'])==10,
    "all_python_sources_parse":True,
    "all_test_modules_parse":True,
    "no_load_tests_hooks_found":not any(m['has_load_tests'] for m in suite_modules),
    "suite_method_ids_are_unique":len({x['id'] for x in suite_methods})==len(suite_methods),
    "old_C225_source_pins_unchanged":all(source_table[p]['sha256']==expected for p,expected in [
        (EXTERNAL,'21fd6bad8738ed51d4ced8036a0fcde5dd046823f55f71de52b9b81df659ccd5'),
        (ARCHIVE,'b1e54a6cfef133f7004b1988c90bc718fc954409843c2bcac3772d42e904a0c9'),
        (HOST,'2ed86412f09c74f5d3fb038f50e6417872b8eace0f89d7f168c79923efb14994'),
        (TARGET,'2f0abd812aa668b7abf9e249315acdb9c0fd175adb59672ab1c454679d494394'),
        (FORMAT,'e0d71482b9878fbdf9ca1287013756fc0f6b9df530864f5634b8863354a29447'),
        (JS,'156c988ffc478adafe59c495a07e0a48f5ac77c12829d85d147838578b523b4c')]),
    "loader_member_matches_historical_binding":external_inventory['inspected_loader_member']['matches_historical_binding'],
    "source_bytes_unchanged_during_analysis":all(binding(p)==source_table[p] for p in sorted(all_paths)),
}
save("STATIC-VALIDATION.json",{"schema":"ontokin.c271.p05-map-validation/1","checks":checks,"passed":all(checks.values()),
    "counts":{"source_files":len(inventory),"functions_scopes_and_boundaries":len(functions),"python_predicate_nodes":len(nodes),
              "python_call_nodes":len(calls),"javascript_segments":len(js_records),"graph_edges":len(edges),
              "target_methods":len(method_rows),"suite_modules":len(suite_modules),"suite_methods":len(suite_methods),"static_generated_methods":len(generated)},
    "scope":"Artifact consistency and static source identity only; not tests, runtime qualification, complete routine, integration or task closure.",
    "project_code_imports":0,"test_methods_executed":0,"node_starts":0,"ldd_starts":0,"dependency_installs":0,"native_starts":0,
    "commands_executed_by_inventory_program":[],"prior_static_attempt_failure":"Initial size-probe assumed tests/__init__.py existed; FileNotFoundError. Corrected to record absent namespace package file; no project code or test was executed."})
print(json.dumps({"passed":all(checks.values()),"methods":len(method_rows),"suite_modules":len(suite_modules),
                  "suite_methods":len(suite_methods),"generated":len(generated),"predicate_nodes":len(nodes),"call_nodes":len(calls)},sort_keys=True))
