#!/usr/bin/env python3
"""Add explicit source-preservation dispositions to the static P05 inventory."""
import hashlib
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
REPO=OUT.parent/'OntoKin'
def sha(b):return hashlib.sha256(b).hexdigest()
def save(p,d):(OUT/p).write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
graph=json.loads((OUT/'METHOD-PREDICATE-MAP.json').read_bytes())
predicates=json.loads((OUT/'PREDICATES.json').read_bytes())
proposed_python='prototypes/static_tray_v01/current_host_readback_v01.py'
proposed_js='prototypes/static_tray_v01/current_host_readback_v01.mjs'
proposed_preparer='tools/prepare_current_host_readback.py'

# Each group names source conditions and the precise destination obligation.
# Full atomic condition/call expressions are retained in PREDICATES.json.
GROUPS=[
 ('T00','tests/test_static_tray_readback_v01.py',1,29,'historical-runtime-selection',
  'Imports of original coordinator/supervisor/fixture helpers and three hardcoded historical NODE/DEPS/HOST paths. Preserve original source object; introduce new provider imports and explicit config interface only in the operational setup revision.',
  'same test module imports; new provider selected by documented config path and SHA-256; import guarded_run_process as run_process','Explicit operational binding differs; original supervisor remains unchanged and is delegated to once; no monkeypatch of historical globals.'),
 ('T01','tests/test_static_tray_readback_v01.py',30,74,'coordinator-seam-harness',
  'Temporary root cleanup, synthetic candidate files, fixed N01 row/job/probe, exactly one mocked start, alarm observations, patched manifest/check_file/prior_result/candidate/child seams, exclusive writer delegation and unlink fault after real removal.',
  'same ReadbackCoordinatorSeams.run_seam and nested helpers','No body change.'),
 ('T02','tests/test_static_tray_readback_v01.py',76,101,'coordinator-assertions',
  'Write failure and lost removal produce passed = False / state = UNKNOWN/pending marker; successor N02 raises Stop unresolved finalization. During child alarm = 0; successful finalization alarm > 0 and <= 30 s.',
  'same four test IDs/bodies','No body change; mocks remain mocks.'),
 ('T03','tests/test_static_tray_readback_v01.py',104,124,'cpu-class-lifecycle',
  'Historical availability decorator; explicit output root must be absent; otherwise temporary root; fresh supplemental-cpu manifest and absent unused-native-schedule; manifest build/verify; temporary cleanup.',
  'same class setup -> '+proposed_python+'::prepare_case_manifest/verify_case_manifest','Only explicit provider selection/decorator/setup and necessary teardown wiring may change; absent/unqualified provider fails visibly.'),
 ('T04','tests/test_static_tray_readback_v01.py',125,168,'shared-cpu-assertions',
  'Fresh case labels/stages; exact synthetic artifact+independent audit; passed audit; Q01 negative adds exactly .001 to left/base world_matrix[0][3] and explanatory scope. Job binds manifest/artifact/audit. One checker, 30,000 ms clock, child deadline started + 28 s, exact Node argv except final job path, Stop accepted only for negative. Probe assertions preserve cleanup/closed handles/artifact hash/validator version+pass/Three version/14 nodes / 12 meshes/expected pass/input preserved/matrix_0_3 finding.',
  'same ReadbackCPUControls.check_case; imported run_process explicitly aliases new provider.guarded_run_process','No body, constant, mutation, assertion or exception change. Guard owns pre/post validation under same Clock; every guard refusal including its own deadline failure is an unswallowable CurrentHostBindingError, distinct from Stop.'),
 ('T05','tests/test_static_tray_readback_v01.py',169,180,'original-method-identity',
  'Q01 positive, Q03 rotations positive, Q01 changed-reference negative; their exact call bodies remain. __main__ entry is explicit invocation, not default discovery.',
  'same three default-discovered IDs','No rename/move/replacement; namespace aliases recorded separately.'),
 ('F00','prototypes/static_tray_v01/format_check.py',20,34,'manifest-constants-and-aliases',
  'Historical schema/profile; maximum 12; host 30,000 / child 28,000 / cleanup 2,000 ms; GLB 8 MiB / result 4 MiB / log 4 MiB; --no-addons and 256 MiB old-space; exact clean environment; Khronos zero errors/warnings/max 1,000/no timestamps/no resources; Three tolerances 5e-6 / 1e-6, 14 nodes / 12 meshes / 0 animations; aliases resolved path/link kind/link target.',
  proposed_python+'::fixed constants and alias verifier','New manifest schema only; preserve scientific/resource/process constants and alias predicates.'),
 ('F01','prototypes/static_tray_v01/format_check.py',37,60,'manifest-build-inputs',
  'Resolve selected paths; new manifest+schedule; actual Node --version within 5 s and exact v24.22.1; dependency subtree walk rejects symlinks; bind every regular file, exact loader+Python+JS roles; exact validator/Three package versions.',
  proposed_python+'::prepare_case_manifest; '+proposed_preparer+'::qualified preparation','Use approved external current-host paths and separately named source roles. Existing old function remains byte-identical; Node version remains v24.22.1.'),
 ('F02','prototypes/static_tray_v01/format_check.py',61,96,'manifest-runtime-slots-write',
  'ldd within 5 s/check=True/not-found refusal; parse library paths; include executable and loader configuration from bounded HOST; runtime aliases and bytes/modes; exact C198 twelve slots; per-row paths/maximum starts 1/argv; schema/profile/scope/options/role paths; exclusive canonical manifest write+hash.',
  proposed_python+'::prepare_case_manifest; '+proposed_preparer+'::qualified preparation','New current-host observation/approval and source bindings replace historical host identity. Retain slot structure without authorizing native execution.'),
 ('F03','prototypes/static_tray_v01/format_check.py',99,135,'manifest-verification',
  'Bounded 1 MiB JSON; exact schema/profile/limits/environment/options/schedule; reader+Node versions; full actual dependency/source file set equality; file hashes/sizes/modes; HOST hash/size; executable inside closure; aliases; all executable roles in files; probe belongs to checkout; exactly 12 frozen slots and exact case/route/maxstarts/stage/result/argv.',
  proposed_python+'::verify_case_manifest','New schema/source roles/config and verified workspace derivation; preserve or strengthen every original verification predicate. Old verify_manifest remains untouched and rejects new schema.'),
 ('F04','prototypes/static_tray_v01/format_check.py',138,184,'coordinator-success-path',
  '30,000 ms Clock; initial rejected result; bounded outer alarm; verify lock-bound manifest; fresh stage+pending+reserved; accepted prior closure; bound job; record one start; suspend host alarm for supervisor; child 28,000 ms; check remaining clock; bound passed probe+accepted closure preservation+handles/cleanup; bounded inventory and accepted result.',
  'same format_check.run_check','No change. Four seam methods substitute the explicitly marked calls, so real verification/start paths are not qualified by those methods.'),
 ('F05','prototypes/static_tray_v01/format_check.py',185,221,'coordinator-errors-finalization',
  'BaseException retains error/state/process/failed probe hash; success finalization uses remaining same outer alarm, exclusive result, pending unlink, directory fsync; failure evidence allows no retry; uncertain write/removal recreates pending and failed marker; marker failure retained; elapsed>host forces UNKNOWN.',
  'same format_check.run_check','No change; preserve every rejection and uncertainty consequence.'),
 ('F06','prototypes/static_tray_v01/format_check.py',224,235,'predecessor-gate',
  'Only prior ordinal slots; pending or failed-finalization marker blocks; predecessor must pass, match slot+lock, have one checker, and pre-finalization elapsed <= 30,000 ms.',
  'same format_check.verify_predecessors','No change; exercised directly by two seam methods.'),
 ('S00','prototypes/static_tray_v01/supervisor.py',20,77,'clock-and-diagnostics',
  'Transaction ceiling 65,000 ms distinct from selected CPU 30,000 ms; cleanup 2,000 / poll 50 / TERM grace 500 ms; output 64 MiB / GLB 8 MiB / log 4 MiB / result 4 MiB; finite ASCII JSON; chunked SHA; Stop state/code/reason; Clock positive and <= 65,000 ms, monotonic deadlines/cancel and remaining-stage checks.',
  'same supervisor source','No change. Clock.stage is preserved context, not called by the three CPU helper paths.'),
 ('S01','prototypes/static_tray_v01/supervisor.py',79,121,'staging-and-reaping',
  'At most 2,048 filesystem entries; clock per entry; no staged symlinks, special files or multiple hardlinks; aggregate 64 MiB and GLB/JSON caps; process-group existence and nonblocking adopted-child reap.',
  'same supervisor inventory/group_exists/_reap','No change.'),
 ('S02','prototypes/static_tray_v01/supervisor.py',123,162,'mandatory-group-cleanup',
  'SIGTERM; grace <= 500 ms and outer end; poll/reap; SIGKILL; cleanup deadline <= 2,000 ms and outer end; group absent+wait+reaped receipt; final kill on overrun and failed cleanup, never success.',
  'same supervisor.terminate_group','No change; require actual process receipts where run, separately declared fault controls for unreachable branches.'),
 ('S03','prototypes/static_tray_v01/supervisor.py',165,226,'single-child-resource-control',
  'Private stage+explicit argv; Linux child subreaper required; deadline and cleanup reserve before Popen; one new-session child with closed stdin, piped outputs, exact cwd/env; immediate start counting; exclusive nonblocking logs; selector polling <= 50 ms; cancellation/deadline/inventory; cap logs at 4 MiB; wait, no lingering descendant, zero exit required.',
  'same supervisor.run_process','No change; nonzero expected negative still raises Stop with record.'),
 ('S04','prototypes/static_tray_v01/supervisor.py',227,258,'process-failure-and-handles',
  'Wrap errors; mandatory group cleanup; failed cleanup supersedes failure; close selector and all registered/remaining pipes/logs; handles_closed and return code/end/cancellation latency; cancellation completion <= 2,000 ms; durable process JSON; attach record to Stop and rethrow.',
  'same supervisor.run_process','No change.'),
 ('L00','prototypes/static_tray_v01/lock.py',41,68,'bounded-bound-inputs',
  'JSON regular non-symlink and byte limit, limit+1 read+strict parser; file SHA+size; repeated clock callback while hashing; reject size/kind/hash/mode changes.',
  'same lock.read_json/file_binding/check_file; called by new provider or preserved equivalent','No weakening; stronger admission is separately identified as new control.'),
 ('L01','prototypes/static_tray_v01/lock.py',168,258,'unchanged-native-lock-boundary',
  'Original native lock/source-host-platform-approval/Blender/source-budget/slot protections, including old manifest verifier. This is not a CPU-provider entry point.',
  'same lock.verify_lock','Preserve entire source; no new schema through old native verifier; do not claim this body ran under target CPU/seam methods.'),
 ('L02','prototypes/static_tray_v01/lock.py',275,357,'source-sealing-context',
  'build_lock requires clean tracked Git source and binds all prototype Python/JSON/JS, all OntoKin Python, reader5, fixtures/C198 files and all test_static_tray*.py; host/native/data/approval are separate.',
  'same lock.build_lock','Preserve entire native builder. New operational test setup necessarily has a new source identity and cannot reuse old exact lock/helper approval.'),
 ('C00','prototypes/static_tray_v01/canonical.py',74,99,'canonical-json',
  'Sorted compact finite ASCII canonical bytes; explicit Unicode/value/type/recursion error; strict bounded UTF-8 JSON, no duplicate keys or nonfinite constants; original diagnostic conversion.',
  'same canonical.json_bytes/strict_json','No change; producer geometry arithmetic/record validation remains separate unused context.'),
 ('X00','prototypes/static_tray_v01/transaction.py',29,43,'exclusive-durable-result',
  'Parent creation; canonical serialization; structured result <= 4 MiB; xb file creation; stream write/flush/fsync; directory fsync and descriptor close.',
  'same transaction.write_new','No change.'),
 ('X01','prototypes/static_tray_v01/transaction.py',108,142,'outer-alarm-coordination',
  'Reject ambient timer; arm minimum 1 microsecond until min(stage,host); restore old handler and disable timer; supervised child disables host alarm, preserves absolute remaining time, rearms only unspent positive allowance after cleanup.',
  'same transaction.alarm_until/supervised_process_clock','No change.'),
 ('X02','prototypes/static_tray_v01/transaction.py',144,156,'accepted-predecessor',
  'Required durable prior result; accepted matching slot; verify actual candidate; closure hash agrees; convert read/input errors to binding refusal.',
  'same transaction._prior_result','No change; mocked by target seams and not invoked by CPU helper.'),
 ('O00','prototypes/static_tray_v01/store.py',54,66,'candidate-immutability',
  'Inventory exact declared files plus closure.json; byte size and SHA of each; immutable file mode 0444.',
  'same store.verify_candidate','No change; mocked by target seams and not invoked by CPU helper.'),
 ('Y00','tests/test_static_tray_reader_v01.py',28,181,'independent-synthetic-fixture',
  'Fixed PARTS/FACES with outward face winding; hand-derived side/part dimensions and offsets; Q01/Q03 translations+unit exact-catalog quaternions; two fixed PBR materials; 24 float32 positions/normals and 36 uint16 indices per box; four-byte alignment and optional stride; explicit semantic owner/follow metadata;14 nodes / 12 meshes/two roots; embedded pack. Other cases/metadata/stride branches preserved.',
  'same frozen_rules/source_table/synthetic and nested add','No change. frozen_rules is not passed by the target CPU helper; other synthetic variants are whole-suite obligations.'),
 ('R00','tools/static_tray_reader_v01/expected.py',12,130,'independent-reference-mathematics',
  'Exact Fraction 5e-6 / 1e-6 tolerances; fixed materials, part IDs, side IDs; hand-transcribed Q01-Q05; finite decimal scalar domain; exact quaternion catalog/unit and signed-permutation rotation; exact dimensions/ranges/frames/metadata/cavity/gaps.',
  'same independent expected source','No producer import or oracle replacement. Q02/Q04/Q05 and expected_bounds are preserved outside the three target cases.'),
 ('G00','tools/static_tray_reader_v01/glb.py',16,100,'strict-bounded-input-decoding',
  '8 MiB GLB / 4 MiB JSON; duplicate/nonfinite/BOM/nesting > 32 rejection; exact int nonbool bounds and finite numerics; artifact regular non-symlink+cap; auxiliary JSON O_NOFOLLOW/O_NONBLOCK/O_CLOEXEC regular fd+cap.',
  'same independent glb helpers','No change; auxiliary path branch retained although target audit passes Q01/Q03 IDs.'),
 ('G01','tools/static_tray_reader_v01/glb.py',103,152,'container-and-packing',
  'GLB length/header/version/total; aligned bounded chunks exactly JSON then BIN; object asset 2.0; exactly embedded buffer no external extensions; byte length/padding; collection caps; deterministic JSON+BIN pack <= 8 MiB.',
  'same independent glb.parse/pack','No change.'),
 ('G02','tools/static_tray_reader_v01/glb.py',155,209,'actual-accessor-decoding',
  'Accessor index/shape, no sparse/extensions/unknowns; float32 VEC3 position/normal count 1..256; unsigned scalar index count 1..768; view embedded+allowed target/fields; positive lengths, component alignment, stride item..252 and explicit multiple of 4 / non-index; full bounds; finite decoded positions/normals; exact offsets.',
  'same independent glb.accessor','No change. JS separate cap 4,096 is also preserved; do not conflate these independent limits.'),
 ('R01','tools/static_tray_reader_v01/reader.py',16,114,'layout-metadata',
  'Complete exact delivery declaration/type validation when supplied; exact order/count/layout/material profile; fixed generator/scene metadata and no buffer/view/accessor names, including unused accessors; readable metadata failure retains measurements.',
  'same independent reader helpers','No change. delivery_rules=None returns before full-layout checking in target CPU audit; do not claim native delivery qualification.'),
 ('R02','tools/static_tray_reader_v01/reader.py',116,221,'rational-transforms-findings',
  'Finite Fraction conversion; vector cardinality; matrix vs TRS exclusivity and affine bottom row; world transform multiplication; cross/dot/sub; canonical serial/zero normalization; unique stable findings; threshold absolute/minimum comparisons; rigid orthogonality/determinant and matrix values with separate 5e-6 / 1e-6.',
  'same independent reader numerical helpers','No change.'),
 ('R03','tools/static_tray_reader_v01/reader.py',224,353,'document-graph-material',
  'Only finite static supported glTF fields; one selected scene; unit quaternion; validate all active/unused views/accessors; one triangle NORMAL/POSITION primitive per mesh; no shared/multiple/cyclic/unreachable graph occurrence; exact finite PBR values/types/name.',
  'same independent reader validate_document/scene_graph/material','No change.'),
 ('R04','tools/static_tray_reader_v01/reader.py',356,449,'box-surface-topology',
  'Actual extrema and positive side lengths; independent side/face/world-corner measurements; unique eight-corner weld within 5e-6; 36 indices; nondegenerate/unrepeated exterior triangles; strictly outward winding; normals 1e-6; two covering triangles per face sharing diagonal; 18 welded edges each two incident triangles; positive signed Fraction volume and propagated dimensional allowance.',
  'same independent reader.box_measurement','No change; actual vertices measured, accessor min/max never substitute.'),
 ('R05','tools/static_tray_reader_v01/reader.py',452,479,'tray-clearance',
  'Require all parts before tray summary; all four exact and minimum gaps; cavity width/depth/height; bottom gap 0; exact+minimum headroom; wall floor/rim; reject simultaneous positive overlap > 5e-6 across all axes for any structural-part pair.',
  'same independent reader.tray_measurements','No change.'),
 ('R06','tools/static_tray_reader_v01/reader.py',482,620,'audit-control-flow',
  'Bound fixture -> independent geometry -> actual GLB -> document/layout/metadata/graph; exact names/IDs, 14 nodes, 12 meshes and 2 materials; fixed roots/order/unique mesh ownership; exact extras/direct-leaf/mesh names; actual attributes/cardinality/all referenced; world+tray transforms, topology, material; complete right closure; exact baseline for Q04/Q05 or supplied baselines; errors produce findings; stable sorting and pass iff no findings; artifact/right hash and finite scope.',
  'same independent reader.audit','No change; no baseline supplied by Q01/Q03 target; baseline branches remain whole-reader requirements.'),
 ('I00','tools/static_tray_reader_v01/corrupt.py',16,21,'import-time-reader-integrity',
  'Reject independent reader __pycache__ or pyc/pyo before importing local helpers; only this independent directory added.',
  'same corrupt import boundary','Imported through target synthetic-support module, even though corrupt() is not called.'),
 ('I01','tools/static_tray_reader_v01/audit.py',11,59,'separate-isolated-cli',
  'CLI cache rejection, reader lock with five hashes, complete rules, 30-second alarm, output/code/finally semantics remain. Not called by the target three CPU tests; those call reader.audit directly.',
  'same independent audit CLI','Preserved outside target method runtime closure; no CLI/native claim from CPU methods.'),
 ('H00','docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py',23,35,'historical-exact-source-pins',
  'Historical absolute dependency/HOST destinations and all six SOURCE_HASHES remain exact; full original target/format/JS hashes prevent old helper accepting future modified setup.',
  'same C225 helper; separate '+proposed_preparer,'Old bytes unchanged; new provider has own source/config/version/approval, never rewritten historical pins.'),
 ('H01','docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py',39,124,'safe-static-installation-helpers',
  'Chunked hash; explicit require; reject every symlink ancestor; regular kind/hash/size/mode; full exact existing files+directories; host absent/exact; atomic report; renameat2 no-replace required.',
  'old helper unchanged; analogous explicit predicates in '+proposed_preparer,'Targets/source bindings versioned; no silent partial-state repair, no replacement or global alias change.'),
 ('H02','docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py',127,224,'historical-preparation-control-flow',
  'Safe report outside source/deps/HOST; clean actual Git/source pins; original version+runtime files 10 + aliases+host; 24 dependencies archive member duplicate/type/path/hash/size checks; exact old installation state and absence/exact consistency; dry-run/complete-exact return.',
  'old helper unchanged; new current-host preparation owns new identities','Every scientific/dependency/safe-extraction predicate preserved. Historical runtime/file/alias counts describe old closure; new closure must be complete and explicitly admitted, not arbitrarily forced to 10.'),
 ('H03','docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py',225,294,'installation-race-and-failure',
  'Pre-install receipt; Linux atomic no-replace; staged exclusive bytes/modes; revalidate staged payload; target ancestor/absence/same-device checks; no-replace sequential publication and durable in-progress receipts; exact after-state; failure preserves error/rollback receipts; remove only owned exact bytes or require reconciliation; cleanup of own staged root.',
  'old helper unchanged; separate current-host installer design','Unknown outcomes retained; new attempt only after explicit reconciliation; source-map publication is not installation.'),
 ('D00','tools/check_local.py',34,214,'isolated-driver-source-provenance',
  'Source-file inventory includes tests/tools/docs/fixtures/prototypes; excludes only existing generated/cache categories; rejects symlinks; real Git commit/tree metadata retained in separate repo; copied bytes inventory equals source; no source mutation.',
  'same driver with explicit current-host workspace-binding step','Only approved provider config/rebind additions; source-equivalence verified before manifests use workspace paths.'),
 ('D01','tools/check_local.py',295,374,'default-routine-inventory',
  'Default unit command retains -B -m unittest discover -s tests -v and all original core stages; optional roles unchanged.',
  'same build_plan and default discovery','Add preflight without filtering tests/classes/stages or substituting a new suite.'),
 ('D02','tools/check_local.py',394,571,'routine-outcomes-and-selection',
  'Per-step process/log/timeout; zero skip/expected-failure complete regression check; required reports; source+workspace preservation after every selected run; list-only no execution; invalid timeout refusal.',
  'same driver plus --readback-config and documented two env bindings','Absent/unqualified config fails before unit discovery; preserve raw per-method outcomes and namespace reconciliation; full routine later.')
]

groups=[]
for gid,path,start,end,category,meaning,destination,change in GROUPS:
    raw=(REPO/path).read_bytes();lines=raw.decode().splitlines(keepends=True)
    groups.append({'id':gid,'path':path,'line':start,'end_line':end,'source_sha256':sha(raw),
                   'segment_sha256':sha(''.join(lines[start-1:end]).encode()),'category':category,
                   'preserved_predicates':meaning,'proposed_destination':destination,'permitted_change':change,
                   'execution_status':'not-run-P05'})

dispositions=[]
target_roots={x for m in graph['methods'] for x in m['source_reachability_nodes']}
for node in graph['nodes']:
    current=node['id'];path=node.get('path');line=node.get('line',0);end=node.get('end_line',0)
    group_ids=[g['id'] for g in groups if g['path']==path and g['line']<=end and g['end_line']>=line]
    label='preserve-source-bytes-at-existing-path'
    destination=current
    if path=='prototypes/static_tray_v01/format_check.py' and current.endswith(('::build_manifest','::verify_manifest','::_alias')):
        label='historical-source-immutable; separate-versioned-equivalent-required'
        destination=proposed_python+'::'+('prepare_case_manifest' if current.endswith('::build_manifest') else 'verify_case_manifest' if current.endswith('::verify_manifest') else 'runtime_alias_validation')
    elif current.startswith('js:'):
        label='historical-source-immutable; copy-scientific-range-in-new-version'
        destination=proposed_js+'::'+current[3:]
        if current in ('js:JS05','js:JS06'):
            label='historical-source-immutable; explicit-schema-and-bootstrap-version-adaptation'
    elif path=='tests/test_static_tray_readback_v01.py' and current.endswith(('::<module>','::ReadbackCPUControls','::ReadbackCPUControls.setUpClass','::ReadbackCPUControls.tearDownClass')):
        label='original-Git-source-preserved; future-explicit-provider-imports-decorator-setup-teardown-only-diff'
    elif path=='docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py':
        label='historical-source-immutable; separately-versioned-preparer-controls'
        destination=proposed_preparer+'::separate-reviewed-contract-role'
    elif path=='tools/check_local.py':
        label='original-source-preserved; future-explicit-config-and-workspace-rebind-only-diff'
    elif current=='external:node-and-system-runtime':
        label='historical-runtime-records-preserved; new-pinned-build-and-current-host-closure-qualified-separately'
        destination='Explicitly bound new external runtime executable, system-library, loader and alias paths; original historical records and paths retain their meaning.'
    elif current=='external:khronos-three-loader':
        label='exact-24-retained-dependency-file-bytes-preserved; relocation-to-explicitly-bound-external-paths'
        destination='New task-specific dependency root with the same retained relative layout, all 24 exact hashes/sizes and unchanged loader bytes; no inference from version strings alone.'
    elif current=='external:python-stdlib-unittest':
        label='historical-interpreter-records-preserved; actual-current-interpreter-and-stdlib-qualified-separately'
        destination='Actual Python executable, standard-library and applicable package/platform closure in the new host inventory; no claim that historical runtime bytes or absolute paths are restored.'
    dispositions.append({'node_id':current,'source_groups':group_ids,'disposition':label,'proposed_destination':destination,
                         'in_target_source_reachability':current in target_roots,
                         'outside_target_call_closure_note':None if current in target_roots else 'Preserved inspection context; no claim this body is called by the original seven methods.',
                         'proposed_source_sha256':None,'proposed_hash_status':'unimplemented; bind actual candidate in next authorized phase'})

save('PRESERVATION-DISPOSITIONS.json',{'schema':'ontokin.c271.p05-preservation-dispositions/1',
 'groups':groups,'node_dispositions':dispositions,
 'new_python_interface':{'path':proposed_python,
   'prepare_case_manifest':'prepare_case_manifest(output, *, config_path, config_sha256, source_root, schedule_root) -> (manifest, manifest_sha256)',
   'verify_case_manifest':'verify_case_manifest(path, *, config_path, config_sha256, source_root, schedule_root)',
   'input_selection':['ONTOKIN_CURRENT_HOST_READBACK_CONFIG','ONTOKIN_CURRENT_HOST_READBACK_CONFIG_SHA256'],
   'guarded_run_process':'guarded_run_process(argv, *, stage, label, clock, stage_end, env=None, on_started=None, cancel_after_ms=None): validate declared case/job/config/source/runtime/dependency bindings before and after; delegate once to original supervisor.run_process with identical arguments and Clock; preserve process record and original exception as evidence',
   'driver_arguments':['--readback-config ABSOLUTE_FILE','--readback-config-sha256 EXPECTED_DIGEST'],
   'expected_digest_authority':'Frozen independently in the accepted execution plan; never derived only from untrusted selected config bytes.'},
 'new_js_path':proposed_js,'new_preparer_path':proposed_preparer,
 'schemas':{'contract':'ontokin.current-host-readback/0.1.0','manifest':'ontokin.current-host-readback-lock/0.1.0',
            'host':'ontokin.current-host-readback-host/0.1.0','result':'ontokin.current-host-readback-result/0.1.0'},
 'fixed_supported_node_version':'v24.22.1',
 'equivalence_acceptance':["Original seven default method IDs and method-line/body AST hashes unchanged; check_case and run_seam+nested bodies unchanged.",
  "Source-scoped setup/import/decorator/teardown diff must be explicit and independently reviewed. The CPU run_process import aliases the new guard; method/check_case bodies remain identical. Missing/unqualified provider fails, never skip/xfail.",
  "Old format checker, JS, C225 helper/pins and source/data dependencies remain byte-identical. Historical exact replay requires original full test source.",
  "Bind every new source file and exact preserved JS range; schema/runtime/bootstrap changes are enumerated. JS parser-based equivalence is a future gate, not claimed P05 evidence.",
  "Every original source predicate has either identical source or one-to-one new provider obligation; strengthened guards are additional, not substitutions.",
  "New whole-suite methods may be added; preserve the baseline default inventory plus explained approved additions, raw method outcomes, failure/skip/error/interruption accounting."],
 'status':'source-backed design mapping only; no implementation or qualification'})

# The original graph remains a graph of original source. A separate graph states
# proposed routing, avoiding any implication that the new adapter already exists.
graph['proposed_operational_graph']={
 'status':'unimplemented-design-only',
 'nodes':[
  {'id':'proposed:prepare_case_manifest','path':proposed_python,'source_sha256':None},
  {'id':'proposed:verify_case_manifest','path':proposed_python,'source_sha256':None},
  {'id':'proposed:guarded_run_process','path':proposed_python,'source_sha256':None},
  {'id':'proposed:CurrentHostBindingError','path':proposed_python,'source_sha256':None,'base_type':'RuntimeError','not_subclass_of':'supervisor.Stop'},
  {'id':'proposed:versioned_js_probe','path':proposed_js,'source_sha256':None}],
 'edges':[
  {'from':'tests/test_static_tray_readback_v01.py::ReadbackCPUControls.setUpClass','to':'proposed:prepare_case_manifest','kind':'explicit-future-setup-call'},
  {'from':'tests/test_static_tray_readback_v01.py::ReadbackCPUControls.setUpClass','to':'proposed:verify_case_manifest','kind':'explicit-future-setup-call'},
  {'from':'tests/test_static_tray_readback_v01.py::ReadbackCPUControls.check_case','to':'proposed:guarded_run_process','kind':'future-explicit-import-alias','unchanged_callsite_line':148},
  {'from':'proposed:guarded_run_process','to':'proposed:verify_case_manifest','kind':'before-and-after-under-same-existing-clock'},
  {'from':'proposed:guarded_run_process','to':'prototypes/static_tray_v01/supervisor.py::run_process','kind':'delegate-exactly-once-same-arguments-clock-deadline-environment-callback'},
  {'from':'prototypes/static_tray_v01/supervisor.py::run_process','to':'proposed:versioned_js_probe','kind':'declared-manifest-argv-no-runtime-fallback'}],
 'error_contract':[
  'All provider/preflight/postflight refusals use distinct CurrentHostBindingError(RuntimeError), never Stop; negative original helper cannot swallow them.',
  'A Stop raised by the guard own Clock.check is wrapped with timeout/state metadata; only a genuine delegated-supervisor Stop can be re-raised unchanged after successful bounded postflight.',
  'On any guard failure preserve actual observed process record, original supervisor exception as cause/evidence, source bindings and failed outcome; do not fabricate cleanup pass or overwrite prior results.',
  'The existing Clock includes guard time; no new full deadline, timeout extension, reset, retry or changed supervisor limits.'],
 'provenance':'Director CONTRACT.md and CONTRACT.json draft-002; actual future source hashes and reviewed diffs required before qualification.'}
save('METHOD-PREDICATE-MAP.json',graph)

callbacks=[
 {'id':'CB01','binding':['prototypes/static_tray_v01/format_check.py',164,170],
  'invoke_sites':[['prototypes/static_tray_v01/supervisor.py',189,190],['tests/test_static_tray_readback_v01.py',47,54]],
  'target':'prototypes/static_tray_v01/format_check.py::run_check.started',
  'semantics':'Increment checker_starts and exclusive write started.json; each seam mock calls the actual callback at test L50. Real supervisor calls after Popen.',
  'graph':'Explicit callback edges from run_check and mock child; callback -> transaction.write_new.'},
 {'id':'CB02','binding':['tests/test_static_tray_readback_v01.py',148,149],
  'invoke_sites':[['prototypes/static_tray_v01/supervisor.py',189,190]],
  'target':'lambda record: started.append(record)',
  'semantics':'Original CPU helper records actual starts; lambda Call AST at L149 remains owned by check_case in the predicate inventory. New guard forwards same callback once without substitution.',
  'graph':'Callback body call is a check_case-owned predicate/call; method closure includes it and original supervisor.'},
 {'id':'CB03','binding':['prototypes/static_tray_v01/transaction.py',115,118],
  'invoke_sites':[['prototypes/static_tray_v01/transaction.py',115,116]],
  'target':'prototypes/static_tray_v01/transaction.py::alarm_until.expired',
  'semantics':'SIGALRM handler raises TIMEOUT; explicit signal-handler graph edge; timer off during supervised child and cleanup.'},
 {'id':'CB04','binding':['tests/test_static_tray_readback_v01.py',55,70],
  'invoke_sites':[['prototypes/static_tray_v01/format_check.py',156,216]],
  'target':'run_seam.writer, run_seam.unlink, run_seam.child',
  'semantics':'patch side_effect and replacement callable targets are explicit nested-node edges; writer delegates original durable write; unlink calls real unlink before controlled failure.'},
 {'id':'CB05','binding':['prototypes/static_tray_v01/format_check.py',150,151],
  'invoke_sites':[['prototypes/static_tray_v01/lock.py',55,68],['prototypes/static_tray_v01/format_check.py',113,121]],
  'target':'supervisor.Clock.check or original default lambda: None',
  'semantics':'Production coordinator passes active clock; manifest and file checks preserve callback calls; seam patches suppress them. CPU class build/verify uses default noop callback before its per-case clock.'},
 {'id':'CB06','binding':['prototypes/static_tray_v01/canonical.py',83,99],
  'invoke_sites':[['prototypes/static_tray_v01/canonical.py',94,95]],
  'target':'strict_json.pairs and parse_constant rejection lambda',
  'semantics':'Duplicate-key function explicit graph edge; constant rejection expression captured in strict_json owner; stdlib JSON dispatch is external bound behavior.'},
 {'id':'CB07','binding':['tools/static_tray_reader_v01/glb.py',26,60],
  'invoke_sites':[['tools/static_tray_reader_v01/glb.py',45,46]],
  'target':'glb.pairs and glb.reject_constant',
  'semantics':'Both explicit graph edges from glb.strict_json.'},
 {'id':'CB08','binding':['tests/test_static_tray_readback_v01.py',33,34],
  'invoke_sites':'unittest cleanup after each seam; external standard-library implementation',
  'target':'TemporaryDirectory.cleanup',
  'semantics':'Cleanup registration is retained call at L34; temporary cleanup itself is standard-library external boundary, not project source.'},
 {'id':'CB09','binding':'source loops using map, iter, sorted, comprehension keys and private recursive visits',
  'invoke_sites':'PREDICATES.json exact AST call/loop/lambda expressions',
  'target':'expected.scalar, reader.number/serial/scene_graph.visit, synthetic.add, stream reads, sorting keys',
  'semantics':'All project-defined map/recursive/nested targets used by the original method closure have explicit/lexical edges. Lambda expressions and standard-library operations remain exact AST nodes in their owning function, not separate executable/coverage claims.'}
]
save('KNOWN-CALLBACKS.json',{'schema':'ontokin.c271.p05-known-callbacks/1','callbacks':callbacks,
 'review_finding_resolved':'RV-04: run_check.started previously lacked incoming graph edge; explicit binder/mock-invoker edges and durable-writer edge added. All four seam method closures now include callback predicates.',
 'status':'static-source-mapping; no callback executed in P05'})

save('SCOPED-EXCLUSIONS.json',{'schema':'ontokin.c271.p05-scoped-exclusions/1','rows':[
 {'id':'E01','scope':'external validator/Three/Node/OS/interpreter internals','treatment':'Exact dependency inventory and separately admitted host/runtime closure; owned integration predicates mapped; no claim every external internal algorithm is authored/audited.'},
 {'id':'E02','scope':'Other default-suite method bodies','treatment':'All 372 default modules and 4,741 static IDs enumerated with source/AST hashes and generated-method provenance; no transitive semantic audit of the remaining 4,734 methods and no execution result.'},
 {'id':'E03','scope':'Native transaction, source compiler and receiving/render pipelines','treatment':'Full lock/canonical/transaction/store modules inspected, hashes bound, relevant call sites mapped; only shared functions enter readback closure. Imported native/compiler bodies remain unchanged and are not made operational by the new CPU schema.'},
 {'id':'E04','scope':'Independent reader full-layout, Q02/Q04/Q05, baseline, CLI/corruption branches','treatment':'Original predicates inventoried/preserved with exact source; Q01/Q03 CPU helper uses delivery_rules=None and no baseline; its imported audit is reader.audit, not audit.py CLI. No claim those unused branches execute in the three CPU methods.'},
 {'id':'E05','scope':'Coordinator mock targets','treatment':'run_seam replaces format.check_file, verify_manifest, run_process, transaction._prior_result and store.verify_candidate. Their real source predicates are mapped but not behaviorally qualified by the seam cases.'},
 {'id':'E06','scope':'Static inventory vs runtime discovery','treatment':'No test import/discovery/Node/ldd run. Test namespace aliases, import failure, host-dependent decorators and arbitrary imported decorator side effects remain runtime reconciliation gates. Only the identified source-driven force method generator is statically expanded.'},
 {'id':'E07','scope':'JS AST equivalence','treatment':'No installed Python JS parser; Node prohibited. Every one of the 168 original line is hashed and 17 source syntax ranges are fully inspected. Actual new JS source/token/AST comparison is deferred to implementation; do not claim executable equivalence from P05 line inventory.'},
 {'id':'E08','scope':'Product source budgets','treatment':'100,000 operations / 30,000 ms preserved by GOAL and lock.ALL_LIMITS; this static/synthetic readback map does not execute a .ok source program or certify its budget compliance.'},
 {'id':'E09','scope':'Runtime restoration, full routine, integration and parent acceptance','treatment':'Not selected in P05. Historical failures unchanged; new current-host design cannot relabel old host recovery, create R03 pass, integrate main or close R04/R05.'}
], 'exclusions_do_not_waive_requirements':True})
print(json.dumps({'groups':len(groups),'node_dispositions':len(dispositions),'target_reachable_nodes':len(target_roots)},sort_keys=True))
