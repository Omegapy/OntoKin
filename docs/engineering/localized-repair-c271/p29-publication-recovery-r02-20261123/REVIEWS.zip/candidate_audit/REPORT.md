# Independent P29 candidate and evidence audit

**Verdict: pass for publication of the exact preserved candidate, with reuse of the recorded historical P29 evidence.** The data audit completed 71 checks with zero final failures. No product code was imported or executed. No Git index, candidate file, remote object or ref was changed by this reviewer.

## Candidate identity

The accepted publication archive is 38,143,260 bytes, SHA-256 `84b4c7781779a108bf7f6f991bafdcc06632289e4031135c6484c373e6ed114f`. Its 245 intended payloads match every path, byte count, SHA-256, Git blob ID, mode, and encoded content in `INTENT.json`; `INVENTORY.json` matches the same metadata. The outer archive contains exactly the expected 247 safe, unique entries, and every entry equals the extracted copy.

An independent in-memory Git-tree calculation starts from immutable parent `6c7f52a2ee627a382eea91ce26bf58bac4e6cccb` and reproduces base tree `6620a0ed0c2a580ea018fa5d8c9eb1010828f78f`. Applying the 245 intended files produces exactly `db30c29f24c154f378a5acac713385fc8bb44f52`. This calculation did not alter the repository index or object database.

## Historical evidence that can be reused

The exact publication production bytes match both final execution snapshots: 249,393 bytes, SHA-256 `71e837c31df06df7ce10262683c5d28a72bdb3c039f09b97eec58839f4121758`. The final adapter, fixture freeze, orchestrator and inherited cohort match their accepted hashes. All 116 frozen payload files match. All 127 source identities recorded by each final attempt match the preserved candidate or immutable-base inventories; both final attempts identify the same sources. The command argument arrays equal the frozen commands.

The complete evidence archive contains 33,403 regular files, representing 944,488,731 uncompressed bytes. Every regular file passes CRC, byte-count, SHA-256 and mode checks. The archive also preserves 14,436 directory metadata records, 45 symlink metadata records and three special-fixture metadata records, without materializing or following them. All six attempts and their results match the embedded reconciliation record.

The final focused evidence has all 116 expected case IDs, all passed, with empty forbidden-call lists. The final inherited evidence has the exact 481 method IDs, all passed, with no exclusions, errors or skips. These remain two separate cohorts because the focused suite nests some compatibility checks. They do not verify the unrelated original P28 reported 597-test result.

The preserved independent acceptance by `/root/scope_review` binds the same production, adapter, freeze, cohort, runtime records and prior reviews. Its referenced reports and read-set match their recorded hashes. The final save record precedes both final executions. This audit checks that chronology record; the Director owns current Library and remote-state reconciliation.

The historical execution environment records Python 3.12.14, Clang 22.1.3, and Linux 6.18.57 on x86_64 with glibc 2.41. Exact selected environment values and commands are retained in `AUDIT.json`. These are past-host observations, not assertions that old paths or installed inputs exist now.

## Preserved failures and limits

The discovery mismatch (372 declared versus 481 observed), the 40 mapping-retention setup failures, and the first focused RI-L08 metadata failure remain preserved with their original nonzero outcomes. Later passes do not relabel them. The full staged whitespace check remains exit 2 with its documented formatting disposition; only the scoped check passed.

All 11 protected Git blob IDs match the immutable parent tree; the candidate leaves all 943 protected source paths unchanged. This audit did not freshly recompute SHA-256 for every inherited base blob: the authentic clone was blob-filtered and initially lacked those bytes. The exact Git identities, preserved prior hash inventories and independent historical source review provide the bounded reuse chain. This is sufficient for publishing unchanged candidate bytes. It does not establish a fresh execution result on this host.

Claims about mocked receipts and in-memory object identity still rely on the reviewed adapter assertions that ran historically. No operational host qualification, H0/H1, original-seven/full routine, native target execution, main integration, branch deletion, parent closure or global process-state claim follows from this audit. N34 and historical N57 remain outside these runtime results.

My first audit filename filter omitted 13 letter-suffixed case IDs and therefore reported three audit-only failures. `AUDIT-attempt001.json` and its script are preserved. Correcting only that filter yielded all 116 cases and 71 passing data checks; no source, fixture, oracle or saved result changed.

## First remaining gate

Subject to the Director's current live-ref and ownership reconciliation, publish the exact accepted tree on the retained work branch using the observed expected parent and a conditional nonforce update. Read back the resulting commit and tree. Then complete the verified saved handoff and external receipt, and stop this recovery phase. A new implementation or behavioral rerun is not required by this unchanged-candidate audit.

Detailed machine-readable evidence: `AUDIT.json` and `FINAL-REVIEW.json`. Reproducible data audit: `audit_candidate.py`.
