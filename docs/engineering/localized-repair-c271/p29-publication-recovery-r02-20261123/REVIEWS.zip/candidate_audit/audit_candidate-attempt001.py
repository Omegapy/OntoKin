"""Read-only data audit of the preserved C271 P29 publication candidate.

This script neither imports project code nor executes behavioral checks. Git calls
read immutable objects only, with lazy fetching and optional locks disabled.
Output is confined to this reviewer's directory.
"""
from pathlib import Path, PurePosixPath
import base64
import collections
import datetime
import hashlib
import json
import os
import re
import stat
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/18d6675d4cbb/recovery')
OUT = ROOT / 'reviews/candidate_audit'
ACCEPTED = ROOT / 'accepted'
FILES = ACCEPTED / 'files'
AREA_PATH = 'docs/engineering/localized-repair-c271/required-images-p29'
AREA = FILES / AREA_PATH
ARCHIVE = ROOT / 'accepted-input/OntoKin/OntoKin_C271_P29_accepted_Publication_Recovery_2026-11-23.zip'
checks = []


def load(path):
    return json.loads(path.read_bytes())


def sha(data):
    return hashlib.sha256(data).hexdigest()


def ident(data):
    return {'bytes': len(data), 'sha256': sha(data)}


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def check(name, passed, **detail):
    checks.append({'check': name, 'passed': bool(passed), **detail})


def safe(name):
    p = PurePosixPath(name)
    return not p.is_absolute() and '..' not in p.parts and '.' not in p.parts and str(p) == name and '\\' not in name


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT / 'repo'), *args],
                                   env=dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0'))


def treehash(flat):
    root = {}
    for path, (mode, kind, oid) in flat.items():
        parts = path.split('/')
        d = root
        for part in parts[:-1]:
            d = d.setdefault(part, {})
        d[parts[-1]] = (mode, kind, oid)

    def walk(node):
        body = b''
        for name, child in sorted(node.items(), key=lambda x: x[0].encode() + (b'/' if isinstance(x[1], dict) else b'')):
            mode, oid = ('40000', walk(child)) if isinstance(child, dict) else (child[0], child[2])
            body += mode.encode() + b' ' + name.encode() + b'\0' + bytes.fromhex(oid)
        return hashlib.sha1(b'tree ' + str(len(body)).encode() + b'\0' + body).hexdigest()
    return walk(root)


OUT.mkdir(parents=True, exist_ok=True)
intent = load(ACCEPTED / 'INTENT.json')
inventory = load(ACCEPTED / 'INVENTORY.json')
items = intent['items']
listed = {row['path']: row for row in items}
stripped = {k: v for k, v in intent.items() if k != 'items'}
stripped['items'] = [{k: v for k, v in row.items() if k != 'content'} for row in items]
check('intent_inventory_exact_metadata_equality', stripped == inventory)
check('intended_payload_count_and_unique_paths', len(items) == len(listed) == 245)
actual_paths = {p.relative_to(FILES).as_posix() for p in FILES.rglob('*') if p.is_file()}
check('extracted_payload_exact_inventory', actual_paths == set(listed))
payload_rows = []
for path, row in listed.items():
    raw = (FILES / path).read_bytes()
    encoded = row['content'].encode('utf-8') if row['encoding'] == 'utf-8' else base64.b64decode(row['content'], validate=True)
    ok = (safe(path) and stat.S_ISREG((FILES / path).lstat().st_mode)
          and row['mode'] == '100644' and row['type'] == 'blob'
          and ident(raw) == {'bytes': row['bytes'], 'sha256': row['sha256']}
          and blob(raw) == row['git_blob'] and raw == encoded)
    payload_rows.append({'path': path, 'passed': ok, **ident(raw), 'git_blob': blob(raw), 'mode': row['mode']})
check('every_payload_bytes_sha256_git_blob_content_mode', all(row['passed'] for row in payload_rows), files=len(payload_rows), failures=[r['path'] for r in payload_rows if not r['passed']])
outer_identity = ident(ARCHIVE.read_bytes())
check('accepted_archive_exact_identity', outer_identity == {'bytes': 38143260, 'sha256': '84b4c7781779a108bf7f6f991bafdcc06632289e4031135c6484c373e6ed114f'})
with zipfile.ZipFile(ARCHIVE) as z:
    names = z.namelist()
    expected = {'INTENT.json', 'INVENTORY.json'} | {'files/' + p for p in listed}
    check('outer_safe_unique_exact_membership', len(names) == len(set(names)) == 247 and all(safe(n) for n in names) and set(names) == expected)
    failures = [n for n in names if z.read(n) != (ACCEPTED / n).read_bytes()]
    check('outer_crc_and_every_member_matches_extraction', not failures, failures=failures)

base = {}
for line in git('ls-tree', '-r', '-z', intent['expected_head']).split(b'\0'):
    if not line:
        continue
    header, path = line.split(b'\t', 1)
    mode, kind, oid = header.decode().split()
    base[path.decode()] = (mode, kind, oid)
base_tree = git('rev-parse', intent['expected_head'] + '^{tree}').decode().strip()
check('immutable_parent_tree_matches_intent', base_tree == intent['base_tree'])
check('independent_tree_algorithm_reproduces_base', treehash(base) == base_tree)
candidate = dict(base)
candidate.update({p: (r['mode'], r['type'], r['git_blob']) for p, r in listed.items()})
computed_tree = treehash(candidate)
check('independent_full_candidate_tree_matches_intent', computed_tree == intent['expected_tree'], computed=computed_tree, expected=intent['expected_tree'], base_paths=len(base), resulting_paths=len(candidate))

protected = load(AREA / 'PROTECTED-INPUTS.json')['files']
protected_source = load(AREA / 'PROTECTED-SOURCE-INVENTORY.json')['files']
check('all_eleven_protected_git_blobs_unchanged', len(protected) == 11 and all(base.get(r['path'], (None, None, None))[2] == r['git_blob'] and r['path'] not in listed for r in protected))
check('all_943_protected_source_paths_retained_without_override', len(protected_source) == 943 and all(r['path'] in base and r['path'] not in listed for r in protected_source))
source_identities = {r['path']: {'bytes': r['bytes'], 'sha256': r['sha256']} for r in protected_source + protected}
source_identities.update({p: {'bytes': r['bytes'], 'sha256': r['sha256']} for p, r in listed.items()})
freeze = load(AREA / 'controls/FREEZE.json')
companions = load(AREA / 'controls/COMPANIONS.json')
cohort = load(AREA / 'INHERITED-COHORT.json')
commands = load(AREA / 'controls/COMMANDS.json')
for r in companions['files']:
    source_identities.setdefault(r['path'], {'bytes': r['size_bytes'], 'sha256': r['sha256']})
freeze_failures = [r['path'] for r in freeze['files'] if ident((FILES / r['path']).read_bytes()) != {'bytes': r['size_bytes'], 'sha256': r['sha256']}]
check('all_116_frozen_payload_bytes_match', len(freeze['files']) == 116 and not freeze_failures, failures=freeze_failures)
check('exact_focused_adapter_freeze_runner_cohort',
      sha((AREA / 'controls/FREEZE.json').read_bytes()) == '69065e25738c81ab88cd502edc7069b3b005ba6ae4a67181c30c83f950aa54d5'
      and sha((FILES / 'tests/test_current_host_required_images_v01.py').read_bytes()) == '92ed832d2f78509cc60185b5bbfd9da0ff563f595561f5a2cc46e5ff515581a7'
      and sha((AREA / 'orchestration/run_verification.py').read_bytes()) == 'ef30c5505fe0941aa132a9fb92ed0b836300f8cb50077076a0e93c9b5e7a24e7'
      and sha((AREA / 'INHERITED-COHORT.json').read_bytes()) == '7aa9e1278419e6b4fd27afbc758d5dcea195a245960cd4c972d8102a34dcce77')
check('inherited_cohort_481_unique_no_exclusions', len(cohort['selected_test_ids']) == len(set(cohort['selected_test_ids'])) == 481 and cohort['exclusions'] == [])

verification = load(AREA / 'VERIFICATION.json')
attempts = load(AREA / 'VERIFICATION-ATTEMPTS.json')
evidence_zip = AREA / 'evidence/VERIFICATION-EVIDENCE.zip'
evidence_identity = ident(evidence_zip.read_bytes())
check('verification_archive_exact_identity', evidence_identity == {'bytes': 25817783, 'sha256': 'bae1b62fd3cc78e8cb886e08c4c2f7d76eaaf765e7f6374a394d5f0aa980d038'})
attempt_details = []
with zipfile.ZipFile(evidence_zip) as z:
    manifest_bytes = z.read('EVIDENCE-MANIFEST.json')
    manifest = json.loads(manifest_bytes)
    regular = manifest['files']
    dirs = manifest['directory_metadata']
    special = manifest['nonregular_fixture_metadata']
    names = z.namelist()
    paths = [r['path'] for r in regular + dirs + special]
    check('evidence_manifest_metadata_sections_unique_safe_disjoint', len(paths) == len(set(paths)) and all(safe(p) for p in paths))
    check('evidence_exact_regular_membership', len(names) == len(set(names)) == 33404 and set(names) == {'EVIDENCE-MANIFEST.json'} | {r['path'] for r in regular})
    nonregular_counts = dict(collections.Counter(r['kind'] for r in special))
    check('evidence_expected_metadata_counts', len(regular) == 33403 and len(dirs) == 14436 and len(special) == 48 and nonregular_counts.get('symlink') == 45, nonregular_counts=nonregular_counts)
    payload_failures = []
    uncompressed = 0
    for r in regular:
        raw = z.read(r['path'])
        zi = z.getinfo(r['path'])
        mode = zi.external_attr >> 16
        uncompressed += len(raw)
        if ident(raw) != {'bytes': r['bytes'], 'sha256': r['sha256']} or stat.S_IMODE(mode) != int(r['mode'], 8) or not stat.S_ISREG(mode):
            payload_failures.append(r['path'])
    check('every_evidence_regular_crc_bytes_hash_and_mode', not payload_failures, files=len(regular), uncompressed_bytes=uncompressed, failures=payload_failures)
    check('evidence_reconciliation_exactly_preserved', manifest['attempt_reconciliation'] == attempts)
    request_final = {}
    for summary in attempts['attempts']:
        label = summary['label']
        qraw = z.read(label + '/REQUEST.json')
        rraw = z.read(label + '/RESULT.json')
        q, result = json.loads(qraw), json.loads(rraw)
        check(label + ':result_identity_exit_and_unchanged_sources', sha(rraw) == summary['result_sha256'] and result['returncode'] == summary['returncode'] and result['source_changes_during_run'] == [])
        check(label + ':raw_stdout_stderr_bound', all(ident(z.read(label + '/' + stream + '.log')) == result[stream] for stream in ['stdout', 'stderr']))
        production = z.read(label + '/source-snapshot/current_host_inspection_v01.py')
        adapter = z.read(label + '/source-snapshot/test_current_host_required_images_v01.py')
        check(label + ':snapshot_hashes_bound', sha(production) == summary['production_sha256'] and ident(production) == q['sources']['prototypes/static_tray_v01/current_host_inspection_v01.py'] and ident(adapter) == q['sources']['tests/test_current_host_required_images_v01.py'])
        record = {'label': label, 'recorded_result': summary, 'request': ident(qraw), 'result': ident(rraw), 'python': q['runner_python'], 'selected_environment': q['selected_environment'], 'command': q['command'], 'source_count': len(q['sources'])}
        if label.startswith('final-'):
            request_final[label] = q
            source_failures = [p for p, identity in q['sources'].items() if source_identities.get(p) != identity]
            check(label + ':all_127_source_identities_match_candidate_or_base_inventory', len(q['sources']) == 127 and not source_failures, failures=source_failures)
            check(label + ':exact_frozen_command', q['command'] == commands['focused' if q['kind'] == 'focused' else 'inherited_command'])
            check(label + ':exact_runner_identity', {k: q['runner_identity'][k] for k in ['bytes', 'sha256']} == ident((AREA / 'orchestration/run_verification.py').read_bytes()))
            check(label + ':final_snapshots_equal_publication_payload', production == (FILES / 'prototypes/static_tray_v01/current_host_inspection_v01.py').read_bytes() and adapter == (FILES / 'tests/test_current_host_required_images_v01.py').read_bytes())
        elif label == 'baseline-inherited-fixed-retention':
            check('baseline_snapshot_matches_immutable_parent_git_blob', blob(production) == base['prototypes/static_tray_v01/current_host_inspection_v01.py'][2])
        if q['kind'] == 'inherited':
            runtime = json.loads(z.read(label + '/RUNTIME-INVENTORY.json'))
            check(label + ':runtime_inventory_count_and_report_match', len(runtime['actual_ids']) == summary['runtime_inventory_count'] and runtime['exact_match'] == summary['runtime_inventory_match'])
            if summary['tests_run']:
                per_method = json.loads(z.read(label + '/control-data/inherited/RESULTS.json'))
                counts = collections.Counter(row['status'] for row in per_method['methods'])
                check(label + ':all_inherited_method_results_reconciled', per_method['tests_run'] == summary['tests_run'] == len(per_method['methods']) and counts.get('passed', 0) == summary['passed'] and counts.get('failed', 0) == summary['failed'] and len(per_method['errors']) == summary['errors'] and len(per_method['skipped']) == summary['skipped'])
                if label.startswith('final-'):
                    check('final_inherited_exact_481_ids_and_passes', sorted(r['id'] for r in per_method['methods']) == sorted(cohort['selected_test_ids']) and all(r['status'] == 'passed' for r in per_method['methods']))
        else:
            prefix = label + '/control-data/required-images/'
            case_names = [n for n in names if n.startswith(prefix) and re.fullmatch(r'RI-[A-Z]\d{2}\.json', n[len(prefix):])]
            cases = [json.loads(z.read(n)) for n in case_names]
            check(label + ':focused_case_results_reconciled', len(cases) == 116 and sum(bool(c['passed']) for c in cases) == summary['passed'])
            if label.startswith('final-'):
                run_inputs = json.loads(z.read(prefix + 'RUN-INPUTS.json'))
                check('final_focused_all_116_ids_and_no_forbidden_calls', sorted(c['id'] for c in cases) == sorted(run_inputs['ids']) and all(c['passed'] and c['forbidden_calls'] == [] for c in cases))
                record['focused_groups'] = dict(collections.Counter(c['id'][3] for c in cases))
        attempt_details.append(record)
    q1, q2 = request_final['final-focused-004'], request_final['final-inherited-004']
    check('final_runs_identical_sources_and_python_identity', q1['sources'] == q2['sources'] and q1['runner_python'] == q2['runner_python'] and q1['command_executable'] == q2['command_executable'])
    env_record = json.loads(z.read('final-inherited-004/control-data/inherited/rtld/INPUTS.json'))
    historical_environment = {k: env_record[k] for k in ['python', 'executable', 'platform']}
    check('historical_python_and_linux_platform_recorded_consistently', historical_environment['python'] == q2['runner_python']['version'] and historical_environment['executable'] == q2['command_executable'] and historical_environment['platform'] == 'Linux-6.18.57-x86_64-with-glibc2.41')

acceptance = load(AREA / 'independent-review/FINAL-IMPLEMENTATION-ACCEPTANCE.json')
review_refs = [acceptance[k] for k in ['production', 'adapter', 'accepted_freeze', 'fixture_manifest', 'inherited_cohort', 'saved_before_final_execution']]
review_ref_failures = []
for r in review_refs:
    path = r['path'].removeprefix('repository/')
    if ident((FILES / path).read_bytes()) != {'bytes': r['bytes'], 'sha256': r['sha256']}:
        review_ref_failures.append(path)
check('independent_acceptance_candidate_bindings_exact', not review_ref_failures, failures=review_ref_failures)
for key in ['independent_prior_reviews', 'final_evidence_checks', 'final_read_set']:
    rows = acceptance[key] if isinstance(acceptance[key], list) else [acceptance[key]]
    for r in rows:
        p = AREA / 'independent-review' / Path(r['path']).name
        check('historical_review_ref:' + p.name, ident(p.read_bytes()) == {'bytes': r['bytes'], 'sha256': r['sha256']})
check('independent_acceptance_has_no_remaining_concrete_defects_or_new_design_blockers', acceptance['reviewer'] == '/root/scope_review' and acceptance['concrete_remaining_production_or_adapter_defects'] == [] and acceptance['new_design_blockers'] == [])
saved = load(AREA / 'FIXTURE-FREEZE-004-RECEIPT.json')
check('final_freeze_save_record_precedes_both_final_runs', all(saved['confirmed_at_utc'] < r['recorded_result']['started_at_utc'] for r in attempt_details if r['label'].startswith('final-')))

report = {
    'schema': 'ontokin.c271.p29-r02-independent-candidate-data-audit/1',
    'reviewer': '/root/candidate_audit',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Read-only archive, source-identity and historical-evidence audit; no product import, behavioral execution, Git/index or remote mutation.',
    'governing_read_set': [{'path': str(ROOT / 'live-instructions' / p), **ident((ROOT / 'live-instructions' / p).read_bytes())} for p in ['AGENTS.md', 'ROLE.md', 'docs/workflow/PROTOCOL.md', 'docs/workflow/HANDOFF.md', 'docs/workflow/EPHEMERAL-HOST.md']],
    'archive': {'path': str(ARCHIVE), **outer_identity},
    'candidate': {'parent': intent['expected_head'], 'base_tree': base_tree, 'expected_tree': intent['expected_tree'], 'computed_tree': computed_tree, 'payload_files': len(items), 'branch': intent['branch']},
    'evidence_archive': {**evidence_identity, 'manifest': ident(manifest_bytes), 'regular_files': len(regular), 'directory_metadata': len(dirs), 'nonregular_metadata': len(special), 'uncompressed_regular_bytes': uncompressed},
    'historical_environment': historical_environment,
    'attempts': attempt_details,
    'checks': checks,
    'check_counts': {'passed': sum(c['passed'] for c in checks), 'failed': sum(not c['passed'] for c in checks)},
    'payload_checks': payload_rows,
    'limits': ['Historical P29 execution evidence only; no new behavioral execution or environment qualification.', 'Protected source Git identity and non-overwrite checked. Fresh SHA256-to-base-byte checks need immutable base blobs because the authentic clone is blob-filtered.', 'Serialized mocked receipts and object-identity claims rely on the historically reviewed adapter assertions; no independent in-memory trace is asserted.', 'Original P28 implementation and reported 597 result remain unavailable and unverified.', 'No H0/H1, original-seven/full routine, native target launch, main integration, branch deletion, parent completion or current process state is proven.']
}
(OUT / 'AUDIT.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'output': str(OUT / 'AUDIT.json'), 'counts': report['check_counts'], 'failures': [c for c in checks if not c['passed']], 'candidate_tree': computed_tree}, indent=2))
