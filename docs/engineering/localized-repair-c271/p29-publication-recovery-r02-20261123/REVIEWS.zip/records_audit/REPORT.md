# P29 publication recovery: task and scope audit

Reviewer: `/root/records_audit`  
Assignment: independent, read-only audit of scope, task preservation, operative requirements and documentary publication boundaries.  
Verdict: **PASS for documentary scope and task preservation. Publication and saved-delivery gates remain separate and are not accepted by this report.**

## Inspected identities

- Governing main: `e43cc6c5777874101a40559e4058ad6826b07e51`.
- Retained branch baseline: `6c7f52a2ee627a382eea91ce26bf58bac4e6cccb`, tree `6620a0ed0c2a580ea018fa5d8c9eb1010828f78f`, branch `work/c271-missing-import-digest-control`.
- Accepted P29 candidate: expected tree `db30c29f24c154f378a5acac713385fc8bb44f52`; all 245 supplied file byte identities match their manifest SHA-256, byte length and Git blob entries; declared Git modes are retained in the scope comparison.
- Observed baseline record: PR274 draft/open/unmerged, issue273 open, no main integration lease. These remote facts come from the Director's supplied live observations and recorded responses; this worker made no GitHub call.
- Prior recovery ownership statement: comment `7119244517`, Director `c271-p29-recovery-f7b7b8b26729`, read from `recovery/evidence/branch-extra-1.json`. It describes the previous recovery session. It does not prove current ownership or prior process termination.

The audit produced 49 passing data assertions and no failed final assertion. Exact results are in [CHECKS.json](CHECKS.json), [SCOPE-IDENTITY-CHECKS.json](SCOPE-IDENTITY-CHECKS.json), [PAYLOAD-SCOPE.json](PAYLOAD-SCOPE.json), and [RECORD-DELTA.json](RECORD-DELTA.json).

## Operative parent requirements

C271 addresses the isolated missing actual source-import digest control in H22.02. It preserves the original observer behavior and C260 contract. Its later environment/inspection work supports mandatory verification; it does not replace the original task.

| Requirement | State retained | What remains operative |
| --- | --- | --- |
| R01 | done | Independently frozen missing-digest mutation, unchanged companions, exact expected refusal and construction evidence. |
| R02 | done | Actual positive and isolated-refusal observations through the source/binding/comparison interfaces; no qualified partial result. |
| R03 | not_done | Complete affected regression inventory, required routine local driver, applicable document/workflow checks and independent integration acceptance. Historical timeout, setup failures and unexecuted prerequisites remain evidence. |
| R04 | not_done | Later reviewed integration under verified expected-head ownership, actual-main verification and branch disposition with retained history. |
| R05 | not_done | Every phase's verified saved handoff and separate receipt; truthful parent closure only after all acceptance and integration gates. |

P01 remains `done`; P02 remains `in_progress`. The candidate parent status changes from the earlier missing-source `blocked` state to `in_progress` for explicitly selected new P29 work. `completion.merge_commit` remains null and `completion.branch_disposition` remains `retained`. Completing this recovery's partial delivery cannot complete R03, R04, R05 or C271.

## Authority and phase selection

Governing AGENTS supplies standing autonomous technical development authorization. ROLE assigns bounded phase and route selection to the Director. PROTOCOL sections 1, 3, 4 and 8 retain existing authorization and distinguish current user direction from historical handoff suggestions. The fully read R02 reconstruction option was a proposal at its own source boundary; it did not independently authorize work or revoke standing authority.

P27 adoption `P27-REQUIRED-IMAGES-001` accepts the finite design and explicitly identifies a later fixture-freeze/implementation phase. P29's [RECONSTRUCTION-DECISION.md](../../accepted/files/docs/engineering/localized-repair-c271/required-images-p29/RECONSTRUCTION-DECISION.md) records that new route before implementation. Its independent scope review supports the same interpretation and discloses that the original generic user prompt was supplied by the Director. This audit confirms consistency among those sources; it does not independently reconstruct that earlier conversation.

The current assignment is narrower: complete the interrupted publication and delivery only. New implementation, behavioral reruns, host preparation, H0/H1, original-seven/full-routine execution, main integration, deletion and parent closure are excluded. Stop at the verified recovery handoff; no second phase belongs in this thread.

## Exact change and preservation findings

The candidate has **240 additions and five modified files**, with no deletion represented in its payload. The only modified production file is `prototypes/static_tray_v01/current_host_inspection_v01.py`; the only added test adapter is `tests/test_current_host_required_images_v01.py`. The other four modifications are C271 REQUIREMENTS, PLAN, task.json and CURRENT. All remaining additions are under `docs/engineering/localized-repair-c271/required-images-p29/`. This matches the adopted P27 FUTURE-SURFACE and introduces no new dependency file, prior fixture edit, existing test edit, STATUS change or nested AGENTS override.

Both candidate Markdown task documents retain the **exact raw Git baseline bytes as a prefix**, then append the P29 route and technical-acceptance sections. Task JSON retains every baseline key. Its complete requirements, parent plan, checks, completion object, authorization, historical phases/deliveries, H0 constraints, reconciliation records and original-P28 recovery objects are value-identical. Only status, owner, next_action, session_phase and blocked_reason change; six P29-specific evidence/decision fields are added. The prior missing-source reason and source revision remain explicit in `p29_predecessor_state`.

CURRENT removes no key. It preserves the existing active/latest task, observed main, saved handoff/recovery objects and all historical boundaries, then appends the P29 boundary. Its changed fields are snapshot_date, next_action and boundaries, plus the new p29_reconstruction field. No parent requirement is promoted.

The supplied `branch-instructions` copies each contain one extra trailing LF relative to Git. An initial raw-blob check therefore failed for all four copies. Direct raw Git reads established exact substantive equality; JSON values match and the candidate Markdown prefixes preserve the actual Git bytes. The discrepancy and corrective comparison are retained in [BASELINE-COPY-COMPARISON.json](BASELINE-COPY-COMPARISON.json); no input was rewritten.

## Evidence meaning and unresolved history

P29 records a newly accepted `/0.1.5` finite required-image implementation: 116 focused obligations and 481 inherited methods passed on the held candidate, with no final failures, errors or skips. These are preserved historical P29 results, not tests executed by this recovery audit. Their numerical sum must not be used to validate the original P28 report of 597 tests. Nested inherited executions inside the focused suite are not additional distinct tests.

The candidate retains six attempts, including the incomplete inherited inventory, mapping-retention setup failure and RI-L08 recording-metadata failure. It preserves N34 and historical N57 as external source-completeness obligations. Finite metadata/control acceptance establishes neither operational host qualification nor the complete required routine. The candidate retains original P28's implementation as unverified, its reported 597 tests as `reported_unverified`, and original uploads with parent `360c80062e769230199602326fa8de25660df714`, null tree/commit and `replayed: false`. C270 ancillary-driver completion, global prior-process termination and P13 read-only difflib completion remain historical unknowns.

## Publication transport finding supplied during this audit

The Director reported that exact blob `9facb186ec11523163520323d83dc58fd68e829c` contains the 25,817,783-byte evidence archive. Its 34,423,712-character base64 request was rejected before transport with HTTP400 and a 16 MiB body-limit diagnostic; a subsequent blob lookup returned 404. The Director reported 209 other missing blobs not yet uploaded and was checking a permitted browser route. This worker did not independently observe that operation or the alternative's final outcome.

If the permitted alternative cannot publish the exact bytes, that is a concrete **publication capability blocker**. Retain the candidate, tree intent, exact failed operation and postattempt readback. Do not reduce, rewrite, split or substitute the accepted evidence inside the candidate merely to fit the failed endpoint. The negative lookup does not resolve historical P28 uploads or establish a universal absence of any object. The final handoff must say publication remains incomplete and preserve the exact recovery inputs. Any later attempt must reconcile live object/ref state first.

## Required documentary finish

Run the two governing checks against the actual documentary/published candidate: `python3 tools/chat_workflow.py check` and `python3 docs/maintenance/reorganization-2026-10-17/verify_reorganization.py`. Retain exact revision, environment, commands, outputs, failures and limits. Inspect whitespace/payload integrity as applicable. This worker did not run those commands; the Director owns final candidate and receipt validation. No new runtime check is justified by this publication-only audit.

The final ZIP must meet HANDOFF: required root files, both complete prompts, HOST-ENVIRONMENT.md, exact manifest and frozen repository inputs, safe paths and duplicate checks, fresh extraction and size/hash verification, independent package review, confirmed save/readback, and a separate actual receipt. A new host must reconstruct required inputs from durable identities, without treating previous paths or workers as resources. The saved receipt and matching terminal readbacks resolve only their named pending fields. Ownership is released only on actual completion or an explicit honest blocked disposition.

The minimal additive update is in [MINIMAL-DOCUMENTARY-UPDATE.md](MINIMAL-DOCUMENTARY-UPDATE.md). In particular, the accepted source snapshot still has the old P29 owner and P28 delivery/latest_handoff fields. Their preservation is valid source-time history, but a current recovery record must explicitly identify the new owner, actual publication/save state and remaining gate.

## Read coverage and limits

All four governing documents, all three selected repository skills, registry, worker template, OK-ENG-006 and OK-ENG-009 were read fully. P27 ADOPTION, DESIGN and FUTURE-SURFACE, the R02 reconstruction option and P29 selection/summary/phase/scope-review records were read fully. Full task/requirements/plan/CURRENT coverage spans **16,105 paragraph or JSON-leaf occurrences** across baseline and candidate. Exact duplicate prose was read once: 1,182 unique prose entries in 12 chunks; 2,181 unique atomic values were parsed, preserved with every source pointer and inspected through structural/identity comparisons. [READ-COVERAGE.json](READ-COVERAGE.json), [READ-NARRATIVES.json](READ-NARRATIVES.json), [READ-ATOMS.json](READ-ATOMS.json) and [SOURCE-READ-SET.json](SOURCE-READ-SET.json) identify this coverage precisely.

The audit did not reread every P27 supporting source excerpt, every control definition or all runtime logs. It does not replace the independent implementation/evidence audit, current GitHub reconciliation or final ZIP review. No product import, behavioral execution, Git index/ref write, remote write, canonical record edit or nested worker occurred. Scoped output files are the only authored changes. Read-only source access may hydrate Git objects through the existing clone; no index/ref mutation was requested. Learning capture is skipped because this is a read-only verification of existing rules and preserved evidence, with no new reusable technical finding.
