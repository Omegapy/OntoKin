# Minimal documentary update after the P29 publication gate

This is a proposed record change for the Director, not an applied patch or a future-success assertion. Preserve the accepted candidate at expected tree `db30c29f24c154f378a5acac713385fc8bb44f52` and all frozen evidence. The current recovery phase permits documentary publication and delivery only.

## If exact source publication succeeds

1. Read back the actual commit, parent, tree, branch and relevant PR/issue state. Bind the source to the preserved 245-file inventory. Record the real publication identity externally; never insert a commit's unknown future identity into itself.
2. Add one scoped publication/recovery record containing the current Director token, explicit supersession of prior recovery ownership, exact candidate/source identities, current failed/unknown operation dispositions, fresh documentary check results and the no-behavior-rerun limit. Preserve the prior owner and source-time phase objects intact through an explicit snapshot or exact immutable Git reference.
3. In task.json, retain all R01–R05 criteria and states, P01/P02 states, merge_commit:null and retained branch disposition. Add actual P29 implementation-publication and current documentary evidence references. Preserve the old P28 delivery object before assigning a P29 delivery object. Keep the accepted technical result distinct from the current recovery phase.
4. In CURRENT, preserve all displaced handoff/recovery objects and historical pending-delivery records. Update the active next action to the actual remaining delivery gate. After confirmed save/readback, set latest_handoff to the actual P29 ZIP and its receipt. Keep the old P28 latest_handoff in history; its `technical_implementation_verified:false` still describes P28.
5. Add a short append-only REQUIREMENTS/PLAN delivery section if those documents need a current human-readable boundary. State what was published, what is saved, which receipt resolves source-time pending fields, and that R03–R05 remain not_done. Do not edit old history to claim it always knew the new result.
6. Freeze, independently verify and save the final ZIP and matching prompts. Publish a separate receipt binding the actual saved identities, versions, bytes, hashes, source revision and package review. The receipt's own publication and later terminal evidence remain external until observed. Recheck documentary records for the receipt delta.
7. Publish/read back matching terminal disposition records only with observed identities. Release the current recovery owner, retain branch/draft PR/open issue and stop. The future `/0.1.5` plan-preparation/review step is a fresh-chat action, not work to begin now.

Do not rewrite accepted PHASE.json, SUMMARY.md, old receipts or immutable ZIPs solely to insert later identities. Do not promote R05 just because this session's partial ZIP is delivered. Do not change STATUS or acquire main integration ownership.

## If exact source publication remains blocked

Record the exact transport blocker and actual object/ref readbacks separately. Keep technical acceptance intact while saying source publication is incomplete. Preserve the full accepted candidate, original INTENT/INVENTORY, baseline reference, all unique recovery bytes and failed operation evidence in the verified partial handoff. Describe the concrete next attempt supported by available capability; do not repeat the same rejected endpoint blindly.

The live branch's old task record and the unpublished candidate's newer task record must be labelled separately. A saved candidate is not a published source commit. If the Director publishes an independent documentary checkpoint, later recovery must reconcile that changed branch and preserve its records before applying the candidate; the old expected parent is no longer an automatic write target. Never force the old tree onto a newer branch.

The partial-delivery receipt must retain original P28 uploads/test claims as unresolved, all parent requirements unchanged, no H0/H1/full-routine/main-integration claim, the actual ownership disposition and the stop. A concrete transport failure can justify a blocked recovery phase; a planned pause alone cannot.

## Required commands and guard against recursive receipts

Use `python3 tools/chat_workflow.py check` and `python3 docs/maintenance/reorganization-2026-10-17/verify_reorganization.py` for the actual source/receipt change. Report each as passed, failed or not_run with its exact candidate identity. Runtime outcomes are preserved evidence, not current executions.

Freeze the verified package once. Later actual save/receipt/terminal identities belong in separate records; a receipt-only commit needs no rebuilt ZIP. Rebuild only if the payload or executable recovery instructions materially change. This prevents an endless sequence of archives containing the next archive's receipt.
