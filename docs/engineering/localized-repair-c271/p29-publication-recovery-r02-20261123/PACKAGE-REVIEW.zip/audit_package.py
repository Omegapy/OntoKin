from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse, collections, hashlib, json, stat, zipfile

ROOT = Path('/workspace/scratch/18d6675d4cbb/recovery')
OWN = ROOT/'reviews/package_audit'
NAME = 'OntoKin_C271_P29_R02_Publication_Blocker_Handoff_2026-11-23.zip'
SCOPE = 'docs/engineering/localized-repair-c271/p29-publication-recovery-r02-20261123'
MAIN = 'e43cc6c5777874101a40559e4058ad6826b07e51'
BASE = '6c7f52a2ee627a382eea91ce26bf58bac4e6cccb'
ACCEPTED_SHA = '84b4c7781779a108bf7f6f991bafdcc06632289e4031135c6484c373e6ed114f'
BRANCH = 'work/c271-missing-import-digest-control'

parser=argparse.ArgumentParser();parser.add_argument('--attempt',default='attempt-01');args=parser.parse_args()
out=OWN/args.attempt
assert not out.exists(), 'Preserve prior audit attempts; choose a new attempt name.'
out.mkdir(parents=True)
checks=[]

def sha(b): return hashlib.sha256(b).hexdigest()
def gitblob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def check(label, value, detail=None):
    checks.append({'assertion':label,'passed':bool(value),'detail':detail})
    if not value: print('FAILED',label,detail)
def dump(path,data): path.write_text(json.dumps(data,indent=2)+'\n')
def walk(value):
    if isinstance(value,dict):
        yield value
        for x in value.values(): yield from walk(x)
    elif isinstance(value,list):
        for x in value: yield from walk(x)
    elif isinstance(value,str) and value.lstrip().startswith(('{','[')):
        try: parsed=json.loads(value)
        except (ValueError,TypeError): return
        yield from walk(parsed)

zip_path=ROOT/'out'/NAME
zip_bytes=zip_path.read_bytes()
pub=json.loads((ROOT/'evidence/DOC-PUBLICATION-VERIFIED.json').read_text())
expected_main={x['package_path']:x for x in json.loads((ROOT/'early-package/SOURCE-MANIFEST.json').read_text()) if x['package_path'].startswith('repository/')}
expected_branch={'branch-state/'+x['path']:x for x in pub['files']}
read_set=[]
for p in [zip_path, ROOT/'evidence/DOC-PUBLICATION-VERIFIED.json', ROOT/'early-package/SOURCE-MANIFEST.json']:
    b=p.read_bytes();read_set.append({'path':str(p),'bytes':len(b),'sha256':sha(b)})

with zipfile.ZipFile(zip_path) as z:
    names=z.namelist();regular=[]
    check('ZIP entry names are unique',len(names)==len(set(names)))
    for info in z.infolist():
        parts=PurePosixPath(info.filename)
        safe=not parts.is_absolute() and '..' not in parts.parts and '\\' not in info.filename and '\x00' not in info.filename
        safe=safe and not stat.S_ISLNK(info.external_attr>>16) and not (info.flag_bits&1)
        check('Safe archive entry: '+info.filename,safe)
        if not info.is_dir():regular.append(info.filename)
    check('ZIP CRCs pass',z.testzip() is None)
    manifest=json.loads(z.read('MANIFEST-SHA256.json'))
    rows=manifest['files'];by_path={x['path']:x for x in rows}
    check('Manifest paths are unique',len(rows)==len(by_path))
    check('Manifest exactly covers non-manifest payloads',set(by_path)==set(regular)-{'MANIFEST-SHA256.json'})
    check('Manifest explicitly excludes itself',manifest.get('self_excluded') is True)
    fresh=out/'fresh-extract';fresh.mkdir()
    assert all(c['passed'] for c in checks if c['assertion'].startswith('Safe archive entry: '))
    z.extractall(fresh)
    for row in rows:
        b=(fresh/row['path']).read_bytes()
        check('Fresh payload identity: '+row['path'],len(b)==row['bytes'] and sha(b)==row['sha256'])

required={'README-START-HERE.md','CHECKPOINT.json','HANDOFF.md','NEXT-TASK.md','RECOVERY-STATUS.md','PROMPT-1-CONTINUE.md','PROMPT-2-RECOVER.md','HOST-ENVIRONMENT.md','HISTORICAL-DEPENDENCIES.json','CURRENT-DEPENDENCIES.json','SOURCE-MANIFEST.json'}
check('All required root handoff files are present',required<=set(regular))
bindings=json.loads((fresh/'SOURCE-MANIFEST.json').read_text())
check('Source manifest paths are unique',len(bindings)==len({x['package_path']for x in bindings}))
check('Source manifest covers exact main and documentary snapshots',{x['package_path']for x in bindings}==set(expected_main)|set(expected_branch))
for row in bindings:
    p=row['package_path'];b=(fresh/p).read_bytes()
    check('Source binding byte identity: '+p,len(b)==row['bytes'] and sha(b)==row['sha256'] and gitblob(b)==row['git_blob'])
    if p in expected_main:
        check('Preserved governing-main binding: '+p,row==expected_main[p] and row['source_commit']==MAIN)
    else:
        e=expected_branch[p]
        check('Published documentary binding: '+p,row['source_commit']==pub['commit'] and row['source_path']==e['path'] and row['git_blob']==e['git_blob'] and row['sha256']==e['sha256'] and row['bytes']==e['bytes'])

accepted=fresh/'pending-candidate/OntoKin_C271_P29_accepted_Publication_Recovery_2026-11-23.zip'
b=accepted.read_bytes()
check('Embedded accepted archive is unchanged',len(b)==38143260 and sha(b)==ACCEPTED_SHA)
check('Original accepted inventory remains embedded',(fresh/'pending-candidate/INVENTORY.json').read_bytes()==(ROOT/'accepted/INVENTORY.json').read_bytes())
prompts=[]
for member,suffix in [('PROMPT-1-CONTINUE.md','Continue'),('PROMPT-2-RECOVER.md','Recover')]:
    p=ROOT/'out'/f'OntoKin_C271_P29_R02_{suffix}_2026-11-23.md';b=p.read_bytes()
    check('Standalone prompt exactly matches ZIP: '+member,b==(fresh/member).read_bytes())
    prompts.append({'file_name':p.name,'bytes':len(b),'sha256':sha(b),'matching_zip_member':member})

cp=json.loads((fresh/'CHECKPOINT.json').read_text())
check('Checkpoint binds the published source and base',cp['source_commit']==pub['commit'] and cp['source_tree']==pub['tree'] and cp['source_parent']==BASE and cp['documentary_source_published'] is True)
check('Checkpoint preserves original accepted tree',cp['candidate_expected_tree']=='db30c29f24c154f378a5acac713385fc8bb44f52')
check('Parent and candidate remain unfinished',cp['parent_complete'] is False and cp['candidate_published'] is False and cp['parent_status']=='blocked')
check('Phase delivery remains pending at immutable freeze',cp['phase_complete'] is False and 'follow this immutable freeze' in cp['source_time_delivery_state'])
check('Parent requirement statuses preserved',cp['requirements']=={'R01':'done','R02':'done','R03':'not_done','R04':'not_done','R05':'not_done'})
check('Parent plan statuses preserved',cp['parent_plan']=={'P01':'done','P02':'in_progress'})
check('Branch/main/PR/issue boundaries retained',cp['branch']==BRANCH and cp['observed_main']==MAIN and cp['main_lease_held'] is False and cp['main_integration'] is False and cp['pr_state']=='draft_open_unmerged' and cp['issue_state']=='open')
check('Behavioral work was not rerun',cp['behavioral_tests_this_recovery']==0 and cp['runtime_changes_this_recovery']==0)
check('Active package auditor accurately recorded at freeze','/root/package_audit' in json.dumps(cp['current_workers']))
check('Original P28 report remains unverified',cp['original_p28_implementation_verified'] is False and cp['original_p28_597_test_report']=='reported_unverified')

scope=fresh/'branch-state'/SCOPE
raw=json.loads((scope/'REMOTE-BLOB-RECONCILIATION.json').read_text())
counts=collections.Counter()
for x in raw['records']:
    c=x.get('response',{}).get('error_code')
    counts['known_absent' if c=='NOT_FOUND' else ('readable_exists' if x.get('isError') is False else 'existence_unknown')]+=1
check('Independent remote classification equals corrected counts',dict(counts)=={'known_absent':166,'existence_unknown':43,'readable_exists':4})
disp=json.loads((scope/'REMOTE-BLOB-DISPOSITION.json').read_text())
check('Corrected disposition matches raw read outcomes',disp['availability_counts']==dict(counts) and disp['total']==213)
check('Corrected disposition binds preserved raw responses',disp['raw_response_file_sha256']==sha((scope/'REMOTE-BLOB-RECONCILIATION.json').read_bytes()))
block=json.loads((scope/'PUBLICATION-BLOCKER.json').read_text())
check('Size blocker remains tied to exact large archive',block['blob']=='9facb186ec11523163520323d83dc58fd68e829c' and block['bytes']==25817783 and block['sha256']=='bae1b62fd3cc78e8cb886e08c4c2f7d76eaaf765e7f6374a394d5f0aa980d038' and block['post_attempt_blob_lookup']=='404')
check('Unknown existence is retained in blocker',block['unknown_existence_unique_candidate_blobs']==43 and block['known_absent_unique_candidate_blobs']==166 and block['other_known_absent_unique_candidate_blobs']==165)
check('Historical dependencies are retained byte-exact',(fresh/'HISTORICAL-DEPENDENCIES.json').read_bytes()==(ROOT/'early-package/HISTORICAL-DEPENDENCIES.json').read_bytes())
snapshot=json.loads((fresh/'recovery-evidence/EARLY-SNAPSHOT-RECHECK.json').read_text())
snap_nodes=[x for x in walk(snapshot) if 'exact_equal' in x]
check('Four early ZIP branch snapshots remain exact',len(snap_nodes)==4 and all(x['exact_equal'] is True for x in snap_nodes))

readback=json.loads((fresh/'recovery-evidence/DOC-READBACK.json').read_text())
nodes=list(walk(readback))
refs=[x for x in nodes if x.get('ref')=='refs/heads/'+BRANCH and isinstance(x.get('object'),dict)]
check('Preserved GitHub readback confirms source branch ref',bool(refs) and all(x['object'].get('sha')==pub['commit']for x in refs))
main_refs=[x for x in nodes if x.get('ref')=='refs/heads/main' and isinstance(x.get('object'),dict)]
check('Preserved GitHub readback confirms unchanged main',bool(main_refs) and all(x['object'].get('sha')==MAIN for x in main_refs))
commit_nodes=[x for x in nodes if x.get('sha')==pub['commit'] and isinstance(x.get('files'),list) and isinstance(x.get('commit'),dict)]
check('Preserved GitHub readback includes source commit changed-file identities',bool(commit_nodes))
for c in commit_nodes[:1]:
    check('Readback source tree and parent match',c['commit']['tree']['sha']==pub['tree'] and [x['sha']for x in c['parents']]==[BASE])
    actual={x['filename']:x['sha'] for x in c['files']}
    expected={x['path']:x['git_blob']for x in pub['files']}
    check('Readback changed-file identities match every published documentary file',actual==expected)
    check('Readback has no deletions or runtime changes',all(x['status'] in ['added','modified'] and (x['filename'].startswith(SCOPE+'/') or x['filename'] in ['docs/workflow/CURRENT.json','docs/workflow/tasks/C271/task.json','docs/workflow/tasks/C271/PLAN.md','docs/workflow/tasks/C271/REQUIREMENTS.md'])for x in c['files']))

final_checks=json.loads((fresh/'recovery-evidence/DOCUMENTARY-FINAL-CHECKS.json').read_text())
executions=[x for x in walk(final_checks) if 'command' in x and 'exit_code' in x]
check('Final workflow, documentation and whitespace executions passed',{x.get('name')for x in executions}=={'DOCUMENTARY-FINAL-WORKFLOW','DOCUMENTARY-FINAL-DOCUMENTATION','DOCUMENTARY-FINAL-WHITESPACE'} and len(executions)==3 and all(x['exit_code']==0 for x in executions))
check('Workflow log confirms 12 tasks','Workflow structure passed (12 tasks).' in (fresh/'recovery-evidence/DOCUMENTARY-FINAL-WORKFLOW.stdout').read_text())
doc=json.loads((fresh/'recovery-evidence/DOCUMENTARY-FINAL-DOCUMENTATION.stdout').read_text())
check('Documentation log confirms required sources and sections',doc['failures']==[] and doc['sources_verified']==29 and doc['sections_verified']==233)

texts={n:(fresh/n).read_text()for n in required if n.endswith('.md')}
check('Final narrative source substitutions are complete',all('@@SOURCE_COMMIT@@' not in x for x in texts.values()))
check('Narratives preserve one-phase fresh-chat stop and prior-read reconciliation',all('fresh main chat' in texts[n] and ('first unmet gate' in texts[n] or 'first unmet' in texts[n]) and 'before' in texts[n] and 'stop' in texts[n] for n in ['PROMPT-1-CONTINUE.md','PROMPT-2-RECOVER.md']))
check('Next action preserves later history and forbids reset','every later documentary/receipt commit' in texts['NEXT-TASK.md'] and 'Never reset the branch' in texts['NEXT-TASK.md'])
check('Unknown existence is visible in current reader-facing status','43' in texts['HANDOFF.md'] and 'existence unknown' in texts['HANDOFF.md'] and 'Existence remains unknown' in texts['RECOVERY-STATUS.md'])
check('Receipt remains external at freeze','cannot include its future save receipt' in texts['RECOVERY-STATUS.md'] and 'DELIVERY.json' in texts['RECOVERY-STATUS.md'])
check('Online and disposable-host boundaries are explicit','different, disposable execution host' in texts['README-START-HERE.md'] and 'complete offline repository backup' in texts['README-START-HERE.md'])

failed=[x for x in checks if not x['passed']]
report={'schema':'ontokin.c271.p29-r02-independent-package-review/1','reviewer':'/root/package_audit','reviewed_at_utc':datetime.now(timezone.utc).isoformat(),'status':'passed' if not failed else 'changes_required','passed_assertions':len(checks)-len(failed),'failed_assertions':len(failed),'mandatory_findings':failed,'package':{'file_name':NAME,'bytes':len(zip_bytes),'sha256':sha(zip_bytes),'payloads':len(rows),'source_bindings':len(bindings)},'source':{'commit':pub['commit'],'tree':pub['tree'],'parent':BASE,'main':MAIN},'prompts':prompts,'scope':'Independent frozen-package structure, fresh extraction, manifest/hash/source binding, exact accepted archive, prompt parity and recovery-boundary review.','limits':['Saved Library readback and terminal receipt publication occur afterward and are not verified by this local frozen-package audit.','GitHub identity checks use the preserved postpublication tool readback; this auditor made no separate network requests.','The unchanged accepted archive is bound by its independently rechecked complete ZIP hash; the prior 245-payload/33,403-evidence-file audit and behavioral tests were not repeated.','Historical unknown operations and 43 unknown remote object-existence results remain unknown.'],'parent_complete':False,'candidate_published':False,'behavioral_tests':0,'attempt':args.attempt}
dump(out/'ASSERTIONS.json',checks);dump(out/'READ-SET.json',read_set);dump(out/'REVIEW.json',report)
dump(OWN/'FINAL-REVIEW.json',report)
summary=f"# Independent final package review\n\nResult: **{report['status']}**. {report['passed_assertions']} assertions passed; {report['failed_assertions']} failed.\n\nPackage: `{NAME}`\n\n- Bytes: `{len(zip_bytes)}`.\n- SHA-256: `{sha(zip_bytes)}`.\n- Payloads: `{len(rows)}`; source bindings: `{len(bindings)}`.\n- Documentary source: `{pub['commit']}`; tree: `{pub['tree']}`.\n\nThe archive was freshly extracted into this review's isolated directory. Every manifest payload, every main/documentary source binding, the unchanged accepted ZIP, and both standalone prompts were checked. Recovery boundaries and the corrected 166 absent/43 unknown/4 readable outcomes were checked against preserved evidence.\n\nLibrary save/readback and receipt/terminal publication follow this review. No behavior tests, network requests, repository edits or remote mutations occurred. C271 remains open and the accepted implementation remains unpublished.\n\nDetailed assertions: `{args.attempt}/ASSERTIONS.json`.\n"
if failed:summary+='\n## Mandatory findings\n\n'+'\n'.join('- '+x['assertion']+': '+str(x['detail'])for x in failed)+'\n'
(OWN/'REPORT.md').write_text(summary)
print(json.dumps(report,indent=2))
