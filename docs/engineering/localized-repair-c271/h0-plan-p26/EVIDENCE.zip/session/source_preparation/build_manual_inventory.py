#!/usr/bin/env python3
"""Construct the P06 source document manually; never import project code."""
from pathlib import Path, PurePosixPath
import ast
import hashlib
import json
import os
import stat
import subprocess
import sys
from datetime import datetime, timezone

BASE = Path("/workspace/scratch/cf652064a9a1")
ROOT = BASE / "frozen-source"
OUT = BASE / "session/source_preparation"
COMMIT = "ed2fc453042a9f0bc4808c2aea7f015baf1ff73e"
TREE = "de3bd4fa567c4aeb11364e79d99e646dfde81659"
SCHEMA = "ontokin.current-host-readback-source/0.1.0"
EXPECTED_TREES = ("ontokin", "tests", "prototypes/static_tray_v01", "tools/static_tray_reader_v01")
EXPECTED_OPTIONAL = ("prototypes/__init__.py", "tools/__init__.py", "tests/__init__.py")
EXPECTED_FILES = (
    "tools/check_local.py", "tools/prepare_current_host_readback.py", "tools/storage_identity.py",
    "tools/force-agent-verification-requirements.txt", "tools/native-reader-verification-linux-cp312.lock", "pyproject.toml",
    "docs/engineering/static-tray-mapping-c198/CONTROLS.json",
    "docs/engineering/static-tray-qualification-c199/EXTERNAL-INPUTS.json",
    "docs/engineering/localized-repair-c271/current-host-p05/CONTRACT.md",
    "docs/engineering/localized-repair-c271/current-host-p05/CONTRACT.json",
    "docs/engineering/localized-repair-c271/current-host-p05/ADOPTION.json",
    "docs/engineering/localized-repair-c271/current-host-p05/mapping/MAP-EVIDENCE.zip",
)
ENV = {
    "PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8", "TZ": "UTC",
    "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": os.devnull, "GIT_TERMINAL_PROMPT": "0",
    "GIT_ATTR_NOSYSTEM": "1", "GIT_OPTIONAL_LOCKS": "0", "GIT_NO_REPLACE_OBJECTS": "1",
    "GIT_NO_LAZY_FETCH": "1", "GIT_CEILING_DIRECTORIES": str(ROOT.parent),
}
OUT.mkdir(parents=True, exist_ok=True)
commands = []

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False).encode("ascii")

def save_json(name, value, canonical_bytes=False):
    raw = canonical(value) if canonical_bytes else (json.dumps(value, indent=2, ensure_ascii=True) + "\n").encode()
    path = OUT / name
    with path.open("xb") as stream:
        stream.write(raw)
    return path

def identity(info):
    return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink, info.st_size, info.st_mtime_ns, info.st_ctime_ns)

def absolute(path):
    assert path.is_absolute() and str(path) == str(Path(path)) and ".." not in path.parts
    for item in (path, *path.parents):
        if item.exists() or item.is_symlink():
            assert not stat.S_ISLNK(item.lstat().st_mode), str(item)
    return path

def bind(path):
    absolute(path)
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1, str(path)
        digest = hashlib.sha256()
        blob = hashlib.sha1(("blob " + str(before.st_size) + "\0").encode("ascii"))
        size = 0
        while True:
            chunk = os.read(fd, 1024 * 1024)
            if not chunk:
                break
            size += len(chunk)
            digest.update(chunk)
            blob.update(chunk)
        assert size == before.st_size and identity(before) == identity(os.fstat(fd)) == identity(path.lstat()), str(path)
        return {"sha256": digest.hexdigest(), "size_bytes": size, "mode": oct(stat.S_IMODE(before.st_mode))}, blob.hexdigest()
    finally:
        os.close(fd)

def git(args, name):
    argv = ["git", "-c", "core.fsmonitor=false", "-C", str(ROOT), *args]
    result = subprocess.run(argv, env=ENV, capture_output=True, check=False, timeout=60)
    (OUT / (name + ".stdout")).write_bytes(result.stdout)
    (OUT / (name + ".stderr")).write_bytes(result.stderr)
    commands.append({"argv": argv, "environment": ENV, "exit_code": result.returncode,
                     "stdout": name + ".stdout", "stderr": name + ".stderr"})
    assert result.returncode == 0, (argv, result.stderr.decode(errors="replace"))
    return result.stdout

def source_state(suffix):
    top = git(["rev-parse", "--show-toplevel"], "git-top-" + suffix).decode().strip()
    head = git(["rev-parse", "--verify", "HEAD^{commit}"], "git-head-" + suffix).decode().strip()
    tree = git(["rev-parse", "--verify", COMMIT + "^{tree}"], "git-tree-" + suffix).decode().strip()
    dirty = git(["status", "--porcelain=v1", "--untracked-files=no"], "git-status-" + suffix)
    extra = git(["ls-files", "--others", "--exclude-standard", "-z"], "git-untracked-" + suffix)
    assert (top, head, tree, dirty, extra) == (str(ROOT), COMMIT, TREE, b"", b"")
    return {"root": top, "commit": head, "tree": tree, "tracked_clean": True, "ordinary_untracked_empty": True}

def constants(path):
    tree = ast.parse(path.read_text(), filename=str(path))
    values = {}
    def literal(node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, (ast.Tuple, ast.List)):
            return tuple(literal(x) for x in node.elts)
        if isinstance(node, ast.Name):
            return values[node.id]
        raise ValueError(type(node).__name__)
    for node in tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            try:
                values[node.targets[0].id] = literal(node.value)
            except (ValueError, KeyError):
                pass
    return {key: values[key] for key in ("SOURCE_TREES", "SOURCE_FILES", "SOURCE_OPTIONAL")}

def collect_paths():
    rows = set()
    counts = {}
    for relative in EXPECTED_TREES:
        directory = absolute(ROOT / relative)
        assert directory.is_dir(), relative
        pending = [directory]
        count = 0
        while pending:
            parent = pending.pop()
            before = identity(parent.lstat())
            with os.scandir(parent) as it:
                entries = sorted(it, key=lambda entry: entry.name)
            for entry in entries:
                path = Path(entry.path)
                info = path.lstat()
                count += 1
                assert count <= 32768
                assert not stat.S_ISLNK(info.st_mode)
                assert stat.S_ISDIR(info.st_mode) or stat.S_ISREG(info.st_mode)
                assert path.name != "__pycache__"
                if stat.S_ISDIR(info.st_mode):
                    pending.append(path)
                else:
                    assert path.suffix not in (".pyc", ".pyo")
                    rows.add(path.relative_to(ROOT).as_posix())
                    assert len(rows) <= 32768
            assert before == identity(parent.lstat()), str(parent)
        counts[relative] = count
    for relative in EXPECTED_FILES:
        assert (ROOT / relative).is_file(), relative
        rows.add(relative)
    for relative in EXPECTED_OPTIONAL:
        if (ROOT / relative).exists():
            rows.add(relative)
    return sorted(rows), counts

absolute(ROOT)
assert (ROOT / ".git").is_dir() and not (ROOT / ".git").is_symlink()
before = source_state("before")
source_constants = {
    "inspector": constants(ROOT / "prototypes/static_tray_v01/current_host_inspection_v01.py"),
    "provider": constants(ROOT / "prototypes/static_tray_v01/current_host_readback_v01.py"),
}
expected_constants = {"SOURCE_TREES": EXPECTED_TREES, "SOURCE_FILES": EXPECTED_FILES, "SOURCE_OPTIONAL": EXPECTED_OPTIONAL}
assert source_constants["inspector"] == source_constants["provider"] == expected_constants

raw_tree = git(["ls-tree", "-rz", "--full-tree", COMMIT], "git-complete-tree")
tracked = {}
for item in raw_tree.split(b"\0"):
    if not item:
        continue
    header, raw_name = item.split(b"\t", 1)
    mode, kind, oid = header.decode("ascii").split(" ")
    name = raw_name.decode("utf-8")
    assert name not in tracked
    tracked[name] = {"mode": mode, "type": kind, "oid": oid}

names, tree_counts = collect_paths()
inventory = {"schema": SCHEMA, "files": {}}
witnesses = []
for name in names:
    assert not PurePosixPath(name).is_absolute() and ".." not in PurePosixPath(name).parts
    binding, calculated_blob = bind(ROOT / name)
    git_row = tracked[name]
    assert git_row["type"] == "blob" and git_row["mode"] in ("100644", "100755"), name
    assert calculated_blob == git_row["oid"], name
    assert binding["mode"] == ("0o755" if git_row["mode"] == "100755" else "0o644"), name
    inventory["files"][name] = binding
    witnesses.append({"path": name, "git_mode": git_row["mode"], "git_blob": git_row["oid"],
                      "working_file_binding": binding, "working_file_git_blob_equal": True})

# Independent raw Git object readback: each selected blob is streamed separately
# by Git and checked against the manually observed filesystem SHA-256 and size.
request = OUT / "git-blob-request.txt"
request.write_text("".join(tracked[name]["oid"] + "\n" for name in names), encoding="ascii")
argv = ["git", "-c", "core.fsmonitor=false", "-C", str(ROOT), "cat-file", "--batch"]
with request.open("rb") as inp, (OUT / "git-blob-readback.stderr").open("wb") as error:
    process = subprocess.Popen(argv, env=ENV, stdin=inp, stdout=subprocess.PIPE, stderr=error)
    try:
        for row in witnesses:
            header = process.stdout.readline().decode("ascii").rstrip("\n")
            oid, kind, size_text = header.split(" ")
            size = int(size_text)
            assert oid == row["git_blob"] and kind == "blob"
            remaining = size
            digest = hashlib.sha256()
            while remaining:
                chunk = process.stdout.read(min(1024 * 1024, remaining))
                assert chunk
                remaining -= len(chunk)
                digest.update(chunk)
            assert process.stdout.read(1) == b"\n"
            binding = row["working_file_binding"]
            assert size == binding["size_bytes"] and digest.hexdigest() == binding["sha256"], row["path"]
            row["raw_git_object_sha256_equal"] = True
        assert process.stdout.read() == b""
        exit_code = process.wait(timeout=60)
        assert exit_code == 0
    except BaseException:
        process.kill()
        process.wait(timeout=10)
        raise
commands.append({"argv": argv, "environment": ENV, "exit_code": exit_code,
                 "stdin": request.name, "stderr": "git-blob-readback.stderr",
                 "stdout_handling": "Streamed exact blob bytes; per-file digests retained in RAW-GIT-FILE-VERIFICATION.json"})

again, final_tree_counts = collect_paths()
assert again == names and tree_counts == final_tree_counts
for row in witnesses:
    binding, blob = bind(ROOT / row["path"])
    assert binding == row["working_file_binding"] and blob == row["git_blob"]
after = source_state("after")
assert after == before

inventory_path = save_json("SOURCE-INVENTORY.json", inventory, canonical_bytes=True)
inventory_binding, _ = bind(inventory_path)
descriptor = {"path": str(inventory_path), **inventory_binding}
source = {"root": str(ROOT), "commit": COMMIT, "tree": TREE, "inventory": descriptor}
source_path = save_json("SOURCE-OBJECT.json", source, canonical_bytes=True)
save_json("RAW-GIT-FILE-VERIFICATION.json", {
    "schema": "ontokin.c271.p26.manual-source-file-verification/1", "files": witnesses,
    "file_count": len(names), "all_working_git_blob_ids_equal": True,
    "all_raw_git_object_sha256_equal": True, "all_modes_equal": True,
    "complete_checkout_tree_entries": len(tracked),
})
save_json("SOURCE-READBACK.json", {
    "schema": "ontokin.c271.p26.manual-source-readback/1",
    "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
    "passed": True, "source": source, "source_object_file": str(source_path),
    "file_count": len(names), "source_tree_entry_counts": tree_counts,
    "constants_match_exact_inspector_and_provider_literals": True,
    "expected_source_constants": expected_constants,
    "before": before, "after": after, "commands": commands,
    "source_inventory_canonical_no_newline": inventory_path.read_bytes() == canonical(inventory),
    "source_object_canonical_no_newline": source_path.read_bytes() == canonical(source),
    "private_regular_files_checked": len(names), "actual_source_bytes_unchanged_before_after": True,
    "ordinary_git_directory": True, "checkout_detached_at_selected_commit": True,
    "project_modules_imported": [], "project_helpers_executed": [], "tests_run": [],
    "target_runtime_starts": {"node": 0, "ldd": 0, "direct_loader": 0, "checkers": 0},
    "package_installations": 0,
    "limits": [
        "Manual static source/inventory construction and raw Git/hash readback only.",
        "Does not accept N34, H0 operational plan, host readiness, H1, original-seven/full routine, integration or parent completion.",
        "General docs and Git metadata are outside the exact P06 CPU inventory except explicit SOURCE_FILES; full checkout commit/tree and clean status remain bound.",
        "Both future current-host preparation plans and H0 must reuse this exact full source object and immutable inventory descriptor.",
        "No historical source/install receipt was rewritten. No previous-host path was accessed."
    ],
})
print(json.dumps({"passed": True, "source": source, "file_count": len(names),
                  "raw_git_verified": len(witnesses), "evidence": str(OUT / "SOURCE-READBACK.json")}, indent=2))
