#!/usr/bin/env python3
"""Independent P26 early archive audit. Does not execute packaged code."""
import collections
import hashlib
import json
import stat
import subprocess
import unicodedata
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

BASE = Path('/workspace/scratch/cf652064a9a1')
OWN = BASE / 'session/handoff_audit'
REPO = BASE / 'OntoKin'
ARCHIVE = BASE / 'packages/OntoKin_C271_P26_H0_Plan_Early_Recovery_2026-11-23.zip'
EXPECTED = {'bytes':2386043,'sha256':'78b29adb68f3eeaa624b7e4c77562f94c4ef2bbda14015cccd5eb94461a1bac6'}
MAIN = 'e43cc6c5777874101a40559e4058ad6826b07e51'
SOURCE = 'ed2fc453042a9f0bc4808c2aea7f015baf1ff73e'
checks = []

def ident(b):
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def check(label, ok, **details):
    checks.append({'check':label,'passed':bool(ok),**details})

def parse(b):
    def pairs(items):
        d = {}
        for k,v in items:
            if k in d:
                raise ValueError('Duplicate JSON key '+k)
            d[k] = v
        return d
    return json.loads(b,object_pairs_hook=pairs)

def safe(n):
    return bool(n) and not n.startswith('/') and '\\' not in n and '\x00' not in n and ':' not in n and all(p not in ('','.','..') for p in n.split('/')) and str(PurePosixPath(n)) == n

def git(*args):
    return subprocess.run(['git',*args],cwd=REPO,check=True,capture_output=True).stdout

archive_bytes=ARCHIVE.read_bytes()
check('exact_archive_identity',ident(archive_bytes)==EXPECTED,observed=ident(archive_bytes))
with zipfile.ZipFile(ARCHIVE) as z:
    infos=z.infolist(); names=[i.filename for i in infos]
    check('crc',z.testzip() is None)
    check('safe_paths',all(safe(n) for n in names))
    check('unique_names',len(names)==len(set(names)))
    portable=[unicodedata.normalize('NFC',n).casefold() for n in names]
    check('no_portable_collisions',len(portable)==len(set(portable)))
    check('no_encryption_or_special_files',all(not i.flag_bits&1 and not i.is_dir() and stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG) for i in infos))
    if not all(c['passed'] for c in checks):
        raise RuntimeError('Unsafe or wrong archive')
    data={n:z.read(n) for n in names}

fresh=OWN/'fresh-early-p26'; fresh.mkdir(exist_ok=False)
for n,b in data.items():
    p=fresh/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
check('fresh_extraction_bytes',all((fresh/n).read_bytes()==b for n,b in data.items()))
required=['README-START-HERE.md','CHECKPOINT.json','HANDOFF.md','NEXT-TASK.md','RECOVERY-STATUS.md','PROMPT-1-CONTINUE.md','PROMPT-2-RECOVER.md','HISTORICAL-DEPENDENCIES.json','HOST-ENVIRONMENT.md','MANIFEST-SHA256.json','SOURCE-MANIFEST.json','RECOVERY-MANIFEST.json']
check('required_roots',set(required)<=data.keys())
manifest=parse(data['MANIFEST-SHA256.json'])['files']
source=parse(data['SOURCE-MANIFEST.json'])['entries']
recovery=parse(data['RECOVERY-MANIFEST.json'])['entries']
check('full_manifest_exact_inventory',set(manifest)==set(data)-{'MANIFEST-SHA256.json'})
for n,e in manifest.items():
    check('full_manifest_size_hash',n in data and ident(data[n])==e,path=n)
for label,entries,prefix in [('source',source,'repository/'),('recovery',recovery,'recovery/')]:
    enames=[e['archive_path'] for e in entries]
    check(label+'_unique',len(enames)==len(set(enames)))
    check(label+'_exact_inventory',set(enames)=={n for n in data if n.startswith(prefix)})
    for e in entries:
        check(label+'_size_hash',e['archive_path'] in data and ident(data[e['archive_path']])=={k:e[k] for k in ['bytes','sha256']},path=e['archive_path'])
check('source_revision_set',{e['commit'] for e in source}=={MAIN,SOURCE})
for e in source:
    b=git('show',e['commit']+':'+e['repository_path'])
    entry=git('ls-tree',e['commit'],'--',e['repository_path']).decode().strip()
    mode=entry.split()[0]
    check('source_exact_git_bytes_mode',e['archive_path']=='repository/'+e['repository_path'] and b==data[e['archive_path']] and mode==e['git_mode'],path=e['repository_path'],commit=e['commit'])
for e in recovery:
    p=Path(e['original_session_path'])
    check('recovery_current_input_bytes',p.is_relative_to(BASE) and p.is_file() and p.read_bytes()==data[e['archive_path']],path=e['archive_path'])
config_path=BASE/'session/early-package-config.json'
config=parse(config_path.read_bytes())
for n,v in config['root_files'].items():
    encoded=(json.dumps(v,indent=2,ensure_ascii=False)+'\n').encode() if isinstance(v,(dict,list)) else (v.rstrip()+'\n').encode()
    check('root_matches_frozen_config',data[n]==encoded,path=n)
checkpoint=parse(data['CHECKPOINT.json'])
check('checkpoint_source',checkpoint['source_commit']==SOURCE and checkpoint['starting_head']==SOURCE)
check('checkpoint_main',checkpoint['observed_main']==MAIN and checkpoint['observed_main_tree']==git('rev-parse',MAIN+'^{tree}').decode().strip())
check('checkpoint_phase_before_work',checkpoint['kind']=='early_recovery' and checkpoint['technical_work_started'] is False and checkpoint['delivery_state']=='early_save_pending')
check('checkpoint_parent_open',checkpoint['parent_complete'] is False and checkpoint['parent_status']=='in_progress' and checkpoint['requirements']=={'R01':'done','R02':'done','R03':'not_done','R04':'not_done','R05':'not_done'} and checkpoint['parent_plan']=={'P01':'done','P02':'in_progress'})
check('checkpoint_no_main_lease',checkpoint['main_lease_held'] is False)
check('checkpoint_exclusions',set(['H1','original-seven and full-routine execution','production/test/contract/pin changes','main integration','branch deletion','parent closure'])<=set(checkpoint['exclusions']))
check('checkpoint_concrete_stop','first concrete blocker' in checkpoint['stop'] and 'No second phase' in checkpoint['stop'])
for n in ['README-START-HERE.md','HOST-ENVIRONMENT.md','PROMPT-1-CONTINUE.md','PROMPT-2-RECOVER.md']:
    t=data[n].decode()
    check('essential_disposable_host_rule',all(s in t for s in ['different disposable execution host','historical evidence only','Never search for or repair a prior host']),path=n)
check('explicit_no_host_acceptance','establishes no current-host H0/H1 result' in data['HOST-ENVIRONMENT.md'].decode())
check('prior_pending_delivery_preserved','source boundary' in data['RECOVERY-STATUS.md'].decode() and 'later receipt' in data['RECOVERY-STATUS.md'].decode())
check('matching_next_action',all(checkpoint['next_action'] in data[n].decode() for n in ['NEXT-TASK.md','PROMPT-1-CONTINUE.md','PROMPT-2-RECOVER.md']))
historical=parse(data['HISTORICAL-DEPENDENCIES.json'])
for key in ['p25_zip','p25_receipt']:
    e=historical[key]
    check('predecessor_identity',ident(data[e['included']])=={k:e[k] for k in ['bytes','sha256']},dependency=key)
check('predecessor_zip_exact_incoming',data[historical['p25_zip']['included']]==(BASE/'incoming/OntoKin/OntoKin_C271_P25_RTLD_Path_Implementation_Handoff_2026-11-23.zip').read_bytes())
check('predecessor_receipt_exact_incoming',data[historical['p25_receipt']['included']]==(BASE/'incoming/OntoKin/OntoKin_C271_P25_Delivery_Receipt_2026-11-23.json').read_bytes())
check('predecessor_manifest_unchanged',historical['predecessor_manifest']==parse((BASE/'incoming/p25/HISTORICAL-DEPENDENCIES.json').read_bytes()))
governance=['CHATGPT-START-HERE.md','AGENTS.md','GOAL.md','STATUS.md','ROLE.md','docs/workflow/registry.json','docs/workflow/CURRENT.json','docs/workflow/PROTOCOL.md','docs/workflow/HANDOFF.md','docs/workflow/BROWSER-PROMPTS.md','.agents/skills/ontokin-session/SKILL.md','.agents/skills/ontokin-delivery/SKILL.md','.agents/skills/ontokin-learning/SKILL.md']
check('mandatory_repository_snapshots',all('repository/'+p in data for p in governance))
check('active_task_snapshots',all('repository/docs/workflow/tasks/C271/'+n in data for n in ['REQUIREMENTS.md','PLAN.md','task.json']))
root_verification=parse((BASE/'session/OntoKin_C271_P26_H0_Plan_Early_Recovery_2026-11-23-VERIFICATION.json').read_bytes())
check('independent_agreement_with_root',root_verification['passed'] is True and all(root_verification[k]==v for k,v in EXPECTED.items()) and root_verification['members']==len(data) and root_verification['source_bindings']==len(source) and root_verification['recovery_files']==len(recovery))
report={
    'schema':'ontokin.c271.p26.early-handoff-audit/1','auditor':'/root/handoff_audit',
    'completed_at_utc':datetime.now(timezone.utc).isoformat(),'archive':{'path':str(ARCHIVE),**ident(archive_bytes)},
    'passed':all(c['passed'] for c in checks),'failures':[c for c in checks if not c['passed']],
    'counts':{'members':len(data),'payloads':len(manifest),'source_bindings':len(source),'recovery_files':len(recovery),'checks':len(checks)},
    'source_revisions':dict(collections.Counter(e['commit'] for e in source)),
    'fresh_extraction':str(fresh),'config_identity':{'path':str(config_path),**ident(config_path.read_bytes())},
    'manual_content_review':{'required_root_prose':'read in full','phase_boundary':'One P26 H0-plan phase or first concrete blocker; H1, full routine, implementation changes, integration and parent closure excluded.','host_resources':'No claim that predecessor paths/environments persist; fresh-host reconstruction instruction repeated.','acceptance':'No H0/H1 or actual N34 acceptance claimed; P25 evidence explicitly historical.','recovery_namespace':'P25 original archive/receipt embedded at explicit predecessor paths; inherited manifest preserved as a historical object.'},
    'delivery_limit':'Package acceptance permits save. Early saved delivery remains pending until the Director saves and independently byte-reads back this exact identity. No live-terminal or remote-state conclusion is inferred here.',
    'actions_not_performed':['target code/native/test execution','package installation','repository/index/ref changes','Library/PR writes'],
    'inspection_note':'Initial manifest display assumed list form but P26 uses a mapping; this display raised KeyError for slice(None, 1, None) before verification. The independent audit parses the actual documented schemas and preserves this note. No archive code or builder was executed.',
    'checks':checks}
(OWN/'EARLY-AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['passed','counts','failures','source_revisions','archive']},indent=2))
raise SystemExit(0 if report['passed'] else 1)
