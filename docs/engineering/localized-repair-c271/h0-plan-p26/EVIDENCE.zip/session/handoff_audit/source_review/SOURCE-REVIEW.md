# P26 retained loader and current ldd source review

Reviewer: `/root/handoff_audit`. Source revision: `ed2fc453042a9f0bc4808c2aea7f015baf1ff73e`.

## Decision

Accept the exact retained P15 loader provenance and finite suffix rationale for their existing, narrow purpose. The current Director observation binds the same 225,672-byte loader, SHA-256 `c8438e4fde1934e61c88311633f00949ff645d5c04cdb8671fa3d78164d2f307`. The complete current `ldd` script has been read as data. Its external call destinations are exactly its three literal RTLD candidates; its interpreter is `/bin/bash`.

No unavoidable `inspector_commands.commands` representation blocker is established. A transparent redundant binding of the actual canonical Bash interpreter is compatible with the inspected aggregate contract, while the separate RTLD candidate list and ELF closure continue to cover every loader call. This is a scoped source-review interpretation. It is not a claim that the script body launches a second Bash command, a completed operational plan, whole N34 acceptance, H0 acceptance, or an observed product result.

## Exact evidence and provenance

`P15-EVIDENCE-AUDIT.json` records 266 successful archive/source-manifest checks. The 5,727,316-byte P15 bundle, SHA-256 `a6a601f3b51d02bc793746f2e78e70b91ba3269f4d8217d378a0161c4e7f0d9f`, exactly matches its Git blob. All 200 declared payloads and 201 archive members passed integrity, path, inventory and hash checks. The separate source-provenance manifest has 60 available files plus one explicitly external upstream source archive.

`LOADER-BINDING-AUDIT.json` records 116 successful data checks. An independent in-memory ar/tar inspection of retained `libc6_2.41-12+deb13u4_amd64.deb` reproduced the package-member comparison. Its loader bytes equal the official-package inert copy, the retained host copy and the retained static-admission copy. The package identifies source `glibc`, version `2.41-12+deb13u4`, architecture `amd64`. The exact `.dsc` and Debian patch archive match their recorded hashes and source-version association. All 80 active patch hashes match members of that retained patch archive. Nineteen independently retained source-member bindings also match their recorded bytes.

An independent ELF data reader confirms ELF64, little-endian, x86-64, ET_DYN, build ID `86f7eb4ff495ed3f2831c6d3d662e4321762a2a3`, and **no PT_INTERP** in this loader. Current loader identity comes from the Director's fresh `session/readiness/run001.stdout.json`; this reviewer did not reread or execute the system loader.

The full upstream `glibc_2.41.orig.tar.xz` is an explicitly external P15 recovery object. This review verifies the retained source texts and their exact historical extraction bindings; it does not claim a new extraction from that full archive. The original accepted relation relies on official HTTPS retrieval, source-package metadata, published checksums, source/build recipes and exact binary-member correspondence. Its limits remain: no locally verified OpenPGP signature, recovered amd64 compiler environment/buildinfo, or reproduced binary build.

## Scope of the suffix argument under /0.1.4

P13 makes actual-loader suffix completeness an external review prerequisite. P24 preserves that boundary and the earlier Python-origin proof; P25's implementation does not convert a synthetic control into source-completeness approval.

The existing accepted sorted union is the base entry `""` and `glibc-hwcaps/x86-64-v2`, `glibc-hwcaps/x86-64-v3`, `glibc-hwcaps/x86-64-v4`. The retained x86-64 source supplies exactly those three nonempty names. The fully reread constructor combines an optional prepend list, a masked built-in list and one base entry; the splitter filters names without generating new ones. The retained source initialization/CLI excerpts keep prepend and mask null unless their explicit loader options are provided.

P15's accepted applicability is ordinary direct invocation of the selected Python under the unchanged P11/P13 guards. That argument can be reused for this same loader and invocation restriction, with exact rationale and variant inventory bound to the eventual plan. It does not by itself approve the current `ldd` invocation context. The current script's fixed calls contain no `--glibc-hwcaps-prepend` or `--glibc-hwcaps-mask` arguments, which is compatible with the same finite constructor inputs. This compatibility observation is not an independent whole-source review of every native behavior or a full resolution-map proof. Default directories, cache interpretation, relevant library names, Python-origin nonselection, interpreter/native closure, current path guards and plan identity remain separately required.

## Complete current script branch review

The Director's current raw observation is 14,396 bytes, SHA-256 `a69df0de6bd8c256a6d6d189e8e4534c930a2d61762f9a474445e52c58645920`. Its embedded script equals `session/rtld/ldd-script.txt`: 5,356 bytes, SHA-256 `7bcd61a279946cb376d36fd91f4938ab4f4aba48e793c652a9797319d23f8dd3`, mode `0o755`, link count 1, direct shebang `#!/bin/bash`. Both recorded path-observation passes agree. Their two ENOENT witnesses bind the matching physical-parent identities. These are raw observations; the production finite path proof was not executed.

The reviewed future call is exactly `/usr/bin/ldd ABSOLUTE_NODE`, one argument, no options, with the five-variable environment `PATH=/usr/bin:/bin`, `LANG=C.UTF-8`, `LC_ALL=C.UTF-8`, `TZ=UTC`, `UV_THREADPOOL_SIZE=2`. The required input is a bound regular readable executable. Those are conditions for this analysis, not observations of an installed Node in this review.

| Script branch | Fixed-call consequence and possible outcome |
| --- | --- |
| Option loop | An absolute Node path begins with `/`, so it takes the ordinary-argument branch immediately. Help, version, relocation, verbose, unused, `--`, ambiguous and unknown-option branches are unreachable for this exact argv. They exist in the full source and were inspected. |
| Argument count | Exactly one argument selects `single_file=t`; no filename header is printed. Zero-argument failure and multiple-file formatting are excluded by the fixed argv. |
| Path spelling | The absolute argument already contains `/`, so the script does not prepend `./`. The quoted argument is retained through verification and tracing. |
| Existence/type/readability | Missing or nonregular input sets result 1; unreadable input sets result 1 with its diagnostic. These shell tests are not substitutes for the inspector's independent absence and file-identity proof. Mutation or access faults can still affect them after static review. |
| Loader loop | The exact ordered list is `/lib64/ld-linux-x86-64.so.2`, `/lib/ld-linux.so.2`, `/libx32/ld-linux-x32.so.2`. Each executable candidate can receive `--version`; only a zero return permits `--verify NODE`. A verification result of 0 or 2 selects that candidate and breaks the loop. |
| Present-host raw facts | Only the first candidate resolves to the pinned regular loader. The other two are observed absent through their exact physical witnesses. Under unchanged facts, they cause no loader execution. All three must remain in the declared list and path proof. |
| Version/verification failure | A failed version check skips verification; a verification result outside 0/2 continues the candidate loop. With no accepted candidate, ret 1 calls the local `nonelf` function, which always returns 1, then prints the non-dynamic diagnostic and sets failure. Another final ret emits the unknown-exit-code diagnostic and exits 1. No fallback invocation of Node itself exists. |
| Trace | `try_trace RTLD NODE` uses the already selected loader. It sets `LD_TRACE_LOADED_OBJECTS=1`; `LD_WARN`, `LD_BIND_NOW` and `LD_VERBOSE` are empty for this fixed call. No unused/LD_DEBUG branch is entered. The evaluated command retains quoted positional arguments. No loader prepend, mask, audit, preload or alternate executable option is supplied. |
| Trace capture | The function captures the loader's stdout and stderr together, appends/removes an `x` sentinel to preserve trailing newlines, prints the capture, and returns the loader status. A nonzero trace status sets script result 1. A zero script status still must satisfy the unchanged strict external output parser; source review supplies no expected successful output or fabricated process receipt. |
| Other faults | Shell/exec/resource failures, signals, timeout, namespace drift, logging or cleanup failures remain actual-outcome obligations. This review does not infer that native execution succeeds or that post-validation state is immutable. |

The script uses shell control constructs and the Bash built-ins `test`, `echo`, `printf`, `return`, `exit`, `eval` and `:`. `nonelf` and `try_trace` are locally defined functions. There is no external `cat`, `grep`, `sed`, `readlink`, `env`, `uname`, or PATH-selected utility in the script body. Its command substitutions and trace function invoke only selected RTLD candidates. The fixed initial environment contains no `BASH_ENV`, exported shell functions, shell-option variables or inherited `LD_*` injection variables. The native Bash image, its loader/shared inputs and applicable startup behavior still require their actual plan bindings; classification of its built-ins is not a claim that a complete Bash implementation audit has occurred.

## Command-descriptor hypothesis: findings and correction

The following source behavior is established by reading the exact inspector, without importing or invoking it:

1. `_check_resolution` requires a nonempty `inspector_commands.commands` list. Each item is a descriptor. `_binding_shape(..., descriptor=True)` and `_read_file` require a normalized canonical path with no symlink component.
2. Command descriptor paths become executable roots. A root whose literal path is not one of the RTLD candidate spellings must have PT_INTERP.
3. A descriptor using `/lib64/ld-linux-x86-64.so.2` would fail canonicality. A descriptor using `/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2` has no PT_INTERP and does not equal a literal candidate string, so that command entry would fail the static-executable predicate. These are conditional source deductions, not executed runtime refusals.
4. Those deductions do not prove that every faithful plan is impossible. The adopted P07 text defines `inspector_commands` as the aggregate binding of script, interpreter and all reviewed external commands/loaders. No inspected adopted text requires the `commands` sublist to be disjoint from the separately bound interpreter or to be the exact external-script-body destination set.
5. The actual canonical Bash interpreter is an executable that this fixed shebang genuinely uses. Listing its exact already-bound descriptor redundantly in `commands`, while retaining all RTLD candidates and complete images/roles/aliases, does not invent a program or authorize another launch. The source's loader-specific closure route remains active. This narrowly scoped interpretation is acceptable; do not describe Bash as an additional external command emitted by the script body.
6. Synthetic P08 `ClosureFixture` supplies a separate utility while its inert script does not invoke that utility. Its explicit synthetic boundary means this fixture neither establishes operational source completeness nor proves a prohibition on interpreter redundancy.

No product change, fake executable, altered script, omitted candidate, deleted gate or test-expectation change is recommended by this review. An actual plan must state the redundant-interpreter rationale explicitly and bind the real Bash descriptor, canonical route, PT_INTERP and closure. Shape compatibility alone does not establish these facts.

## Remaining gate and stop

The exact loader correspondence and script destination/control-flow questions have a bounded supporting answer. This review supplies no accepted operational plan, variant/rationale/plan-digest relationship, complete Bash/Node/native closure, cache/default-directory interpretation, or current full source/input inventory. Whole N34 and H0 remain unaccepted. Historical N57 stays an external obligation with no fabricated runtime pass. No helper, target, loader, shell script, installer, test or product code was executed by this reviewer. Stop here and return the supporting evidence and remaining requirements to the Director.
