#!/usr/bin/env python3
"""Read-only P25 archive/source audit; writes only within this auditor's directory."""
import collections
import hashlib
import json
import os
import platform
import stat
import subprocess
import sys
import unicodedata
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

BASE = Path('/workspace/scratch/cf652064a9a1')
OWN = BASE / 'session/handoff_audit'
REPO = BASE / 'OntoKin'
ZIP = BASE / 'incoming/OntoKin/OntoKin_C271_P25_RTLD_Path_Implementation_Handoff_2026-11-23.zip'
EXTRACTED = BASE / 'incoming/p25'
RECEIPT = BASE / 'incoming/OntoKin/OntoKin_C271_P25_Delivery_Receipt_2026-11-23.json'
MAIN = 'e43cc6c5777874101a40559e4058ad6826b07e51'
SOURCE = '0df3d39084e11b68a434035fa0cc67e1d7d8955e'
RECEIPT_COMMIT = 'ed2fc453042a9f0bc4808c2aea7f015baf1ff73e'
EXPECTED_ZIP = {'bytes': 2264988, 'sha256': '23fb56fbcb3e1d1d8011e1bd97242be3b7d9c114f91e18c5e12fb8050d7d5a08'}
EXPECTED_RECEIPT = {'bytes': 123928, 'sha256': '1f0b9dc3a665bf0153b445644bd4858acb662c1f60ab33549ebef965c124017d'}
checks, bindings = [], []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def ident(data):
    return {'bytes': len(data), 'sha256': sha(data)}

def check(name, ok, **details):
    checks.append({'check': name, 'passed': bool(ok), **details})

def parse(data):
    def no_duplicates(items):
        result = {}
        for k, v in items:
            if k in result:
                raise ValueError('Duplicate JSON key: ' + k)
            result[k] = v
        return result
    return json.loads(data, object_pairs_hook=no_duplicates)

def git(*args):
    return subprocess.run(['git', *args], cwd=REPO, check=True, capture_output=True).stdout

def safe(name):
    return (bool(name) and not name.startswith('/') and '\\' not in name and
            '\x00' not in name and ':' not in name and
            all(p not in ('', '.', '..') for p in name.split('/')) and
            str(PurePosixPath(name)) == name)

def records_manifest(entries, key, actual, namespace):
    names = [e[key] for e in entries]
    check(namespace + '_unique_entries', len(names) == len(set(names)))
    check(namespace + '_safe_paths', all(safe(n) for n in names))
    check(namespace + '_exact_inventory', set(names) == set(actual),
          missing=sorted(set(names) - set(actual)), undeclared=sorted(set(actual) - set(names)))
    for e in entries:
        data = payload.get(e[key])
        ok = data is not None and ident(data) == {'bytes': e['bytes'], 'sha256': e['sha256']}
        check(namespace + '_size_sha256', ok, path=e[key])

OWN.mkdir(parents=True, exist_ok=True)
archive_bytes = ZIP.read_bytes()
receipt_bytes = RECEIPT.read_bytes()
check('archive_expected_identity', ident(archive_bytes) == EXPECTED_ZIP, observed=ident(archive_bytes))
check('receipt_expected_identity', ident(receipt_bytes) == EXPECTED_RECEIPT, observed=ident(receipt_bytes))
receipt = parse(receipt_bytes)

with zipfile.ZipFile(ZIP) as z:
    infos = z.infolist()
    names = [i.filename for i in infos]
    check('crc_integrity', z.testzip() is None)
    check('zip_unique_names', len(names) == len(set(names)))
    normalized = [unicodedata.normalize('NFC', n).casefold() for n in names]
    check('zip_no_portability_collisions', len(normalized) == len(set(normalized)))
    check('zip_safe_relative_paths', all(safe(n) for n in names))
    check('zip_regular_files_only', all(stat.S_ISREG(i.external_attr >> 16) and not i.is_dir() for i in infos))
    check('zip_no_encryption', all(not i.flag_bits & 1 for i in infos))
    if not all(c['passed'] for c in checks):
        raise RuntimeError('Archive safety or exact identity failed before extraction')
    payload = {i.filename: z.read(i) for i in infos}
    fresh = OWN / 'fresh-incoming-p25'
    fresh.mkdir(exist_ok=False)
    for name, data in payload.items():
        target = fresh / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    check('fresh_extraction_all_bytes_match', all((fresh / n).read_bytes() == b for n, b in payload.items()))
    existing = {p.relative_to(EXTRACTED).as_posix(): p for p in EXTRACTED.rglob('*') if p.is_file() or p.is_symlink()}
    check('provided_extraction_exact_inventory', set(existing) == set(payload))
    check('provided_extraction_no_symlinks', all(not p.is_symlink() for p in existing.values()))
    check('provided_extraction_all_bytes_match', all(n in existing and existing[n].read_bytes() == b for n,b in payload.items()))

required = ['README-START-HERE.md','CHECKPOINT.json','HANDOFF.md','NEXT-TASK.md','RECOVERY-STATUS.md',
            'PROMPT-1-CONTINUE.md','PROMPT-2-RECOVER.md','HISTORICAL-DEPENDENCIES.json','MANIFEST-SHA256.json',
            'HOST-ENVIRONMENT.md','SOURCE-MANIFEST.json','RECOVERY-MANIFEST.json']
check('required_roots_present', all(n in payload for n in required))
manifest = parse(payload['MANIFEST-SHA256.json'])
sources = parse(payload['SOURCE-MANIFEST.json'])
recovery = parse(payload['RECOVERY-MANIFEST.json'])
checkpoint = parse(payload['CHECKPOINT.json'])
records_manifest(manifest['files'], 'path', set(payload) - {'MANIFEST-SHA256.json'}, 'full_manifest')
records_manifest(sources['files'], 'member', [n for n in payload if n.startswith('repository/')], 'source_manifest')
records_manifest(recovery['files'], 'member', [n for n in payload if n.startswith('recovery/')], 'recovery_manifest')
check('source_wrapper_mapping', all(e['member'] == 'repository/' + e['path'] for e in sources['files']))
check('recovery_wrapper_mapping', all(e['member'] == 'recovery/' + e['session_path'] and safe(e['session_path']) for e in recovery['files']))
check('source_commits_expected', set(e['commit'] for e in sources['files']) == {MAIN, SOURCE})
check('checkpoint_source', checkpoint['source_commit'] == SOURCE)
check('checkpoint_main', checkpoint['observed_main'] == MAIN)
check('checkpoint_task_open', checkpoint['parent_complete'] is False and checkpoint['parent_status'] == 'in_progress')
check('checkpoint_unaccepted_runtime', checkpoint['h0_accepted'] is False and checkpoint['h1_executed'] is False)

trees = {}
for commit in [MAIN, SOURCE, RECEIPT_COMMIT]:
    check('git_commit_available', git('cat-file', '-t', commit).strip() == b'commit', commit=commit)
    entries = {}
    for raw in git('ls-tree', '-r', '-z', commit).split(b'\0'):
        if not raw:
            continue
        meta, path = raw.split(b'\t', 1)
        mode, kind, oid = meta.decode().split(' ')
        entries[path.decode()] = {'mode': mode, 'type': kind, 'sha': oid}
    trees[commit] = entries

for e in sources['files']:
    node = trees[e['commit']].get(e['path'])
    ok = bool(node and node['type'] == 'blob' and node['mode'] == e['mode'])
    if node and node['type'] == 'blob':
        data = git('cat-file', 'blob', node['sha'])
        ok = ok and data == payload[e['member']] and ident(data) == {'bytes': e['bytes'], 'sha256': e['sha256']}
    check('source_exact_git_blob_mode_size_hash', ok, commit=e['commit'], path=e['path'])
    bindings.append({**e, 'git_blob': node['sha'] if node else None, 'verified': ok})

for key, rev in [('source_tree', SOURCE), ('observed_main_tree', MAIN)]:
    check('checkpoint_' + key, checkpoint[key] == git('rev-parse', rev + '^{tree}').decode().strip())
check('receipt_source_tree', receipt['packaged_source_tree'] == checkpoint['source_tree'])
check('receipt_source_commit', receipt['packaged_source_commit'] == SOURCE)
check('receipt_main', receipt['observed_main'] == MAIN)
check('receipt_commit', receipt['receipt_commit'] == RECEIPT_COMMIT)
check('receipt_tree', receipt['receipt_tree'] == git('rev-parse', RECEIPT_COMMIT + '^{tree}').decode().strip())
check('receipt_parent', receipt['receipt_commit_parent'] == SOURCE and git('rev-parse', RECEIPT_COMMIT + '^').decode().strip() == SOURCE)
check('receipt_archive_binding', all(receipt['archive'][k] == v for k,v in EXPECTED_ZIP.items()) and receipt['archive']['file_name'] == ZIP.name)
for e in receipt['prompts']:
    check('receipt_prompt_binding', ident(payload[e['matching_zip_member']]) == {'bytes': e['bytes'], 'sha256': e['sha256']}, member=e['matching_zip_member'])

delivery_path = checkpoint['receipt_path']
delivery_bytes = git('show', RECEIPT_COMMIT + ':' + delivery_path)
check('receipt_repository_delivery_bytes', ident(delivery_bytes) == {k: receipt['repository_delivery_record'][k] for k in ['bytes','sha256']})
check('receipt_repository_delivery_content', parse(delivery_bytes) == receipt['repository_delivery_content'])
check('delivery_absent_at_frozen_source', delivery_path not in trees[SOURCE])

changed = git('diff-tree', '--no-commit-id', '--name-only', '-r', '-z', RECEIPT_COMMIT).decode().strip('\0').split('\0')
listed = receipt['receipt_publication']['changed_file_identities']
check('receipt_changed_exact_inventory', set(changed) == {e['path'] for e in listed} and len(listed) == len(changed), count=len(changed))
for e in listed:
    node = trees[RECEIPT_COMMIT].get(e['path'])
    data = git('show', RECEIPT_COMMIT + ':' + e['path'])
    check('receipt_changed_git_binding', node == {k:e[k] for k in ['mode','type','sha']} and ident(data) == {k:e[k] for k in ['bytes','sha256']}, path=e['path'])
check('receipt_no_production_or_test_change', not any(n.startswith(('ontokin/','prototypes/','tests/','tools/')) for n in changed))

for e in receipt['postfreeze_recovery']['files']:
    data = e['content_utf8'].encode('utf-8')
    check('embedded_recovery_size_hash', safe(e['path']) and ident(data) == {k:e[k] for k in ['bytes','sha256']}, path=e['path'])

for correction in receipt['package_clarifications']:
    check('clarification_archive_binding', correction['archive_sha256'] == EXPECTED_ZIP['sha256'])
    for e in correction['source_evidence']:
        data = payload.get('repository/' + e['path'])
        check('clarification_source_evidence', data is not None and ident(data) == {k:e[k] for k in ['bytes','sha256']}, path=e['path'])
clarification_path = 'docs/engineering/localized-repair-c271/path-implementation-p25/PACKAGE-CLARIFICATION.json'
check('published_clarification_matches_receipt', parse(git('show', RECEIPT_COMMIT + ':' + clarification_path)) in receipt['package_clarifications'])

governance_paths = ['AGENTS.md','ROLE.md','docs/workflow/PROTOCOL.md','docs/workflow/HANDOFF.md','.agents/skills/ontokin-delivery/SKILL.md']
readset = [{'commit': MAIN, 'path': p, **ident(git('show', MAIN + ':' + p)), 'read_in_full': True} for p in governance_paths]
report = {
    'schema': 'ontokin.c271.p26.incoming-handoff-audit/1',
    'auditor': '/root/handoff_audit',
    'completed_at_utc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Incoming P25 archive, extracted payload, exact available Git snapshots and external receipt; no target code, native input, test, install, ref, index, Library or PR mutation.',
    'environment': {'python': sys.version, 'platform': platform.platform()},
    'governing_readset': readset,
    'archive': {'path': str(ZIP), **ident(archive_bytes), 'members': len(payload)},
    'external_receipt': {'path': str(RECEIPT), **ident(receipt_bytes)},
    'counts': {'manifest_payloads': len(manifest['files']), 'source_files': len(sources['files']), 'recovery_files': len(recovery['files']), 'receipt_changed_files': len(listed), 'embedded_postfreeze_files': len(receipt['postfreeze_recovery']['files']), 'checks': len(checks)},
    'source_commits': dict(collections.Counter(e['commit'] for e in sources['files'])),
    'fresh_extraction': str(fresh),
    'passed': all(c['passed'] for c in checks),
    'failures': [c for c in checks if not c['passed']],
    'historical_pending_semantics': {
        'frozen_zip': checkpoint['delivery_state'],
        'receipt_source_time': receipt['self_save_status'],
        'resolution': 'Matching P25 save/publication/ownership pending fields require separate saved receipt and both live PR274/issue273 ONTOKIN-C271-P25-TERMINAL markers. The exact external receipt is verified here; live markers remain Director reconciliation responsibility.',
        'not_resolved_by_delivery': ['N34 actual loader/script/source completeness','H0 acceptance','H1','original seven/full routine','main integration','C271 parent closure','historical failed or unknown operations']
    },
    'correction': 'Both retained syntax checks passed. Frozen ZIP prose calling this a failed syntax attempt is corrected by the exact external receipt and PACKAGE-CLARIFICATION.json at the receipt commit; payload remains immutable.',
    'wrapper_namespace': 'repository/<path> maps directly to source-manifest Git path; recovery/<session_path> contains historical session evidence. HISTORICAL-DEPENDENCIES.inherited_unchanged paths resolve in the named original P24 archive, not inside this P25 archive.',
    'limitations': ['Audit proves supplied bytes and available exact Git object bindings, not a fresh remote-head or live-terminal observation.', 'Recovery helpers were not executed.', 'Historical filesystem locations were not probed.', 'Earlier source-specific evidence is unchanged; no runtime validity or complete offline restoration is inferred.'],
    'inspection_note': 'One exploratory read attempted PACKAGE-CLARIFICATION.json under the frozen extracted source and found it absent; the correction is postfreeze at the exact receipt commit and was verified there. No package mutation or retry occurred.',
    'checks': checks,
}
(OWN / 'INCOMING-AUDIT.json').write_text(json.dumps(report, indent=2) + '\n')
(OWN / 'INCOMING-SOURCE-BINDINGS.json').write_text(json.dumps({'files': bindings}, indent=2) + '\n')
(OWN / 'READ-SET.json').write_text(json.dumps({'files': readset}, indent=2) + '\n')
print(json.dumps({k:report[k] for k in ['passed','counts','failures','source_commits','archive','external_receipt']}, indent=2))
sys.exit(0 if report['passed'] else 1)
