#!/usr/bin/env python3
"""Independent byte and identity binding of the recorded early saved delivery."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import zipfile

BASE=Path('/workspace/scratch/cf652064a9a1')
OWN=BASE/'session/handoff_audit'
NAME='OntoKin_C271_P26_H0_Plan_Early_Recovery_2026-11-23.zip'
original=BASE/'packages'/NAME
readback=BASE/'saved-readback/early'/NAME
receipt_path=BASE/'session/EARLY-RECOVERY-RECEIPT.json'
save_path=BASE/'session/early-save-result.json'
prior_path=OWN/'EARLY-AUDIT.json'
expected={'bytes':2386043,'sha256':'78b29adb68f3eeaa624b7e4c77562f94c4ef2bbda14015cccd5eb94461a1bac6'}
expected_id='libfile_fde3_f-7d9d36db3c788191bfc2eebe9be15eb2_2ab2a24d43748191957f9bcc356b59de'
expected_file_id='file_00000000c9e881fbb678d64bbd140354'
checks=[]

def identity(b):
    return {'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def check(name,passed,**details):
    checks.append({'check':name,'passed':bool(passed),**details})

prior_bytes=prior_path.read_bytes()
prior=json.loads(prior_bytes)
receipt_bytes=receipt_path.read_bytes()
save_bytes=save_path.read_bytes()
receipt=json.loads(receipt_bytes)
saves=json.loads(save_bytes)['results']
check('single_save_result',len(saves)==1)
save=saves[0]
ob=original.read_bytes(); rb=readback.read_bytes()
check('original_expected_identity',identity(ob)==expected)
check('readback_expected_identity',identity(rb)==expected)
check('byte_for_byte_saved_readback_equality',ob==rb)
check('prior_independent_audit_accepts_same_archive',prior['passed'] is True and all(prior['archive'][k]==v for k,v in expected.items()))
check('recorded_save_succeeded',save['status']=='succeeded' and receipt['status']=='succeeded' and save['purpose']=='create_library_file')
check('file_name_path_identity',save['file_name']==receipt['file_name']==NAME and save['path']==receipt['path']=='/OntoKin/'+NAME and save['local_path']==receipt['local_path']==str(original))
check('stable_library_id',save['library_file_id']==receipt['library_file_id']==expected_id)
check('provider_file_id',save['file_id']==receipt['file_id']==expected_file_id)
check('exact_version',save['current_version_number']==receipt['current_version_number']==receipt['version']==0)
check('receipt_size_hash',all(receipt[k]==v for k,v in expected.items()))
check('receipt_recorded_readback',receipt['readback_byte_equal'] is True and receipt['local_metadata_applied'] is True and save['local_metadata_applied'] is True)
check('receipt_url_binding',receipt['url']=='https://chatgpt.com/library?file_id='+expected_id+'&account_id=personal')
attrs={}
for label,p in [('original',original),('readback',readback)]:
    values={n:os.getxattr(p,n).decode() for n in os.listxattr(p)}
    attrs[label]=values
    check(label+'_library_identity_attributes',values.get('user.library-file-id')==expected_id and values.get('user.library-file-version')=='0')
check('receipt_observed_xattrs',receipt['observed_xattrs'][NAME]==attrs['readback'])
with zipfile.ZipFile(readback) as z:
    check('saved_copy_crc',z.testzip() is None)
    cp=json.loads(z.read('CHECKPOINT.json'))
    check('source_revision_binding',cp['source_commit']==receipt['source_commit']=='ed2fc453042a9f0bc4808c2aea7f015baf1ff73e')
    check('honest_frozen_pending_state',cp['delivery_state']=='early_save_pending' and cp['technical_work_started'] is False)
check('recorded_before_substantial_work',receipt['substantial_work_started_before_confirmation'] is False)
check('original_audit_preserved',prior_path.read_bytes()==prior_bytes)
report={
    'schema':'ontokin.c271.p26.early-saved-audit/1','auditor':'/root/handoff_audit',
    'completed_at_utc':datetime.now(timezone.utc).isoformat(),'passed':all(c['passed'] for c in checks),
    'archive':{'file_name':NAME,**expected,'original_path':str(original),'readback_path':str(readback)},
    'saved_identity':{'library_file_id':expected_id,'file_id':expected_file_id,'version':0,'path':'/OntoKin/'+NAME,'url':receipt['url']},
    'inputs':[{'path':str(p),**identity(b)} for p,b in [(receipt_path,receipt_bytes),(save_path,save_bytes),(prior_path,prior_bytes)]],
    'observed_xattrs':attrs,'checks':checks,'failures':[c for c in checks if not c['passed']],
    'conclusion':'Exact saved-byte equality and stable Library identity/version/path are verified against the successful save result and materialized readback. The source-time early_save_pending field is resolved for this exact early package only.',
    'limits':['No independent remote Library request was made; inspected the recorded successful save result and the separately materialized readback.','No H0/N34/runtime acceptance, later phase completion or parent completion follows from this saved recovery audit.','Substantive-work timing is a recorded receipt fact; this audit does not claim observation of every Director operation.'],
    'original_audit_modified':False,
}
target=OWN/'EARLY-SAVED-AUDIT.json'
assert not target.exists()
target.write_text(json.dumps(report,indent=2)+'\n')
assert prior_path.read_bytes()==prior_bytes
print(json.dumps({'passed':report['passed'],'checks':len(checks),'failures':report['failures'],'saved_identity':report['saved_identity'],'archive':report['archive']},indent=2))
raise SystemExit(0 if report['passed'] else 1)
