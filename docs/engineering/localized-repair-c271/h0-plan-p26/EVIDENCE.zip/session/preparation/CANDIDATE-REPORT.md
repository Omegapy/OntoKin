# P26 preparation candidate001

**Candidate is ready for exact independent review. Preparation has not run.**

The immutable candidate is in `session/preparation/candidate001`. Its [manifest](candidate001/MANIFEST.json) has SHA-256 `942d505da390ee9d9d205fe8d3850d55ea924c87a7a3f4b66cd0b659a95c15d1`. The Director and H0 reviewer must accept this exact candidate before launching its [execution request](candidate001/EXECUTION-REQUEST.json).

## Bound source and preserved installation contents

Both plans contain the unchanged full [P26 source object](../source_preparation/SOURCE-OBJECT.json): root `/workspace/scratch/cf652064a9a1/frozen-source`, commit `ed2fc453042a9f0bc4808c2aea7f015baf1ff73e`, tree `de3bd4fa567c4aeb11364e79d99e646dfde81659`, inventory SHA-256 `87aa2c337ff76e5b3e718d6d7b322d9ae6a3affe5e1bff57a543b61963e5382f`.

Data-only checks re-established the exact source membership and all **627 file bytes, sizes and modes**, before and after candidate construction. Five read-only Git commands confirmed source root, HEAD, tree, clean tracked state and no ordinary untracked files. No project helper was imported to construct or verify the inventory.

The installation plans preserve the P22 `members`, `files`, `directories`, `root_mode`, `purpose` and schema without alteration. Only the source object, current archive descriptor, destination and report path changed. The dependency inventory changes only its archive descriptor.

| Input | Complete archive members checked | Target files | Target directories |
| --- | ---: | ---: | ---: |
| Node candidate | 2 | 2 | 1 |
| C195 readback dependencies | 730 | 24 | 13 |

Both archives were streamed as data without extraction. Every frozen member kind, name, size, SHA-256 and mode matched; complete member sets matched. Archive descriptors were rehashed afterward. Node expands to 126,952,861 bytes; the complete C195 archive expands to 42,685,553 bytes. Only its 24 declared dependency members have destination mappings.

Fresh destinations are `prepared-inputs/node` and `prepared-inputs/readback-dependencies`. The Director created only their empty parent. The candidate binds its actual ancestors and the empty `session/preparation/attempt001` evidence directory. All 24 declared output paths and both destinations were absent at final author inspection.

## Prior reviewed source comparison

The preparer is byte-identical to the P22 reviewed source: 19,788 bytes, SHA-256 `fd4da23dde3cd75a95c3f5edc071028e5884da62932c32cba4be928e72f87bb3`. The provider is also unchanged: 65,533 bytes, SHA-256 `2a8144624ea00f3f350a6b7f482c993665b4049b363b93bc399ed0cd7a14ba78`.

The complete execution-source inventory differs from P22 only through the P25 inspection module and added `tests/test_current_host_rtld_paths_v01.py`. No prior source or receipt was rewritten.

The adapted launcher has the same 9,884-byte length as reviewed P22 candidate003. Its [exact diff](candidate001/LAUNCHER-DIFF.patch) changes only the P22 phase label and evidence schema names to P26. Process ordering, no-replace records, pending-operation accounting, timeout cleanup, report checks and index creation retain the reviewed semantics. Syntax was parsed as data; the launcher was not executed.

## Proposed bounded execution

The request selects the current verified Python bytes with `-I -S -B`, the five-variable clean environment, exact frozen-source cwd, and one unchanged preparer invocation for Node followed by one for dependencies. Each command supplies the independently reviewable external `--plan-sha256` value and `--apply`.

The per-preparer timeout is **120 seconds**. The Director can drive the outer command through a nonblocking tool call with `yield_time_ms=1000`, then poll while retaining progress visibility. This tool-driving note does not add an installation command.

The launcher keeps uncertainty from launch intent through completed wait and report/index verification. It stops on the first failure or unknown outcome without retry. An installation index is created exclusively only after the original report establishes zero-exit `INSTALLED_EXACT`, `apply_requested=true`, `after.state=complete_exact` and zero Node/ldd/checker starts.

## Exact review identities

| Artifact | SHA-256 |
| --- | --- |
| Node plan | `140bf303753ef0559afb252c611d2f4bc9e7d8c7e091b618d2e3e9c03236c974` |
| Dependency plan | `19bb29c9150dd3bd78661bacf9038be23ca6d958fe8ee7a18d24f3ab6fec8694` |
| Dependency inventory | `c8e2817ebb4a39a1bb6c0b100ce903f4ab0ed6d43b988dbdf80744d8b97eaa80` |
| Launcher | `ea1dcfd20838fe5c5a86635fc2c18de816a8cfe3f90abc5621fc3079477a1568` |
| Launch plan | `e75b9f1ff59ae9d97cb23691874943323049eccb8c12d10b907406d65d046141` |
| Execution request | `980737d8f9f3b9fd2f06f04c2d9e2e3ca448906018d0d7835f092a10a71fd5d2` |

[STATIC-CHECKS.json](candidate001/STATIC-CHECKS.json) contains complete descriptors, source differences, archive findings, fresh-path inventory and the Git read evidence.

No preparer, target runtime, Node, ldd, loader, venv, pip, package installation, product test or H0/H1 operation ran during this authoring. These candidates introduce no early-save claim and accept no current-host operational plan, N34, runtime compatibility or parent gate.
