#!/usr/bin/env python3
"""Author P26 preparation candidates using only standard-library data reads."""
from pathlib import Path, PurePosixPath
import ast
import copy
import difflib
import hashlib
import json
import os
import stat
import subprocess
import tarfile
from datetime import datetime, timezone

BASE=Path("/workspace/scratch/cf652064a9a1")
SOURCE=BASE/"frozen-source"
OLD=SOURCE/"docs/engineering/localized-repair-c271/retained-input-p22"
WORK=BASE/"session/preparation"
CANDIDATE=WORK/"candidate001"
ATTEMPT=WORK/"attempt001"
SOURCE_OBJECT=BASE/"session/source_preparation/SOURCE-OBJECT.json"
SOURCE_INVENTORY=BASE/"session/source_preparation/SOURCE-INVENTORY.json"
NODE_ARCHIVE=BASE/"portable-inputs/OntoKin_C271_P05_Node_Candidate_2026-11-20.tar.gz"
DEP_ARCHIVE=SOURCE/"docs/engineering/ownership-recovery-c195/evidence/recorded-evidence.tar.xz"
DESTINATIONS={"NODE":BASE/"prepared-inputs/node","DEPENDENCIES":BASE/"prepared-inputs/readback-dependencies"}
EXPECTED_SOURCE_COMMIT="ed2fc453042a9f0bc4808c2aea7f015baf1ff73e"
EXPECTED_SOURCE_TREE="de3bd4fa567c4aeb11364e79d99e646dfde81659"
EXPECTED_INVENTORY_HASH="87aa2c337ff76e5b3e718d6d7b322d9ae6a3affe5e1bff57a543b61963e5382f"
ENV={"LANG":"C.UTF-8","LC_ALL":"C.UTF-8","PATH":"/usr/bin:/bin","TZ":"UTC","UV_THREADPOOL_SIZE":"2"}

def canonical(value):
    return json.dumps(value,sort_keys=True,separators=(",",":"),ensure_ascii=True,allow_nan=False).encode("ascii")
def write_new(path,value):
    with path.open("xb") as stream:
        stream.write(canonical(value))
    return describe(path)
def write_text_new(path,text):
    with path.open("x") as stream:
        stream.write(text)
def same_stat(x):
    return (x.st_dev,x.st_ino,x.st_size,x.st_mode,x.st_nlink,x.st_mtime_ns,x.st_ctime_ns)
def describe(path):
    p=Path(path)
    assert p.is_absolute() and ".." not in p.parts
    fd=os.open(p,os.O_RDONLY|os.O_NONBLOCK|os.O_NOFOLLOW)
    try:
        before=os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_nlink==1,str(p)
        digest=hashlib.sha256()
        length=0
        while True:
            block=os.read(fd,1024*1024)
            if not block:break
            length+=len(block);digest.update(block)
        assert length==before.st_size and same_stat(before)==same_stat(os.fstat(fd))==same_stat(p.lstat()),str(p)
        return {"path":str(p),"sha256":digest.hexdigest(),"size_bytes":length,"mode":oct(stat.S_IMODE(before.st_mode))}
    finally:os.close(fd)
def binding(d):
    return {k:d[k] for k in ("sha256","size_bytes","mode")}
def bound(d):
    assert describe(d["path"])==d,d["path"]
def load(path,require_canonical=True):
    raw=path.read_bytes();value=json.loads(raw)
    if require_canonical:assert canonical(value)==raw,str(path)
    return value
def norm_member(name):
    assert isinstance(name,str) and name and "\\" not in name
    value=name[:-1] if name.endswith("/") else name
    p=PurePosixPath(value)
    assert not p.is_absolute() and str(p)==value and ".." not in p.parts and value!="."
    return value

CANDIDATE.mkdir(parents=True,exist_ok=False)
ATTEMPT.mkdir(parents=True,exist_ok=False)
assert DESTINATIONS["NODE"].parent.is_dir(),"Director must create the empty prepared-inputs parent first"
assert all(not p.exists() and not p.is_symlink() for p in DESTINATIONS.values())
assert (SOURCE/".git").is_dir() and not (SOURCE/".git").is_symlink()
source=load(SOURCE_OBJECT)
assert source["root"]==str(SOURCE) and source["commit"]==EXPECTED_SOURCE_COMMIT and source["tree"]==EXPECTED_SOURCE_TREE
assert source["inventory"]["path"]==str(SOURCE_INVENTORY) and source["inventory"]["sha256"]==EXPECTED_INVENTORY_HASH
bound(source["inventory"])
inventory=load(SOURCE_INVENTORY)
assert set(inventory)=={"schema","files"} and inventory["schema"]=="ontokin.current-host-readback-source/0.1.0"
assert len(inventory["files"])==627
source_bindings=[]
for name,value in inventory["files"].items():
    d={"path":str(SOURCE/name),**value};bound(d);source_bindings.append(d)

# This independent membership reconstruction reads the source text as AST;
# it does not import or invoke any project helper.
def source_constants(path):
    values={}
    def literal(n):
        if isinstance(n,ast.Constant):return n.value
        if isinstance(n,(ast.Tuple,ast.List)):return tuple(literal(x) for x in n.elts)
        if isinstance(n,ast.Name):return values[n.id]
        raise ValueError
    for n in ast.parse(path.read_text()).body:
        if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
            try:values[n.targets[0].id]=literal(n.value)
            except (KeyError,ValueError):pass
    return {key:values[key] for key in ("SOURCE_TREES","SOURCE_FILES","SOURCE_OPTIONAL")}
constants=source_constants(SOURCE/"prototypes/static_tray_v01/current_host_readback_v01.py")
assert constants==source_constants(SOURCE/"prototypes/static_tray_v01/current_host_inspection_v01.py")
actual=set()
for relative in constants["SOURCE_TREES"]:
    top=SOURCE/relative
    assert top.is_dir() and not top.is_symlink()
    for parent,dirs,files in os.walk(top,followlinks=False):
        for name in dirs:
            p=Path(parent)/name
            assert not p.is_symlink() and name!="__pycache__" and p.is_dir()
        for name in files:
            p=Path(parent)/name
            assert p.suffix not in (".pyc",".pyo") and not p.is_symlink() and stat.S_ISREG(p.lstat().st_mode)
            actual.add(p.relative_to(SOURCE).as_posix())
actual.update(constants["SOURCE_FILES"])
actual.update(x for x in constants["SOURCE_OPTIONAL"] if (SOURCE/x).exists())
assert actual==set(inventory["files"])

git_env=ENV|{"GIT_CONFIG_NOSYSTEM":"1","GIT_CONFIG_GLOBAL":os.devnull,"GIT_TERMINAL_PROMPT":"0","GIT_ATTR_NOSYSTEM":"1",
             "GIT_OPTIONAL_LOCKS":"0","GIT_NO_REPLACE_OBJECTS":"1","GIT_NO_LAZY_FETCH":"1","GIT_CEILING_DIRECTORIES":str(SOURCE.parent)}
git_commands=[]
for args,expected in [
    (["rev-parse","--show-toplevel"],str(SOURCE)),
    (["rev-parse","--verify","HEAD^{commit}"],EXPECTED_SOURCE_COMMIT),
    (["rev-parse","--verify",EXPECTED_SOURCE_COMMIT+"^{tree}"],EXPECTED_SOURCE_TREE),
    (["status","--porcelain=v1","--untracked-files=no"],""),
    (["ls-files","--others","--exclude-standard","-z"],"")]:
    argv=["git","-c","core.fsmonitor=false","-C",str(SOURCE),*args]
    r=subprocess.run(argv,env=git_env,capture_output=True,timeout=10)
    assert r.returncode==0 and r.stdout.decode().strip()==expected,(args,r.stdout,r.stderr)
    git_commands.append({"argv":argv,"environment":git_env,"exit_code":r.returncode,"stdout":r.stdout.decode(),"stderr":r.stderr.decode()})

old_inventory=load(OLD/"preparation/SOURCE-INVENTORY.json")["files"]
source_delta={"added":sorted(set(inventory["files"])-set(old_inventory)),
              "removed":sorted(set(old_inventory)-set(inventory["files"])),
              "changed":[{"path":n,"P22":old_inventory[n],"P26":inventory["files"][n]} for n in old_inventory if n in inventory["files"] and old_inventory[n]!=inventory["files"][n]]}
assert source_delta["added"]==["tests/test_current_host_rtld_paths_v01.py"] and source_delta["removed"]==[]
assert [r["path"] for r in source_delta["changed"]]==["prototypes/static_tray_v01/current_host_inspection_v01.py"]
preparer=describe(SOURCE/"tools/prepare_current_host_readback.py")
provider=describe(SOURCE/"prototypes/static_tray_v01/current_host_readback_v01.py")
assert binding(preparer)==old_inventory["tools/prepare_current_host_readback.py"]
assert binding(provider)==old_inventory["prototypes/static_tray_v01/current_host_readback_v01.py"]

readiness=load(BASE/"session/readiness/run001.stdout.json",False)
pyrow=next(r for r in readiness["observations"] if r["role"]=="python")
python=describe(Path(pyrow["measured"]["path"]))
assert binding(python)==pyrow["expected"] and pyrow["matched"]
git=describe(Path("/usr/bin/git"))
plans={}
archive_reviews=[]
plan_deltas={}
for name,archive in [("NODE",NODE_ARCHIVE),("DEPENDENCIES",DEP_ARCHIVE)]:
    old=load(OLD/("preparation/"+name+"-INSTALL-PLAN.json"))
    current=copy.deepcopy(old)
    current["source"]=copy.deepcopy(source)
    current["archive"]=describe(archive)
    assert current["archive"]["sha256"]==old["archive"]["sha256"]
    assert current["archive"]["size_bytes"]==old["archive"]["size_bytes"]
    current["destination"]=str(DESTINATIONS[name])
    current["report"]=str(ATTEMPT/(name+"-INSTALL-REPORT.json"))
    assert {k for k in old if old[k]!=current[k]}=={"source","archive","destination","report"}
    assert all(current[k]==old[k] for k in ("members","files","directories","root_mode","purpose","schema"))
    d=write_new(CANDIDATE/(name+"-INSTALL-PLAN.json"),current)
    plans[name]={"value":current,"descriptor":d}
    plan_deltas[name]={"changed_top_level_keys":["archive","destination","report","source"],
                       "immutable_fields_equal":["members","files","directories","root_mode","purpose","schema"],
                       "archive_changed_fields":[k for k in old["archive"] if old["archive"][k]!=current["archive"][k]]}
    seen=set();expanded=0;mapped=0
    with tarfile.open(archive,"r:*") as tar:
        for member in tar:
            n=norm_member(member.name)
            assert n not in seen and len(seen)<32768
            seen.add(n);expected=current["members"][n]
            assert (member.isfile() or member.isdir()) and not member.sparse
            kind="file" if member.isfile() else "directory"
            assert expected["kind"]==kind and expected["size_bytes"]==member.size and expected["mode"]==oct(member.mode)
            expanded+=member.size
            assert expanded<=1024*1024*1024
            if kind=="file":
                digest=hashlib.sha256();length=0
                with tar.extractfile(member) as stream:
                    for chunk in iter(lambda:stream.read(1024*1024),b""):
                        length+=len(chunk);assert length<=member.size;digest.update(chunk)
                assert length==member.size and digest.hexdigest()==expected["sha256"]
            else:assert expected["sha256"] is None and expected["size_bytes"]==0
            if expected["target"] is not None:mapped+=1
    assert seen==set(current["members"])
    bound(current["archive"])
    archive_reviews.append({"name":name,"archive":current["archive"],"full_members_verified":len(seen),
                            "expanded_bytes_verified":expanded,"mapped_members":mapped,
                            "target_files":len(current["files"]),"target_directories":len(current["directories"]),
                            "extraction_performed":False,"all_frozen_member_bindings_equal":True})
dependency_inventory=load(OLD/"preparation/DEPENDENCY-INVENTORY.json")
dependency_inventory["archive"]=copy.deepcopy(plans["DEPENDENCIES"]["value"]["archive"])
assert dependency_inventory["files"]==plans["DEPENDENCIES"]["value"]["files"]
assert dependency_inventory["directories"]==plans["DEPENDENCIES"]["value"]["directories"]
dependency_descriptor=write_new(CANDIDATE/"DEPENDENCY-INVENTORY.json",dependency_inventory)

old_launcher=OLD/"session-tools/run_preparation.py"
old_launcher_raw=old_launcher.read_bytes()
assert hashlib.sha256(old_launcher_raw).hexdigest()=="676c24af7e0402ccc2971bc41a8a25e4409ac8c47eeb8b914cb45079e24a69d1"
launcher_text=old_launcher_raw.decode().replace("P22","P26").replace("ontokin.c271.p22-","ontokin.c271.p26-")
ast.parse(launcher_text)
launcher_path=CANDIDATE/"run_preparation.py"
write_text_new(launcher_path,launcher_text)
launcher=describe(launcher_path)
launcher_diff="".join(difflib.unified_diff(old_launcher_raw.decode().splitlines(keepends=True),launcher_text.splitlines(keepends=True),
                                        fromfile="P22/run_preparation.py",tofile="P26/candidate001/run_preparation.py"))
write_text_new(CANDIDATE/"LAUNCHER-DIFF.patch",launcher_diff)

old_launch=load(OLD/"preparation/LAUNCH-PLAN.json")
launch=copy.deepcopy(old_launch)
launch["schema"]="ontokin.c271.p26-preparation-launch/1"
launch["recorded_at_utc"]=datetime.now(timezone.utc).isoformat()
launch["source"]=copy.deepcopy(source)
launch["source_file_count"]=len(inventory["files"])
launch["cwd"]=str(SOURCE)
launch["preparer"]=preparer
launch["python"]=python
launch["python_version"]=readiness["python_version"]
launch["git"]=git
launch["environment"]=ENV
launch["per_command_timeout_seconds"]=120
for c in launch["commands"]:
    name=c["name"];selected=plans[name]
    c["plan"]=selected["descriptor"]
    c["destination"]=str(DESTINATIONS[name])
    c["argv"]=[python["path"],"-I","-S","-B",preparer["path"],"--plan",c["plan"]["path"],"--plan-sha256",c["plan"]["sha256"],"--apply"]
    c["fresh_outputs"]=[str(ATTEMPT/Path(p).name) for p in c["fresh_outputs"]]
    c["process_journal"]={k:str(ATTEMPT/Path(v).name) for k,v in c["process_journal"].items()}
launch["outer_outputs"]={k:str(ATTEMPT/Path(v).name) for k,v in launch["outer_outputs"].items()}
ancestors={}
for start in (ATTEMPT,DESTINATIONS["NODE"].parent):
    for p in (start,*start.parents):
        st=p.lstat()
        assert stat.S_ISDIR(st.st_mode) and not stat.S_ISLNK(st.st_mode)
        ancestors[str(p)]={"device":st.st_dev,"inode":st.st_ino,"mode":oct(stat.S_IMODE(st.st_mode))}
launch["destination_and_evidence_ancestors"]=ancestors
boundary=launch["execution_boundary"]
boundary["later_h0_plan_schema"]="ontokin.current-host-readback-inspection-plan/0.1.4"
boundary["later_h0_runtime_profile"]="linux-glibc-declared-python-origin-rpath-libc-plt-static-tls-rtld-paths-v1"
boundary["approved_current_host"]="No accepted H0 plan or qualified runtime follows from these preparation candidates."
launch["stop"]="This controller stops after two preparations or the first failure/unknown; preserve evidence for independent outcome review. No H0/H1, target execution or second phase is launched."
all_fresh=[p for c in launch["commands"] for p in c["fresh_outputs"]]+list(launch["outer_outputs"].values())
assert len(all_fresh)==len(set(all_fresh))
assert all(not Path(p).exists() and not Path(p).is_symlink() for p in all_fresh)
assert [c["name"] for c in launch["commands"]]==["NODE","DEPENDENCIES"]
assert all(plans[c["name"]]["value"]["source"]==launch["source"] for c in launch["commands"])
launch_descriptor=write_new(CANDIDATE/"LAUNCH-PLAN.json",launch)

request=load(OLD/"preparation/EXECUTION-REQUEST.json",False)
request["schema"]="ontokin.c271.p26-execution-request/1"
request["launch_plan"]=launch_descriptor
request["launcher"]=launcher
request["cwd"]=str(BASE)
request["argv"]=[python["path"],"-I","-S","-B",launcher["path"],"--launch-plan",launch_descriptor["path"],"--launch-sha256",launch_descriptor["sha256"]]
request["environment"]=ENV
request["stdout"]=launch["outer_outputs"]["stdout"];request["stderr"]=launch["outer_outputs"]["stderr"]
request["invocation_count"]=1
request_descriptor=write_new(CANDIDATE/"EXECUTION-REQUEST.json",request)

for d in source_bindings:bound(d)
bound(source["inventory"]);bound(preparer);bound(provider);bound(python);bound(git)
for row in plans.values():bound(row["descriptor"]);bound(row["value"]["archive"])

static={
 "schema":"ontokin.c271.p26-preparation-candidate-static/1","passed":True,
 "candidate":"candidate001","recorded_at_utc":datetime.now(timezone.utc).isoformat(),
 "status":"draft_awaiting_director_and_independent_exact_candidate_review",
 "source":source,"source_files_verified":627,"membership_matches_source_constants":True,
 "source_delta_since_P22":source_delta,"P22_preparer_unchanged":True,"P22_provider_unchanged":True,
 "preparer":preparer,"provider":provider,"git":git,"python":python,
 "plan_changes":plan_deltas,"archive_reviews":archive_reviews,"source_git_reads":git_commands,
 "launcher_basis":{"original":describe(old_launcher),"adapted":launcher,
                   "changes":"Only P22 to P26 phase text and ontokin.c271.p22- to p26- evidence schema labels.",
                   "AST_parse":"passed; no execution","command_and_process_control_semantics_unchanged":True},
 "canonical_documents":[row["descriptor"] for row in plans.values()]+[dependency_descriptor,launch_descriptor,request_descriptor],
 "fresh_outputs_absent":all_fresh,"fresh_destinations_absent":[str(p) for p in DESTINATIONS.values()],
 "per_command_timeout_seconds":120,
 "nonblocking_execution_note":"Director may use exec_command yield_time_ms=1000 for the reviewed outer command and then poll; the unchanged controller's child wait remains bounded at 120 seconds. This is a tool-driving note, not an additional command.",
 "project_imports":[],"preparer_invocations":0,"target_starts":{"node":0,"ldd":0,"direct_loader":0,"checkers":0},
 "package_installations":0,"venv_commands":0,"pip_commands":0,"tests":0,
 "execution_authorization":"No launch authorized by this self-authored candidate; exact request requires Director and independent h0_review acceptance.",
 "report_index_rule":"Controller creates each exclusive inspection-installation index only after zero-exit preparer report states INSTALLED_EXACT, apply_requested true, after.complete_exact and zero Node/ldd/checker starts.",
 "limits":["Data-only source/JSON/archive/metadata checks; all original plans, source and receipts preserved.",
           "No H0 plan adoption, N34 acceptance, runtime compatibility, H1, original-seven/full routine, integration or parent completion.",
           "No early-recovery prerequisite claim is introduced by these candidates."]
}
static_descriptor=write_new(CANDIDATE/"STATIC-CHECKS.json",static)
manifest={
 "schema":"ontokin.c271.p26-preparation-candidate-manifest/1","candidate":"candidate001",
 "state":"draft_awaiting_independent_review","artifacts":[describe(p) for p in sorted(CANDIDATE.iterdir()) if p.is_file()],
 "source":source,"execution_request":request_descriptor,
 "unchanged_P22_plan_fields":["members","files","directories","root_mode","purpose","schema"],
 "preparation_executed":False,"next_action":"Independent review of this exact immutable candidate before any one-shot launch."
}
manifest_descriptor=write_new(CANDIDATE/"MANIFEST.json",manifest)
print(json.dumps({"candidate":str(CANDIDATE),"passed":True,"execution_authorized":False,
                 "source_files":627,"archive_members":[r["full_members_verified"] for r in archive_reviews],
                 "manifest":manifest_descriptor,"request":request_descriptor,"launch":launch_descriptor},indent=2))
