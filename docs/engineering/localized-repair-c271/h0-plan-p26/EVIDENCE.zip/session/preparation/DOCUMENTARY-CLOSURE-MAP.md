# P26 canonical update and delivery map

Read-only advice against C271 branch `ed2fc453042a9f0bc4808c2aea7f015baf1ff73e` and main instructions `e43cc6c5777874101a40559e4058ad6826b07e51`. Canonical records were not edited. P26 preparation candidate001 remains frozen separately.

## Exact fields

| Record and path | P26 action |
| --- | --- |
| `task.json#/prior_session_phases`, `#/prior_phase_deliveries` | Append exact existing P25 `session_phase` and `delivery` objects before replacing the current objects; preserve their source-time pending fields. |
| `task.json#/phase_reconciliations` | Append P25 delivery-only resolution linked to the exact P25 receipt, matching live markers and P26 startup reconciliation. No parent gate promotion. |
| `task.json#/owner`, `#/session_phase` | Use the actual P26 token and bounded scope. Record starting head, current main, actual early receipt, completed/unrun gates, workers, known/unknown operations, outcome/review paths, technical stop and conditional ownership-release rule. Preserve the three historical unknowns verbatim. |
| `task.json#/status`, `#/next_action`, `#/blocked_reason` | Keep parent open. A concrete observed obstacle may use `blocked` with its precise reason/action under PROTOCOL §3; a planned pause alone is not a blocker. Otherwise retain `in_progress`. |
| `task.json#/blocked_reason_history`, `#/prior_h0_constraints` | Append the displaced P25 reason/constraint before replacing current values. Never revise earlier failure meanings. |
| `task.json#/remaining_h0_constraint` | Describe only the actual P26 stopping point. Keep accepted plan, H0 validation, H1 observation and runtime qualification distinct; set acceptance fields only where exact review/execution supports them. |
| `task.json#/checks`, `#/requirements/*/evidence`, `#/completion/evidence` | Append actual source-bound P26 checks/reviews/outcome and early/final delivery evidence. R03 evidence may advance without R03 completion; R05 phase delivery does not complete parent R05. |
| `task.json#/delivery` | New P26 partial-delivery state, actual saved identities when known, packaged source revision/tree, receipt path and explicit remaining gates. Never invent a future commit, save or terminal result. |
| `CURRENT.json#/snapshot_date`, `#/observed_main`, `#/next_action` | Explicit UTC timestamp, freshly observed main and one executable remaining action with P26 evidence sources. Keep `latest_task`/`active_task` as C271. |
| `CURRENT.json#/latest_recovery`, `#/previous_recovery`, `#/older_recoveries` | Promote the actual verified P26 early save; preserve displaced full objects, deduplicating only identical entries. |
| `CURRENT.json#/pending_phase_delivery` | Preserve the old P25 object first, e.g. new `prior_p26_start_pending_delivery`; then mirror current P26 delivery. This historical copy is not another active ledger. |
| `CURRENT.json#/latest_handoff`, `#/previous_handoff`, `#/older_handoffs` | Leave the P25 saved handoff latest until P26 save is confirmed. Then promote actual P26, move P25 to previous, preserve displaced history. |
| `CURRENT.json#/boundaries` | At most one concise P26 scope/outcome statement; preserve existing historical entries. |

Keep R01/R02 `done`, R03/R04/R05 `not_done`, P01 `done`, P02 `in_progress`; keep PR274 draft/open/unmerged and issue273 open. Preserve original task authorization, base SHA, all implementation identities and `completion.merge_commit=null`. Add continuation authority inside the P26 phase object rather than replacing the original C271 authorization. No STATUS/main-lease edit is selected.

Append a short P26 section to REQUIREMENTS/PLAN stating actual scope, stopping point, evidence and remaining gates; do not rewrite their historical sections.

## If the native-root prerequisite fails

Stop P26 technical work at the first established mismatch and preserve the precise failed predicate, exact versioned source, current-host descriptors and unrun remainder. Do not turn this into an automatic phase to accommodate another disposable host.

Suggested first remaining action: **review the saved mismatch against the adopted H0 contract and identify the exact portable input or durable source/contract decision needed to satisfy it. Reconstruct only a necessary, already justified pinned input on the next new host. If no such route is established, retain the concrete prerequisite blocker and name the missing artifact/capability.**

A representation change, input substitution or broader compatibility project is not silently authorized by this diagnosis. A later separately declared scope must address a durable project requirement. Main EPHEMERAL-HOST requires one concrete blocker when required inputs/capabilities are unavailable, forbids recovery of old hosts and repeated host profiling, and treats environment setup as a prerequisite. Old paths and successful installation receipts remain historical evidence.

## Three identities and the freeze boundary

Do not conflate these:

1. **P26 execution source:** frozen `ed2fc453...` and its exact source object/inventory. New preparation plans and H0 retain it even when documentary commits advance.
2. **Packaged source A:** the new reviewed P26 technical/documentary commit whose snapshots enter the final ZIP.
3. **Receipt commit B:** the later receipt-only commit, normally with parent A, containing saved ZIP/prompt identities and source-time terminal-pending state.

Use `task.delivery.core_source_commit/core_source_tree` and `CURRENT.latest_handoff.source_revision` for A. Use the phase's explicit `execution_source` for the unchanged operational object. The repository receipt cannot know its own future B identity: put observed B/tree/parent in the later external receipt. Matching terminal evidence then binds that external receipt's actual saved identity and resolves only P26 delivery/ownership pending fields. Do not rebuild the ZIP to insert B or its future save receipt.

## Terminal publication can use comments

**PROTOCOL and HANDOFF require verified publication, readback and ownership release; neither requires PR/issue bodies.** New top-level PR274 conversation and issue273 comments can therefore carry matching P26 markers while preserving the nearly full bodies and all P25 markers. Record this chosen location and release condition in P26 before publishing.

Use the same compact `ONTOKIN-C271-P26-TERMINAL` JSON marker in both comments. Bind phase/parent states, packaged A/tree, receipt B/tree, ZIP and external-receipt stable IDs/version/bytes/SHA-256, matching prompt identities, actual owner, conditional release, current unknown operations and the exact next action. Point to the external receipt for detailed checks/failures/history. State explicitly that the marker resolves P26 only and preserves P25 and historical unknowns.

Keep comment-specific IDs/URLs outside the matching marker. Read both returned comments back independently, compare exact marker content and artifact identities, then record their IDs/URLs and observed release. A successful first comment alone does not satisfy the two-copy condition. After an uncertain write, inspect actual comments before retrying. Preserve final readback evidence separately; do not alter the frozen ZIP.

## Required finish

Independent exact outcome/canonical review; applicable workflow and documentation checks; receipt-listed/staged-file comparison including ignored evidence; frozen expected-head branch publication and exact readback. Preserve failures and all unavailable/unrun checks.

Verify the required HANDOFF root files, safe unique ZIP paths, complete size/hash manifest, fresh extraction and declared-source equality; include current-host-only instructions, portable reconstruction inputs and unique unpublished recovery bytes. Freeze once, save ZIP and matching prompts, verify actual returned bytes/identities, save/publish the separate receipt, reconcile final comments/ownership/refs, then stop. No merge, branch deletion or parent closure follows from this partial handoff.
