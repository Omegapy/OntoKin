"""Capture one independently reviewed fixed raw reader; preserve every attempt."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import selectors
import signal
import stat
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
PLAN = HERE / 'cache-candidate001/CACHE-LAUNCH-PLAN.json'
REVIEW = HERE.parent / 'h0_review/CACHE-SHARED-REVIEW.json'
ATTEMPT = HERE / 'cache-run001.attempt.json'
STARTED = HERE / 'cache-run001.started.json'

def digest(path):
    hasher = hashlib.sha256()
    with Path(path).open('rb') as stream:
        count = 0
        while True:
            block = stream.read(1024 * 1024)
            if not block:
                break
            count += len(block)
            require(count <= 172 * 1024 * 1024, 'Capture input exceeds bounded size')
            hasher.update(block)
    return hasher.hexdigest()

def require(condition, message):
    if not condition:
        raise RuntimeError(message)

def exclusive(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def main():
    require(len(sys.argv) == 3, 'Expected external plan and review SHA-256 values')
    plan_hash, review_hash = sys.argv[1:]
    require(digest(PLAN) == plan_hash and digest(REVIEW) == review_hash, 'Plan/review changed')
    plan = json.loads(PLAN.read_text())
    review = json.loads(REVIEW.read_text())
    require(review['verdict'] == 'accepted_for_one_bounded_cache_shared_observation', 'Review not accepted')
    require(review['plan_sha256'] == plan_hash, 'Review plan mismatch')
    require(review['reader_sha256'] == digest(plan['reader']['path']) == plan['reader']['sha256'], 'Reader mismatch')
    require(review['capture_sha256'] == digest(__file__), 'Capture mismatch')
    early = json.loads((HERE.parent / 'EARLY-RECOVERY-RECEIPT.json').read_text())
    require(early['status'] == 'succeeded' and early['readback_byte_equal'], 'Early recovery unconfirmed')
    python = {**plan['root_requests'][0], 'mode': '0o755'}
    executable = Path(plan['argv'][0])
    require(str(executable.resolve()) == python['path'], 'Python path mismatch')
    require(executable.stat().st_size == python['bytes'] and oct(stat.S_IMODE(executable.stat().st_mode)) == python['mode'], 'Python size/mode mismatch')
    require(digest(executable) == python['sha256'], 'Python hash mismatch')
    require(plan['environment'] == {'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8','TZ':'UTC','UV_THREADPOOL_SIZE':'2'}, 'Environment mismatch')
    require(plan['supervision']['wall_timeout_seconds'] == 30, 'Unexpected wall bound')
    require(plan['supervision']['hard_address_space_limit_bytes'] == 256 * 1024 * 1024, 'Unexpected memory bound')
    require(plan['supervision']['stdout_limit_bytes'] == 8 * 1024 * 1024 and plan['supervision']['stderr_limit_bytes'] == 512 * 1024, 'Unexpected output bounds')
    for row in [*plan['root_capture_references'], *plan['root_requests']]:
        require(Path(row['path']).is_file() and Path(row['path']).stat().st_size == row['bytes'] and digest(row['path']) == row['sha256'], 'Root input/evidence changed')
    paths = {('capture_receipt' if name == 'receipt' else name):Path(path) for name,path in plan['expected_outputs'].items()}
    for path in [ATTEMPT, STARTED, *paths.values()]:
        require(not path.exists() and not path.is_symlink(), 'Existing attempt/output; reconcile without retry')
    record = {'schema':'ontokin.c271.p26-cache-shared-capture/1','plan_sha256':plan_hash,
              'review_sha256':review_hash,'reader_sha256':plan['reader']['sha256'],
              'capture_sha256':digest(__file__),'started_at_utc':utc(),
              'argv':plan['argv'],'cwd':plan['cwd'],'environment':plan['environment'],
              'status':'launch_intent','direct_reader_starts':0,'target_starts':0,
              'unknown_operation':False,'memory_limit_bytes':256 * 1024 * 1024,
              'output_limits':{'stdout':8 * 1024 * 1024,'stderr':512 * 1024},'wall_timeout_seconds':30,
              'root_inputs_rehashed_before':True}
    exclusive(ATTEMPT, record)
    def restrict():
        resource.setrlimit(resource.RLIMIT_AS, (256 * 1024 * 1024, 256 * 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_FSIZE, (8 * 1024 * 1024, 8 * 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_CPU, (26, 26))
    process = None
    started = time.monotonic()
    try:
        with paths['stdout'].open('xb') as out, paths['stderr'].open('xb') as err:
            process = subprocess.Popen(plan['argv'], cwd=plan['cwd'], env=plan['environment'],
                                       stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                       start_new_session=True, preexec_fn=restrict)
            record.update(pid=process.pid, direct_reader_starts=1, status='reader_started')
            exclusive(STARTED, {'pid':process.pid,'started_at_utc':utc(),'attempt_sha256':digest(ATTEMPT)})
            streams = {'stdout':(process.stdout,out), 'stderr':(process.stderr,err)}
            counts = dict.fromkeys(streams,0)
            deadline = time.monotonic() + 30
            stopped = False
            try:
                with selectors.DefaultSelector() as selector:
                    for name,(pipe,writer) in streams.items():
                        os.set_blocking(pipe.fileno(),False)
                        selector.register(pipe,selectors.EVENT_READ,(name,writer))
                    while selector.get_map():
                        remaining = deadline - time.monotonic()
                        if remaining <= 0:
                            record['timed_out'] = True
                            stopped = True
                            break
                        for key,_mask in selector.select(min(remaining,0.1)):
                            name,writer = key.data
                            room = record['output_limits'][name] - counts[name]
                            data = os.read(key.fileobj.fileno(),min(65536,room + 1))
                            if not data:
                                selector.unregister(key.fileobj)
                                continue
                            writer.write(data[:room])
                            counts[name] += min(len(data),room)
                            if len(data) > room:
                                record['output_limit_exceeded'] = name
                                stopped = True
                                break
                        if stopped:
                            break
                if stopped:
                    os.killpg(process.pid,signal.SIGKILL)
                    code = process.wait(timeout=5)
                else:
                    try:
                        code = process.wait(timeout=max(0.001,deadline-time.monotonic()))
                    except subprocess.TimeoutExpired:
                        record['timed_out'] = True
                        os.killpg(process.pid,signal.SIGKILL)
                        code = process.wait(timeout=5)
            finally:
                for pipe,_writer in streams.values():
                    pipe.close()
            record.update(returncode=code,status='completed',wait_completed=True,retained_output_bytes=counts)
    except Exception as exc:
        record.update(status='capture_failure', error={'type':type(exc).__name__,'message':str(exc)})
        if process is not None and process.poll() is None:
            record['unknown_operation'] = True
            try:
                os.killpg(process.pid, signal.SIGKILL)
                record['returncode'] = process.wait(timeout=5)
                record.update(unknown_operation=False, wait_completed=True)
            except Exception as cleanup:
                record['cleanup_error'] = {'type':type(cleanup).__name__,'message':str(cleanup)}
    record.update(finished_at_utc=utc(), elapsed_seconds=time.monotonic()-started)
    record['outputs'] = {name:{'path':str(path),'bytes':path.stat().st_size,'sha256':digest(path)}
                         for name,path in paths.items() if name != 'capture_receipt' and path.is_file()}
    if record.get('returncode') == 0 and record['status'] == 'completed':
        try:
            raw = json.loads(paths['stdout'].read_text())
            require(raw['status'] == 'complete_conditional_cache_observation', 'Raw reader did not complete')
            require(all(row['expected_pin_matches'] is not False for row in raw['observations']), 'Selected libc/loader pin mismatch')
            require(not record.get('output_limit_exceeded'), 'Output limit exceeded')
            for row in [*plan['root_capture_references'], *plan['root_requests']]:
                require(Path(row['path']).stat().st_size == row['bytes'] and digest(row['path']) == row['sha256'], 'Root input/evidence changed after observation')
            record['root_inputs_rehashed_after'] = True
            require(paths['stderr'].stat().st_size == 0, 'Reader stderr not empty')
            record['raw_observation_complete'] = True
        except Exception as exc:
            record.update(status='capture_validation_failure',error={'type':type(exc).__name__,'message':str(exc)})
    exclusive(paths['capture_receipt'],record)
    print(json.dumps({key:record.get(key) for key in ('status','returncode','raw_observation_complete','direct_reader_starts','target_starts','unknown_operation','elapsed_seconds')}))
    return 0 if record.get('raw_observation_complete') and not record.get('timed_out') else 1

if __name__ == '__main__':
    raise SystemExit(main())
