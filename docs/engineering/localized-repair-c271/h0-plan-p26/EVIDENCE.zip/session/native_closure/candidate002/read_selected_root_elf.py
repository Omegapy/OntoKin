#!/usr/bin/env python3
"""Unexecuted candidate: raw selected Python/Node ELF and fixed kernel witnesses.

Stream-hash only the two named files and pread bounded ELF metadata ranges.
Never execute either target, import project code or ctypes, invoke subprocesses,
scan directories, read dependencies, write files, or emit a policy verdict.
"""
import hashlib
import json
import os
import signal
import stat
import struct
import sys
import time

TARGETS = (
    "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12",
    "/workspace/scratch/cf652064a9a1/prepared-inputs/node/bin/node",
)
EXPECTED_PINS = {
    TARGETS[0]: {"bytes": 30894944, "sha256": "fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7", "mode": "0o755"},
    TARGETS[1]: {"bytes": 126951512, "sha256": "acbe4b8d9153b841ed0697cbfc4f93e767386620edb745ab9358306c0a6f31aa", "mode": "0o755"},
}
MAX_FILE_BYTES = 160 * 1024 * 1024
MAX_TOTAL_BYTES = 200 * 1024 * 1024
MAX_RANGE_READ_BYTES = 16 * 1024 * 1024
MAX_RANGE_READ_TOTAL = 32 * 1024 * 1024
RANGE_READ_TOTAL = 0
MAX_OUTPUT_BYTES = 512 * 1024
MAX_PROGRAM_HEADERS = 4096
MAX_DYNAMIC_ENTRIES = 8192
MAX_STRING_BYTES = 4096
DEADLINE = time.monotonic() + 25
TAG_NAMES = {
    0: "DT_NULL", 1: "DT_NEEDED", 5: "DT_STRTAB", 10: "DT_STRSZ",
    14: "DT_SONAME", 15: "DT_RPATH", 16: "DT_SYMBOLIC",
    22: "DT_TEXTREL", 24: "DT_BIND_NOW", 29: "DT_RUNPATH", 30: "DT_FLAGS",
    0x6FFFFEFB: "DT_DEPAUDIT", 0x6FFFFEFC: "DT_AUDIT",
    0x6FFFFFFB: "DT_FLAGS_1", 0x7FFFFFFD: "DT_AUXILIARY",
    0x7FFFFFFF: "DT_FILTER",
}
STRING_TAGS = {1, 14, 15, 29, 0x6FFFFEFB, 0x6FFFFEFC, 0x7FFFFFFD, 0x7FFFFFFF}


def bounded():
    if time.monotonic() > DEADLINE:
        raise TimeoutError("collector 25-second deadline")


def alarm(_signum, _frame):
    raise TimeoutError("collector 25-second alarm")


def identity(st):
    return {"dev": st.st_dev, "ino": st.st_ino, "mode": st.st_mode,
            "nlink": st.st_nlink, "uid": st.st_uid, "gid": st.st_gid,
            "size": st.st_size, "mtime_ns": st.st_mtime_ns,
            "ctime_ns": st.st_ctime_ns}


def component_observations(path):
    rows = []
    current = ""
    for part in path.split("/")[1:]:
        bounded()
        current += "/" + part
        st = os.lstat(current)
        rows.append({"path": current, "identity": identity(st)})
        if stat.S_ISLNK(st.st_mode):
            raise ValueError("fixed target has symlink component: " + current)
        if current != path and not stat.S_ISDIR(st.st_mode):
            raise ValueError("fixed target has non-directory parent: " + current)
    return rows


def raw_elf(fd, file_size, result):
    def bounds(offset, size):
        bounded()
        if offset < 0 or size < 0 or offset > file_size or size > file_size - offset:
            raise ValueError("ELF range outside measured file")

    def span(offset, size):
        global RANGE_READ_TOTAL
        bounds(offset, size)
        if size > MAX_RANGE_READ_BYTES or RANGE_READ_TOTAL + size > MAX_RANGE_READ_TOTAL:
            raise ValueError("ELF range-read byte budget exceeded")
        raw = os.pread(fd, size, offset)
        RANGE_READ_TOTAL += len(raw)
        if len(raw) != size:
            raise ValueError("short ELF metadata range read")
        return raw

    ident = span(0, 16)
    if ident[:7] != b"\x7fELF\x02\x01\x01":
        raise ValueError("reader supports ELF64 little-endian version 1 only")
    header = struct.unpack("<HHIQQQIHHHHHH", span(16, 48))
    etype, machine, version, entry, phoff, shoff, flags, ehsize, phsize, phnum, shsize, shnum, shstr = header
    if ehsize != 64 or phsize != 56 or not 0 < phnum <= MAX_PROGRAM_HEADERS:
        raise ValueError("unsupported or oversized ELF program-header layout")
    span(phoff, phsize * phnum)
    ph = []
    for i in range(phnum):
        ptype, pflags, offset, vaddr, paddr, filesz, memsz, align = struct.unpack(
            "<IIQQQQQQ", span(phoff + i * phsize, phsize))
        bounds(offset, filesz)
        ph.append({"index": i, "type": ptype, "flags": pflags, "offset": offset,
                   "vaddr": vaddr, "paddr": paddr, "filesz": filesz,
                   "memsz": memsz, "align": align})
    result.update({"elf_class": 64, "byte_order": "little", "osabi": ident[7],
              "abi_version": ident[8], "elf_ident_hex": ident.hex(), "type": etype,
              "machine": machine, "version": version, "entry": entry,
              "header_flags": flags, "program_headers": ph,
              "pt_interp": [], "dynamic_entries": [], "dynamic_strings": [],
              "dt_needed": [], "dt_soname": [], "dt_rpath": [], "dt_runpath": [],
              "dt_flags": [], "dt_flags_1": [], "review_relevant_tags": []})
    for p in ph:
        if p["type"] == 3:
            if p["filesz"] > MAX_STRING_BYTES:
                raise ValueError("PT_INTERP exceeds reader string bound")
            raw = span(p["offset"], p["filesz"])
            result["pt_interp"].append({"program_header_index": p["index"],
                "raw_hex": raw.hex(), "ends_with_nul": raw.endswith(b"\x00"),
                "text": raw[:-1].decode("ascii") if raw.endswith(b"\x00") else None})
    dyn = [p for p in ph if p["type"] == 2]
    if not dyn:
        result["pt_dynamic_present"] = False
        return result
    if len(dyn) != 1:
        raise ValueError("multiple PT_DYNAMIC segments require separate review")
    p = dyn[0]
    result["pt_dynamic_present"] = True
    if p["filesz"] % 16 or p["filesz"] // 16 > MAX_DYNAMIC_ENTRIES:
        raise ValueError("unsupported or oversized dynamic segment")
    entries = result["dynamic_entries"]
    for i in range(p["filesz"] // 16):
        tag, value = struct.unpack("<qQ", span(p["offset"] + 16 * i, 16))
        entries.append({"index": i, "tag": tag, "tag_hex": hex(tag),
                        "name": TAG_NAMES.get(tag), "value": value})
        if tag == 0:
            break
    if not entries or entries[-1]["tag"] != 0:
        raise ValueError("no DT_NULL within bounded dynamic segment")
    result["dynamic_segment_capacity_entries"] = p["filesz"] // 16
    result["entries_after_first_dt_null_not_interpreted"] = p["filesz"] // 16 - len(entries)
    string_entries = [e for e in entries if e["tag"] in STRING_TAGS]
    if string_entries:
        addresses = [e["value"] for e in entries if e["tag"] == 5]
        sizes = [e["value"] for e in entries if e["tag"] == 10]
        if len(addresses) != 1 or len(sizes) != 1:
            raise ValueError("string-bearing dynamic tags need unique DT_STRTAB/DT_STRSZ")
        address, size = addresses[0], sizes[0]
        result["dynamic_string_table"] = {"vaddr": address, "size": size}
        # Match the adopted P10 file-backed interval rule. Several coincident
        # segments are allowed only when each interval names one file offset.
        if not 0 < size <= 4 * 1024 * 1024:
            raise ValueError("dynamic string table exceeds the adopted 4 MiB bound")
        table_end = address + size
        boundaries = {address, table_end}
        loads = [q for q in ph if q["type"] == 1]
        for q in loads:
            bounded()
            first = max(address, q["vaddr"])
            last = min(table_end, q["vaddr"] + q["filesz"])
            if first < last:
                boundaries.update((first, last))
        ordered = sorted(boundaries)
        intervals = []
        result["dynamic_string_table"] = {
            "vaddr": address, "size": size, "boundaries": ordered,
            "mapping_rule": "file-backed intervals require one unique file offset",
            "intervals": intervals,
        }
        pieces = []
        for first, last in zip(ordered, ordered[1:]):
            bounded()
            covering = [{"program_header_index": q["index"],
                         "file_offset": q["offset"] + first - q["vaddr"]}
                        for q in loads
                        if q["vaddr"] <= first and last <= q["vaddr"] + q["filesz"]]
            offsets = sorted({q["file_offset"] for q in covering})
            interval = {"virtual_start": first, "virtual_end": last,
                        "covering_segments": covering, "unique_file_offsets": offsets}
            intervals.append(interval)
            if len(offsets) != 1:
                raise ValueError("dynamic string table has an unmapped or conflicting file-backed interval")
            piece = span(offsets[0], last - first)
            interval.update({"bytes": len(piece), "sha256": hashlib.sha256(piece).hexdigest()})
            pieces.append(piece)
        strings = b"".join(pieces)
        result["dynamic_string_table"].update({
            "reconstructed_bytes": len(strings), "sha256": hashlib.sha256(strings).hexdigest()})
        fields = {1: "dt_needed", 14: "dt_soname", 15: "dt_rpath", 29: "dt_runpath"}
        for e in string_entries:
            bounded()
            offset = e["value"]
            if offset >= size:
                raise ValueError("dynamic string offset outside DT_STRSZ")
            end = strings.find(b"\x00", offset, min(size, offset + MAX_STRING_BYTES + 1))
            if end < 0:
                raise ValueError("dynamic string lacks terminator within reader bound")
            raw = strings[offset:end]
            row = {"dynamic_entry_index": e["index"], "tag": e["tag"],
                   "name": e["name"], "offset": offset, "raw_hex": raw.hex(),
                   "text": raw.decode("ascii")}
            result["dynamic_strings"].append(row)
            if e["tag"] in fields:
                result[fields[e["tag"]]].append(row["text"])
    result["dt_flags"] = [e["value"] for e in entries if e["tag"] == 30]
    result["dt_flags_1"] = [e["value"] for e in entries if e["tag"] == 0x6FFFFFFB]
    review_tags = {16, 22, 24, 30, 0x6FFFFFFB, 0x6FFFFEFB, 0x6FFFFEFC, 0x7FFFFFFD, 0x7FFFFFFF}
    result["review_relevant_tags"] = [e for e in entries if e["tag"] in review_tags]
    return result


def collect(path, remaining):
    before_components = component_observations(path)
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC
    fd = os.open(path, flags)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError("fixed target is not a regular file")
        if not 0 < before.st_size <= min(MAX_FILE_BYTES, remaining):
            raise ValueError("fixed target exceeds byte bound or is empty")
        if identity(before) != before_components[-1]["identity"]:
            raise ValueError("file identity changed before bounded read")
        digest = hashlib.sha256()
        count = 0
        while count < before.st_size:
            bounded()
            block = os.read(fd, min(1024 * 1024, before.st_size - count))
            if not block:
                raise ValueError("short stream while hashing fixed target")
            count += len(block)
            digest.update(block)
        if os.read(fd, 1):
            raise ValueError("fixed target grew during stream hash")
        row = {"path": path, "bytes": count, "sha256": digest.hexdigest(),
               "mode": oct(stat.S_IMODE(before.st_mode)),
               "before_identity": identity(before)}
        row["expected_pin"] = EXPECTED_PINS[path]
        row["expected_pin_matches"] = all(row[key] == value for key, value in EXPECTED_PINS[path].items())
        row["elf"] = {"raw_parse_complete": False}
        try:
            raw_elf(fd, before.st_size, row["elf"])
            row["elf"]["raw_parse_complete"] = True
            row["parse_status"] = "parsed_raw_fields"
        except Exception as exc:
            row["parse_status"] = "reader_limit_or_parse_error"
            row["parse_error"] = {"type": type(exc).__name__, "message": str(exc)}
        after = os.fstat(fd)
    finally:
        os.close(fd)
    bounded()
    after_components = component_observations(path)
    if identity(before) != identity(after) or before_components != after_components:
        raise ValueError("fixed target or pathname changed during bounded read")
    row.update({"after_identity": identity(after), "components_before": before_components,
                "components_after": after_components, "stable_observation": True})
    return row


def fixed_kernel_witnesses():
    def read_proc(path, limit):
        fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
        try:
            result = bytearray()
            while len(result) <= limit:
                bounded()
                block = os.read(fd, min(256, limit + 1 - len(result)))
                if not block:
                    break
                result.extend(block)
            if len(result) > limit:
                raise ValueError("fixed proc witness exceeds bound: " + path)
            return bytes(result)
        finally:
            os.close(fd)

    bounded()
    uname = os.uname()
    libc = os.confstr("CS_GNU_LIBC_VERSION")
    boot = read_proc("/proc/sys/kernel/random/boot_id", 128)
    exe_before = {"target": os.readlink("/proc/self/exe"),
                  "identity": identity(os.stat("/proc/self/exe"))}
    auxv = read_proc("/proc/self/auxv", 4096)
    exe_after = {"target": os.readlink("/proc/self/exe"),
                 "identity": identity(os.stat("/proc/self/exe"))}
    if exe_before != exe_after or len(os.fsencode(exe_before["target"])) > 4096:
        raise ValueError("kernel executable witness changed or exceeds bound")
    pairs = [list(struct.unpack_from("<QQ", auxv, offset))
             for offset in range(0, len(auxv) - len(auxv) % 16, 16)]
    return {"uname": {"system": uname.sysname, "release": uname.release,
                       "machine": uname.machine},
            "gnu_libc_confstr": libc, "boot_id_raw_hex": boot.hex(),
            "boot_id_text": boot.decode("ascii"),
            "proc_exe_before": exe_before, "proc_exe_after": exe_after,
            "auxv_raw_hex": auxv.hex(), "auxv_bytes": len(auxv),
            "auxv_pairs": pairs, "auxv_multiple_of_16": len(auxv) % 16 == 0,
            "at_secure_values": [value for kind, value in pairs if kind == 23],
            "at_null_pairs": [[i, value] for i, (kind, value) in enumerate(pairs) if kind == 0]}


def main():
    result = {"schema": "ontokin-p26-selected-root-elf-raw-v1", "targets": list(TARGETS),
              "status": "incomplete", "observations": [], "total_file_bytes_read": 0,
              "python_executable": sys.executable,
              "ctypes_module_imported": "_ctypes" in sys.modules or "ctypes" in sys.modules,
              "scope": "raw selected Python/Node ELF and fixed kernel witnesses; no native closure or H0 verdict"}
    try:
        if len(sys.argv) != 1:
            raise ValueError("fixed collector accepts no arguments")
        if result["ctypes_module_imported"]:
            raise ValueError("unexpected ctypes module already imported")
        signal.signal(signal.SIGALRM, alarm)
        signal.setitimer(signal.ITIMER_REAL, max(0.001, DEADLINE - time.monotonic()))
        result["kernel_witnesses"] = fixed_kernel_witnesses()
        for path in TARGETS:
            row = collect(path, MAX_TOTAL_BYTES - result["total_file_bytes_read"])
            result["observations"].append(row)
            result["total_file_bytes_read"] += row["bytes"]
            if row["parse_status"] != "parsed_raw_fields":
                raise ValueError("stopped at raw reader limit; no policy conclusion")
        bounded()
        result["status"] = "complete_raw_observation"
    except Exception as exc:
        result["error"] = {"type": type(exc).__name__, "message": str(exc)}
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    result["elf_range_read_bytes"] = RANGE_READ_TOTAL
    result["elapsed_seconds"] = round(time.monotonic() - (DEADLINE - 25), 6)
    payload = json.dumps(result, sort_keys=True, separators=(",", ":"))
    if len(payload.encode("utf-8")) > MAX_OUTPUT_BYTES:
        payload = json.dumps({"schema": result["schema"], "status": "output_bound_exceeded"})
        result["status"] = "output_bound_exceeded"
    print(payload)
    return 0 if result["status"] == "complete_raw_observation" else 1


if __name__ == "__main__":
    raise SystemExit(main())
