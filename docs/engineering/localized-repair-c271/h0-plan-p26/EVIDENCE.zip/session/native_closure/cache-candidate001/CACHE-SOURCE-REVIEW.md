# P26 finite cache candidate: source rationale and limits

## Observation to prepare

The two exact root captures supply twelve direct needed names. The reader starts from those recorded requests and adds only names read from selected shared images. It measures cache-selected candidates as data; it does not invoke a loader, target, project parser, installer or checker. A completed capture proves only the stated cache branch and its raw files, not whole-loader selection or H0 acceptance.

The source roots, exact capture identities, reader identity and complete static readset are in `CACHE-LAUNCH-PLAN.json`. The reused `raw_elf` function is byte-identical to selected-root candidate002, which retained the actual Python partitioned string-table observations. It now applies to the necessary shared candidates without changing the product parser.

## Actual cache source and package relation

The underlying source is the exact recovered `glibc_2.41.orig.tar.xz`, SHA256 `f24aa441021121a79266f0d75242706cab8843a47901fefe74527491807f1998`, associated with the retained Debian `2.41-12+deb13u4` source package and actual loader provenance. Its complete `elf/dl-cache.c`, `sysdeps/x86_64/dl-cache.h` and `sysdeps/generic/dl-cache.h` have been read. The independent all-80-patch index finds no patch touching those files. This reuses the recorded official-package/source trust relation; it does not claim a reproduced binary build.

The x86-64 header defines the accepted cache flag value as exactly `0x303`. The generic header defines the new cache header, 24-byte entries, offsets, endianness test and extension directory. The cache implementation compares names with `_dl_cache_libcmp`, which compares digit runs numerically. Its binary search operates on descending comparison order, then scans the comparator-equivalent group from its first entry.

The reader supports the new-only `glibc-ld.so.cache1.1` layout. It retains the entire bounded cache bytes and verifies every adjacent key against the source comparison order. Under that verified order, scanning all comparator-equivalent rows and selecting the first eligible ordinary row gives the same result as the source binary-search/group-scan branch. Comparator digit runs exceeding signed C-int range stop the reader rather than inventing overflow semantics. Wrong architecture flags are skipped. Legacy nonzero hwcap records are skipped, as the source specifies. An encountered eligible named-hwcaps record stops before selection because its ISA compatibility and runtime priority are not modeled here. The cache extension headers and relevant raw hwcaps bytes remain evidence for that boundary.

The reader's string-offset, format, extension-validation, size and directory-prefix checks are deliberately finite collection limits. They are narrower than some loader behaviors. An old/combined format, malformed or unfamiliar extension record, out-of-profile path, unmodeled alternative, read error or limit breach is an observer boundary, not an observed product refusal. Cache raw bytes remain available in ordinary failure output for independent interpretation.

## Selection scope

The exact `dl-load.c` source checks applicable inherited RPATH, environment search paths, RUNPATH, cache and finally compiled defaults. The active `git-updates.diff` hunks for `dl-load.c` change debugger notification and a stack-end argument; they do not alter that search-order/cache call block. The ARM ABI hunk is guarded by `__arm__`. The machine-mismatch hunk changes rejection of wrong-architecture candidates in `open_verify`, which remains relevant to checking observed images. The complete active `rtld.c` hunks were also read; they concern program-header bookkeeping, executable-stack handling and debugger state. This review does not infer runtime success from those observations.

The four root captures already show no RPATH/RUNPATH for Node, Bash and Git. Python has the adopted `$ORIGIN/../lib` RPATH. The clean five-variable launch environment contains no loader-path, preload or audit overrides. This candidate binds `/etc/ld.so.preload` and stops if it is nonempty. It does not yet establish Python-origin nonselection, compiled-default directories, earlier-path absence, loaded-object name reuse, or a complete invocation-specific selection argument. All returned edges therefore carry `full_loader_selection_proved: false`.

Only cache-selected aliases within `/lib/x86_64-linux-gnu/`, `/usr/lib/x86_64-linux-gnu/`, `/lib64/` or `/usr/lib64/` can be considered. A bounded symlink/component trace must end at a regular canonical image under `/usr/lib/x86_64-linux-gnu/` before any content read. A selected path outside that scope stops. Each alias and measured image is rechecked at completion. No unrelated shared-library directory is enumerated.

The reader binds `/etc/ld.so.conf` and its finite include files. Include traversal is confined to the single `/etc/ld.so.conf.d` directory, at most 2048 immediate entries and sixteen configuration files. It records directory declarations without scanning them. These configuration inputs satisfy a necessary plan-evidence category; their text alone is not evidence of actual runtime search. Full search-directory and Python-origin absence proofs are deferred until the necessary image metadata is supported.

## Product predicates remain separate

The raw output retains ELF identification including OSABI, every program header, interpreter, dynamic entries, needed names, SONAME, RPATH/RUNPATH and flags. The independent source analysis must first inspect each observed image against the frozen inspector's existing predicates: architecture/type/OSABI, dynamic and string-table mapping, tag allowlist, duplicate metadata, names, flags and search paths. The reader does not implement or emit a product acceptance verdict.

General images admit only `DT_FLAGS` values with bits contained in `8`, and `DT_FLAGS_1` bits contained in `1 | 0x08000000`. The exact selected libc has a private adopted profile for its fixed PLT tag trio and flag values `0`, `8` or `24`, subject to all current Python dependency, descriptor, alias, role and loader-pin relations. Other images cannot borrow that exception. A raw match to libc's bytes is not by itself proof that those plan relations are satisfied.

If actual observed fields contradict a current predicate, the next report must identify the image hash, raw field, exact source rule and applicability. It must distinguish a conditional source deduction from a product invocation result. No incompatibility is predicted in this candidate, and no actual shared input has been assigned as a Python extension merely to satisfy a nonempty list.

## Review and execution boundary

The candidate is unexecuted. Static AST parsing and comparison of the reused raw parser are the only author-side validation. The Director must bind and review the external capture wrapper, exact environment, 30-second outer deadline, 256 MiB address-space limit and output caps before one invocation. A successful capture remains data for the independent source assessment. The final operational plan, source rationale, role inventory and N34/H0 approvals remain the Director's separate work.
