#!/usr/bin/env python3
"""Unexecuted bounded cache/shared-image observer; no product verdict.

Resolve only observed root DT_NEEDED names and their transitive raw names using
one source-reviewed baseline cache branch. Hash/read selected canonical images
as data. Bind fixed loader config/preload and one bounded include directory.
No target start, project import, general search-tree scan, or file write.
"""
import fnmatch
import hashlib
import json
import os
import signal
import stat
import struct
import sys
import time

ROOT_REQUESTS = [{'path': '/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12', 'sha256': 'fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7', 'bytes': 30894944, 'needed': ['libpthread.so.0', 'libdl.so.2', 'libutil.so.1', 'libm.so.6', 'librt.so.1', 'libc.so.6'], 'rpath': ['$ORIGIN/../lib'], 'runpath': []}, {'path': '/workspace/scratch/cf652064a9a1/prepared-inputs/node/bin/node', 'sha256': 'acbe4b8d9153b841ed0697cbfc4f93e767386620edb745ab9358306c0a6f31aa', 'bytes': 126951512, 'needed': ['libdl.so.2', 'libstdc++.so.6', 'libm.so.6', 'libgcc_s.so.1', 'libpthread.so.0', 'libc.so.6', 'ld-linux-x86-64.so.2'], 'rpath': [], 'runpath': []}, {'path': '/usr/bin/bash', 'sha256': '223fe8564b60636bc738b6178d3ba9a50ef7d791266b0efae6363bb716e4c47f', 'bytes': 1298416, 'needed': ['libtinfo.so.6', 'libc.so.6'], 'rpath': [], 'runpath': []}, {'path': '/usr/bin/git', 'sha256': '356db14e102d68a1a37d8a1ac577dfd678d45d46e92f468bef8b7154e7bfdc60', 'bytes': 4082768, 'needed': ['libpcre2-8.so.0', 'libz.so.1', 'libc.so.6'], 'rpath': [], 'runpath': []}]
ROOT_CAPTURE_REFERENCES = [{'path': '/workspace/scratch/cf652064a9a1/session/native_closure/roots-run002.stdout.json', 'bytes': 23350, 'sha256': 'cc999e5b0b4dc9cc49db413d8d37abaa78f2670d2f33217a826ae88897008fd9'}, {'path': '/workspace/scratch/cf652064a9a1/session/native_roots/run001.stdout.json', 'bytes': 18954, 'sha256': '79c63102812f02ce4bc222a2f776aac2e3d898403609fca8994bdf7c8edf65e5'}]
EXPECTED_PINS = {
    "/usr/lib/x86_64-linux-gnu/libc.so.6": {"bytes": 1995216, "sha256": "9792e3cbb541c8f44c7acf5f14f4022ea62998ecc787d326bed4d8b6547dfd92", "mode": "0o755"},
    "/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2": {"bytes": 225672, "sha256": "c8438e4fde1934e61c88311633f00949ff645d5c04cdb8671fa3d78164d2f307", "mode": "0o755"},
}
CACHE_PATH = "/etc/ld.so.cache"
CONF_PATH = "/etc/ld.so.conf"
PRELOAD_PATH = "/etc/ld.so.preload"
INCLUDE_DIRECTORY = "/etc/ld.so.conf.d"
ALIAS_PREFIXES = ("/lib/x86_64-linux-gnu/", "/usr/lib/x86_64-linux-gnu/", "/lib64/", "/usr/lib64/")
CANONICAL_PREFIX = "/usr/lib/x86_64-linux-gnu/"
INTERPRETER_ALIAS = "/lib64/ld-linux-x86-64.so.2"
MAX_AUX_BYTES = 2 * 1024 * 1024
AUX_BYTES = 0
MAX_IMAGES = 64
MAX_NAMES = 128
MAX_CONFIG_FILES = 16
MAX_PENDING_EDGES = 4096
MAX_FILE_BYTES = 32 * 1024 * 1024
MAX_TOTAL_BYTES = 128 * 1024 * 1024
MAX_RANGE_READ_BYTES = 16 * 1024 * 1024
MAX_RANGE_READ_TOTAL = 32 * 1024 * 1024
RANGE_READ_TOTAL = 0
MAX_OUTPUT_BYTES = 8 * 1024 * 1024
MAX_PROGRAM_HEADERS = 4096
MAX_DYNAMIC_ENTRIES = 8192
MAX_STRING_BYTES = 4096
DEADLINE = time.monotonic() + 25
TAG_NAMES = {
    0: "DT_NULL", 1: "DT_NEEDED", 5: "DT_STRTAB", 10: "DT_STRSZ",
    14: "DT_SONAME", 15: "DT_RPATH", 16: "DT_SYMBOLIC",
    22: "DT_TEXTREL", 24: "DT_BIND_NOW", 29: "DT_RUNPATH", 30: "DT_FLAGS",
    0x6FFFFEFB: "DT_DEPAUDIT", 0x6FFFFEFC: "DT_AUDIT",
    0x6FFFFFFB: "DT_FLAGS_1", 0x7FFFFFFD: "DT_AUXILIARY",
    0x7FFFFFFF: "DT_FILTER",
}
STRING_TAGS = {1, 14, 15, 29, 0x6FFFFEFB, 0x6FFFFEFC, 0x7FFFFFFD, 0x7FFFFFFF}


def bounded():
    if time.monotonic() > DEADLINE:
        raise TimeoutError("collector 25-second deadline")


def alarm(_signum, _frame):
    raise TimeoutError("collector 25-second alarm")


def identity(st):
    return {"dev": st.st_dev, "ino": st.st_ino, "mode": st.st_mode,
            "nlink": st.st_nlink, "uid": st.st_uid, "gid": st.st_gid,
            "size": st.st_size, "mtime_ns": st.st_mtime_ns,
            "ctime_ns": st.st_ctime_ns}


def component_observations(path):
    rows = []
    current = ""
    for part in path.split("/")[1:]:
        bounded()
        current += "/" + part
        st = os.lstat(current)
        rows.append({"path": current, "identity": identity(st)})
        if stat.S_ISLNK(st.st_mode):
            raise ValueError("fixed target has symlink component: " + current)
        if current != path and not stat.S_ISDIR(st.st_mode):
            raise ValueError("fixed target has non-directory parent: " + current)
    return rows


def raw_elf(fd, file_size, result):
    def bounds(offset, size):
        bounded()
        if offset < 0 or size < 0 or offset > file_size or size > file_size - offset:
            raise ValueError("ELF range outside measured file")

    def span(offset, size):
        global RANGE_READ_TOTAL
        bounds(offset, size)
        if size > MAX_RANGE_READ_BYTES or RANGE_READ_TOTAL + size > MAX_RANGE_READ_TOTAL:
            raise ValueError("ELF range-read byte budget exceeded")
        raw = os.pread(fd, size, offset)
        RANGE_READ_TOTAL += len(raw)
        if len(raw) != size:
            raise ValueError("short ELF metadata range read")
        return raw

    ident = span(0, 16)
    if ident[:7] != b"\x7fELF\x02\x01\x01":
        raise ValueError("reader supports ELF64 little-endian version 1 only")
    header = struct.unpack("<HHIQQQIHHHHHH", span(16, 48))
    etype, machine, version, entry, phoff, shoff, flags, ehsize, phsize, phnum, shsize, shnum, shstr = header
    if ehsize != 64 or phsize != 56 or not 0 < phnum <= MAX_PROGRAM_HEADERS:
        raise ValueError("unsupported or oversized ELF program-header layout")
    span(phoff, phsize * phnum)
    ph = []
    for i in range(phnum):
        ptype, pflags, offset, vaddr, paddr, filesz, memsz, align = struct.unpack(
            "<IIQQQQQQ", span(phoff + i * phsize, phsize))
        bounds(offset, filesz)
        ph.append({"index": i, "type": ptype, "flags": pflags, "offset": offset,
                   "vaddr": vaddr, "paddr": paddr, "filesz": filesz,
                   "memsz": memsz, "align": align})
    result.update({"elf_class": 64, "byte_order": "little", "osabi": ident[7],
              "abi_version": ident[8], "elf_ident_hex": ident.hex(), "type": etype,
              "machine": machine, "version": version, "entry": entry,
              "header_flags": flags, "program_headers": ph,
              "pt_interp": [], "dynamic_entries": [], "dynamic_strings": [],
              "dt_needed": [], "dt_soname": [], "dt_rpath": [], "dt_runpath": [],
              "dt_flags": [], "dt_flags_1": [], "review_relevant_tags": []})
    for p in ph:
        if p["type"] == 3:
            if p["filesz"] > MAX_STRING_BYTES:
                raise ValueError("PT_INTERP exceeds reader string bound")
            raw = span(p["offset"], p["filesz"])
            result["pt_interp"].append({"program_header_index": p["index"],
                "raw_hex": raw.hex(), "ends_with_nul": raw.endswith(b"\x00"),
                "text": raw[:-1].decode("ascii") if raw.endswith(b"\x00") else None})
    dyn = [p for p in ph if p["type"] == 2]
    if not dyn:
        result["pt_dynamic_present"] = False
        return result
    if len(dyn) != 1:
        raise ValueError("multiple PT_DYNAMIC segments require separate review")
    p = dyn[0]
    result["pt_dynamic_present"] = True
    if p["filesz"] % 16 or p["filesz"] // 16 > MAX_DYNAMIC_ENTRIES:
        raise ValueError("unsupported or oversized dynamic segment")
    entries = result["dynamic_entries"]
    for i in range(p["filesz"] // 16):
        tag, value = struct.unpack("<qQ", span(p["offset"] + 16 * i, 16))
        entries.append({"index": i, "tag": tag, "tag_hex": hex(tag),
                        "name": TAG_NAMES.get(tag), "value": value})
        if tag == 0:
            break
    if not entries or entries[-1]["tag"] != 0:
        raise ValueError("no DT_NULL within bounded dynamic segment")
    result["dynamic_segment_capacity_entries"] = p["filesz"] // 16
    result["entries_after_first_dt_null_not_interpreted"] = p["filesz"] // 16 - len(entries)
    string_entries = [e for e in entries if e["tag"] in STRING_TAGS]
    if string_entries:
        addresses = [e["value"] for e in entries if e["tag"] == 5]
        sizes = [e["value"] for e in entries if e["tag"] == 10]
        if len(addresses) != 1 or len(sizes) != 1:
            raise ValueError("string-bearing dynamic tags need unique DT_STRTAB/DT_STRSZ")
        address, size = addresses[0], sizes[0]
        result["dynamic_string_table"] = {"vaddr": address, "size": size}
        # Match the adopted P10 file-backed interval rule. Several coincident
        # segments are allowed only when each interval names one file offset.
        if not 0 < size <= 4 * 1024 * 1024:
            raise ValueError("dynamic string table exceeds the adopted 4 MiB bound")
        table_end = address + size
        boundaries = {address, table_end}
        loads = [q for q in ph if q["type"] == 1]
        for q in loads:
            bounded()
            first = max(address, q["vaddr"])
            last = min(table_end, q["vaddr"] + q["filesz"])
            if first < last:
                boundaries.update((first, last))
        ordered = sorted(boundaries)
        intervals = []
        result["dynamic_string_table"] = {
            "vaddr": address, "size": size, "boundaries": ordered,
            "mapping_rule": "file-backed intervals require one unique file offset",
            "intervals": intervals,
        }
        pieces = []
        for first, last in zip(ordered, ordered[1:]):
            bounded()
            covering = [{"program_header_index": q["index"],
                         "file_offset": q["offset"] + first - q["vaddr"]}
                        for q in loads
                        if q["vaddr"] <= first and last <= q["vaddr"] + q["filesz"]]
            offsets = sorted({q["file_offset"] for q in covering})
            interval = {"virtual_start": first, "virtual_end": last,
                        "covering_segments": covering, "unique_file_offsets": offsets}
            intervals.append(interval)
            if len(offsets) != 1:
                raise ValueError("dynamic string table has an unmapped or conflicting file-backed interval")
            piece = span(offsets[0], last - first)
            interval.update({"bytes": len(piece), "sha256": hashlib.sha256(piece).hexdigest()})
            pieces.append(piece)
        strings = b"".join(pieces)
        result["dynamic_string_table"].update({
            "reconstructed_bytes": len(strings), "sha256": hashlib.sha256(strings).hexdigest()})
        fields = {1: "dt_needed", 14: "dt_soname", 15: "dt_rpath", 29: "dt_runpath"}
        for e in string_entries:
            bounded()
            offset = e["value"]
            if offset >= size:
                raise ValueError("dynamic string offset outside DT_STRSZ")
            end = strings.find(b"\x00", offset, min(size, offset + MAX_STRING_BYTES + 1))
            if end < 0:
                raise ValueError("dynamic string lacks terminator within reader bound")
            raw = strings[offset:end]
            row = {"dynamic_entry_index": e["index"], "tag": e["tag"],
                   "name": e["name"], "offset": offset, "raw_hex": raw.hex(),
                   "text": raw.decode("ascii")}
            result["dynamic_strings"].append(row)
            if e["tag"] in fields:
                result[fields[e["tag"]]].append(row["text"])
    result["dt_flags"] = [e["value"] for e in entries if e["tag"] == 30]
    result["dt_flags_1"] = [e["value"] for e in entries if e["tag"] == 0x6FFFFFFB]
    review_tags = {16, 22, 24, 30, 0x6FFFFFFB, 0x6FFFFEFB, 0x6FFFFEFC, 0x7FFFFFFD, 0x7FFFFFFF}
    result["review_relevant_tags"] = [e for e in entries if e["tag"] in review_tags]
    return result


def collect(path, remaining):
    before_components = component_observations(path)
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC
    fd = os.open(path, flags)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode):
            raise ValueError("fixed target is not a regular file")
        if not 0 < before.st_size <= min(MAX_FILE_BYTES, remaining):
            raise ValueError("fixed target exceeds byte bound or is empty")
        if identity(before) != before_components[-1]["identity"]:
            raise ValueError("file identity changed before bounded read")
        digest = hashlib.sha256()
        count = 0
        while count < before.st_size:
            bounded()
            block = os.read(fd, min(1024 * 1024, before.st_size - count))
            if not block:
                raise ValueError("short stream while hashing fixed target")
            count += len(block)
            digest.update(block)
        if os.read(fd, 1):
            raise ValueError("fixed target grew during stream hash")
        row = {"path": path, "bytes": count, "sha256": digest.hexdigest(),
               "mode": oct(stat.S_IMODE(before.st_mode)),
               "before_identity": identity(before)}
        row["expected_pin"] = EXPECTED_PINS.get(path)
        row["expected_pin_matches"] = (all(row[key] == value for key, value in EXPECTED_PINS[path].items())
                                       if path in EXPECTED_PINS else None)
        row["elf"] = {"raw_parse_complete": False}
        try:
            raw_elf(fd, before.st_size, row["elf"])
            row["elf"]["raw_parse_complete"] = True
            row["parse_status"] = "parsed_raw_fields"
        except Exception as exc:
            row["parse_status"] = "reader_limit_or_parse_error"
            row["parse_error"] = {"type": type(exc).__name__, "message": str(exc)}
        after = os.fstat(fd)
    finally:
        os.close(fd)
    bounded()
    after_components = component_observations(path)
    if identity(before) != identity(after) or before_components != after_components:
        raise ValueError("fixed target or pathname changed during bounded read")
    row.update({"after_identity": identity(after), "components_before": before_components,
                "components_after": after_components, "stable_observation": True})
    return row


class CollectionBoundary(ValueError):
    """A bounded observer branch needs review; never a product refusal."""


def clean_absolute(path):
    if (not isinstance(path, str) or not path.startswith("/") or not path.isascii()
            or any(p in ("", ".", "..") for p in path.split("/")[1:])
            or any(c.isspace() or c in "\x00$\\" for c in path)):
        raise CollectionBoundary("path outside clean absolute observer profile")
    return path


def read_aux_file(path, maximum):
    global AUX_BYTES
    clean_absolute(path)
    try:
        before_components = component_observations(path)
    except FileNotFoundError as exc:
        if exc.filename != path:
            raise CollectionBoundary("auxiliary file has a missing intermediate component") from exc
        parent = os.path.dirname(path)
        parent_components = component_observations(parent)
        return {"path": path, "state": "absent", "parent": parent,
                "parent_components": parent_components}, None
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        if (not stat.S_ISREG(before.st_mode) or before.st_size > maximum
                or AUX_BYTES + before.st_size > MAX_AUX_BYTES):
            raise CollectionBoundary("auxiliary file type/size exceeds observer profile")
        if identity(before) != before_components[-1]["identity"]:
            raise CollectionBoundary("auxiliary file changed before read")
        parts, count = [], 0
        while count < before.st_size:
            bounded()
            part = os.read(fd, min(65536, before.st_size - count))
            if not part:
                raise CollectionBoundary("short auxiliary-file read")
            parts.append(part)
            count += len(part)
        if os.read(fd, 1):
            raise CollectionBoundary("auxiliary file grew during read")
        raw = b"".join(parts)
        AUX_BYTES += count
        after = os.fstat(fd)
    finally:
        os.close(fd)
    after_components = component_observations(path)
    if identity(before) != identity(after) or before_components != after_components:
        raise CollectionBoundary("auxiliary file or components changed during read")
    return {"path": path, "state": "file", "bytes": len(raw),
            "sha256": hashlib.sha256(raw).hexdigest(),
            "mode": oct(stat.S_IMODE(before.st_mode)), "raw_hex": raw.hex(),
            "before_identity": identity(before), "after_identity": identity(after),
            "components_before": before_components, "components_after": after_components}, raw


def include_directory_inventory():
    before_components = component_observations(INCLUDE_DIRECTORY)
    before = os.lstat(INCLUDE_DIRECTORY)
    if not stat.S_ISDIR(before.st_mode):
        raise CollectionBoundary("fixed include directory is not a directory")
    rows = {}
    with os.scandir(INCLUDE_DIRECTORY) as entries:
        for entry in entries:
            bounded()
            if len(rows) >= 2048:
                raise CollectionBoundary("fixed include directory exceeds2048 entries")
            info = entry.stat(follow_symlinks=False)
            kind = ("file" if stat.S_ISREG(info.st_mode) else
                    "directory" if stat.S_ISDIR(info.st_mode) else
                    "symlink" if stat.S_ISLNK(info.st_mode) else "special")
            rows[entry.name] = {"kind": kind, "device": info.st_dev, "inode": info.st_ino,
                                "mode": oct(stat.S_IMODE(info.st_mode)),
                                "target": os.readlink(entry.path) if kind == "symlink" else None}
    after_components = component_observations(INCLUDE_DIRECTORY)
    if before_components != after_components:
        raise CollectionBoundary("fixed include directory changed during inventory")
    return {"path": INCLUDE_DIRECTORY, "device": before.st_dev, "inode": before.st_ino,
            "mode": oct(stat.S_IMODE(before.st_mode)), "entries": rows,
            "components_before": before_components, "components_after": after_components}


def collect_configuration(result):
    for path, maximum in ((PRELOAD_PATH, 65536), (CONF_PATH, 65536)):
        row, raw = read_aux_file(path, maximum)
        row["includes"] = []
        result["loader_inputs"].append(row)
        if path == PRELOAD_PATH:
            if raw:
                raise CollectionBoundary("nonempty preload needs separate source assessment")
            continue
        pending = [(row, raw)] if raw is not None else []
        seen = {CONF_PATH}
        while pending:
            current, content = pending.pop(0)
            bounded()
            current["text"] = content.decode("utf-8")
            current["declared_search_directories"] = []
            for original in current["text"].splitlines():
                bounded()
                line = original.split("#", 1)[0].strip()
                if not line:
                    continue
                if not line.startswith("include "):
                    current["declared_search_directories"].append(clean_absolute(line))
                    continue
                pattern = line[8:].strip()
                parent, basename = os.path.split(pattern)
                if (parent != INCLUDE_DIRECTORY or not basename or "**" in basename
                        or "/" in basename or ".." in basename or "$" in basename
                        or any(c.isspace() for c in basename)):
                    raise CollectionBoundary("configuration include is outside the one-directory profile")
                if result["include_directory"] is None:
                    result["include_directory"] = include_directory_inventory()
                matches = sorted(name for name in result["include_directory"]["entries"]
                                 if fnmatch.fnmatchcase(name, basename))
                for name in matches:
                    selected = INCLUDE_DIRECTORY + "/" + name
                    current["includes"].append(selected)
                    if selected in seen:
                        raise CollectionBoundary("duplicate or cyclic configuration include requires review")
                    if len(seen) >= MAX_CONFIG_FILES:
                        raise CollectionBoundary("configuration file-count bound exceeded")
                    seen.add(selected)
                    included, included_raw = read_aux_file(selected, 65536)
                    included["includes"] = []
                    result["loader_inputs"].append(included)
                    if included_raw is None:
                        raise CollectionBoundary("selected include disappeared")
                    pending.append((included, included_raw))


def cache_compare(left, right):
    """Exact ASCII/numeric comparison branch, refusing C-int overflow inputs."""
    i = j = 0
    while i < len(left):
        bounded()
        a = left[i]
        b = right[j] if j < len(right) else "\x00"
        if "0" <= a <= "9":
            if not "0" <= b <= "9":
                return 1
            first = second = 0
            while i < len(left) and "0" <= left[i] <= "9":
                first = first * 10 + ord(left[i]) - 48
                i += 1
                if first > 2147483647:
                    raise CollectionBoundary("cache comparator numeric run exceeds signed C int")
            while j < len(right) and "0" <= right[j] <= "9":
                second = second * 10 + ord(right[j]) - 48
                j += 1
                if second > 2147483647:
                    raise CollectionBoundary("cache comparator numeric run exceeds signed C int")
            if first != second:
                return first - second
        elif "0" <= b <= "9":
            return -1
        elif a != b:
            return ord(a) - ord(b)
        else:
            i += 1
            j += 1
    return -(ord(right[j]) if j < len(right) else 0)


def parse_baseline_cache(raw, evidence):
    magic = b"glibc-ld.so.cache1.1"
    evidence["header_raw_hex"] = raw[:48].hex()
    if len(raw) <= 48 or raw[:len(magic)] != magic:
        raise CollectionBoundary("cache is outside the new-only1.1 observer profile")
    count, string_bytes = struct.unpack_from("<II", raw, 20)
    flags = raw[28]
    extension_offset = struct.unpack_from("<I", raw, 32)[0]
    evidence.update({"format": "glibc-ld.so.cache1.1", "entry_count": count,
                     "string_bytes": string_bytes, "header_flags": flags,
                     "extension_offset": extension_offset})
    if not (flags == 0 or flags & 3 == 2):
        raise CollectionBoundary("cache header does not match little-endian loader rule")
    table_end = 48 + count * 24
    if count > 16384 or table_end > len(raw) or string_bytes > len(raw) - table_end:
        raise CollectionBoundary("cache entry/string ranges exceed bounded file")
    string_end = table_end + string_bytes

    def string(offset):
        bounded()
        if not table_end <= offset < string_end:
            raise CollectionBoundary("cache string index outside declared string area")
        end = raw.find(b"\x00", offset, min(string_end, offset + 4097))
        if end < 0:
            raise CollectionBoundary("cache string lacks bounded terminator")
        text = raw[offset:end].decode("ascii")
        if not text:
            raise CollectionBoundary("empty cache string outside observer profile")
        return text

    rows = []
    for index in range(count):
        bounded()
        entry_flags, key, value, osversion, hwcap = struct.unpack_from("<iIIIQ", raw, 48 + 24 * index)
        rows.append({"index": index, "flags": entry_flags, "key_offset": key,
                     "value_offset": value, "osversion_unused": osversion, "hwcap": hwcap,
                     "name": string(key)})
    for previous, current in zip(rows, rows[1:]):
        if cache_compare(previous["name"], current["name"]) < 0:
            raise CollectionBoundary("cache name table is not in source binary-search order")
    evidence["all_adjacent_names_verified_descending_by_source_comparator"] = True
    evidence["extension_headers"] = []
    if extension_offset:
        if extension_offset % 4 or extension_offset + 8 > len(raw):
            raise CollectionBoundary("cache extension directory needs separate review")
        ext_magic, ext_count = struct.unpack_from("<II", raw, extension_offset)
        evidence["extension_magic"] = ext_magic
        evidence["extension_count"] = ext_count
        if ext_magic != ((-358342284) & 0xFFFFFFFF) or ext_count > 32 or extension_offset + 8 + ext_count * 16 > len(raw):
            raise CollectionBoundary("cache extension directory is outside observer profile")
        for index in range(ext_count):
            tag, ext_flags, offset, size = struct.unpack_from("<IIII", raw, extension_offset + 8 + index * 16)
            row = {"index": index, "tag": tag, "flags": ext_flags, "offset": offset, "size": size}
            evidence["extension_headers"].append(row)
            if offset + size > len(raw):
                raise CollectionBoundary("cache extension data escapes file")
            row["sha256"] = hashlib.sha256(raw[offset:offset + size]).hexdigest()
            if tag == 1:
                row["raw_hex"] = raw[offset:offset + size].hex()
                row["alignment_and_size_valid"] = bool(size and offset % 4 == 0 and size % 4 == 0)
    return rows, string


def lookup_cache(name, rows, string, evidence):
    matches = [dict(row) for row in rows if cache_compare(name, row["name"]) == 0]
    evidence.update({"needed_name": name, "comparator_equivalent_entries": matches,
                     "selected": None, "scope": "cache branch only; earlier search paths still unproved"})
    for row in matches:
        bounded()
        if row["flags"] != 0x303:
            row["cache_branch"] = "skipped_by_exact_x86_64_flag_rule"
            continue
        row["path"] = string(row["value_offset"])
        if row["hwcap"]:
            named_hwcap = (((row["hwcap"] >> 32) & ~0x3FF) == (1 << 30))
            row["named_hwcap"] = named_hwcap
            if named_hwcap:
                raise CollectionBoundary("relevant named-hwcaps/ISA cache alternative needs separate source review")
            row["cache_branch"] = "legacy_nonzero_hwcap_skipped_by_source"
            continue
        row["cache_branch"] = "first_eligible_ordinary_x86_64_entry"
        evidence["selected"] = {"index": row["index"], "path": row["path"], "cache_name": row["name"]}
        return clean_absolute(row["path"])
    raise CollectionBoundary("needed name has no selectable baseline cache entry; default search not collected")


def observe_alias(path):
    clean_absolute(path)
    if not path.startswith(ALIAS_PREFIXES):
        raise CollectionBoundary("selected cache/interpreter path outside fixed library prefixes")
    pending = path.split("/")[1:]
    parts, trace, links, steps = [], [], 0, 0
    while pending:
        bounded()
        steps += 1
        if steps > 256:
            raise CollectionBoundary("alias component budget exceeded")
        part = pending.pop(0)
        if part in ("", "."):
            continue
        if part == "..":
            if not parts:
                raise CollectionBoundary("alias target escapes filesystem root")
            parts.pop()
            continue
        current = "/" + "/".join(parts + [part])
        info = os.lstat(current)
        row = {"path": current, "identity": identity(info), "target": None}
        trace.append(row)
        if stat.S_ISLNK(info.st_mode):
            links += 1
            if links > 40:
                raise CollectionBoundary("alias symlink budget exceeded")
            target = os.readlink(current)
            row["target"] = target
            if len(os.fsencode(target)) > 4096 or "\x00" in target:
                raise CollectionBoundary("alias link text exceeds bound")
            if target.startswith("/"):
                parts = []
            pending = target.split("/") + pending
        else:
            parts.append(part)
            if pending and not stat.S_ISDIR(info.st_mode):
                raise CollectionBoundary("alias parent is not a directory")
    resolved = "/" + "/".join(parts)
    if not resolved.startswith(CANONICAL_PREFIX):
        raise CollectionBoundary("resolved image lies outside fixed canonical library directory")
    if not trace or not stat.S_ISREG(trace[-1]["identity"]["mode"]):
        raise CollectionBoundary("selected alias does not end in a regular file")
    named_info = os.lstat(path)
    named_link = stat.S_ISLNK(named_info.st_mode)
    return {"path": path, "resolved_path": resolved, "symlink": named_link,
            "link_target": os.readlink(path) if named_link else None,
            "named_identity": identity(named_info), "trace": trace}


def needed_name(name):
    if (not isinstance(name, str) or not name or len(name) > 4096 or not name.isascii()
            or any(c.isspace() or c in "/\x00$\\" for c in name)):
        raise CollectionBoundary("DT_NEEDED name is outside bounded name-only observer profile")
    return name


def final_recheck(result):
    for row in result["loader_inputs"]:
        bounded()
        if row["state"] == "file":
            if component_observations(row["path"]) != row["components_after"]:
                raise CollectionBoundary("loader input drifted before completion")
        elif os.path.lexists(row["path"]) or component_observations(row["parent"]) != row["parent_components"]:
            raise CollectionBoundary("loader-input absence drifted before completion")
    for row in result["aliases"]:
        if observe_alias(row["path"]) != row:
            raise CollectionBoundary("selected alias drifted before completion")
    for row in result["observations"]:
        if component_observations(row["path"]) != row["components_after"]:
            raise CollectionBoundary("selected image drifted before completion")
    if result["include_directory"] is not None:
        if include_directory_inventory() != result["include_directory"]:
            raise CollectionBoundary("configuration include directory drifted before completion")


def main():
    result = {"schema": "ontokin-p26-cache-shared-images-raw-v1", "status": "incomplete",
              "root_requests": ROOT_REQUESTS, "root_capture_references": ROOT_CAPTURE_REFERENCES,
              "loader_inputs": [], "include_directory": None, "cache": {},
              "cache_queries": [], "aliases": [], "observations": [], "needed_edges": [],
              "total_file_bytes_read": 0, "python_executable": sys.executable,
              "scope": "conditional cache candidates and raw necessary shared images; no full selection/N34/H0 verdict"}
    try:
        if len(sys.argv) != 1:
            raise CollectionBoundary("fixed collector accepts no arguments")
        if "ctypes" in sys.modules or "_ctypes" in sys.modules:
            raise CollectionBoundary("unexpected ctypes module already imported")
        signal.signal(signal.SIGALRM, alarm)
        signal.setitimer(signal.ITIMER_REAL, max(0.001, DEADLINE - time.monotonic()))
        cache_row, raw = read_aux_file(CACHE_PATH, 512 * 1024)
        cache_row["includes"] = []
        result["loader_inputs"].append(cache_row)
        if raw is None:
            raise CollectionBoundary("cache absent; default-path observation requires separate candidate")
        collect_configuration(result)
        cache_rows, cache_string = parse_baseline_cache(raw, result["cache"])
        pending = [(root["path"], name) for root in ROOT_REQUESTS for name in root["needed"]]
        queried, images, aliases = {}, {}, {}
        while pending:
            bounded()
            requester, name = pending.pop(0)
            name = needed_name(name)
            if name not in queried:
                if len(queried) >= MAX_NAMES:
                    raise CollectionBoundary("needed-name count bound exceeded")
                query = {}
                result["cache_queries"].append(query)
                selected = lookup_cache(name, cache_rows, cache_string, query)
                alias = observe_alias(selected)
                if selected not in aliases:
                    aliases[selected] = alias
                    result["aliases"].append(alias)
                elif alias != aliases[selected]:
                    raise CollectionBoundary("alias changed between cache queries")
                queried[name] = alias
            alias = queried[name]
            canonical = alias["resolved_path"]
            result["needed_edges"].append({"requesting_image": requester, "needed_name": name,
                "cache_selected_alias": alias["path"], "canonical_path": canonical,
                "full_loader_selection_proved": False})
            if canonical in images:
                continue
            if len(images) >= MAX_IMAGES:
                raise CollectionBoundary("selected-image count bound exceeded")
            image_row = collect(canonical, MAX_TOTAL_BYTES - result["total_file_bytes_read"])
            result["observations"].append(image_row)
            images[canonical] = image_row
            result["total_file_bytes_read"] += image_row["bytes"]
            if observe_alias(alias["path"]) != alias:
                raise CollectionBoundary("selected alias changed during image observation")
            if image_row["parse_status"] != "parsed_raw_fields":
                raise CollectionBoundary("raw image parser stopped; independent source assessment required")
            if image_row["expected_pin_matches"] is False:
                raise CollectionBoundary("previously pinned loader/libc identity differs; separate assessment required")
            elf = image_row["elf"]
            if elf["dt_rpath"] or elf["dt_runpath"]:
                raise CollectionBoundary("shared image has search paths; cache-only transitive branch not established")
            if any(e["tag"] in (0x6FFFFEFB, 0x6FFFFEFC, 0x7FFFFFFD, 0x7FFFFFFF)
                   for e in elf["dynamic_entries"]):
                raise CollectionBoundary("shared image names extra loader inputs; separate source assessment required")
            for interp in elf["pt_interp"]:
                if interp["text"] != INTERPRETER_ALIAS:
                    raise CollectionBoundary("shared-image interpreter differs from fixed observed loader alias")
                current = observe_alias(INTERPRETER_ALIAS)
                if INTERPRETER_ALIAS not in aliases:
                    aliases[INTERPRETER_ALIAS] = current
                    result["aliases"].append(current)
                elif current != aliases[INTERPRETER_ALIAS]:
                    raise CollectionBoundary("interpreter alias changed during observation")
            if len(elf["dt_needed"]) > 256 or len(pending) + len(elf["dt_needed"]) > MAX_PENDING_EDGES:
                raise CollectionBoundary("needed-edge work queue exceeds observer bound")
            pending.extend((canonical, dependency) for dependency in elf["dt_needed"])
        final_recheck(result)
        bounded()
        result["status"] = "complete_conditional_cache_observation"
    except Exception as exc:
        result["error"] = {"type": type(exc).__name__, "message": str(exc),
                           "classification": "observer boundary or collection error; no product verdict"}
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    result["elf_range_read_bytes"] = RANGE_READ_TOTAL
    result["auxiliary_file_bytes_read"] = AUX_BYTES
    result["elapsed_seconds"] = round(time.monotonic() - (DEADLINE - 25), 6)
    payload = json.dumps(result, sort_keys=True, separators=(",", ":"))
    if len(payload.encode("utf-8")) > MAX_OUTPUT_BYTES:
        payload = json.dumps({"schema": result["schema"], "status": "output_bound_exceeded"})
        result["status"] = "output_bound_exceeded"
    print(payload)
    return 0 if result["status"] == "complete_conditional_cache_observation" else 1


if __name__ == "__main__":
    raise SystemExit(main())


