# P26 native closure preparation: source boundary and next observation

## Current decision

Collect the selected Python and prepared Node ELF fields before building a full native closure. The unexecuted candidate is `read_selected_root_elf.py`, with exact inputs and capture requirements in `ROOTS-LAUNCH-PLAN.json`. It reads two executable files as data, uses streaming SHA-256 and bounded metadata reads, and records the fixed platform, boot, kernel executable and auxiliary-vector witnesses required by the existing inspector. It does not launch either executable, discover dependencies or approve a plan.

The exact current inspector is the frozen `ed2fc453042a9f0bc4808c2aea7f015baf1ff73e` source, SHA256 `eea3e6343ae34d9c930a810ca4f363cbcd4264a8d943731f927e41b213755d7a`. Its `_read_elf_metadata` and profile dispatch determine admissibility. The collector reports raw observations; its size, format, mapping or timeout limits are not product refusals. The Director and independent reviewer must evaluate the actual fields against that source after collection.

The previous Bash/Git observation is bound at `session/native_roots/run001.stdout.json`, SHA256 `79c63102812f02ce4bc222a2f776aac2e3d898403609fca8994bdf7c8edf65e5`. It records Bash needing `libtinfo.so.6` and `libc.so.6`, and Git needing `libpcre2-8.so.0`, `libz.so.1` and `libc.so.6`; neither has RPATH/RUNPATH. These are observed direct names, not accepted transitive edges. Python and Node direct names remain pending this candidate. No specific library incompatibility is assumed.

## Exact source availability is resolved

P15 retained the complete upstream archive inside its saved Attempt002 recovery ZIP. The saved ZIP identity is recorded in the repository's `host-loader-p15/P15-DELIVERY.json`: 49,067,300 bytes, SHA256 `d1f978b059b5b11a3b344532a550b9593d7a53ed221dca751c73aa6510de36c5`, version 0, Library ID `libfile_fde3_f-1b955f3186dc8191912549393355a8c2_2ab2a24d43748191957f9bcc356b59de`. Its exact member is `recovery/session/source-provenance/downloads-attempt001/glibc_2.41.orig.tar.xz`.

The Director recovered that member to `portable-inputs/p15-source/glibc_2.41.orig.tar.xz`. Its 20,323,540 bytes and SHA256 `f24aa441021121a79266f0d75242706cab8843a47901fefe74527491807f1998` were independently rechecked. `SOURCE-EXTRACTION.json` binds 14 required upstream files extracted as inert mode-0644 data. This closes the source-availability prerequisite; it does not establish complete native-selection semantics.

The complete `elf/dl-cache.c` and actual `sysdeps/x86_64/dl-cache.h` have now been read. The x86-64 override accepts cache entry flags exactly `0x303`. The implementation supports new, old and combined cache formats; compares library names numerically within digit runs; searches its ordered table; and treats named hwcaps, ISA compatibility and legacy nonzero hwcap fields separately. A raw cache hash cannot substitute for this selection argument.

`PATCH-INDEX-CROSSCHECK.json` independently verifies every byte binding and file-header path set for all 80 active patches from the exact 499,524-byte Debian archive, SHA256 `dda4153511bfd543502d18e5bc9323110996fe9c531f14ae3fad6eb17f027c7d`. No active patch touches `elf/dl-cache.c`, the generic cache header, the actual x86-64 cache header or `elf/dl-deps.c`. The only cache-header patch changes the i386 override. The index retains both historical path normalization and actual strip-one paths; the first analysis assertion that confused those forms is explicitly preserved in the report.

Five patch files affect adjacent selection/build sources: `git-updates.diff`, `arm/unsubmitted-ldso-multilib.diff`, `all/local-remove-manual.diff`, `any/local-ld-multiarch.diff` and `any/unsubmitted-ldso-machine-mismatch.diff`. Their relevant hunks, the Debian amd64 build variables and generated default-directory relation must be fully traced before relying on compiled search directories. The narrow P15 suffix acceptance does not supply this missing whole-selection argument.

## Next closure stage, conditional on supported root observations

1. Start from the four actual executable roots, their interpreters, and only native/shared inputs proven necessary by the current helper import graph. Resolve each actual `DT_NEEDED` name to a named alias and canonical measured file. Retain each image's raw metadata and every transitive edge. Keep Node's shared-library role set distinct from Python, Bash and Git inputs, as the current source requires. A common libc dependency or the main Python image must not be invented as a Python extension role.

2. Bind `/etc/ld.so.cache`, `/etc/ld.so.conf` and `/etc/ld.so.preload` as present files or guarded absences. Bind exact configuration includes using the inspector's finite, nonrecursive wildcard rule. These configuration bytes are required plan inputs; a directory mentioned in configuration is not itself evidence that the runtime loader selects it directly. The actual cache and compiled defaults need their separate source relation.

3. Review the observed cache format, entry order and all comparator-equivalent rows for each needed name. Bind flags, path strings, hwcap/ISA fields and any extension records relevant to the decision. A simple baseline case may avoid host CPU-feature assumptions if all relevant compatible alternatives are absent or select the same measured image. Nonzero hwcap records, competing images, malformed ordering or another cache format require an explicit reviewed branch or a precise collection boundary. They are not automatically product incompatibilities.

4. Establish search precedence from the exact patched loader source for each invocation context: inherited RPATH, absent environment search path, RUNPATH, cache and compiled defaults. The selected Python's special `$ORIGIN/../lib` rule requires its own current nonselection inventory. P15's suffix union supplies only its accepted base/v2/v3/v4 constructor scope. Bind complete immediate entries for each finite relevant directory, all required hwcaps descendants, aliases and guarded absences. Do not recursively scan unrelated system trees.

5. Freeze a bounded follow-on reader only after actual root names and the source-derived path set are known. Use streaming file hashes, range metadata reads, finite image/directory/entry budgets and stable identities. Preserve raw evidence and stop on unreviewed alternatives. The independent N34 rationale must then bind the observed mapping and exact final plan; the collector never writes its own approval.

## Existing unsupported product cases to check separately

The current inspector rejects unreviewed dynamic tags; general `DT_FLAGS` bits beyond `BIND_NOW`; `DT_FLAGS_1` bits beyond `NOW` and `PIE`; malformed or ambiguous ELF mappings; duplicate or unsupported needed names; static executable roots; unreviewed search tokens; conflicting legacy/modern search paths; nonempty global preload; and unsupported configuration includes. Only the exact selected Python and exact pinned libc receive their adopted private profile exceptions. The libc exception is not available to an arbitrary shared library.

The new raw reader retains OSABI, ABI version and full ELF identification bytes. It also records `AT_SECURE` and the actual `/proc/self/exe` target/identity without interpreting those observations as acceptance. Its current one-file-backed-segment string-table limit is a collector simplification; if encountered, an error would require data-reader review and cannot be described as the product's mapping refusal.

No adopted schema, pin, product parser or source-backed acceptance condition was changed. Complete cache selection, native closure, author runtime roles, N34 and H0 remain pending. The source reads and candidate authoring performed here caused no target starts.
