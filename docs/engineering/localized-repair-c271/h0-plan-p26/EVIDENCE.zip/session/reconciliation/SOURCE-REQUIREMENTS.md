# Source requirements for the P26 /0.1.4 H0 plan

This is a static reading of source commit `ed2fc453042a9f0bc4808c2aea7f015baf1ff73e` (tree `de3bd4fa567c4aeb11364e79d99e646dfde81659`). It does not establish H0 eligibility.

## Exact inventory

The operational source document remains `ontokin.current-host-readback-source/0.1.0`, even when the inspection plan uses `ontokin.current-host-readback-inspection-plan/0.1.4`. It has exactly `schema` and `files`; `files` maps canonical repository-relative paths to exactly `sha256`, `size_bytes` and `mode`. Digests are lowercase SHA-256 without a prefix; modes use octal strings such as `0o644`.

Inventory **every regular file**, recursively, under these four trees:

- `ontokin`
- `tests`
- `prototypes/static_tray_v01`
- `tools/static_tray_reader_v01`

Also include these exact twelve files:

| Required file |
| --- |
| `tools/check_local.py` |
| `tools/prepare_current_host_readback.py` |
| `tools/storage_identity.py` |
| `tools/force-agent-verification-requirements.txt` |
| `tools/native-reader-verification-linux-cp312.lock` |
| `pyproject.toml` |
| `docs/engineering/static-tray-mapping-c198/CONTROLS.json` |
| `docs/engineering/static-tray-qualification-c199/EXTERNAL-INPUTS.json` |
| `docs/engineering/localized-repair-c271/current-host-p05/CONTRACT.md` |
| `docs/engineering/localized-repair-c271/current-host-p05/CONTRACT.json` |
| `docs/engineering/localized-repair-c271/current-host-p05/ADOPTION.json` |
| `docs/engineering/localized-repair-c271/current-host-p05/mapping/MAP-EVIDENCE.zip` |

Add `prototypes/__init__.py`, `tools/__init__.py` and `tests/__init__.py` only when present.

This is the exact P06 execution-source set, not all tracked files. It is filesystem-derived: every file under the four trees matters, including an ignored file. No extension filter removes non-Python assets. Symlinks, special files, `__pycache__`, `.pyc`, `.pyo` and privately bound hard-linked files are refused; they are not silently omitted. The inspector bounds each traversal and the execution-source file set to 32,768 entries. Hashes, byte counts and actual modes must match stable private regular files.

General documentation, workflow records, root instructions and Git metadata are outside this particular inventory unless explicitly named above. They still belong to the clean selected Git commit/tree. The inspector separately pins P06 `SCHEMA.json` through `P06_SCHEMA_BINDING`; do not insert it as an extra inventory row. The full-routine driver's broader source/evidence-copy inventory is separate and remains a later obligation.

Serialize inventory and other operational JSON exactly as sorted-key ASCII JSON with comma/colon separators, `ensure_ascii=True`, `allow_nan=False`, **without a trailing newline**. The reader rejects a different byte serialization.

## Checkout and source object

Use an ordinary clean checkout whose `.git` is a directory. The inspector rejects a linked worktree's `.git` file. The entry point, provider and preparer must belong to that same root. Bind actual HEAD commit/tree; no dirty tracked files or ordinary untracked files are admitted anywhere in the checkout. Keep the inventory and evidence outside it. Freeze the source while canonical P26 documents change in the Director's separate checkout.

The closed source object is exactly `{root, commit, tree, inventory}`. The inventory descriptor is exactly `{path, sha256, size_bytes, mode}`, using its fresh absolute path and exact serialized bytes.

**Both selected-node and retained-dependencies preparation plans must use the identical full source object used by H0.** Equality includes the root and the inventory's absolute descriptor, not only its hashes. The inspector directly compares `selected["source"] == plan["source"]`; the preparer requires its own provider's root. Historical plans from P22 cannot be relabeled or reused under a new root or revision. Fresh verified preparation records may bind the retained portable archive bytes to the current frozen source.

## Source basis

- [Inspector at the selected revision](https://github.com/Omegapy/OntoKin/blob/ed2fc453042a9f0bc4808c2aea7f015baf1ff73e/prototypes/static_tray_v01/current_host_inspection_v01.py): `SOURCE_TREES/SOURCE_FILES/SOURCE_OPTIONAL`, `_plan_shape`, `_source_paths`, `_check_source_files`, `_git_state`, `_check_git`, `_decode`, `_check_installation`, `_p06_definitions`.
- [Provider](https://github.com/Omegapy/OntoKin/blob/ed2fc453042a9f0bc4808c2aea7f015baf1ff73e/prototypes/static_tray_v01/current_host_readback_v01.py): source constants, `source_inventory`, `file_binding`, `_verify_source`.
- [Preparer](https://github.com/Omegapy/OntoKin/blob/ed2fc453042a9f0bc4808c2aea7f015baf1ff73e/tools/prepare_current_host_readback.py): `_source`.
- [P06 implementation policy](https://github.com/Omegapy/OntoKin/blob/ed2fc453042a9f0bc4808c2aea7f015baf1ff73e/docs/engineering/localized-repair-c271/current-host-p06/PROVIDER-IMPLEMENTATION.md): source closure and separate broader driver inventory.
