#!/usr/bin/env python3
"""Unexecuted candidate: fixed, bounded raw ELF observations; no policy verdict.

Read /usr/bin/bash and /usr/bin/git as data, list names in one fixed lib-dynload
directory, and observe builtin module names. Never load either image, import
project code or ctypes/_ctypes, follow a target symlink, invoke subprocesses,
recurse through directories, or write files. The Director captures stdout/stderr.
"""
import hashlib
import json
import os
import signal
import stat
import struct
import sys
import time

TARGETS = ("/usr/bin/bash", "/usr/bin/git")
DYNLIB_DIRECTORY = "/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/lib-dynload"
MAX_FILE_BYTES = 8 * 1024 * 1024
MAX_TOTAL_BYTES = 16 * 1024 * 1024
MAX_OUTPUT_BYTES = 512 * 1024
MAX_PROGRAM_HEADERS = 4096
MAX_DYNAMIC_ENTRIES = 8192
MAX_STRING_BYTES = 4096
DEADLINE = time.monotonic() + 25
TAG_NAMES = {
    0: "DT_NULL", 1: "DT_NEEDED", 5: "DT_STRTAB", 10: "DT_STRSZ",
    14: "DT_SONAME", 15: "DT_RPATH", 16: "DT_SYMBOLIC",
    22: "DT_TEXTREL", 24: "DT_BIND_NOW", 29: "DT_RUNPATH", 30: "DT_FLAGS",
    0x6FFFFEFB: "DT_DEPAUDIT", 0x6FFFFEFC: "DT_AUDIT",
    0x6FFFFFFB: "DT_FLAGS_1", 0x7FFFFFFD: "DT_AUXILIARY",
    0x7FFFFFFF: "DT_FILTER",
}
STRING_TAGS = {1, 14, 15, 29, 0x6FFFFEFB, 0x6FFFFEFC, 0x7FFFFFFD, 0x7FFFFFFF}


def bounded():
    if time.monotonic() > DEADLINE:
        raise TimeoutError("collector 25-second deadline")


def alarm(_signum, _frame):
    raise TimeoutError("collector 25-second alarm")


def identity(st):
    return {"dev": st.st_dev, "ino": st.st_ino, "mode": st.st_mode,
            "nlink": st.st_nlink, "uid": st.st_uid, "gid": st.st_gid,
            "size": st.st_size, "mtime_ns": st.st_mtime_ns,
            "ctime_ns": st.st_ctime_ns}


def component_observations(path):
    rows = []
    current = ""
    for part in path.split("/")[1:]:
        bounded()
        current += "/" + part
        st = os.lstat(current)
        rows.append({"path": current, "identity": identity(st)})
        if stat.S_ISLNK(st.st_mode):
            raise ValueError("fixed target has symlink component: " + current)
        if current != path and not stat.S_ISDIR(st.st_mode):
            raise ValueError("fixed target has non-directory parent: " + current)
    return rows


def raw_elf(data):
    def span(offset, size):
        bounded()
        if offset < 0 or size < 0 or offset > len(data) or size > len(data) - offset:
            raise ValueError("ELF range outside measured file")
        return data[offset:offset + size]

    if span(0, 16)[:7] != b"\x7fELF\x02\x01\x01":
        raise ValueError("reader supports ELF64 little-endian version 1 only")
    header = struct.unpack("<HHIQQQIHHHHHH", span(16, 48))
    etype, machine, version, entry, phoff, shoff, flags, ehsize, phsize, phnum, shsize, shnum, shstr = header
    if ehsize != 64 or phsize != 56 or not 0 < phnum <= MAX_PROGRAM_HEADERS:
        raise ValueError("unsupported or oversized ELF program-header layout")
    span(phoff, phsize * phnum)
    ph = []
    for i in range(phnum):
        ptype, pflags, offset, vaddr, paddr, filesz, memsz, align = struct.unpack(
            "<IIQQQQQQ", span(phoff + i * phsize, phsize))
        span(offset, filesz)
        ph.append({"index": i, "type": ptype, "flags": pflags, "offset": offset,
                   "vaddr": vaddr, "paddr": paddr, "filesz": filesz,
                   "memsz": memsz, "align": align})
    result = {"elf_class": 64, "byte_order": "little", "type": etype,
              "machine": machine, "version": version, "entry": entry,
              "header_flags": flags, "program_headers": ph,
              "pt_interp": [], "dynamic_entries": [], "dynamic_strings": [],
              "dt_needed": [], "dt_soname": [], "dt_rpath": [], "dt_runpath": [],
              "dt_flags": [], "dt_flags_1": [], "review_relevant_tags": []}
    for p in ph:
        if p["type"] == 3:
            if p["filesz"] > MAX_STRING_BYTES:
                raise ValueError("PT_INTERP exceeds reader string bound")
            raw = span(p["offset"], p["filesz"])
            result["pt_interp"].append({"program_header_index": p["index"],
                "raw_hex": raw.hex(), "ends_with_nul": raw.endswith(b"\x00"),
                "text": raw[:-1].decode("ascii") if raw.endswith(b"\x00") else None})
    dyn = [p for p in ph if p["type"] == 2]
    if not dyn:
        result["pt_dynamic_present"] = False
        return result
    if len(dyn) != 1:
        raise ValueError("multiple PT_DYNAMIC segments require separate review")
    p = dyn[0]
    result["pt_dynamic_present"] = True
    if p["filesz"] % 16 or p["filesz"] // 16 > MAX_DYNAMIC_ENTRIES:
        raise ValueError("unsupported or oversized dynamic segment")
    entries = result["dynamic_entries"]
    for i in range(p["filesz"] // 16):
        tag, value = struct.unpack("<qQ", span(p["offset"] + 16 * i, 16))
        entries.append({"index": i, "tag": tag, "tag_hex": hex(tag),
                        "name": TAG_NAMES.get(tag), "value": value})
        if tag == 0:
            break
    if not entries or entries[-1]["tag"] != 0:
        raise ValueError("no DT_NULL within bounded dynamic segment")
    result["dynamic_segment_capacity_entries"] = p["filesz"] // 16
    result["entries_after_first_dt_null_not_interpreted"] = p["filesz"] // 16 - len(entries)
    string_entries = [e for e in entries if e["tag"] in STRING_TAGS]
    if string_entries:
        addresses = [e["value"] for e in entries if e["tag"] == 5]
        sizes = [e["value"] for e in entries if e["tag"] == 10]
        if len(addresses) != 1 or len(sizes) != 1:
            raise ValueError("string-bearing dynamic tags need unique DT_STRTAB/DT_STRSZ")
        address, size = addresses[0], sizes[0]
        loads = [q for q in ph if q["type"] == 1 and q["vaddr"] <= address
                 and address - q["vaddr"] <= q["filesz"]
                 and size <= q["filesz"] - (address - q["vaddr"])]
        if len(loads) != 1:
            raise ValueError("dynamic string table is not within one file-backed PT_LOAD")
        table_offset = loads[0]["offset"] + address - loads[0]["vaddr"]
        span(table_offset, size)
        result["dynamic_string_table"] = {"vaddr": address, "size": size,
                                           "file_offset": table_offset}
        fields = {1: "dt_needed", 14: "dt_soname", 15: "dt_rpath", 29: "dt_runpath"}
        for e in string_entries:
            bounded()
            offset = e["value"]
            if offset >= size:
                raise ValueError("dynamic string offset outside DT_STRSZ")
            start = table_offset + offset
            end = data.find(b"\x00", start, min(table_offset + size, start + MAX_STRING_BYTES + 1))
            if end < 0:
                raise ValueError("dynamic string lacks terminator within reader bound")
            raw = data[start:end]
            row = {"dynamic_entry_index": e["index"], "tag": e["tag"],
                   "name": e["name"], "offset": offset, "raw_hex": raw.hex(),
                   "text": raw.decode("ascii")}
            result["dynamic_strings"].append(row)
            if e["tag"] in fields:
                result[fields[e["tag"]]].append(row["text"])
    result["dt_flags"] = [e["value"] for e in entries if e["tag"] == 30]
    result["dt_flags_1"] = [e["value"] for e in entries if e["tag"] == 0x6FFFFFFB]
    review_tags = {16, 22, 24, 30, 0x6FFFFFFB, 0x6FFFFEFB, 0x6FFFFEFC, 0x7FFFFFFD, 0x7FFFFFFF}
    result["review_relevant_tags"] = [e for e in entries if e["tag"] in review_tags]
    return result


def collect(path, remaining):
    before_components = component_observations(path)
    flags = os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC
    with os.fdopen(os.open(path, flags), "rb") as stream:
        before = os.fstat(stream.fileno())
        if not stat.S_ISREG(before.st_mode):
            raise ValueError("fixed target is not a regular file")
        if not 0 < before.st_size <= min(MAX_FILE_BYTES, remaining):
            raise ValueError("fixed target exceeds byte bound or is empty")
        if identity(before) != before_components[-1]["identity"]:
            raise ValueError("file identity changed before bounded read")
        data = stream.read(before.st_size + 1)
        after = os.fstat(stream.fileno())
    bounded()
    after_components = component_observations(path)
    if len(data) != before.st_size or identity(before) != identity(after) or before_components != after_components:
        raise ValueError("fixed target or pathname changed during bounded read")
    row = {"path": path, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest(),
           "before_identity": identity(before), "after_identity": identity(after),
           "components_before": before_components, "components_after": after_components,
           "stable_observation": True}
    try:
        row["elf"] = raw_elf(data)
        row["parse_status"] = "parsed_raw_fields"
    except Exception as exc:
        row["parse_status"] = "reader_limit_or_parse_error"
        row["parse_error"] = {"type": type(exc).__name__, "message": str(exc)}
    return row


def fixed_directory_names():
    before_components = component_observations(DYNLIB_DIRECTORY)
    flags = os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC
    fd = os.open(DYNLIB_DIRECTORY, flags)
    try:
        before = os.fstat(fd)
        if identity(before) != before_components[-1]["identity"]:
            raise ValueError("fixed directory identity changed before name listing")
        names = []
        with os.scandir(fd) as entries:
            for item in entries:
                bounded()
                if len(names) >= 256 or len(os.fsencode(item.name)) > 255:
                    raise ValueError("fixed directory filename inventory exceeds bound")
                names.append(item.name)
        after = os.fstat(fd)
    finally:
        os.close(fd)
    after_components = component_observations(DYNLIB_DIRECTORY)
    if identity(before) != identity(after) or before_components != after_components:
        raise ValueError("fixed directory changed during name listing")
    return {"path": DYNLIB_DIRECTORY, "names": sorted(names),
            "before_identity": identity(before), "after_identity": identity(after),
            "components_before": before_components, "components_after": after_components,
            "stable_observation": True, "entry_contents_read": False,
            "entry_types_observed": False, "recursive": False}


def main():
    result = {"schema": "ontokin-p26-native-roots-raw-v1", "targets": list(TARGETS),
              "status": "incomplete", "observations": [], "total_file_bytes_read": 0,
              "python_executable": sys.executable,
              "python_builtin_module_names": list(sys.builtin_module_names),
              "ctypes_builtin_name_present": "_ctypes" in sys.builtin_module_names,
              "ctypes_module_imported": "_ctypes" in sys.modules or "ctypes" in sys.modules,
              "scope": "raw Bash/Git file observations; no native closure or H0 verdict"}
    try:
        if len(sys.argv) != 1:
            raise ValueError("fixed collector accepts no arguments")
        if result["ctypes_module_imported"]:
            raise ValueError("unexpected ctypes module already imported")
        signal.signal(signal.SIGALRM, alarm)
        signal.setitimer(signal.ITIMER_REAL, max(0.001, DEADLINE - time.monotonic()))
        result["fixed_lib_dynload_filename_inventory"] = fixed_directory_names()
        for path in TARGETS:
            row = collect(path, MAX_TOTAL_BYTES - result["total_file_bytes_read"])
            result["observations"].append(row)
            result["total_file_bytes_read"] += row["bytes"]
            if row["parse_status"] != "parsed_raw_fields":
                raise ValueError("stopped at raw reader limit; no policy conclusion")
        bounded()
        result["status"] = "complete_raw_observation"
    except Exception as exc:
        result["error"] = {"type": type(exc).__name__, "message": str(exc)}
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    result["elapsed_seconds"] = round(time.monotonic() - (DEADLINE - 25), 6)
    payload = json.dumps(result, sort_keys=True, separators=(",", ":"))
    if len(payload.encode("utf-8")) > MAX_OUTPUT_BYTES:
        payload = json.dumps({"schema": result["schema"], "status": "output_bound_exceeded"})
        result["status"] = "output_bound_exceeded"
    print(payload)
    return 0 if result["status"] == "complete_raw_observation" else 1


if __name__ == "__main__":
    raise SystemExit(main())
