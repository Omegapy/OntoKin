# P26 independent H0 requirements review

Reviewer: `/root/h0_review`. Source supplied by the Director: `ed2fc453042a9f0bc4808c2aea7f015baf1ff73e`. Actual inspector bytes were independently hashed as `eea3e6343ae34d9c930a810ca4f363cbcd4264a8d943731f927e41b213755d7a` (233,502 bytes). Current-main governance was read from the Director's frozen `session/governing` snapshot. This reviewer has no main lease and does not own the Director's plan, source checkout, publication or delivery.

**Disposition: requirements identified; no operational plan supplied or accepted.** Two narrow prerequisite captures have succeeded. They are raw observations, not H0 execution or source-completeness acceptance. The command-inventory concern described below does not establish a whole-plan contradiction.

## Required selected profile

The exact pair is `ontokin.current-host-readback-inspection-plan/0.1.4` and `linux-glibc-declared-python-origin-rpath-libc-plt-static-tls-rtld-paths-v1`. It inherits P05/P07, P11/P13, P16 and P17. P25 accepted only a bounded implementation. Its `ACCEPTANCE.json` expressly withholds operational adoption under N34. Historical `/0.1.3` source inventories, P23 advisory import lists and old temporary-host paths cannot become current `/0.1.4` evidence by relabelling.

The closed plan keys are `schema`, `contract`, `source`, `author`, `runtime`, `dependencies`, `host_static`, `environment`, `commands`, `evidence`, `limits`. Contract remains `ontokin.current-host-readback/0.1.0`. The plan is canonical JSON, with an independently reviewed expected digest supplied outside the plan. All real execution-bearing fields must be concrete. An honest partial candidate may record missing prerequisites in separate evidence; it is not an executable plan.

| Area | Minimum exact inputs and relationships |
| --- | --- |
| Source | Ordinary clean checkout, actual commit/tree/root, complete 627-file candidate inventory subject to independent exact comparison, author entry-point descriptor, unchanged P05/P06 sources and full imported helper source. The count alone is not source equality. |
| Author | Closed `{entry_point, source_descriptor, python_descriptor, python_version, runtime_inventory, metadata_inventory, git_descriptor, source_commands}`. Actual selected Python descriptor must match executing resolved Python and version; source descriptor must match the entry point and complete source inventory. |
| Author runtime | Closed `{schema, executable, interpreter, files, aliases, startup_files, extension_files, loader_inputs, environment}` with schema `ontokin.current-host-readback-author-runtime/0.1.0`. All three file lists are nonempty in source. File/alias maps must cover the exact named union. Every loaded file-backed module, including available bytecode caches, must be bound in runtime or project source. Builtin/frozen modules remain distinct from file-backed modules. |
| Metadata | Closed `{schema, lock, packages}` with schema `ontokin.current-host-readback-author-metadata/0.1.0`. Exactly seven unique lock-matching packages. Each row is `{name, version, distribution_root, metadata_files}`. Bind every regular metadata file and necessary directory in each actual `.dist-info` root, including METADATA; reject executable metadata entries. P19's shared-runtime mismatch stays historical, and separately prepared inputs need current bindings. |
| Node | Exact selected Node v24.22.1, digest `acbe4b8d9153b841ed0697cbfc4f93e767386620edb745ab9358306c0a6f31aa`, 126,951,512 bytes, mode 0755; exact 45,186,132-byte source archive with digest `100ae976555b388472c3e875aeda67bd7d8c9229a968a11661fb852624adaeb5`; fresh isolated installation provenance. No Node invocation for preparation. |
| Dependencies | Complete retained 24-file tree and necessary directory modes, authenticated archive/member identities, exact source object and actual successful preparer plan/report/index. Partial old destinations and past-host installation receipts are not current installations. |
| Host | Closed `{platform, files, aliases, roles, resolution, path_guards}`. Actual Linux/glibc/x86-64 boot/kernel values, complete role/alias/file relations and every significant ancestor/absence guard. Source and output roots remain isolated. |
| Closure | Resolution has the eight inherited keys plus `origin_rpath`, `libc_plt`, `rtld_paths`. Every image row is `{file, metadata, resolved_needed}`; `needed_edges` must equal the exact finite transitive set. Root images include Node, selected Python, Bash, declared commands, fixed-PATH Git, actual author native extensions, every present RTLD candidate and the selected ELF interpreter. |
| Loader inputs | Exact cache/configuration/include/preload bindings or supported precise absence; complete relevant search-directory entries and hwcaps descendants; independently justified selection map. A hash of opaque cache bytes alone is not a selection argument. |
| Future commands | Exactly Node `--version`, then `/usr/bin/ldd NODE`, once each. Exact five-variable environment, labels, cwd topology, 5,000 ms total / 3,000 ms work / 2,000 ms cleanup. H1 remains a separate later phase. |
| Evidence | Existing external parent and exact ancestor identities; absent fresh attempt/output paths; bound external capture authority and initial log prefix; independent candidate descriptor/digest and unresolved-attempt accounting. No plan approval field. |

The five separately bound Git reads are the existing toplevel, HEAD commit, selected commit tree, tracked status and untracked-file inventory reads. They are executable inputs with their own canonical Git descriptor and native closure; they are not authorized by this review. Static inspector invocation imports project helpers and performs these reads, so it is not equivalent to either raw capture already performed.

## Author import and ELF closure

The current `_load_helpers` imports the provider, supervisor, `tools.check_local` and preparer only after source, author, origin/libc/resolution and path proof. Their actual transitive imports must be inventoried. P23's 34-root list is useful navigation only: its `__future__`, `ctypes`, `importlib.metadata`, normal argparse work and lazy imports cannot be omitted simply because no target is launched. Recompute against current source and actual selected runtime before claiming completeness. This review has not executed an import collector or enumerated unrelated installed software.

The exact Python/libc/loader pin matches are necessary but insufficient. Native extension paths cannot be inferred from module names. Each actual admitted extension's ELF metadata, interpreter if present, needed edges and native dependencies must be covered. Cache/startup files actually accessible to imports matter even with `-B`, which prevents bytecode writes rather than proving no existing cache can be read.

P11's exact selected Python `$ORIGIN/../lib` rule remains nonselecting for the **complete** needed-name union across all declared images. Bind the canonical direct-main subject, guarded origin and sibling library directory, `/proc/self/exe` identity, exactly one `AT_SECURE=0`, the finite suffix inventory and each present/absent alternative. No candidate of any filesystem kind may exist for a needed name in those variants. A few direct Python dependency names do not replace the complete union.

P16/P17 exceptions apply only after exact selected dependency-role/alias/file/image/interpreter bindings for the pinned libc and loader. They recognize metadata, not safe PLT rewriting, TLS allocation, relocations or actual native execution. All earlier-profile behavior and failure history stay intact.

## `/0.1.4` path requirements

The three literal candidates remain ordered: `/lib64/ld-linux-x86-64.so.2`, `/lib/ld-linux.so.2`, `/libx32/ld-linux-x32.so.2`. The fixed script is `/usr/bin/ldd`, 5,356 bytes, mode 0755, SHA-256 `7bcd61a279946cb376d36fd91f4938ab4f4aba48e793c652a9797319d23f8dd3`, with direct `#!/bin/bash`.

`rtld_paths` has exactly `{schema, components, absences}`. The nine components must occur in source-prescribed ASCII order, each with `{path, kind, identity, target}` and the seven actual integer stat values, including nlink. The three exact symlinks are `/lib -> usr/lib`, `/lib64 -> usr/lib64`, and `/usr/lib64/ld-linux-x86-64.so.2 -> ../lib/x86_64-linux-gnu/ld-linux-x86-64.so.2`. Canonical terminal is the fixed loader at `/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2`.

The two absence rows are exactly the physical first-missing witnesses: `/usr/lib/ld-linux.so.2` under `/usr/lib`, and `/libx32` under `/` with remaining suffix `ld-linux-x32.so.2`. Literal parent strings in candidate rows remain `/lib` and `/libx32`. The present/absence guards and runtime/host/unique-image maps must agree with these identities. The raw captured rows require a documented projection into those closed shapes; raw `parent_identity` and `observed_errno` do not become extra operational keys.

A full production proof uses descriptor-relative no-follow walks, exact raw link bytes, two independent root-reanchored passes, exact terminal file bytes, precise ENOENT and all inherited guards/rechecks. The P26 raw topology capture establishes compatible raw input facts only. It does not substitute that proof.

## N34 and actual source review

N34 is an external gate: withhold operational-plan adoption while actual loader/script source-completeness evidence is missing, rejected or unresolved. There is no runtime N34 pass/skip or approval Boolean. P13 likewise preserves historical N57 unchanged as an external-review obligation.

P15 independently accepted the exact pinned loader's four-entry suffix union (`""`, x86-64-v2/v3/v4 under `glibc-hwcaps`) for ordinary direct selected-Python invocation. Reuse requires the actual source/package argument and exact applicability, rationale, variant and new plan bindings. A previous decision text or matching image alone is insufficient. Its source association is not a reproduced build or signature verification. This review read the prior decision and argument summary, but has not re-audited all P15 underlying source/build bytes or accepted their reuse in a complete P26 plan.

The fresh ldd text must receive its own complete branch/command review. It invokes only the fixed RTLD candidates externally; other script command names are Bash builtins/functions. Shell interpreter, native inputs and emitted clean-environment effects remain actual closure requirements. Full plan/source acceptance is still absent.

## Command-inventory concern and disposition

The source requires a nonempty `inspector_commands.commands` descriptor list. A literal loader alias is not an ordinary canonical descriptor; the canonical loader is not string-equal to a literal candidate and, if placed in this list, is subjected to the ordinary executable PT_INTERP predicate. The exact archived loader has no PT_INTERP. These are real constraints on those proposed encodings.

They do **not** prove that the whole schema is unsatisfiable. P07 describes `inspector_commands` collectively; P08 identifies the module docstring as its concrete nested-shape index. Neither requires `commands` to be disjoint from `interpreter` or exactly equal only to commands invoked inside script branches. An explicit redundant descriptor of the actual canonical Bash interpreter can represent that already-required executable, while `rtld_candidates` independently carries all external loader calls. This must be described as redundant interpreter closure, never an invented script-body Bash call. It adds no executable, argv, authority or source exception. An unrelated utility inserted merely to fill the list would not have that justification.

The initial suspicion of an unavoidable blocker is therefore withdrawn. `/root/handoff_audit` independently reached the same boundary. No source change, mock, product call or expectation change was made to resolve this interpretation.

## Current evidence and next gate

The readiness capture ran once, returned zero and matched all three fixed image pins. The RTLD capture ran once, returned zero, retained equal raw passes, a one-link pinned script, exact targets and parent/component-consistent ENOENT witnesses. Both captured empty stderr. Their exact launch/review/source/output hashes are retained separately. These successes do not imply full native closure, N34 or H0 acceptance.

No earlier unavoidable representation blocker is established by this review. Continue only the Director's bounded reconstruction/preparation of necessary portable inputs, then current author/runtime/metadata/native-closure collection and exact full-plan review. Stop at the first actual mismatch, unsupported requirement or accepted complete plan. No target process, inspector/private validator, product test, Git operation, installation or host probe was executed by this reviewer.
