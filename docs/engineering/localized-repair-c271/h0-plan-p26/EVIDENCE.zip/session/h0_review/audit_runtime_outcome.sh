#!/usr/bin/env bash
set -euo pipefail
rt_evidence=/workspace/scratch/cf652064a9a1/session/author_runtime/attempt001/run001.stdout.json
rt_plan=/workspace/scratch/cf652064a9a1/session/author_runtime/candidate001/LAUNCH-PLAN.json
jq -e --slurpfile launch "$rt_plan" '
  . as $observed |
  .status == "complete_raw_observation" and .project_imports == false and
  .third_party_imports == false and .collector_subprocesses == 0 and
  .collector_filesystem_writes == false and .target_starts == 0 and .h0_complete == false and
  .source == $launch[0].source and .python == $launch[0].python and
  .environment == $launch[0].environment and .sys_path == $launch[0].allowed_sys_path and
  .direct_stdlib_modules == $launch[0].direct_stdlib_modules and
  .source_read_set_verified_as_data == $launch[0].source_read_set and
  .metadata_candidate.packages == $launch[0].metadata_packages and
  .metadata_candidate.lock == $launch[0].lock and
  (.runtime_candidate_fragment.files | keys) == (.runtime_candidate_fragment.aliases | keys) and
  ([.runtime_candidate_fragment.files | to_entries[] |
    select($observed.explicit_input_observations[.key].binding != .value)] | length) == 0 and
  ([.runtime_candidate_fragment.aliases | to_entries[] |
    select(.value.symlink != false or .value.link_target != null or .value.resolved_path != .key)] | length) == 0 and
  ([.module_observations[] | select(.file != null and .name != "__main__") |
    .file | select($observed.runtime_candidate_fragment.files[.] == null)] | length) == 0 and
  ([.module_observations[] | select(.cache_state == "existing_bound") |
    .cached | select($observed.runtime_candidate_fragment.files[.] == null)] | length) == 0 and
  ([.direct_stdlib_modules[] as $root | select([.module_observations[] | select(.name == $root)] | length != 1)] | length) == 0 and
  (.runtime_candidate_fragment.existing_cache_files | sort) ==
    ([.module_observations[] | select(.cache_state == "existing_bound") | .cached] | unique | sort) and
  (.runtime_candidate_fragment.observed_extension_files | length) == 0
' "$rt_evidence"
rt_count=0
while IFS=$'\t' read -r rt_path rt_sha rt_bytes rt_mode rt_links; do
  test -f "$rt_path"
  test ! -L "$rt_path"
  rt_sum=$(sha256sum -- "$rt_path")
  test "${rt_sum%% *}" = "$rt_sha"
  test "$(stat -c %s -- "$rt_path")" = "$rt_bytes"
  test "0o$(stat -c %a -- "$rt_path")" = "$rt_mode"
  test "$(stat -c %h -- "$rt_path")" = "$rt_links"
  test "$rt_links" = 1
  rt_count=$((rt_count + 1))
done < <(jq -r '.explicit_input_observations | to_entries[] | [.key,.value.binding.sha256,.value.binding.size_bytes,.value.binding.mode,.value.identity.nlink] | @tsv' "$rt_evidence")
test "$rt_count" = 296
printf 'All declared cross-bindings agree; %s actual input files match SHA-256, size, mode and nlink 1.\n' "$rt_count"
