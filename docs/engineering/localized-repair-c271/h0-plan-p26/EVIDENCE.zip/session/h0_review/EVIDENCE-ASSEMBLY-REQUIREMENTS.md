# Evidence assembly requirements for current H0

Requirements extraction only; this is not a Director plan or execution approval. Source: `frozen-source/prototypes/static_tray_v01/current_host_inspection_v01.py`, SHA-256 `eea3e6343ae34d9c930a810ca4f363cbcd4264a8d943731f927e41b213755d7a`. Relevant functions: `_plan_shape`, `output_paths`, `_ancestors`, `_check_evidence`, `_check_log_prefix`, `source_commands`, `_check_git`, `_required_paths`, `_validate`, `inspect_host`.

## Closed evidence shape and parent

`evidence` has exactly `parent, attempt_root, ancestor_identities, outputs, outer_capture`.

Let **P** be the existing evidence parent and **A** its proposed direct child. Both names must be absolute, normalized and free of symlink components. `A.parent == P`; A must not exist, including a dangling symlink. Do not pre-create A or its command directories for static validation.

P must neither contain nor lie inside any of: the source root, the dependency root, or `Node executable.parent.parent`. Shared workspace ancestors are acceptable; an evidence parent equal to a protected root is not.

`ancestor_identities` is exactly the lexicographically path-sorted list for P and every parent through `/`. Each row has exactly:

`{path, kind:"directory", device:<int>, inode:<int>, mode:"0o…", target:null}`

These are ordinary six-field path rows, not the seven-integer RTLD component identities. Preserve large inode integers exactly; do not route them through floating-point JSON tooling.

## Exact future output topology

`outputs` has exactly `reserved, preflight, result, completion, host, node_version, shared_libraries`. There is no descriptor for a nonexistent future output.

| Field | Exact relative name under A |
| --- | --- |
| reserved | `reserved.json` |
| preflight | `preflight.json` |
| result | `result.json` |
| completion | `completion.json` |
| host | `HOST.json` |

Each command subtree has exactly `intent, started, inspection, postflight, failure, stdout, stderr, supervisor_outcome`. The first five are `A/ID/KEY.json`. `supervisor_outcome` has exactly `raw, committed`.

| ID | Label | stdout / stderr | raw supervisor receipt | committed supervisor receipt |
| --- | --- | --- | --- | --- |
| node_version | host-node-version | `A/node_version/host-node-version.stdout.log` / `.stderr.log` | `A/node_version/host-node-version.process.json` | `A/node_version/supervisor-outcome.json` |
| shared_libraries | host-shared-libraries | `A/shared_libraries/host-shared-libraries.stdout.log` / `.stderr.log` | `A/shared_libraries/host-shared-libraries.process.json` | `A/shared_libraries/supervisor-outcome.json` |

The unchanged supervisor owns the raw receipt; the wrapper owns the distinct committed receipt. A successful completed observation has no failure files. Merely listing these future paths launches nothing.

## Outer authority and append-only capture

`outer_capture` has exactly `authority, log`. Each is an existing file descriptor with exactly `path, sha256, size_bytes, mode`. Both paths must be canonical and outside A. The authority is an ordinary immutable bound private regular file. Its content is an independent review responsibility; the inspector checks identity, not an embedded approval schema.

The log descriptor hashes only its already-existing initial prefix. Prefix size may be zero and must be at most **16,777,216 bytes**. Current file size must be at least the prefix length and at most **67,108,864 bytes**. It must remain a regular file, nlink 1, with the declared mode. Prefix SHA-256, device, inode, file mode/type and link count remain unchanged; length may only increase during checks. The snapshot records `identity=[dev,ino,st_mode,nlink]`, canonical resolved path and the prefix binding, allowing append growth. The inspector does not write either outer file.

Both outer paths and their significant ancestors must also be present in the complete `host_static.path_guards` closure. The plan file, source inventory, runtime/metadata descriptors, installation indexes, source archive, resolution rationale, origin review, and required metadata/native paths likewise enter `_required_paths`; generic guard omission is not repaired by an outer descriptor.

Avoid a digest cycle: finalize the authority and initial log prefix before hashing the plan. Supply the final plan digest externally to the harness/inspector. The external final review may bind that plan digest. Do not edit the bound authority or prefix to insert the final plan digest afterward. This is an assembly consequence of content binding, not an added product schema.

## Exact future commands

There are exactly two ordered command objects, with keys:

`id, argv, cwd, label, timeout_ms, active_work_ms, cleanup_ms, expected_direct_starts, stdout_predicate, stderr_predicate`.

| Field | First | Second |
| --- | --- | --- |
| id | `node_version` | `shared_libraries` |
| argv | `[N,"--version"]` | `["/usr/bin/ldd",N]` |
| cwd | `A/node_version` | `A/shared_libraries` |
| label | `host-node-version` | `host-shared-libraries` |
| stdout_predicate | exact `v24.22.1\n` | `linux-glibc-declared-closure-v1` |
| stderr_predicate | empty string | empty string |

Both use integer `timeout_ms=5000, active_work_ms=3000, cleanup_ms=2000, expected_direct_starts=1`. N is the exact selected Node executable. The second stdout predicate retains its historical string even under plan /0.1.4. Commands have no extra environment key; the top environment is exactly `PATH=/usr/bin:/bin, LANG=C.UTF-8, LC_ALL=C.UTF-8, TZ=UTC, UV_THREADPOOL_SIZE=2`.

## Fixed limits

`limits` must equal the exact source object, with no missing/extra keys:

| Key | Value |
| --- | ---: |
| direct_starts | 2 |
| command_ms | 5000 |
| active_work_ms | 3000 |
| cleanup_ms | 2000 |
| log_bytes | 4194304 |
| inspection_bytes | 8388608 |
| host_bytes | 8388608 |
| document_bytes | 16777216 |
| stage_bytes | 67108864 |
| stage_entries | 2048 |
| static_ms | 60000 |
| publication_ms | 30000 |

## Five source-read command records

`author.source_commands` is an ordered list of five exact `{argv, environment, timeout_ms}` records; no cwd or label field. Every argv starts `["git","-c","core.fsmonitor=false","-C",S]`, where S is the exact source root. Append, in order:

1. `["rev-parse","--show-toplevel"]`
2. `["rev-parse","--verify","HEAD^{commit}"]`
3. `["rev-parse","--verify",C+"^{tree}"]`
4. `["status","--porcelain=v1","--untracked-files=no"]`
5. `["ls-files","--others","--exclude-standard","-z"]`

C is the exact source commit. Each timeout is integer **5000 ms**. Each environment is the five top-level values plus `GIT_CONFIG_NOSYSTEM=1, GIT_CONFIG_GLOBAL=/dev/null, GIT_TERMINAL_PROMPT=0, GIT_ATTR_NOSYSTEM=1, GIT_OPTIONAL_LOCKS=0, GIT_NO_REPLACE_OBJECTS=1, GIT_NO_LAZY_FETCH=1, GIT_CEILING_DIRECTORIES=S.parent`.

The declared canonical Git descriptor must match the executable selected by the fixed PATH. Its actual named PATH alias, canonical image, roles and guards must all be admitted before these reads. Expected returned strings are S, C, source tree, empty, empty. The ordinary `.git` directory/ref/index witnesses must remain equal across reads. Per-read actual timeout is bounded by five seconds and the remaining 60-second static deadline.

## Static H0 versus later observation

The public static CLI is the selected Python with `-I -S -B`, the exact inspector source entry point, `--plan PLAN_PATH --plan-sha256 EXTERNAL_SHA256`, and **no `--observe`**. It uses the exact five-value environment. Default static validation admits all source/runtime/native/metadata/evidence inputs and then performs the five Git reads; it launches no Node/ldd and creates no attempt evidence. Success returns `mode:"static", state:"STATIC_READY", command_attempts:[], host:null, evidence_finalized:false`, zero target counts, and source-validation evidence.

Only a separately authorized later `--observe` call reserves A and both command directories, runs the two commands, and produces `HOST.json` and completion evidence. Even success is `OBSERVED_UNAPPROVED`, not qualification. This brief authorizes neither static invocation nor observation and does not waive N34 or historical N57.

