"""Independent source-data audit; no project imports or Git commands."""
import ast
import hashlib
import json
import os
from pathlib import Path
import stat
import time

BASE = Path('/workspace/scratch/cf652064a9a1')
INPUT = BASE / 'session/source_preparation'
OUTPUT = BASE / 'session/h0_review/SOURCE-OBJECT-REVIEW-002.json'
DEADLINE = time.monotonic() + 60
report = {'schema': 'ontokin.c271.p26-independent-source-object-review/1',
          'reviewer': '/root/h0_review', 'checks': [], 'files': [],
          'project_imports': [], 'Git_commands': [], 'product_tests': [],
          'H0_accepted': False, 'N34_satisfied': False}


def require(name, condition):
    report['checks'].append({'check': name, 'passed': bool(condition)})
    if not condition:
        raise ValueError(name)
    if time.monotonic() > DEADLINE:
        raise TimeoutError('Source-data audit exceeded 60-second allowance')


def ident(s):
    return [s.st_dev, s.st_ino, s.st_mode, s.st_nlink, s.st_size,
            s.st_mtime_ns, s.st_ctime_ns]


def describe(p):
    raw = p.read_bytes()
    return {'path': str(p), 'sha256': hashlib.sha256(raw).hexdigest(),
            'size_bytes': len(raw), 'mode': oct(stat.S_IMODE(p.lstat().st_mode))}


def constants(p):
    values = {}
    def literal(node):
        if isinstance(node, ast.Name):
            return values[node.id]
        if isinstance(node, (ast.Tuple, ast.List)):
            return tuple(literal(item) for item in node.elts)
        return ast.literal_eval(node)
    for n in ast.parse(p.read_bytes(), filename=str(p)).body:
        if not isinstance(n, ast.Assign) or len(n.targets) != 1 or not isinstance(n.targets[0], ast.Name):
            continue
        try:
            v = literal(n.value)
            values[n.targets[0].id] = v
        except (ValueError, TypeError, KeyError):
            pass
    return {k: tuple(values[k]) for k in ('SOURCE_TREES', 'SOURCE_FILES', 'SOURCE_OPTIONAL')}


try:
    source_path = INPUT / 'SOURCE-OBJECT.json'
    source_raw = source_path.read_bytes()
    source = json.loads(source_raw)
    report['source'] = source
    report['source_object'] = describe(source_path)
    report['source_readback'] = describe(INPUT / 'SOURCE-READBACK.json')
    canon = lambda x: json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')
    require('source closed shape', set(source) == {'root', 'commit', 'tree', 'inventory'})
    require('source canonical bytes', source_raw == canon(source))
    require('selected commit', source['commit'] == 'ed2fc453042a9f0bc4808c2aea7f015baf1ff73e')
    require('selected tree', source['tree'] == 'de3bd4fa567c4aeb11364e79d99e646dfde81659')
    root = Path(source['root'])
    require('selected current root', root == BASE / 'frozen-source')
    for side in ('before', 'after'):
        require('retained root ' + side, (INPUT / ('git-top-' + side + '.stdout')).read_text().strip() == str(root))
        require('retained commit ' + side, (INPUT / ('git-head-' + side + '.stdout')).read_text().strip() == source['commit'])
        require('retained tree ' + side, (INPUT / ('git-tree-' + side + '.stdout')).read_text().strip() == source['tree'])
        for kind in ('status', 'untracked'):
            require('retained clean ' + kind + ' ' + side, (INPUT / ('git-' + kind + '-' + side + '.stdout')).read_bytes() == b'')
    inventory_path = Path(source['inventory']['path'])
    require('inventory exact descriptor', describe(inventory_path) == source['inventory'])
    raw = inventory_path.read_bytes()
    inventory = json.loads(raw)
    require('inventory closed shape', set(inventory) == {'schema', 'files'})
    require('inventory schema', inventory['schema'] == 'ontokin.current-host-readback-source/0.1.0')
    require('inventory canonical bytes', raw == canon(inventory))
    spec = constants(root / 'prototypes/static_tray_v01/current_host_inspection_v01.py')
    require('provider source constants equal inspector', spec == constants(root / 'prototypes/static_tray_v01/current_host_readback_v01.py'))
    report['source_constants'] = spec
    names = set()
    for tree in spec['SOURCE_TREES']:
        pending = [root / tree]
        count = 0
        while pending:
            directory = pending.pop()
            initial = directory.lstat()
            require('source directory kind ' + str(directory.relative_to(root)), stat.S_ISDIR(initial.st_mode))
            with os.scandir(directory) as entries:
                for entry in entries:
                    count += 1
                    require('finite source tree count ' + tree, count <= 32768)
                    p = Path(entry.path)
                    s = p.lstat()
                    require('source entry type ' + str(p.relative_to(root)), stat.S_ISREG(s.st_mode) or stat.S_ISDIR(s.st_mode))
                    require('no bytecode source entry ' + str(p.relative_to(root)), p.name != '__pycache__' and p.suffix not in ('.pyc', '.pyo'))
                    if stat.S_ISDIR(s.st_mode):
                        pending.append(p)
                    else:
                        names.add(p.relative_to(root).as_posix())
            require('source directory stable ' + str(directory.relative_to(root)), ident(initial) == ident(directory.lstat()))
    names.update(spec['SOURCE_FILES'])
    names.update(n for n in spec['SOURCE_OPTIONAL'] if (root / n).exists())
    require('complete selected source path set', names == set(inventory['files']))
    raw_tree_path = INPUT / 'git-complete-tree.stdout'
    report['retained_git_tree_output'] = describe(raw_tree_path)
    tree_rows = {}
    for raw_row in raw_tree_path.read_bytes().split(b'\0'):
        if not raw_row:
            continue
        head, raw_name = raw_row.split(b'\t', 1)
        mode, kind, oid = head.decode('ascii').split()
        name = raw_name.decode('utf-8')
        require('unique retained tree name ' + name, name not in tree_rows)
        tree_rows[name] = (mode, kind, oid)
    for name in sorted(names):
        p = root / name
        before = p.lstat()
        require('private regular source ' + name, stat.S_ISREG(before.st_mode) and before.st_nlink == 1)
        raw = p.read_bytes()
        after = p.lstat()
        require('stable source read ' + name, ident(before) == ident(after) and len(raw) == before.st_size)
        actual = {'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw), 'mode': oct(stat.S_IMODE(before.st_mode))}
        require('source descriptor matches ' + name, actual == inventory['files'][name])
        mode, kind, oid = tree_rows[name]
        blob = hashlib.sha1(b'blob ' + str(len(raw)).encode('ascii') + b'\0' + raw).hexdigest()
        require('retained Git blob matches ' + name, kind == 'blob' and blob == oid and mode in ('100644', '100755'))
        require('retained Git mode matches ' + name, actual['mode'] == ('0o755' if mode == '100755' else '0o644'))
        report['files'].append({'path': name, 'binding': actual, 'git_blob': blob})
    require('exact inspector accepted bytes', inventory['files']['prototypes/static_tray_v01/current_host_inspection_v01.py'] ==
            {'sha256': 'eea3e6343ae34d9c930a810ca4f363cbcd4264a8d943731f927e41b213755d7a', 'size_bytes': 233502, 'mode': '0o644'})
    report['file_count'] = len(names)
    report['verdict'] = 'accepted_static_source_object_evidence_only'
    report['mandatory_findings'] = []
except BaseException as error:
    report['verdict'] = 'source_object_review_failed'
    report['mandatory_findings'] = [{'type': type(error).__name__, 'message': str(error)}]
finally:
    report['prior_attempt'] = {
        'report': describe(BASE / 'session/h0_review/SOURCE-OBJECT-REVIEW.json'),
        'error': "Reviewer's first AST literal extractor did not resolve names nested in SOURCE_FILES tuple; KeyError SOURCE_FILES before file comparison.",
        'correction': 'Resolve literal tuple/list members recursively through already observed source constants; no product code was executed or changed.',
        'product_failure': False
    }
    report['limits'] = [
        'Current selected source bytes, complete path set, modes and recorded Git blob identities were checked independently as data.',
        'No new Git command or .git index/ref inspection was performed by this reviewer; commit/tree/clean witnesses are independently read retained Director-owned command outputs.',
        'This does not admit current author/runtime metadata or native closure, accept N34/H0, or execute product code.',
        'All writes from this audit are restricted to the reviewer directory.'
    ]
    with OUTPUT.open('x', encoding='utf-8') as stream:
        json.dump(report, stream, indent=2, sort_keys=True)
        stream.write('\n')
    print(json.dumps({'verdict': report['verdict'], 'file_count': report.get('file_count'),
                      'checks': len(report['checks']), 'mandatory_findings': report['mandatory_findings'],
                      'report': str(OUTPUT)}))
