# Author runtime: source coverage for the fixed static H0 entry

The captured runtime is a usable input inventory for the declared static H0 invocation. It is not an execution or acceptance of H0. The observation imported the 34 declared standard-library roots, exercised ordinary successful argument parsing and exact-directory metadata reading, and retained 177 module observations. Its 228 file bindings cover all observed file-backed modules and 107 existing bytecode caches. Project modules were read as source data only.

The scope is the unchanged inspector at commit `ed2fc453042a9f0bc4808c2aea7f015baf1ff73e`, SHA-256 `eea3e6343ae34d9c930a810ca4f363cbcd4264a8d943731f927e41b213755d7a`. The associated raw result is `session/author_runtime/attempt001/run001.stdout.json`, SHA-256 `bac025f5bee583076d0452b7b91937a8630d5f52535b70eee49f6cd59c79838b`.

## Project import graph

`_load_helpers` imports only after authenticating the declared project source. Its four immediate helpers and their top-level project imports account for the 12-file source advisory:

| Entry or helper | Project imports relevant to loading |
| --- | --- |
| `current_host_inspection_v01.py` | Provider, supervisor, local driver, preparer through `_load_helpers` |
| `current_host_readback_v01.py` | Supervisor and `format_check` |
| `format_check.py` | `canonical`, `lock`, supervisor |
| `canonical.py` | `errors` |
| `lock.py` | `canonical`, `errors`, supervisor |
| `tools/check_local.py` | `tools/storage_identity.py` |
| `tools/prepare_current_host_readback.py` | Provider |
| Package initialization | The two reviewed `prototypes` initialization files contain docstrings only |

The source advisory records the complete direct-import union of these files: 34 standard-library roots. The current capture observes every one of those roots. Definitions, literal constants, bounded comprehensions, path construction, regular-expression compilation and two standard `dataclass` decorators account for the inspected helper top-level work. The preparer and local driver's guarded CLI entry points do not run during import.

The `dataclasses` implementation imports its supporting modules at module load; its generated class methods do not introduce an independent project or package import. The observed runtime includes those supporting modules. The selected CPython build reports `_ctypes`, `math` and the other observed native built-ins without standalone extension files; none may be replaced with a fabricated filename.

## Calls reached by static validation

`inspect_host(..., observe=False)` calls `validate_inspection_plan`, which enters `_validate`, then returns `STATIC_READY` before constructing the evidence store or reaching target execution. The following helper calls are the relevant static paths:

| Inspector call site | Helper and input | Additional import or execution consequence |
| --- | --- | --- |
| `_check_metadata` | Provider `_python_pins(ROOT)` | Reads and parses the exact lock with existing `os`, `hashlib`, `re`, path and text facilities. It does not call distribution discovery. |
| `_check_installation` | Preparer `_plan_shape(selected)` | Checks existing plan data through provider shape/path helpers. It does not invoke preparation, archive extraction or rename. |
| `_check_runtime_dependencies` | Provider `dependency_inventory(ROOT)` and `_read(package.json)` | Reads already-bound JSON data and checks the historical dependency pin. No package import. |
| `_check_git` | Driver `git_environment(ROOT)` and `git_read(...)` | Exactly the five declared source-read subprocesses, only after native/alias/role closure is admitted. This remains an execution gate separate from the runtime collector. |
| `_p06_definitions` | Inspector's bound schema JSON read | Uses existing JSON support; does not import a schema-validation package. |

The fixed source commands are the same five already recorded in `EVIDENCE-ASSEMBLY-REQUIREMENTS.md`: three identity reads, the tracked-worktree status read, and the untracked-name read. The driver implements these through `subprocess.check_output` with the declared clean Git environment. Its Linux subprocess implementation's conditional `grp`/`pwd` imports are already observed built-ins; the actual source commands do not request a changed user or group. Text decoding uses the bound standard encoding/locale path. No Git subprocess was run by this review or by the runtime collector.

The inspector's `_check_metadata` parses the `Name` and `Version` headers directly and checks the complete dist-info file set. It does not call provider `_verify_host` or the local driver's package preflight. The collector's explicit `Distribution.at(root).metadata/.version` exercise therefore provides additional bound parser modules, including `email.parser` and `email.feedparser`; it is not evidence that ordinary distribution discovery was exercised.

## Branches outside this static call path

The source contains later or separate-workflow functions with lazy imports. They are not implicitly executed because their module is loaded:

- `format_check.run_check` imports candidate-store and transaction helpers.
- `lock.build_lock` imports source lowering; lock verification/building can import format-check functions and the native reader modules.
- Provider source/parent/workspace operations can call other local-driver inventory and Git helpers.
- The local driver's force-agent preflight imports the seven third-party packages; provider `_verify_host` uses `metadata.version(name)` discovery.
- Observation mode reaches the supervisor and rename/evidence machinery after static validation. It requires separate approval and actual complete native closure.

None of these excluded operations is a reason to expand the current raw collection without a concrete reachable need. None is certified by the runtime result. The actual inspector CLI uses valid declared arguments; help/error rendering was not exercised. The inspected standard argument-parser lazy formatting imports (`copy`, `shutil`, `textwrap`) already appear in the bound runtime.

## Remaining checks before a complete plan

The final author-runtime document must still bind the exact Python executable, ELF interpreter, startup files, actual shared/native inputs and loader inputs, with matching HOST aliases, roles and guards. The collector's empty `observed_extension_files` is an accurate observation, not a finished value for the schema's nonempty `extension_files` field.

The selected-root observation now establishes that Python actually names `libm.so.6`. Together with the observed native built-in `math` and the retained build metadata's `-lm`, this supports the already-described shared-input interpretation. The actual selected libm image, canonical binding, loader search and full transitive closure are still required before that entry is accepted in a plan.

Project source files remain authenticated by the complete source inventory. Any actual existing project bytecode cache must also be bound, or its absence accounted for; the runtime collector deliberately did not import project helpers. `_check_author_runtime(..., loaded=True)` checks file-backed loaded modules and existing caches after helper import. This production check was not executed here and is not a substitute for advance completeness review.

No H0, N34, later target observation, original readback routine or full product qualification is accepted by this source-coverage note. The P13 historical N57 limitation remains unchanged.
