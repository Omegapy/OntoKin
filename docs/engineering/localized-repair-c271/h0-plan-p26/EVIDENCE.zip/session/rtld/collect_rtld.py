"""Observe the fixed /0.1.4 script and path inputs as data, without project imports."""
import errno
import hashlib
import json
import os
import re
import stat
import sys
import time

DEADLINE = time.monotonic() + 15
SCRIPT = '/usr/bin/ldd'
SCRIPT_PIN = {'sha256': '7bcd61a279946cb376d36fd91f4938ab4f4aba48e793c652a9797319d23f8dd3',
              'size_bytes': 5356, 'mode': '0o755'}
COMPONENTS = [('/', 'directory', None), ('/lib', 'symlink', 'usr/lib'),
              ('/lib64', 'symlink', 'usr/lib64'), ('/usr', 'directory', None),
              ('/usr/lib', 'directory', None), ('/usr/lib64', 'directory', None),
              ('/usr/lib64/ld-linux-x86-64.so.2', 'symlink', '../lib/x86_64-linux-gnu/ld-linux-x86-64.so.2'),
              ('/usr/lib/x86_64-linux-gnu', 'directory', None),
              ('/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2', 'file', None)]
CANDIDATES = ['/lib64/ld-linux-x86-64.so.2', '/lib/ld-linux.so.2', '/libx32/ld-linux-x32.so.2']
ABSENCES = [('/lib/ld-linux.so.2', '/usr/lib', 'ld-linux.so.2', []),
            ('/libx32/ld-linux-x32.so.2', '/', 'libx32', ['ld-linux-x32.so.2'])]
result = {'schema': 'ontokin.c271.p26-rtld-raw-observation/1',
          'scope': 'Fixed script bytes and finite raw path facts; no H0 proof or execution',
          'target_starts': 0, 'project_imports': [], 'subprocesses': 0,
          'H0_accepted': False, 'operational_plan_adopted': False, 'passes': []}


def tick():
    if time.monotonic() > DEADLINE:
        raise RuntimeError('15-second observation deadline exceeded')


def identity(value):
    return [value.st_dev, value.st_ino, value.st_mode, value.st_nlink,
            value.st_size, value.st_mtime_ns, value.st_ctime_ns]


def read_script():
    tick()
    fd = os.open(SCRIPT, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        if not stat.S_ISREG(before.st_mode) or before.st_size != SCRIPT_PIN['size_bytes']:
            raise RuntimeError('Pinned ldd script kind or size differs')
        raw = bytearray()
        while len(raw) <= SCRIPT_PIN['size_bytes']:
            tick()
            chunk = os.read(fd, SCRIPT_PIN['size_bytes'] + 1 - len(raw))
            if not chunk:
                break
            raw.extend(chunk)
        after = os.fstat(fd)
        named = os.lstat(SCRIPT)
        if identity(before) != identity(after) or identity(after) != identity(named):
            raise RuntimeError('Pinned ldd script changed during read')
        measured = {'sha256': hashlib.sha256(raw).hexdigest(), 'size_bytes': len(raw),
                    'mode': oct(stat.S_IMODE(before.st_mode))}
        if measured != SCRIPT_PIN:
            result['script_mismatch'] = {'expected': SCRIPT_PIN, 'observed': measured}
            raise RuntimeError('Pinned ldd script bytes or mode differ')
        raw = bytes(raw)
        if raw.split(b'\n', 1)[0] != b'#!/bin/bash':
            raise RuntimeError('Pinned ldd shebang differs')
        lists = re.findall(rb'^RTLDLIST=["\x27]([^"\x27\n]+)["\x27]$', raw, re.MULTILINE)
        if len(lists) != 1 or lists[0].decode('ascii').split() != CANDIDATES:
            raise RuntimeError('Pinned literal RTLDLIST differs')
        return {'path': SCRIPT, **measured, 'identity': identity(before),
                'text': raw.decode('utf-8', 'strict'), 'literal_candidates': CANDIDATES,
                'stable_read': True}
    finally:
        os.close(fd)


def collect_pass():
    rows = []
    for path, kind, target in COMPONENTS:
        tick()
        before = os.lstat(path)
        predicate = {'directory': stat.S_ISDIR, 'symlink': stat.S_ISLNK, 'file': stat.S_ISREG}[kind]
        if not predicate(before.st_mode):
            raise RuntimeError('Fixed component kind differs: ' + path)
        actual_target = None
        if kind == 'symlink':
            if not hasattr(os, 'O_PATH'):
                raise RuntimeError('Required O_PATH capability is unavailable')
            link_fd = os.open(path, os.O_PATH | os.O_NOFOLLOW | os.O_CLOEXEC)
            try:
                if identity(before) != identity(os.fstat(link_fd)):
                    raise RuntimeError('Named and opened symlink identities differ: ' + path)
                actual_target = os.readlink(b'', dir_fd=link_fd).decode('ascii', 'strict')
                if identity(before) != identity(os.fstat(link_fd)):
                    raise RuntimeError('Opened symlink identity changed: ' + path)
            finally:
                os.close(link_fd)
        after = os.lstat(path)
        if identity(before) != identity(after) or actual_target != target:
            raise RuntimeError('Fixed component changed or target differs: ' + path)
        rows.append({'path': path, 'kind': kind, 'identity': identity(before), 'target': actual_target})
    absences = []
    for literal, parent, basename, suffix in ABSENCES:
        tick()
        fd = os.open(parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        try:
            before = os.fstat(fd)
            if identity(before) != identity(os.lstat(parent)):
                raise RuntimeError('Absence parent identity changed')
            try:
                os.stat(basename, dir_fd=fd, follow_symlinks=False)
            except OSError as error:
                if error.errno != errno.ENOENT:
                    raise
            else:
                raise RuntimeError('Required first-missing entry is present: ' + parent + '/' + basename)
            if identity(before) != identity(os.fstat(fd)) or identity(before) != identity(os.lstat(parent)):
                raise RuntimeError('Absence parent identity changed after observation')
            missing = ('/' if parent == '/' else parent + '/') + basename
            absences.append({'path': literal, 'nearest_existing_ancestor': parent,
                             'first_missing': missing, 'remaining_suffix': suffix,
                             'parent_identity': identity(before), 'observed_errno': errno.ENOENT})
        finally:
            os.close(fd)
    return {'components': rows, 'absences': absences}


try:
    result['script'] = read_script()
    result['passes'].append(collect_pass())
    result['passes'].append(collect_pass())
    if result['passes'][0] != result['passes'][1]:
        raise RuntimeError('Finite path observations differ across passes')
    if read_script() != result['script']:
        raise RuntimeError('Pinned script differs at final recheck')
    tick()
    result['state'] = 'FIXED_RTLD_INPUTS_OBSERVED'
    code = 0
except (OSError, ValueError, UnicodeError, RuntimeError) as error:
    result['state'] = 'BLOCKED_FIRST_PREREQUISITE'
    result['error'] = {'type': type(error).__name__, 'message': str(error),
                       'errno': getattr(error, 'errno', None)}
    code = 2
result['checked_at_utc_epoch'] = time.time()
result['limits'] = ['Raw finite inputs only; production descriptor-relative verification has not run',
                    'No loader, shell, Node, ldd, project helper, H0 or H1 started',
                    'No whole-plan acceptance, native closure, kernel integrity or atomic execution claim']
print(json.dumps(result, indent=2, sort_keys=True))
sys.exit(code)
