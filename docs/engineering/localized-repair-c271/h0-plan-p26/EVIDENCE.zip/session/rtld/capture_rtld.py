"""Capture exactly one independently reviewed current-process data observation."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/cf652064a9a1/session/rtld')
PLAN = BASE / 'RTLD-LAUNCH.json'
REVIEW = BASE.parent / 'h0_review' / 'RTLD-REVIEW.json'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


assert len(sys.argv) == 3
expected_plan, expected_review = sys.argv[1:]
assert len(expected_plan) == len(expected_review) == 64
assert digest(PLAN) == expected_plan and digest(REVIEW) == expected_review
plan = json.loads(PLAN.read_text())
review = json.loads(REVIEW.read_text())
assert review['verdict'] == 'accepted_for_one_bounded_rtld_data_observation'
assert review['plan_sha256'] == expected_plan and not review['mandatory_findings']
assert review['capture_sha256'] == digest(Path(__file__))
script = Path(plan['script']['path'])
assert digest(script) == plan['script']['sha256']
assert script.stat().st_size == plan['script']['size_bytes']
result = {'schema': 'ontokin.c271.p26-rtld-capture/1',
          'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'plan_sha256': expected_plan, 'review_sha256': expected_review,
          'capture_sha256': digest(Path(__file__)), 'script_sha256': digest(script),
          'argv': plan['argv'], 'cwd': plan['cwd'], 'environment': plan['environment'],
          'outer_timeout_seconds': plan['outer_timeout_seconds'],
          'launch_count': 0, 'target_starts': 0, 'state': 'PRELAUNCH',
          'H0_accepted': False, 'H1_executed': False}
save(Path(plan['attempt_file']), result)
started = time.monotonic()
try:
    with open(plan['exclusive_stdout'], 'xb') as stdout, open(plan['exclusive_stderr'], 'xb') as stderr:
        assert digest(PLAN) == expected_plan and digest(REVIEW) == expected_review
        assert digest(script) == plan['script']['sha256']
        result['launch_count'] = 1
        try:
            completed = subprocess.run(plan['argv'], cwd=plan['cwd'], env=plan['environment'],
                                       stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                       timeout=plan['outer_timeout_seconds'], check=False)
            result['returncode'] = completed.returncode
            result['state'] = 'COMPLETED'
        except subprocess.TimeoutExpired:
            result['state'] = 'OUTER_TIMEOUT_UNSUCCESSFUL_NO_RETRY'
except BaseException as error:
    result['state'] = 'CAPTURE_ERROR_UNSUCCESSFUL_NO_RETRY'
    result['error'] = {'type': type(error).__name__, 'message': str(error)}
finally:
    result['elapsed_seconds'] = time.monotonic() - started
    result['ended_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result['outputs'] = {}
    for role in ['stdout', 'stderr']:
        path = Path(plan['exclusive_' + role])
        if path.exists():
            result['outputs'][role] = {'path': str(path), 'bytes': path.stat().st_size,
                                       'sha256': digest(path)}
    save(Path(plan['capture_file']), result)
print(json.dumps(result, sort_keys=True))
