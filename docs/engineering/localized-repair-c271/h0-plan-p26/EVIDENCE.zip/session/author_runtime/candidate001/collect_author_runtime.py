"""Observe a reviewed stdlib/metadata candidate; never import project/packages."""
import sys
import os
import time
import stat
import signal
import hashlib
import json
from pathlib import Path

DIRECT_ROOTS = (
    "__future__", "argparse", "ast", "collections.abc", "contextlib", "copy",
    "ctypes", "dataclasses", "datetime", "errno", "fnmatch", "fractions",
    "hashlib", "importlib", "importlib.metadata", "json", "math", "os",
    "pathlib", "platform", "re", "selectors", "shlex", "shutil", "signal",
    "stat", "struct", "subprocess", "sys", "tarfile", "tempfile", "time",
    "types", "uuid",
)
ENVIRONMENT = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
               "TZ": "UTC", "UV_THREADPOOL_SIZE": "2"}
LIMITS = {"collector_seconds": 40, "max_modules": 1024, "max_bound_files": 4096,
          "per_file_bytes": 32 * 1024 * 1024, "aggregate_read_bytes": 256 * 1024 * 1024,
          "metadata_entries_per_package": 2048, "stdout_bytes": 2 * 1024 * 1024}
START = time.monotonic()
READ_BYTES = 0
OBSERVED = {}
IMPORT_EVENTS = []
BLOCKED_EVENTS = []


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def check():
    require(time.monotonic() - START <= LIMITS["collector_seconds"], "Collector deadline exceeded")


def deadline(signum, frame):
    raise RuntimeError("Collector alarm deadline exceeded")


def identity(info):
    return {"device": info.st_dev, "inode": info.st_ino, "mode": oct(stat.S_IMODE(info.st_mode)),
            "size_bytes": info.st_size, "mtime_ns": info.st_mtime_ns,
            "ctime_ns": info.st_ctime_ns, "nlink": info.st_nlink}


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True,
                      allow_nan=False).encode("ascii")


def reject_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "Duplicate JSON key")
        result[key] = value
    return result


def decode(raw):
    return json.loads(raw, object_pairs_hook=reject_duplicate_keys,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError("Nonfinite JSON")))


def stable_file(path, *, expected=None, role="input", retain=False):
    global READ_BYTES
    check()
    path = Path(path)
    require(path.is_absolute() and ".." not in path.parts, "Noncanonical file path")
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and before.st_nlink > 0, "Nonregular input")
    require(0 <= before.st_size <= LIMITS["per_file_bytes"], "Per-file byte limit")
    READ_BYTES += before.st_size
    require(READ_BYTES <= LIMITS["aggregate_read_bytes"], "Aggregate explicit-read limit")
    digest = hashlib.sha256()
    chunks = []
    head = b""
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        require(identity(before) == identity(os.fstat(fd)), "Input changed before read")
        remaining = before.st_size
        while remaining:
            check()
            chunk = os.read(fd, min(remaining, 1024 * 1024))
            require(chunk, "Input shortened during read")
            if not head:
                head = chunk[:4]
            digest.update(chunk)
            if retain:
                chunks.append(chunk)
            remaining -= len(chunk)
        require(not os.read(fd, 1), "Input grew during read")
        require(identity(before) == identity(os.fstat(fd)) == identity(path.lstat()), "Input changed during read")
    finally:
        os.close(fd)
    binding = {"sha256": digest.hexdigest(), "size_bytes": before.st_size,
               "mode": oct(stat.S_IMODE(before.st_mode))}
    if expected is not None:
        require(binding == {key: expected[key] for key in binding}, "Input binding differs: " + str(path))
    previous = OBSERVED.get(str(path))
    if previous is not None:
        require(previous["binding"] == binding and previous["identity"] == identity(before), "Repeated input changed")
        if role not in previous["roles"]:
            previous["roles"].append(role)
    else:
        require(len(OBSERVED) < LIMITS["max_bound_files"], "Bound-file count exceeded")
        OBSERVED[str(path)] = {"binding": binding, "identity": identity(before), "roles": [role]}
    return {"path": str(path), **binding}, b"".join(chunks) if retain else None, head


def audit(event, args):
    forbidden = event.startswith(("subprocess.", "socket.", "os.spawn", "os.exec")) or event in {
        "os.system", "os.fork", "os.forkpty", "os.posix_spawn", "os.posix_spawnp",
        "os.mkdir", "os.rmdir", "os.remove", "os.rename", "os.link", "os.symlink",
        "os.chmod", "os.chown", "os.utime", "os.truncate", "os.putenv", "os.unsetenv",
        "shutil.copyfile", "shutil.copymode", "shutil.copystat", "shutil.rmtree",
    }
    if event == "open":
        mode, flags = args[1], args[2]
        forbidden = forbidden or (isinstance(mode, str) and any(char in mode for char in "wax+"))
        forbidden = forbidden or (isinstance(flags, int) and bool(flags & (os.O_WRONLY | os.O_RDWR | os.O_CREAT | os.O_TRUNC | os.O_APPEND)))
    if event == "import":
        name, filename = args[0], args[1]
        require(len(IMPORT_EVENTS) < LIMITS["max_modules"] * 4, "Import-event bound exceeded")
        IMPORT_EVENTS.append({"name": name, "filename": filename})
        forbidden = forbidden or name.partition(".")[0] not in sys.stdlib_module_names
    if forbidden:
        BLOCKED_EVENTS.append(event)
        raise RuntimeError("Collector operation is outside reviewed scope: " + event)


def module_names():
    require(len(sys.modules) <= LIMITS["max_modules"], "Module-count bound exceeded")
    return set(sys.modules)


def add_stage(stages, label, previous):
    current = module_names()
    stages.append({"stage": label, "added_modules": sorted(current - previous),
                   "removed_modules": sorted(previous - current), "module_count": len(current)})
    return current


def scan_metadata(root):
    root = Path(root)
    require(root.is_absolute() and root.name.endswith(".dist-info"), "Invalid metadata root")
    pending, files, directories, count = [root], {}, {}, 0
    while pending:
        check()
        directory = pending.pop()
        before = directory.lstat()
        require(stat.S_ISDIR(before.st_mode), "Linked or non-directory metadata path")
        names = []
        with os.scandir(directory) as entries:
            for entry in entries:
                check()
                count += 1
                require(count <= LIMITS["metadata_entries_per_package"], "Metadata entry bound exceeded")
                names.append(entry.name)
                path = directory / entry.name
                info = path.lstat()
                relative = path.relative_to(root).as_posix()
                require(not stat.S_ISLNK(info.st_mode), "Metadata symlink is unsupported")
                if stat.S_ISDIR(info.st_mode):
                    pending.append(path)
                else:
                    require(stat.S_ISREG(info.st_mode) and info.st_nlink == 1, "Special or multiply linked metadata input")
                    require(path.suffix not in (".py", ".pyc", ".pth", ".so"), "Executable metadata input")
                    descriptor, _, _ = stable_file(path, role="distribution_metadata")
                    files[relative] = {key: descriptor[key] for key in ("sha256", "size_bytes", "mode")}
        require(identity(before) == identity(directory.lstat()), "Metadata directory changed")
        directories[directory.relative_to(root).as_posix()] = {"identity": identity(before), "entries": sorted(names)}
    require("METADATA" in files and files["METADATA"]["size_bytes"] > 0, "Missing nonempty METADATA")
    needed = {"."}
    for name in files:
        needed.update(str(parent) for parent in Path(name).parents)
    require(set(directories) == needed, "Unnecessary or missing metadata directory")
    return files, directories


def alias(path):
    path = Path(path)
    before = path.lstat()
    linked = stat.S_ISLNK(before.st_mode)
    target = os.readlink(path) if linked else None
    resolved = path.resolve(strict=True)
    require(identity(before) == identity(path.lstat()), "Alias changed")
    return {"resolved_path": str(resolved), "symlink": linked, "link_target": target}


def main():
    require(len(sys.argv) == 5 and sys.argv[1] == "--plan" and sys.argv[3] == "--plan-sha256", "Expected external plan digest")
    require(dict(os.environ) == ENVIRONMENT, "Environment is not the fixed clean five-variable map")
    require(sys.flags.isolated == 1 and sys.flags.no_site == 1 and sys.dont_write_bytecode and "site" not in sys.modules,
            "Expected -I -S -B without site initialization")
    signal.signal(signal.SIGALRM, deadline)
    signal.alarm(LIMITS["collector_seconds"])
    sys.addaudithook(audit)
    initial_modules = module_names()
    initial_path = list(sys.path)
    plan_descriptor, raw, _ = stable_file(sys.argv[2], role="collection_plan", retain=True)
    require(plan_descriptor["sha256"] == sys.argv[4], "External plan digest differs")
    plan = decode(raw)
    require(raw == canonical(plan), "Plan bytes are not canonical")
    require(plan["schema"] == "ontokin.c271.p26-author-runtime-collection-plan/1", "Unexpected plan schema")
    require(tuple(plan["direct_stdlib_modules"]) == DIRECT_ROOTS and plan["limits"] == LIMITS, "Changed import or resource scope")
    require(plan["environment"] == ENVIRONMENT, "Plan environment differs")
    require(str(Path(__file__).resolve()) == plan["collector"]["path"], "Collector path differs")
    stable_file(__file__, expected=plan["collector"], role="collector_authority")
    require(str(Path(sys.executable).resolve()) == plan["python"]["path"], "Selected Python path differs")
    require(".".join(map(str, sys.version_info[:3])) == plan["python_version"], "Selected Python version differs")
    stable_file(plan["python"]["path"], expected=plan["python"], role="selected_python")
    require(initial_path and len(set(initial_path)) == len(initial_path)
            and set(initial_path) <= set(plan["allowed_sys_path"]), "Unexpected interpreter search path")
    require(not any("site-packages" in Path(path).parts for path in initial_path), "Package path is importable")
    stdlib = Path(plan["stdlib_root"])
    documents = {}
    for name, descriptor in plan["input_documents"].items():
        _, data, _ = stable_file(descriptor["path"], expected=descriptor, role=name, retain=True)
        documents[name] = decode(data)
    require(documents["source_object"] == plan["source"], "Source object differs")
    require(documents["import_advisory"]["direct_stdlib_modules"] == list(DIRECT_ROOTS), "Advisory imports differ")
    require(documents["import_advisory"]["source_commit"] == plan["source"]["commit"], "Advisory source differs")
    preparation = documents["python_preparation"]
    require(preparation["status"] == "prepared_static_identity_verified"
            and not preparation["input_checks_before"]["failures"]
            and not preparation["input_checks_after"]["failures"], "Preparation result is not the selected success")
    inventory = documents["source_inventory"]
    require(len(inventory["files"]) == 627, "Source inventory count differs")
    source_text = {}
    for row in plan["source_read_set"]:
        relative = str(Path(row["path"]).relative_to(plan["source"]["root"]))
        require(inventory["files"][relative] == {key: row[key] for key in ("sha256", "size_bytes", "mode")}, "Source read-set binding differs")
        _, data, _ = stable_file(row["path"], expected=row, role="source_read_as_data", retain=True)
        source_text[relative] = data.decode("utf-8")
    for row in plan["stdlib_exercise_sources"]:
        stable_file(row["path"], expected=row, role="stdlib_exercise_source")
    _, lock_bytes, _ = stable_file(plan["lock"]["path"], expected=plan["lock"], role="pin_lock", retain=True)
    stages = [{"stage": "isolated_startup_and_collector_bootstrap", "modules": sorted(initial_modules)}]
    previous = module_names()
    for name in DIRECT_ROOTS:
        check()
        __import__(name, fromlist=("__name__",))
    previous = add_stage(stages, "exact_34_direct_stdlib_roots", previous)
    require("site" not in sys.modules and list(sys.path) == initial_path, "Imports changed isolation")
    ast = sys.modules["ast"]
    argparse = sys.modules["argparse"]
    metadata = sys.modules["importlib.metadata"]
    re = sys.modules["re"]
    pins = {}
    for line in lock_bytes.decode("ascii").splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        matched = re.fullmatch(r"([A-Za-z0-9_.-]+)==([^\s\\]+) --hash=sha256:[0-9a-f]{64}", line)
        require(matched is not None and matched[1] not in pins, "Unreviewed lock shape")
        pins[matched[1]] = matched[2]
    require(pins == {row["name"]: row["version"] for row in plan["metadata_packages"]} and len(pins) == 7,
            "Exact seven metadata pins differ")
    inspector_text = source_text["prototypes/static_tray_v01/current_host_inspection_v01.py"]
    parser = argparse.ArgumentParser(description=ast.get_docstring(ast.parse(inspector_text)), allow_abbrev=False)
    parser.add_argument("--plan", required=True)
    parser.add_argument("--plan-sha256", required=True)
    parser.add_argument("--observe", action="store_true")
    exercises = []
    for observe in (False, True):
        argv = ["--plan", sys.argv[2], "--plan-sha256", sys.argv[4]] + (["--observe"] if observe else [])
        parsed = vars(parser.parse_args(argv))
        require(parsed == {"plan": sys.argv[2], "plan_sha256": sys.argv[4], "observe": observe}, "Argparse exercise differed")
        exercises.append({"argv": argv, "parsed": parsed, "calls_project": False})
    previous = add_stage(stages, "ordinary_inspector_argparse_success_paths", previous)
    packages, metadata_observations = [], []
    for row in plan["metadata_packages"]:
        root = Path(row["distribution_root"])
        require(root.parent == Path(plan["metadata_site_root"]), "Metadata root escaped the selected site")
        files, directories = scan_metadata(root)
        require(files == row["metadata_files"], "Prepared metadata file set/bytes differ")
        distribution = metadata.Distribution.at(root)
        header = distribution.metadata
        names, versions = header.get_all("Name"), header.get_all("Version")
        normalize = lambda name: re.sub(r"[-_.]+", "-", name).lower()
        require(names is not None and len(names) == 1 and normalize(names[0]) == normalize(row["name"]), "Metadata name differs")
        require(versions == [row["version"]] and distribution.version == row["version"], "Metadata version differs")
        packages.append({"name": row["name"], "version": row["version"],
                         "distribution_root": str(root), "metadata_files": files})
        metadata_observations.append({"distribution_root": str(root), "directories": directories,
                                      "header_name": names[0], "header_version": versions[0],
                                      "reader": "importlib.metadata.Distribution.at(...).metadata/.version"})
        previous = add_stage(stages, "metadata_reader:" + row["name"], previous)
    final_names = module_names()
    modules, files, aliases, extensions, caches = [], {}, {}, set(), set()
    for name in sorted(final_names):
        check()
        module = sys.modules[name]
        if module is None:
            modules.append({"name": name, "state": "none_sentinel"})
            continue
        spec = getattr(module, "__spec__", None)
        origin = getattr(spec, "origin", None)
        loader = getattr(spec, "loader", None)
        filename = getattr(module, "__file__", None)
        cached = getattr(module, "__cached__", None)
        row = {"name": name, "origin": origin, "loader_type": type(loader).__name__ if loader is not None else None,
               "file": filename, "cached": cached, "is_builtin_name": name in sys.builtin_module_names,
               "is_frozen_origin": origin == "frozen"}
        if name == "__main__":
            require(Path(filename).resolve() == Path(__file__).resolve(), "Main module differs")
            row["classification"] = "collector_main_excluded_from_H0_runtime_fragment"
        elif filename is not None:
            require(name.partition(".")[0] in sys.stdlib_module_names, "Nonstdlib module loaded")
            mapping = alias(filename)
            resolved = Path(mapping["resolved_path"])
            require(resolved.is_relative_to(stdlib) and "site-packages" not in resolved.parts, "Module outside selected stdlib")
            descriptor, _, head = stable_file(resolved, role="observed_stdlib_module")
            aliases[str(filename)] = mapping
            files[str(resolved)] = {key: descriptor[key] for key in ("sha256", "size_bytes", "mode")}
            native = head == b"\x7fELF"
            row["classification"] = "observed_native_extension" if native else "frozen_with_source_file" if origin == "frozen" else "observed_stdlib_file"
            if native:
                extensions.add(str(filename))
            if cached is not None:
                if os.path.lexists(cached):
                    cached_alias = alias(cached)
                    resolved_cache = Path(cached_alias["resolved_path"])
                    require(resolved_cache.is_relative_to(stdlib) and "site-packages" not in resolved_cache.parts, "Cache outside selected stdlib")
                    descriptor, _, _ = stable_file(resolved_cache, role="existing_module_cache")
                    aliases[str(cached)] = cached_alias
                    files[str(resolved_cache)] = {key: descriptor[key] for key in ("sha256", "size_bytes", "mode")}
                    caches.add(str(cached))
                    row["cache_state"] = "existing_bound"
                else:
                    row["cache_state"] = "absent_observed"
        else:
            require(origin in ("built-in", "frozen", None), "Unclassified module origin")
            row["classification"] = "builtin_without_file" if origin == "built-in" else "frozen_without_file" if origin == "frozen" else "no_file_no_origin"
        modules.append(row)
    require(module_names() == final_names, "Module set changed during inventory; coverage needs new review")
    for row, original in zip(plan["metadata_packages"], metadata_observations):
        current_files, current_directories = scan_metadata(row["distribution_root"])
        require(current_files == row["metadata_files"] and current_directories == original["directories"], "Metadata changed during collection")
    observed_before = {path: {"binding": row["binding"], "identity": row["identity"]} for path, row in OBSERVED.items()}
    for path, row in observed_before.items():
        stable_file(path, expected=row["binding"], role="final_preservation_readback")
    for name, mapping in aliases.items():
        require(alias(name) == mapping, "Module/cache alias changed during collection")
    require(list(sys.path) == initial_path and "site" not in sys.modules and module_names() == final_names,
            "Final module isolation differs")
    require(dict(os.environ) == ENVIRONMENT and not BLOCKED_EVENTS, "Collection effect refusal recorded")
    result = {
        "schema": "ontokin.c271.p26-author-runtime-raw-observation/1", "status": "complete_raw_observation",
        "plan": plan_descriptor, "source": plan["source"], "source_read_set_verified_as_data": plan["source_read_set"],
        "python": plan["python"], "python_version": plan["python_version"], "environment": dict(os.environ),
        "sys_path": initial_path, "flags": {"isolated": sys.flags.isolated, "no_site": sys.flags.no_site,
                                            "dont_write_bytecode": sys.dont_write_bytecode},
        "direct_stdlib_modules": list(DIRECT_ROOTS), "stages": stages, "argparse_exercises": exercises,
        "module_observations": modules, "all_builtin_module_names": sorted(sys.builtin_module_names),
        "runtime_candidate_fragment": {"files": files, "aliases": aliases,
                                       "observed_extension_files": sorted(extensions), "existing_cache_files": sorted(caches)},
        "metadata_candidate": {"schema": "ontokin.current-host-readback-author-metadata/0.1.0",
                               "lock": plan["lock"], "packages": packages},
        "metadata_observations": metadata_observations, "import_events": IMPORT_EVENTS,
        "explicit_input_observations": OBSERVED, "explicit_read_bytes": READ_BYTES,
        "direct_collector_starts": 1, "target_starts": 0, "project_imports": False,
        "third_party_imports": False, "collector_subprocesses": 0, "collector_filesystem_writes": False,
        "h0_complete": False, "elapsed_seconds": time.monotonic() - START,
        "limits": ["Observed candidate only; no complete H0/runtime/native closure is claimed.",
                   "Project modules are read as data, never imported; helper/lazy path coverage remains separate.",
                   "Only normal argparse success paths and explicit metadata .metadata/.version reads were exercised.",
                   "Metadata discovery over sys.path, entry-point loading, product checks and target commands were not exercised.",
                   "Explicit read budget excludes ordinary interpreter import I/O and metadata-reader internal reads; outer time/memory/output bounds still apply.",
                   "Built-in or frozen modules have no invented extension file; an empty observed extension list remains empty.",
                   "The fragment excludes this collector's __main__; H0's __main__ is the separately bound inspector source.",
                   "Full source-set revalidation, source import-graph coverage, ELF closure, loader selection and final host roles remain separate gates."],
    }
    raw = canonical(result)
    require(len(raw) + 1 <= LIMITS["stdout_bytes"], "Raw result exceeds stdout bound")
    sys.stdout.buffer.write(raw + b"\n")
    sys.stdout.buffer.flush()
    signal.alarm(0)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        signal.alarm(0)
        failure = {"schema": "ontokin.c271.p26-author-runtime-raw-observation/1",
                   "status": "collector_failure", "error": {"type": type(exc).__name__, "message": str(exc)},
                   "target_starts": 0, "h0_complete": False, "blocked_events": BLOCKED_EVENTS,
                   "elapsed_seconds": time.monotonic() - START}
        sys.stderr.write(json.dumps(failure, sort_keys=True) + "\n")
        raise SystemExit(1)
