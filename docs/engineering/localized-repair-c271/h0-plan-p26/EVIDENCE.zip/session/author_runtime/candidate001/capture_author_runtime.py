"""Capture one externally approved author-runtime observation, without retry."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import stat
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
PLAN = HERE / "LAUNCH-PLAN.json"
REVIEW = HERE.parents[1] / "h0_review/AUTHOR-RUNTIME-REVIEW.json"
ENVIRONMENT = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "LC_ALL": "C.UTF-8",
               "TZ": "UTC", "UV_THREADPOOL_SIZE": "2"}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def binding(path):
    path = Path(path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode), "Expected actual regular file")
    require(before.st_size <= 32 * 1024 * 1024, "Capture input exceeds bound")
    raw = path.read_bytes()
    after = path.lstat()
    fields = lambda row: (row.st_dev, row.st_ino, row.st_mode, row.st_size, row.st_mtime_ns, row.st_ctime_ns, row.st_nlink)
    require(fields(before) == fields(after), "Capture input changed")
    return {"path": str(path), "size_bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
            "mode": oct(stat.S_IMODE(after.st_mode))}, raw


def exclusive(path, value):
    with Path(path).open("x", encoding="ascii") as stream:
        json.dump(value, stream, sort_keys=True, indent=2, ensure_ascii=True, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def directory_row(path):
    info = Path(path).lstat()
    require(stat.S_ISDIR(info.st_mode), "Evidence ancestor is not an actual directory")
    return {"path": str(path), "device": info.st_dev, "inode": info.st_ino,
            "mode": oct(stat.S_IMODE(info.st_mode))}


def main():
    require(len(sys.argv) == 3, "Expected externally supplied plan/review digests")
    require(dict(os.environ) == ENVIRONMENT and sys.flags.isolated == 1 and sys.flags.no_site == 1
            and sys.dont_write_bytecode and "site" not in sys.modules, "Capture requires exact clean -I -S -B launch")
    plan_hash, review_hash = sys.argv[1:]
    plan_binding, plan_raw = binding(PLAN)
    review_binding, review_raw = binding(REVIEW)
    require(plan_binding["sha256"] == plan_hash and review_binding["sha256"] == review_hash, "External digest mismatch")
    plan, review = json.loads(plan_raw), json.loads(review_raw)
    require(review["verdict"] == "accepted_for_one_bounded_author_runtime_observation", "Independent review is not accepted")
    require(review["plan_sha256"] == plan_hash, "Review names another plan")
    require(binding(__file__)[0] == plan["capture"], "Capture bytes differ")
    require(binding(plan["collector"]["path"])[0] == plan["collector"], "Collector bytes differ")
    require(review["collector_sha256"] == plan["collector"]["sha256"]
            and review["capture_sha256"] == plan["capture"]["sha256"], "Review scripts differ")
    require(binding(plan["python"]["path"])[0] == plan["python"], "Selected Python differs")
    require(str(Path(sys.executable).resolve()) == plan["python"]["path"], "Capture interpreter differs")
    require(plan["environment"] == ENVIRONMENT, "Plan environment differs")
    early = json.loads((HERE.parents[1] / "EARLY-RECOVERY-RECEIPT.json").read_bytes())
    require(early["status"] == "succeeded" and early["readback_byte_equal"], "Early recovery is not confirmed")
    for row in plan["evidence_ancestors"]:
        require(directory_row(row["path"]) == row, "Evidence ancestor differs")
    outputs = {name: Path(path) for name, path in plan["outputs"].items()}
    attempt_root = HERE.parent / "attempt001"
    require(all(path.parent == attempt_root for path in outputs.values()), "Output escaped the fresh attempt")
    require(set(outputs) == {"intent", "started", "stdout", "stderr", "capture_receipt"}, "Output shape differs")
    require(not any(path.exists() or path.is_symlink() for path in outputs.values()), "Attempt already exists; reconcile without retry")
    argv = [plan["python"]["path"], "-I", "-S", "-B", plan["collector"]["path"],
            "--plan", str(PLAN), "--plan-sha256", plan_hash]
    require(plan["argv_prefix"] == argv[:-1] and plan["cwd"] == str(HERE.parent), "Fixed argv/cwd differs")
    require(plan["supervision"] == {"wall_timeout_seconds": 45, "cleanup_seconds": 5,
                                    "hard_address_space_limit_bytes": 256 * 1024 * 1024,
                                    "hard_cpu_seconds": 42, "per_output_limit_bytes": 2 * 1024 * 1024}, "Resource bounds differ")
    record = {"schema": "ontokin.c271.p26-author-runtime-capture/1", "plan_sha256": plan_hash,
              "review": review_binding, "collector": plan["collector"], "capture": plan["capture"],
              "source": plan["source"], "started_at_utc": utc(), "argv": argv,
              "cwd": plan["cwd"], "environment": ENVIRONMENT, "status": "launch_intent",
              "direct_collector_starts": 0, "target_starts": 0, "unknown_operation": False,
              "h0_complete": False, "supervision": plan["supervision"]}
    exclusive(outputs["intent"], record)
    process, spawn_entered = None, False
    started = time.monotonic()

    def restrict():
        resource.setrlimit(resource.RLIMIT_AS, (256 * 1024 * 1024, 256 * 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_FSIZE, (2 * 1024 * 1024, 2 * 1024 * 1024))
        resource.setrlimit(resource.RLIMIT_CPU, (42, 42))

    def cleanup():
        if process is not None and process.poll() is None:
            os.killpg(process.pid, signal.SIGTERM)
            try:
                return process.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                return process.wait(timeout=3)
        return process.returncode if process is not None else None

    try:
        with outputs["stdout"].open("xb") as out, outputs["stderr"].open("xb") as err:
            spawn_entered = True
            process = subprocess.Popen(argv, cwd=plan["cwd"], env=ENVIRONMENT, stdout=out, stderr=err,
                                       start_new_session=True, preexec_fn=restrict)
            record.update(status="collector_started", pid=process.pid, direct_collector_starts=1, unknown_operation=True)
            exclusive(outputs["started"], {"started_at_utc": utc(), "pid": process.pid,
                                           "intent_sha256": binding(outputs["intent"])[0]["sha256"],
                                           "unknown_operation": True})
            try:
                code = process.wait(timeout=45)
            except subprocess.TimeoutExpired:
                record["timed_out"] = True
                code = cleanup()
            record.update(status="completed", returncode=code, wait_completed=True, unknown_operation=False)
    except Exception as exc:
        record.update(status="capture_failure", error={"type": type(exc).__name__, "message": str(exc)},
                      unknown_operation=spawn_entered)
        if process is not None:
            try:
                code = cleanup()
                record.update(returncode=code, wait_completed=True, unknown_operation=False)
            except Exception as cleanup_error:
                record["cleanup_error"] = {"type": type(cleanup_error).__name__, "message": str(cleanup_error)}
    record.update(finished_at_utc=utc(), elapsed_seconds=time.monotonic() - started)
    record["outputs"] = {name: binding(path)[0] for name, path in outputs.items()
                         if name != "capture_receipt" and path.is_file()}
    if record["status"] == "completed" and record.get("returncode") == 0 and not record.get("timed_out"):
        try:
            raw = json.loads(outputs["stdout"].read_bytes())
            require(raw["status"] == "complete_raw_observation" and raw["plan"]["sha256"] == plan_hash,
                    "Collector did not return this exact raw observation")
            require(raw["source"] == plan["source"] and raw["h0_complete"] is False and raw["target_starts"] == 0,
                    "Collector overclaimed scope")
            require(outputs["stderr"].stat().st_size == 0, "Collector stderr is not empty")
            record["raw_observation_complete"] = True
        except Exception as exc:
            record.update(status="capture_validation_failure", error={"type": type(exc).__name__, "message": str(exc)})
    exclusive(outputs["capture_receipt"], record)
    print(json.dumps({key: record.get(key) for key in ("status", "returncode", "raw_observation_complete",
                                                     "direct_collector_starts", "target_starts", "unknown_operation", "h0_complete")}))
    return 0 if record.get("raw_observation_complete") and not record["unknown_operation"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
