# P26 author runtime candidate001

Authored and statically verified only. Neither collector nor capture was executed. `candidate001/MANIFEST.json` freezes the scripts, plan, coverage scope, static checks and execution request. `attempt001` was created empty for the one proposed observation.

## Bound inputs and scope

The candidate retains the identical source object for `ed2fc453042a9f0bc4808c2aea7f015baf1ff73e` and its 627-file source inventory. It verifies the source-object/inventory documents and reads the advisory's 12 project source files as data; it never imports them and does not claim to rehash all 627 files.

The successful Python preparation receipt is bound by SHA-256 `7d2ab6de9e20f80a7ad3d9d19984cdb157446e43d71aec262afa654594a46c16`. Its seven exact distribution roots contain 47 metadata files. Those complete trees are the only package-tree read scope. Their expected file sets/bindings come from the receipt, while lock spelling and versions come from the unchanged source lock. Package modules are never imported, and the isolated installation's `site-packages` is never added to `sys.path`.

The collector explicitly imports only the 34 standard-library roots in `IMPORT-SOURCE-ADVISORY.json`, plus their normal standard-library dependencies. It exercises the inspector's valid argument-parser paths with `--observe` false and true. Explicit `Distribution.at(root).metadata/.version` calls cover the ordinary metadata text/email parsing route without distribution discovery over `sys.path` or entry-point loading. The two standard-library implementation files used to justify these exercises are separately byte-bound.

## Proposed observation

The output records stage-by-stage module additions, actual file-backed modules, aliases, existing caches, complete built-in names, frozen origins and metadata file/header observations. Actual loaded files with ELF magic become extension candidates. Built-in `math` or `_ctypes` is never assigned a fictional extension path; Python/libc cannot serve as filler for an empty extension list.

The output is a raw candidate, not a complete H0 author-runtime document. The collector's own `__main__` is explicitly excluded from the runtime fragment because H0's main module is the separately bound inspector. Project/helper coverage, other lazy paths, native ELF closure, loader selection, final host roles and H0 acceptance remain separate.

Explicit data reads use bounded nofollow regular-file reads with before/after identity and digest checks. Metadata trees are scanned twice, including every actual file and necessary directory; all explicitly bound files and module/cache aliases receive final preservation readback. Ordinary interpreter import I/O and internal metadata reads are not counted in the explicit-byte counter; hard outer memory, CPU, output and wall-time bounds still apply.

## Exact launch gate

Use canonical pinned Python 3.12.14 with `-I -S -B` and exactly the five fixed environment entries. The wrapper requires the externally supplied plan digest and an independently accepted review at `session/h0_review/AUTHOR-RUNTIME-REVIEW.json`, binding both script hashes. Director review remains required before launch.

The wrapper creates exclusive intent/start/stdout/stderr/receipt files, launches one collector, applies 256 MiB address-space, 42-second CPU, 2 MiB-per-output and 45-second wall limits, and allows at most five seconds for process-group cleanup. The collector has a 40-second alarm/deadline. No retry or promotion to an H0 receipt occurs. Attempt uncertainty is retained rather than treated as success. `EXECUTION-REQUEST.json` supplies the exact argv prefix and nonblocking exec guidance; the review digest must be supplied only after actual review.

## Verification

`STATIC-READBACK.json` confirms every manifest member, exact source-object equality, exact import/environment/limit constants, syntax via AST parsing, 12 source bindings, 34 direct roots, 47 metadata bindings and the empty attempt directory. No target process, package installation, project runtime, canonical edit or Git mutation occurred in this assignment.

Plan SHA-256: `81f5082562fe86a84a7dd4963ff892986e1bc8c587f3796c611a8f0667a84f7d`.

Manifest SHA-256: `55fadf7ef59d24af476117b69a6a941b7c1617bea9a00589e8d4b2d5e81e113f`.
