"""Build candidate documents from saved evidence and source bytes; never execute them."""
import ast
import hashlib
import json
import os
from pathlib import Path
import stat

BASE = Path("/workspace/scratch/cf652064a9a1")
HERE = BASE / "session/author_runtime"
CANDIDATE = HERE / "candidate001"
SOURCE = BASE / "frozen-source"
STDLIB = Path("/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12")


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=True, allow_nan=False).encode("ascii")


def descriptor(path):
    path = Path(path)
    raw = path.read_bytes()
    return {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(), "size_bytes": len(raw),
            "mode": oct(stat.S_IMODE(path.lstat().st_mode))}


def read(path):
    return json.loads(Path(path).read_bytes())


def write(name, value):
    path = CANDIDATE / name
    with path.open("xb") as stream:
        stream.write(canonical(value))
    return descriptor(path)


def main():
    attempt = HERE / "attempt001"
    attempt.mkdir(exist_ok=False)
    advisory_path = BASE / "session/h0_review/IMPORT-SOURCE-ADVISORY.json"
    result_path = BASE / "session/python_preparation/RESULT.json"
    source_object_path = BASE / "session/source_preparation/SOURCE-OBJECT.json"
    advisory, result, source = read(advisory_path), read(result_path), read(source_object_path)
    assert descriptor(result_path)["sha256"] == "7d2ab6de9e20f80a7ad3d9d19984cdb157446e43d71aec262afa654594a46c16"
    assert descriptor(advisory_path)["sha256"] == "18e249f3ca3c6f43a63e893d4e77beba654e436f004f7dcfcd206d37dd97941b"
    assert result["status"] == "prepared_static_identity_verified"
    assert result["input_checks_before"] == result["input_checks_after"] == {"checked": 463, "failures": []}
    assert len(result["installed"]["files"]) == 293
    assert all(row["returncode"] == 0 for row in result["steps"])
    source_inventory = read(source["inventory"]["path"])
    assert len(source_inventory["files"]) == 627
    assert descriptor(source_object_path)["sha256"] == "b5498e70a1d9ae1aa8b56d26641deb953dbc11ef3a55cf33ee6dd37bde4028d9"
    collector = CANDIDATE / "collect_author_runtime.py"
    capture = CANDIDATE / "capture_author_runtime.py"
    trees = {str(path): ast.parse(path.read_text(), filename=str(path)) for path in (collector, capture)}
    collector_tree = trees[str(collector)]
    constants = {}
    for node in collector_tree.body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            if node.targets[0].id in ("DIRECT_ROOTS", "ENVIRONMENT"):
                constants[node.targets[0].id] = ast.literal_eval(node.value)
    assert list(constants["DIRECT_ROOTS"]) == advisory["direct_stdlib_modules"]
    source_read_set = []
    for row in advisory["sources"]:
        current = descriptor(SOURCE / row["path"])
        assert current["sha256"] == row["sha256"] and current["size_bytes"] == row["size_bytes"]
        assert {key: current[key] for key in ("sha256", "size_bytes", "mode")} == source_inventory["files"][row["path"]]
        source_read_set.append(current)
    lock = descriptor(SOURCE / "tools/native-reader-verification-linux-cp312.lock")
    import re
    pins = {}
    for line in Path(lock["path"]).read_text().splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        match = re.fullmatch(r"([A-Za-z0-9_.-]+)==([^\s\\]+) --hash=sha256:[0-9a-f]{64}", line)
        assert match and match[1] not in pins
        pins[match[1]] = match[2]
    normalize = lambda value: re.sub(r"[-_.]+", "-", value).lower()
    site = Path(result["installed"]["site_root"])
    expected_site = BASE / "isolated-p26/lib/python3.12/site-packages"
    assert site == expected_site
    packages = []
    for name, version in pins.items():
        candidates = [row for row in result["installed"]["packages"] if normalize(row["name"]) == normalize(name)]
        assert len(candidates) == 1 and candidates[0]["version"] == version
        root = Path(candidates[0]["metadata"]["path"]).parent
        assert root.parent == site
        files = {}
        for row in result["installed"]["files"]:
            path = Path(row["path"])
            if path.is_relative_to(root):
                files[path.relative_to(root).as_posix()] = {"sha256": row["sha256"], "size_bytes": row["bytes"], "mode": row["mode"]}
        assert "METADATA" in files and files
        packages.append({"name": name, "version": version, "distribution_root": str(root), "metadata_files": files})
    assert len(packages) == 7
    python_row = read(BASE / "session/python_preparation/INPUT-INVENTORY.json")["python"]
    python_descriptor = {"path": python_row["path"], "sha256": python_row["sha256"],
                         "size_bytes": python_row["bytes"], "mode": python_row["mode"]}
    assert python_descriptor["sha256"] == "fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7"
    ancestors = []
    for path in (attempt, *attempt.parents):
        info = path.lstat()
        assert stat.S_ISDIR(info.st_mode)
        ancestors.append({"path": str(path), "device": info.st_dev, "inode": info.st_ino,
                          "mode": oct(stat.S_IMODE(info.st_mode))})
    limits = {"collector_seconds": 40, "max_modules": 1024, "max_bound_files": 4096,
              "per_file_bytes": 32 * 1024 * 1024, "aggregate_read_bytes": 256 * 1024 * 1024,
              "metadata_entries_per_package": 2048, "stdout_bytes": 2 * 1024 * 1024}
    coverage = {
        "schema": "ontokin.c271.p26-author-runtime-coverage-scope/1",
        "source": source, "source_read_set": source_read_set,
        "direct_stdlib_modules": advisory["direct_stdlib_modules"],
        "ordinary_exercises": [
            {"source": "prototypes/static_tray_v01/current_host_inspection_v01.py:main/_Parser",
             "operation": "Construct ArgumentParser from source docstring with allow_abbrev=False; add the same --plan, --plan-sha256, --observe arguments; parse valid inputs with observe false and true.",
             "excluded": "No project import, inspect_host call, error/help branch or target."},
            {"source": "current_host_readback_v01.py:_verify_host and tools/check_local.py:force_agent_preflight metadata.version reader relation; inspector:_check_metadata complete-tree rule",
             "operation": "Distribution.at(exact prepared dist-info root).metadata and .version use the ordinary PathDistribution.read_text/email parser path.",
             "excluded": "No distribution discovery over sys.path, no package import, entry-point loading or arbitrary site-packages sweep."},
        ],
        "meaning": "Raw observed module/caches and metadata candidates only. Source/helper graph and unexercised lazy branches remain independent review obligations.",
        "builtin_policy": "Record sys.builtin_module_names and actual origin. math/_ctypes built-in observations do not imply a separate extension path; no extension filler is allowed.",
        "native_policy": "Only actual loaded file-backed modules with ELF magic become observed extension candidates. Full transitive ELF/loader closure is separate.",
    }
    coverage_descriptor = write("COVERAGE-SCOPE.json", coverage)
    plan = {
        "schema": "ontokin.c271.p26-author-runtime-collection-plan/1",
        "state": "candidate_not_executed_requires_Director_and_independent_review",
        "source": source, "collector": descriptor(collector), "capture": descriptor(capture),
        "python": python_descriptor, "python_version": "3.12.14",
        "environment": constants["ENVIRONMENT"], "environment_inheritance": False,
        "cwd": str(HERE), "argv_prefix": [python_descriptor["path"], "-I", "-S", "-B", str(collector),
                                           "--plan", str(CANDIDATE / "LAUNCH-PLAN.json"), "--plan-sha256"],
        "external_digest_argument": "Append the independent SHA-256 of exact LAUNCH-PLAN.json bytes; do not derive authority from the plan itself.",
        "direct_stdlib_modules": advisory["direct_stdlib_modules"], "stdlib_root": str(STDLIB),
        "allowed_sys_path": [str(STDLIB.parent / "python312.zip"), str(STDLIB), str(STDLIB / "lib-dynload")],
        "input_documents": {"source_object": descriptor(source_object_path),
                            "source_inventory": source["inventory"],
                            "import_advisory": descriptor(advisory_path),
                            "python_preparation": descriptor(result_path),
                            "coverage_scope": coverage_descriptor},
        "source_read_set": source_read_set,
        "stdlib_exercise_sources": [descriptor(STDLIB / "argparse.py"), descriptor(STDLIB / "importlib/metadata/__init__.py")],
        "lock": lock, "metadata_site_root": str(site), "metadata_packages": packages,
        "limits": limits, "supervision": {"wall_timeout_seconds": 45, "cleanup_seconds": 5,
                                             "hard_address_space_limit_bytes": 256 * 1024 * 1024,
                                             "hard_cpu_seconds": 42, "per_output_limit_bytes": 2 * 1024 * 1024},
        "outputs": {"intent": str(attempt / "run001.attempt.json"), "started": str(attempt / "run001.started.json"),
                    "stdout": str(attempt / "run001.stdout.json"), "stderr": str(attempt / "run001.stderr.txt"),
                    "capture_receipt": str(attempt / "run001.capture.json")},
        "evidence_ancestors": ancestors,
        "effects": {"project_imports": False, "third_party_imports": False, "target_subprocesses": False,
                    "collector_subprocesses": False, "collector_filesystem_writes": False,
                    "network": False, "metadata_roots": 7, "metadata_tree_enumerations": 14,
                    "stdlib_imports": "Exact 34 explicit roots plus their ordinary standard-library transitive imports and reviewed call paths",
                    "capture_processes": "One selected Python child; no retry; process-group cleanup only on failure"},
        "limits_of_interpretation": coverage["meaning"],
    }
    plan_descriptor = write("LAUNCH-PLAN.json", plan)
    static = {
        "schema": "ontokin.c271.p26-author-runtime-static-checks/1", "collector_executed": False,
        "capture_executed": False, "ast_parse_passed": list(trees), "source": source,
        "advisory_sha256": descriptor(advisory_path)["sha256"], "advisory_direct_roots_match": True,
        "python_preparation_sha256": descriptor(result_path)["sha256"], "python_preparation_status": result["status"],
        "source_read_set_count": len(source_read_set), "source_read_set_bytes_match_advisory_and_inventory": True,
        "metadata_package_count": len(packages), "expected_metadata_file_count": sum(len(row["metadata_files"]) for row in packages),
        "metadata_inputs_derived_only_from_saved_success_result": True,
        "stdlib_exercise_sources": plan["stdlib_exercise_sources"],
        "direct_collector_syntax_imports": sorted({alias.name for node in ast.walk(collector_tree) if isinstance(node, ast.Import) for alias in node.names}
                                                 | {node.module for node in ast.walk(collector_tree) if isinstance(node, ast.ImportFrom)}),
        "reads_not_claimed": ["No runtime import experiment", "No new Python/metadata inventory collection", "No project execution", "No native closure acceptance"],
    }
    write("STATIC-CHECKS.json", static)
    request = {
        "schema": "ontokin.c271.p26-author-runtime-execution-request/1", "state": "not_executed_review_required",
        "plan": plan_descriptor, "capture": descriptor(capture), "collector": descriptor(collector),
        "independent_review_path": str(BASE / "session/h0_review/AUTHOR-RUNTIME-REVIEW.json"),
        "required_review_verdict": "accepted_for_one_bounded_author_runtime_observation",
        "required_review_fields": ["plan_sha256", "collector_sha256", "capture_sha256"],
        "capture_argv_prefix": [python_descriptor["path"], "-I", "-S", "-B", str(capture), plan_descriptor["sha256"]],
        "final_argument": "Exact SHA-256 of the independently accepted review file, supplied externally after Director review",
        "cwd": str(HERE), "environment": constants["ENVIRONMENT"], "environment_inheritance": False,
        "exec_yield_time_ms": 1000, "capture_timeout_and_cleanup_seconds": 50,
        "success": "One completed raw observation with empty stderr, exact bound source/plan and h0_complete=false; preserve all attempt files regardless of outcome.",
        "no_retry": "Existing or uncertain attempt must be reconciled. Any changed scope/bytes needs a new reviewed candidate and fresh attempt."}
    write("EXECUTION-REQUEST.json", request)
    manifest = {"schema": "ontokin.c271.p26-author-runtime-candidate-manifest/1", "state": "frozen_candidate_not_executed",
                "files": [descriptor(path) for path in sorted(CANDIDATE.iterdir()) if path.is_file()],
                "source": source, "plan_sha256": plan_descriptor["sha256"], "attempt_outputs_exist": False}
    write("MANIFEST.json", manifest)
    print(json.dumps({"plan": plan_descriptor, "collector": descriptor(collector), "capture": descriptor(capture),
                      "manifest": descriptor(CANDIDATE / "MANIFEST.json"), "metadata_files": static["expected_metadata_file_count"],
                      "collector_execution": False, "capture_execution": False}, indent=2))


if __name__ == "__main__":
    main()
