#!/usr/bin/env python3
"""Parse the downloaded Debian container as data without installation or execution."""
from pathlib import Path
import hashlib, io, json, tarfile

root=Path('/workspace/scratch/5041e572c132/p15-session')
source=root/'package-retrieval/libc6_2.41-12+deb13u4_amd64.deb.inert'
out=root/'package-inspection';out.mkdir(exist_ok=False)
data=source.read_bytes();assert data[:8]==b'!<arch>\n'
members={};arrows=[];pos=8
while pos<len(data):
    header=data[pos:pos+60];assert len(header)==60 and header[58:60]==b'`\n'
    name=header[:16].decode('ascii').strip().rstrip('/')
    size=int(header[48:58].decode('ascii').strip())
    assert size>=0 and pos+60+size<=len(data) and name not in members
    body=data[pos+60:pos+60+size];members[name]=body
    arrows.append({'name':name,'bytes':size,'sha256':hashlib.sha256(body).hexdigest()})
    pos+=60+size+(size%2)
assert pos==len(data) and members['debian-binary']==b'2.0\n'
inventories={};selected=[];loader=None;metadata={}
for name,body in members.items():
    if not name.startswith(('data.tar','control.tar')):continue
    with tarfile.open(fileobj=io.BytesIO(body),mode='r:*') as archive:
        entries=archive.getmembers();assert len(entries)<10000
        inventories[name]=[{'name':e.name,'bytes':e.size,'type':e.type.decode('ascii','backslashreplace'),'mode':oct(e.mode),'linkname':e.linkname} for e in entries]
        for entry in entries:
            normalized=entry.name.removeprefix('./')
            if normalized.endswith('/ld-linux-x86-64.so.2') and entry.isfile():
                assert entry.size<1024*1024 and loader is None
                loader=archive.extractfile(entry).read();assert len(loader)==entry.size
                (out/'official-loader.elf.inert').write_bytes(loader)
                selected.append({'archive':name,'member':entry.name,'bytes':len(loader),'sha256':hashlib.sha256(loader).hexdigest(),'original_mode':oct(entry.mode),'original_mtime':entry.mtime})
            if name.startswith('control.tar') and normalized in {'control','md5sums'}:
                assert entry.isfile() and entry.size<1024*1024
                content=archive.extractfile(entry).read();(out/(normalized+'.txt')).write_bytes(content)
                metadata[normalized]={'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()}
assert loader is not None
local=(root/'host-evidence-attempt002/loader.elf.inert').read_bytes()
result={'schema':'ontokin.c271.p15-official-package-binding/1','package':{'path':str(source),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'url':'https://deb.debian.org/debian/pool/main/g/glibc/libc6_2.41-12+deb13u4_amd64.deb'},
        'ar_members':arrows,'selected_loader':selected[0],'loader_byte_for_byte_equal_to_actual_host':loader==local,
        'control_metadata':metadata,'archive_inventory':'ARCHIVE-INVENTORY.json',
        'scope':'Authenticates exact byte equality to package served by official Debian HTTPS endpoint. Source/patch/build/suffix review remains separate.',
        'installation':False,'target_execution':False,'untrusted_member_paths_extracted':False}
(out/'ARCHIVE-INVENTORY.json').write_text(json.dumps(inventories,indent=2)+'\n')
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
for p in out.iterdir():p.chmod(0o644)
print(json.dumps(result,indent=2))
print((out/'control.txt').read_text())
