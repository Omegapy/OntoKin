# C271 P15 documentary recommendations

This is an advisory handoff to the canonical writer, `/root`. No canonical file, Git/index state, source, host input, or prior frozen evidence was changed.

## Record the exact partial outcome

P15 independently accepted the identified loader's four-entry suffix union. It then stopped at the first actual H0 input-admission refusal. Keep those decisions separate.

The unchanged production metadata reader returned `CHI-UNSUPPORTED`, reason `Unreviewed ELF dynamic loader feature`, for the captured current Python process's libc. Independent review identifies the first failed predicate as the admitted dynamic-tag check at exact source line 1162. Tag `0x70000000`, file offset 1,980,896, first falsifies it; `0x70000001` and `0x70000003` are also outside that set. The later dynamic-flags check was **not reached**. Do not describe this phase as a flags/TLS diagnosis or repair.

Binding evidence:

- `../loader-review/attempt001/SOURCE-COMPLETENESS-DECISION.json`: SHA256 `2f32377faeea0df9c6a95e7be895a62482a7f776ed35747838c2b9a71354a2cb`.
- `../h0-static-admission-attempt001/OUTCOME.json`: SHA256 `c81c39f10624597a6666ff8acd501a3c68fcd087f37e85899a1884e3612b654a`.
- `../loader-review/blocker-attempt001/BLOCKER-DECISION.json`: SHA256 `2d1cc08582e1a03a7ae1c5689ee55fe8548e5bac2a0b6438e5ed32eb4f82d1f9`.

The reader source remains SHA256 `a8274d56076562a91d26b3cdd2f614fce6fd509733e4939b225dff2ddca09db4`; libc remains SHA256 `9792e3cbb541c8f44c7acf5f14f4022ea62998ecc787d326bed4d8b6547dfd92`. The admission attempt imported the production module and called its data reader in a Python tool process. Preserve the earlier no-import boundary as historical evidence and add this later disclosure. Node, ldd, direct loader commands, installation, H1, original-seven and full-routine execution remain absent from this phase.

## Precise state treatment

`PATCH-RECOMMENDATIONS.json` gives exact file paths, JSON pointers, transition timing, and proposed text. Preserve task `blocked`, R01/R02 `done`, R03–R05 `not_done`, P01 `done`, and aggregate P02 `in_progress`. A completed partial delivery does not complete the parent.

Archive P14's current phase/delivery records into their existing history arrays before replacing current fields with P15. Preserve its confirmed receipt. Keep `CURRENT.latest_handoff` on confirmed P14 until P15's final save and exact-byte readback succeed. P15 technical work is stopped; documentary/publication/delivery gates remain pending until their actual evidence exists. Supersede the old unresolved suffix-completeness constraint only in that accepted scope; retain it historically and install the new libc-tag blocker without implying complete H0 inventory or plan acceptance.

Append distinct P15 outcome and delivery sections to REQUIREMENTS and PLAN; do not rewrite prior phase observations. Historical N57 remains neither a newly executed runtime pass nor a skip. Preserve failures, source pins, limits, controls, and the three retained historical unknowns.

Root reports that main advanced at 06:05:05Z to `70ca7e68ff95df876f801137369d176fe5b2bab3` through licensing PR275, while branch `875c81c506d4e5431b909e190ce294c61312029e` remained unchanged. Update the fresh observed-main field with the retained live evidence. Keep immutable starting-main fields unchanged. Record that this branch lacks those licensing changes and future integration must reconcile the live base. No rebase or main lease belongs to P15.

## Learning recommendation

Recommend one scoped lesson in `docs/workflow/memory.json`, ID `memory-c271-loader-source-admission-boundary`, using the existing record schema (`id`, `kind`, `status`, `summary`, `sources`, `scope`, `recorded_at`, `supersedes`). The complete proposed object is in the JSON recommendations. Root must copy/bind the cited P15 evidence to its chosen canonical evidence directory before adopting it.

The scoped lookup found no C271 entry. All 15 existing memory summaries were inspected; relevant recovery/integration/delivery records were read in full, and knowledge records were filtered for this topic. The proposed lesson adds the evidenced distinction between exact-loader source approval and actual-input admission. Skip separate generic recovery, saved-ZIP, uncertain-write, and current-pointer lessons because MEM-008, MEM-009, `memory-c264-browser-handoff`, and `memory-c266-recovery-closure` already cover them. No knowledge capability or adopted semantics should change.

## Remaining gates and next action

Root should complete exact-evidence/protected-source and required documentary/workflow/whitespace checks, independent documentary review, conditional nonforce publication on the retained branch, and exact remote readback. Recheck the live branch head before publishing. Keep PR274 draft/open, issue273 open, and main untouched. Preserve the diagnosed native-push restriction; do not retry it. The 20,323,540-byte original source archive exceeds the known connector payload limit, so use the established retained-part method if needed and verify concatenation equality.

Then independently verify and freeze the partial ZIP and matching main/subchat prompts; confirm their saves and returned bytes/metadata; record the separate external delivery receipt and terminal confirmation. Do not replace source-time pending fields with invented success or mutate the frozen ZIP to include its own receipt. Stop after the verified final delivery.

The current authorized next step is documentary completion and delivery only. A candidate next fresh phase is a bounded source/semantic decision on the exact excluded libc dynamic tags, with independently frozen controls before any implementation. Its scope must be selected in that fresh phase. Do not automatically resume H0, inspect later gates, loosen the allowlist, substitute inputs, or preselect a flags repair.
