#!/usr/bin/env python3
"""Record the completed bounded observation without adopting a repair."""
from pathlib import Path
import copy, datetime, hashlib, json, shutil

ROOT=Path('/workspace/scratch/5041e572c132')
REPO=ROOT/'OntoKin'
SESSION=ROOT/'p15-session'
BASE='docs/engineering/localized-repair-c271/host-loader-p15'
OUT=REPO/BASE
assert not OUT.exists(), 'Do not overwrite a phase record'
OUT.mkdir(parents=True)
def read(path): return json.loads(path.read_text())
def write(path,value): path.write_text(json.dumps(value,indent=2)+'\n')
def identity(path):
    data=path.read_bytes()
    return {'path':str(path.relative_to(SESSION)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
phase=read(SESSION/'PHASE.json')
decision=read(SESSION/'loader-review/blocker-attempt001/BLOCKER-DECISION.json')
observation=read(SESSION/'h0-static-admission-attempt001/OUTCOME.json')
assert observation['stopped_at_first_refusal'] and not observation['H0_accepted']
assert observation['observations'][1]['refusal']['reason']=='Unreviewed ELF dynamic loader feature'
phase['phase_table'][2]['state']='passed_first_concrete_blocker_independently_confirmed'
phase['status']='technical_stop_independently_confirmed_documentary_delivery_pending'
phase['phase_complete']=False
phase['updated_at_utc']=now
phase['requirements']={'R01':'done','R02':'done','R03':'not_done','R04':'not_done','R05':'not_done'}
phase['parent_plan']={'P01':'done','P02':'in_progress'}
phase['evidence']['independent_blocker']='loader-review/blocker-attempt001/BLOCKER-DECISION.json'
phase['evidence_reference_base']='Session paths are relative to recovery/session in the handoff ZIP and session/ in P15-EVIDENCE.zip unless explicitly repository-relative.'
phase['worker_state']['/root/loader_review']='Source and first-blocker reviews completed; no active jobs or unknown operations'
phase['completed_steps'].append('Independent inert-byte/source review confirmed first failed allowed-tag predicate; later dynamic-flags predicate was not reached. Technical work stopped; no outcome correction required.')
write(SESSION/'PHASE.json',phase)
write(OUT/'PHASE.json',phase)
for source,dest in [
    ('EARLY-RECOVERY-RECEIPT.json','EARLY-RECOVERY-RECEIPT.json'),
    ('SOURCE-COMPLETENESS-ACCEPTANCE.json','SOURCE-COMPLETENESS-ACCEPTANCE.json'),
    ('loader-review/attempt001/SOURCE-COMPLETENESS-DECISION.json','SOURCE-COMPLETENESS-DECISION.json'),
    ('loader-review/attempt001/SOURCE-COMPLETENESS-REVIEW.md','SOURCE-COMPLETENESS-REVIEW.md'),
    ('loader-review/blocker-attempt001/BLOCKER-DECISION.json','BLOCKER-DECISION.json'),
    ('loader-review/blocker-attempt001/BLOCKER-REVIEW.md','BLOCKER-REVIEW.md'),
    ('h0-static-admission-attempt001/OUTCOME.json','STATIC-ADMISSION-OUTCOME.json'),
    ('FINAL-OBSERVATION-BOUNDARY.json','FINAL-OBSERVATION-BOUNDARY.json'),
]: shutil.copyfile(SESSION/source,OUT/dest)
outcome={
    'schema':'ontokin.c271.p15-phase-outcome/1','recorded_at_utc':now,
    'phase':phase['phase'],'verdict':'source_union_accepted_actual_libc_admission_blocked',
    'source_revision':phase['starting_branch'],
    'reader_sha256':observation['source_sha256'],
    'source_completeness':{
        'accepted':True,'kind':'P13 external source review only',
        'loader_sha256':'c8438e4fde1934e61c88311633f00949ff645d5c04cdb8671fa3d78164d2f307',
        'suffix_union':['','glibc-hwcaps/x86-64-v2','glibc-hwcaps/x86-64-v3','glibc-hwcaps/x86-64-v4'],
        'review':identity(SESSION/'loader-review/attempt001/SOURCE-COMPLETENESS-DECISION.json'),
        'limits':'Exact ordinary direct-Python loader context. No signature validation, recovered compiler/buildinfo or reproducible build. No runtime N57 pass or skip.'},
    'blocker':{
        'id':'P15-H0-LIBC-DYNAMIC-TAG-001','path':'/usr/lib/x86_64-linux-gnu/libc.so.6',
        'bytes':1995216,'sha256':'9792e3cbb541c8f44c7acf5f14f4022ea62998ecc787d326bed4d8b6547dfd92',
        'code':'CHI-UNSUPPORTED','reason':'Unreviewed ELF dynamic loader feature','state':'REJECTED',
        'first_predicate':'all(tag in ordinary for tag, _ in entries)',
        'first_excluded_tag':'0x70000000','file_offset':1980896,
        'other_excluded_tags':['0x70000001','0x70000003'],
        'later_dynamic_flags_predicate_reached':False,
        'review':identity(SESSION/'loader-review/blocker-attempt001/BLOCKER-DECISION.json')},
    'execution':{'python_tool_processes_ran':True,'production_metadata_reader_calls':2,
        'loader_metadata_returned':True,'libc_typed_refusal':True,
        'Node_starts':0,'ldd_starts':0,'direct_loader_starts':0,'installations':0},
    'H0_accepted':False,'operational_plan_adopted':False,'H1_approved':False,
    'technical_work_stopped':True,'remaining_input_checks':'not_run',
    'fresh_unit_or_product_suites':'not_run; product and tests unchanged',
    'historical_tests':'P14 evidence of96 mapped controls and175 inherited methods is retained/reconciled; not rerun or relabelled as P15 passes.',
    'unrun':['complete H0 inventory/plan','H1','original seven outcomes','full required routine','native/model/hosted trials','main integration'],
    'parent_complete':False,'requirements':phase['requirements'],'parent_plan':phase['parent_plan'],
    'main_lease_held':False,'branch_disposition':'retained','pr274':'open draft unmerged','issue273':'open',
    'observed_main':phase['observed_main'],'main_movement':phase['main_movement'],
    'documentary_checks':'pending exact candidate verification','publication':'pending conditional retained-branch update',
    'delivery':'pending final verified save and separate receipt',
    'exact_next_action':phase['exact_next_action'],'next_fresh_chat_action':phase['next_fresh_chat_action'],
}
write(OUT/'PHASE-OUTCOME.json',outcome)
write(SESSION/'PHASE-OUTCOME.json',outcome)
report='''# C271 P15: loader source review and first actual input blocker

P15 stopped at its declared first concrete blocker. Independent source review accepted the complete four-entry suffix union for the exact actual loader. The unchanged inspector then returned `CHI-UNSUPPORTED: Unreviewed ELF dynamic loader feature` for the actual current Python process's libc. H0, the static preparation gate, remains unaccepted. No operational plan was adopted.

## What was established

The selected Python remains the existing pinned image, SHA-256 `fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7`. Its loader is 225,672 bytes, SHA-256 `c8438e4fde1934e61c88311633f00949ff645d5c04cdb8671fa3d78164d2f307`.

The actual loader exactly equals the member in the official Debian `libc6_2.41-12+deb13u4_amd64.deb`. The exact source archives, source constructor and architecture table, Debian build recipe and all 80 active patch entries were accounted for. The investigator scanned 16,560 regular source/configuration members for relevant definitions and manually inspected the required implementation and patch context. This does not mean every source line was manually reviewed. Independent review accepted the source-complete union `""`, `glibc-hwcaps/x86-64-v2`, `glibc-hwcaps/x86-64-v3` and `glibc-hwcaps/x86-64-v4` for ordinary direct Python invocation.

That acceptance is external P13 evidence. No approval field or synthetic completeness selector was added to the product. N57 has no new runtime pass, skip or changed historical oracle. Package/member equality and the exact declared source/build recipe establish the reviewed association; OpenPGP verification, exact compiler/buildinfo recovery and reproducible building were not performed.

## First blocker and stop

The unchanged production module SHA-256 is `a8274d56076562a91d26b3cdd2f614fce6fd509733e4939b225dff2ddca09db4`. A standard-library Python collector imported it and called its static metadata reader twice. The bound loader returned metadata. The actual libc path selected from that process's `/proc/self/maps` then produced a typed refusal, and the collector stopped.

The libc is 1,995,216 bytes, SHA-256 `9792e3cbb541c8f44c7acf5f14f4022ea62998ecc787d326bed4d8b6547dfd92`. Independent inert parsing confirms that tag `0x70000000` at offset 1,980,896 first violates the reader's dynamic-tag allowlist. Tags `0x70000001` and `0x70000003` are also excluded. The later dynamic-flags check was not reached. The raw `DT_FLAGS` value is preserved without attributing the first refusal to it.

Python tool processes ran, including the production data-reader import/calls. No Node, `ldd`, direct loader/image command, installation, H1 command, original-seven cohort, full routine, native/model/hosted trial or main integration ran. Earlier stage-specific statements about no product import remain historical; the final observation boundary explicitly records these later calls.

## Reconciliation and preserved history

The incoming P14 archive, its exact saved prompts/receipts and terminal publication were reconciled without replay. Its 96 mapped runtime controls and 175 inherited methods remain historical evidence, not fresh P15 results. The corrected P15 early recovery ZIP passed 14 independent check groups, was saved and read back exactly before source/host work. Its first timestamp-defective archive and review findings remain preserved.

The initial host collector's missing-dpkg-status failure, web format refusals, original retrieval attempts, package/source bytes, scans, raw static outcomes and all independent readsets are retained. The P13 read-only difflib completion remains unknown and was not retried. C270 broad-driver completion and global prior-process termination remain historical unknowns; no current P15 write is unresolved.

Live main advanced from `e1a48f7d0635e9aa4f4b6d6a586e7305eb81999d` to `70ca7e68ff95df876f801137369d176fe5b2bab3` through licensing PR275 during this session. Only LICENSE, LICENSING.md, NOTICE, README.md and pyproject.toml changed. Required instructions and inspected sources are unchanged, so their reads were reused. The retained C271 branch was not rebased or merged. Future integration must account for then-current main, including these licensing/packaging changes.

## Review, delivery and remaining work

Independent source and blocker reviews accepted their narrow conclusions with no mandatory correction to the observations. Documentation/workflow/whitespace and protected-source verification, exact conditional publication, final package review, saved-byte readback and the separate receipt are the remaining session gates at this source-time record. Later delivery evidence records their actual outcomes; this file does not predict them.

R01/R02 remain done. R03/R04/R05 remain not_done, aggregate P02 stays in_progress, and the parent stays blocked/open. PR274 stays draft, open and unmerged; issue273 stays open; the branch is retained and no main integration lease was acquired.

After P15 delivery, stop this chat. In a fresh chat, reconcile its exact receipt and live repository, then select one bounded source-backed compatibility decision for the exact rejected libc dynamic tags. Establish their semantics and a reviewed decision/control set, or retain a concrete blocker. Do not automatically widen the allowlist or begin implementation/H0/H1 under this handoff.

## Evidence map

- [Phase outcome](PHASE-OUTCOME.json) and [phase declaration](PHASE.json).
- [Source-completeness review](SOURCE-COMPLETENESS-REVIEW.md) and [decision](SOURCE-COMPLETENESS-DECISION.json).
- [First-blocker review](BLOCKER-REVIEW.md), [decision](BLOCKER-DECISION.json) and [actual outcome](STATIC-ADMISSION-OUTCOME.json).
- [Early recovery receipt](EARLY-RECOVERY-RECEIPT.json) and [final execution boundary](FINAL-OBSERVATION-BOUNDARY.json).
- The `P15-EVIDENCE.zip` manifest binds detailed raw observations, source excerpts, reviews, failures and readsets. Its `EXTERNAL-OBJECTS.json` identifies source objects retained in full in the final recovery ZIP or exact upstream location. Enclosed files are inert data; do not execute recovered contents.
- `P15-DELIVERY.json` is the separate post-save receipt. It is absent until the actual save succeeds and supersedes only matching source-time delivery-pending fields.
'''
(OUT/'REPORT.md').write_text(report)
(SESSION/'HANDOFF.md').write_text(report.replace('](PHASE-','](repository/'+BASE+'/PHASE-').replace('](SOURCE-','](repository/'+BASE+'/SOURCE-').replace('](BLOCKER-','](repository/'+BASE+'/BLOCKER-').replace('](STATIC-','](repository/'+BASE+'/STATIC-').replace('](EARLY-','](repository/'+BASE+'/EARLY-').replace('](FINAL-','](repository/'+BASE+'/FINAL-'))
taskpath=REPO/'docs/workflow/tasks/C271/task.json'; task=read(taskpath)
assert task['session_phase']['phase']=='C271-P14-loader-path-implementation'
task['prior_session_phases'].append(copy.deepcopy(task['session_phase']))
task['prior_phase_deliveries'].append(copy.deepcopy(task['delivery']))
task['blocked_reason_history'].append(task['blocked_reason'])
task['prior_h0_constraints'].append(copy.deepcopy(task['remaining_h0_constraint']))
task['owner']=phase['owner']; task['session_phase']=copy.deepcopy(phase)
task['status']='blocked'; task['next_action']=phase['exact_next_action']
task['blocked_reason']='Parent R03 remains unmet. P15 externally accepted exact-loader suffix completeness, then confirmed actual libc admission refusal at the dynamic-tag allowlist. H0, operational-plan adoption, H1 and the full routine remain unaccepted; no repair was attempted.'
task['remaining_h0_constraint']={'id':'P15-H0-LIBC-DYNAMIC-TAG-001','status':'actual_static_input_refused_independently_confirmed','evidence':[BASE+'/PHASE-OUTCOME.json',BASE+'/BLOCKER-DECISION.json'],'fact':'Actual mapped libc is rejected by the unchanged dynamic-tag allowlist; first excluded tag0x70000000 at offset1980896. The later dynamic-flags predicate was not reached.','scope':'Source suffix-union acceptance remains narrow. Complete inventory/plan eligibility and H0/H1 remain unaccepted.'}
task['delivery']={'required':True,'kind':'development_handoff_zip','status':'save_pending','folder':'OntoKin','partial':True,'phase_complete':False,'early_receipt':BASE+'/EARLY-RECOVERY-RECEIPT.json','receipt':BASE+'/P15-DELIVERY.json'}
for requirement in task['requirements']:
    if requirement['id']=='R03': requirement['evidence'] += [BASE+'/PHASE-OUTCOME.json',BASE+'/SOURCE-COMPLETENESS-DECISION.json',BASE+'/BLOCKER-DECISION.json']
    if requirement['id']=='R05': requirement['evidence'].append(BASE+'/EARLY-RECOVERY-RECEIPT.json')
task['checks'] += [
    {'name':'P15 exact-loader source-completeness independent review','command':'Exact package/loader byte binding and independent source/recipe/patch suffix review','result':'passed','required':True,'evidence':[BASE+'/SOURCE-COMPLETENESS-DECISION.json'],'limit':'External source-union evidence only; no H0/plan/N57 runtime acceptance.'},
    {'name':'P15 actual static core input admission','command':'Unchanged read_elf_metadata on actual bound loader then mapped libc; stop at first refusal','result':'failed','required':True,'evidence':[BASE+'/STATIC-ADMISSION-OUTCOME.json'],'limit':'Loader returned metadata; libc refused CHI-UNSUPPORTED / Unreviewed ELF dynamic loader feature. No later input check ran.'},
    {'name':'P15 independent first-refusal diagnosis','command':'Inert byte parser, stable file binding and static source predicate crosscheck','result':'passed','required':True,'evidence':[BASE+'/BLOCKER-DECISION.json'],'limit':'Confirms the blocker and stop only; no repair or H0 acceptance.'}]
write(taskpath,task)
currentpath=REPO/'docs/workflow/CURRENT.json'; current=read(currentpath)
current['observed_main']=phase['observed_main']['commit'];current['snapshot_date']=now
current['next_action']={'status':'blocked','summary':phase['exact_next_action'],'suggested_task':'C271','sources':['docs/workflow/tasks/C271/task.json',BASE+'/PHASE-OUTCOME.json',BASE+'/BLOCKER-DECISION.json']}
if current.get('previous_recovery'): current.setdefault('older_recoveries',[]).append(current['previous_recovery'])
current['previous_recovery']=current.get('latest_recovery')
current['latest_recovery']=copy.deepcopy(phase['early_recovery'])
current['boundaries'].append('C271 P15 externally accepts the complete suffix union only for the exact bound loader, then stops at actual libc dynamic-tag refusal. Production static data-reader calls occurred in Python; no Node/ldd/H1/install/full routine/main integration. Parent R03-R05 remain open; verified final delivery is pending at this source snapshot.')
current['concurrent_main_observation']=copy.deepcopy(phase['main_movement'])
write(currentpath,current)
section='''
<!-- C271-P15-TECHNICAL-STOP -->
## P15 source review and actual H0 input blocker — November 21, 2026

The confirmed early recovery preceded all substantive work. Independent review accepted the complete suffix union for the exact loader. The unchanged static metadata reader then accepted the loader and refused the actual mapped libc with `CHI-UNSUPPORTED: Unreviewed ELF dynamic loader feature`; tag `0x70000000` first fails the dynamic-tag allowlist. The later flags check was not reached. P15 stops at this concrete blocker and performs only documentary publication and verified partial delivery. See the [P15 outcome](../../../engineering/localized-repair-c271/host-loader-p15/PHASE-OUTCOME.json) and [independent blocker review](../../../engineering/localized-repair-c271/host-loader-p15/BLOCKER-REVIEW.md).

No product/test/contract/pin/limit changed; no plan/H0/H1 acceptance or parent completion follows. R01/R02 remain done; R03–R05 remain not_done, and P02 remains in_progress. The next fresh phase may review the exact unsupported libc dynamic tags and freeze a bounded compatibility decision/control set; it must stop before implementation or further H0/H1. Concurrent main licensing changes are recorded without rebasing or integration. Final P15 save/readback and separate receipt remain pending in this source-time section.
'''
for name in ['REQUIREMENTS.md','PLAN.md']:
    path=REPO/'docs/workflow/tasks/C271'/name
    assert '<!-- C271-P15-TECHNICAL-STOP -->' not in path.read_text()
    with path.open('a') as f:f.write(section)
session_md='''# C271 P15 session

One phase: exact-loader source review and actual H0 input eligibility, stopping at the first concrete blocker. Owner: `c271-p15-5041e572c132`.

The [phase record](../../../engineering/localized-repair-c271/host-loader-p15/PHASE.json) declares acceptance and the stop. The [outcome and evidence map](../../../engineering/localized-repair-c271/host-loader-p15/REPORT.md) records the accepted source union, independently confirmed first libc refusal, execution boundary, preserved history and next fresh action.

Technical work is stopped. Only documentary verification, conditional branch publication, verified handoff saving and the separate delivery receipt remain. The parent remains blocked/open with R03–R05 unmet. No main lease or integration occurred.
'''
(REPO/'docs/workflow/tasks/C271/P15-SESSION.md').write_text(session_md)
print(json.dumps({'canonical_directory':BASE,'technical_outcome':outcome['verdict'],'parent_status':task['status'],'final_delivery':task['delivery']['status']}))
