#!/usr/bin/env python3
"""Record bounded documentary checks without rerunning product suites."""
from pathlib import Path
import argparse, datetime, hashlib, json, platform, subprocess, sys

ROOT = Path('/workspace/scratch/5041e572c132')
REPO = ROOT / 'OntoKin'
parser = argparse.ArgumentParser()
parser.add_argument('attempt')
args = parser.parse_args()
out = ROOT / 'p15-session' / 'verification' / args.attempt
out.mkdir(parents=True, exist_ok=False)
def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()
commands = [
    ['python3', '-B', 'tools/chat_workflow.py', 'check'],
    ['python3', '-B', 'docs/maintenance/reorganization-2026-10-17/verify_reorganization.py'],
    ['git', 'diff', '--check'],
    ['git', 'diff', '--cached', '--check'],
]
intent = {'schema':'ontokin.c271.p15-documentary-checks/1',
          'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'cwd':str(REPO), 'head':git('rev-parse','HEAD'),
          'index_tree':git('write-tree'),
          'scope':'Documentation, workflow metadata and whitespace only; no product/runtime/R03 acceptance.',
          'python':sys.version, 'platform':platform.platform(), 'commands':commands}
(out/'INTENT.json').write_text(json.dumps(intent,indent=2)+'\n')
results=[]
for index, command in enumerate(commands,1):
    start=datetime.datetime.now(datetime.timezone.utc).isoformat()
    try:
        p=subprocess.run(command,cwd=REPO,capture_output=True,timeout=180)
        stdout,stderr,code=p.stdout,p.stderr,p.returncode
        timed_out=False
    except subprocess.TimeoutExpired as e:
        stdout,stderr,code=e.stdout or b'',e.stderr or b'',None
        timed_out=True
    (out/f'{index:02d}.stdout').write_bytes(stdout)
    (out/f'{index:02d}.stderr').write_bytes(stderr)
    results.append({'command':command,'started_at_utc':start,'exit_code':code,
                    'timed_out':timed_out,'passed':code==0,
                    'stdout_sha256':hashlib.sha256(stdout).hexdigest(),
                    'stderr_sha256':hashlib.sha256(stderr).hexdigest(),
                    'stdout_bytes':len(stdout),'stderr_bytes':len(stderr)})
record={**intent,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'checks':results,'all_passed':all(x['passed'] for x in results),
        'index_tree_unchanged':intent['index_tree']==git('write-tree')}
(out/'CHECKS.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'attempt':args.attempt,'index_tree':record['index_tree'],
                  'all_passed':record['all_passed'],
                  'results':[{'command':x['command'],'exit_code':x['exit_code']} for x in results]}))
sys.exit(0 if record['all_passed'] and record['index_tree_unchanged'] else 1)
