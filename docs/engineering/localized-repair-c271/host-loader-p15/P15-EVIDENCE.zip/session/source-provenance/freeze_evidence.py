from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import re

ROOT = Path('/workspace/scratch/5041e572c132')
BASE = ROOT / 'p15-session/source-provenance'
INSPECT = BASE / 'source-inspection-attempt001'
NOW = datetime.now(timezone.utc).isoformat()

def binding(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def write(name, obj):
    path = BASE / name
    assert not path.exists(), 'Frozen output already exists: ' + str(path)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')
    path.chmod(0o644)

raw_names = ['search-001.json', 'retrieval-002.json', 'retrieval-003.json', 'retrieval-004.json']
raw = []
for name in raw_names:
    row = binding(BASE / name)
    obj = json.loads((BASE / name).read_text())
    row['request'] = obj['request']
    row['reference_ids'] = sorted(set(re.findall(r'turn\d+(?:search|view|fetch)\d+', json.dumps(obj['result']))))
    raw.append(row)
download_files = [BASE / 'downloads-attempt001' / name for name in ['glibc_2.41-12+deb13u4.dsc', 'glibc_2.41.orig.tar.xz', 'glibc_2.41-12+deb13u4.debian.tar.xz']]
write('RAW-RESPONSES-MANIFEST.json', {
    'schema': 'ontokin.c271.p15-source-raw-response-manifest/1',
    'frozen_at_utc': NOW,
    'web_snapshot_format': 'Exact saved JSON serialization of each tool request and returned result; these are tool snapshots, not independently captured HTTP wire bytes.',
    'web_snapshots': raw,
    'ordinary_https_response_bodies': [binding(p) for p in download_files],
    'ordinary_https_transport_records': binding(BASE / 'downloads-attempt001/DOWNLOADS.json'),
    'parent_binary_response_record': binding(ROOT / 'p15-session/package-retrieval/RESULT.json'),
    'prior_web_format_failures_preserved': True,
    'interpretation': 'The web retrieval limits were superseded for binary and source archive access by successful authorized ordinary HTTPS retrieval; no global unavailability is inferred.'
})

pool = 'https://deb.debian.org/debian/pool/main/g/glibc/'
sources = [
    {'id': 'S1', 'url': pool + 'libc6_2.41-12+deb13u4_amd64.deb', 'web_reference': 'turn761065160view0', 'web_outcome': 'unsupported MIME', 'subsequent_outcome': 'Root ordinary HTTPS HTTP200, exact inert package retrieved', 'local_evidence': str(ROOT / 'p15-session/package-inspection/RESULT.json')},
    {'id': 'S2', 'url': 'https://tracker.debian.org/news/1773909/accepted-glibc-241-12deb13u4-source-into-proposed-updates/', 'web_reference': 'turn296821242view2', 'outcome': 'retrieved official exact source acceptance notice', 'supports': 'Exact source version, descriptor SHA/length, Debian patch SHA/length; source architecture only'},
    {'id': 'S3', 'url': pool + 'glibc_2.41-12+deb13u4.dsc', 'web_reference': 'turn761065160view1', 'web_outcome': 'unsupported MIME', 'subsequent_outcome': 'ordinary HTTPS HTTP200; hash equals S2', 'artifact': binding(download_files[0])},
    {'id': 'S4', 'url': pool + 'glibc_2.41.orig.tar.xz', 'outcome': 'ordinary HTTPS HTTP200; hash/length equals pre-read S3 pin', 'artifact': binding(download_files[1])},
    {'id': 'S5', 'url': pool + 'glibc_2.41-12+deb13u4.debian.tar.xz', 'outcome': 'ordinary HTTPS HTTP200; hash/length equals S3 pin and S2 notice', 'artifact': binding(download_files[2])},
    {'id': 'S6', 'url': 'https://sources.debian.org/src/glibc/2.41-12%2Bdeb13u4/', 'web_reference': 'turn296821242view3', 'outcome': 'exact source directory retrieved; attempted individual source-file fetches failed in web tool'},
    {'id': 'S7', 'url': pool, 'web_reference': 'turn199405291search1', 'outcome': 'official pool listing returned exact u4 package name; rounded listing size not used as a digest binding'},
    {'id': 'S8', 'url': 'https://packages.debian.org/trixie/amd64/libc6/download', 'web_reference': 'turn199405291view0', 'outcome': 'page had advanced to deb13u5; all u5 values excluded from u4 proof'}
]
write('SOURCES.json', {'schema': 'ontokin.c271.p15-source-provenance-sources/1', 'frozen_at_utc': NOW, 'primary_sources_only': True, 'sources': sources, 'all_raw_requests_and_retrieval_failures': [str(BASE / name) for name in raw_names], 'trust_boundary': 'Official HTTPS plus published checksum and package control declarations. No local OpenPGP validation, binary buildinfo attestation, or reproduced build.'})

external = [
    ('p15-session/PHASE.json', 'full phase input read'),
    ('p15-session/EARLY-RECOVERY-RECEIPT.json', 'full receipt read'),
    ('OntoKin/docs/engineering/localized-repair-c271/review-boundary-p13/ADOPTION.json', 'full read'),
    ('OntoKin/docs/engineering/localized-repair-c271/review-boundary-p13/design/candidate001/DECISION.md', 'full read; section 3 is the governing independent review boundary'),
    ('OntoKin/docs/engineering/localized-repair-c271/loader-path-p11/design/candidate004/DECISION.md', 'full read; actual-loader source completeness and direct invocation requirements'),
    ('p15-session/host-evidence-attempt002/IDENTITY.json', 'full read; parent-owned inert identity evidence'),
    ('p15-session/host-evidence-attempt002/MANIFEST.json', 'full read; parent-owned captured-byte bindings'),
    ('p15-session/LOADER-PROVENANCE-OBSERVATIONS.json', 'full read; strings and local provenance absence observations'),
    ('p15-session/package-retrieval/RESULT.json', 'full read; parent-owned exact official download'),
    ('p15-session/package-inspection/RESULT.json', 'full read; parent-owned inert package-member equality and control metadata'),
    ('p15-session/state-review/READSET.json', 'unchanged prior full governing-instruction/historical readset, reused without rereading global instructions')
]
external_rows = []
for relative, mode in external:
    row = binding(ROOT / relative)
    row['inspection_mode'] = mode
    external_rows.append(row)

full = {
    'upstream/elf/dl-hwcaps.c', 'upstream/elf/dl-hwcaps.h', 'upstream/elf/dl-hwcaps_split.c',
    'upstream/elf/dl-main.h', 'upstream/elf/dl-hwcaps-subdirs.c',
    'upstream/sysdeps/x86_64/dl-hwcaps-subdirs.c', 'upstream/sysdeps/x86/get-isa-level.h',
    'upstream/sysdeps/x86/dl-tunables.list', 'upstream/elf/dl-tunables.list',
    'upstream/sysdeps/x86_64/Implies', 'upstream/sysdeps/unix/sysv/linux/x86_64/Implies',
    'debian/patches/series', 'debian/patches/arm/unsubmitted-ldso-multilib.diff',
    'debian/patches/any/unsubmitted-ldso-machine-mismatch.diff', 'debian/patches/any/local-ld-multiarch.diff',
    'debian/rules', 'debian/sysdeps/amd64.mk', 'debian/sysdeps/linux.mk', 'debian/rules.d/build.mk',
    'git-updates-suffix-context.diff'
}
selected = {
    'upstream/elf/dl-load.c': {'ranges': [[92,114],[675,750],[1730,1907],[1965,2118]], 'additional': 'capstr/open_path references searched across the complete retained file'},
    'upstream/elf/rtld.c': {'ranges': [[291,307],[1303,1610],[1628,1695],[2480,2730]], 'additional': 'all prepend/mask/state/initialization references searched across the complete retained file'},
    'debian/patches/git-updates.diff': {'selected_hunks_file': str(INSPECT / 'git-updates-suffix-context.diff'), 'additional': 'All patch bytes machine-scanned; selected complete hunks manually read. No claim of manual reading of unrelated hunks.'}
}
source_rows = []
for path in sorted(INSPECT.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(INSPECT).as_posix()
    row = binding(path)
    if relative in full:
        row['inspection_mode'] = 'full manual text read'
    elif relative in selected:
        row['inspection_mode'] = 'selected ranges/hunks plus recorded symbol searches'
        row['inspection_detail'] = selected[relative]
    elif path.suffix == '.json':
        row['inspection_mode'] = 'generated evidence index/scan record; generated results inspected, not a claim of manual reading of every listed source body'
    else:
        row['inspection_mode'] = 'retained exact source/build context; searched or selectively consulted only; not claimed fully manually read'
    source_rows.append(row)
write('READSET.json', {
    'schema': 'ontokin.c271.p15-provenance-readset/1', 'worker': '/root/state_reconciliation', 'frozen_at_utc': NOW,
    'scope': 'This bounded source-provenance assignment; prior startup full reads remain in the unchanged prior readset.',
    'external_inputs': external_rows,
    'source_artifacts': [{'inspection_mode': 'Descriptor fully read; archive bytes hash-verified and selected regular members inspected; not a full manual read of archive content', **binding(p)} for p in download_files],
    'source_text_and_scan_records': source_rows,
    'raw_web_evidence': raw,
    'truncation_handling': 'Truncated intermediate outputs were not counted as full reads. Required selected git-updates hunks, rules, constructor/splitter/architecture code, direct-invocation branch, environment handlers, and load loop were read in bounded complete outputs.'
})

write('AUDIT.json', {
    'schema': 'ontokin.c271.p15-source-provenance-audit/1', 'worker': '/root/state_reconciliation', 'frozen_at_utc': NOW,
    'phase': 'C271-P15-H0-loader-source-and-plan-review',
    'status': 'finite investigation complete; exact frozen candidate submitted for independent decision',
    'report': binding(BASE / 'REPORT.md'),
    'observed_binding': 'Captured actual loader equals the exact official Debian libc6 2.41-12+deb13u4 amd64 package member according to root inspection; control declares glibc source. Exact descriptor/source/patch archives checksum-verified.',
    'candidate_suffix_union': ['', 'glibc-hwcaps/x86-64-v2', 'glibc-hwcaps/x86-64-v3', 'glibc-hwcaps/x86-64-v4'],
    'candidate_scope': 'Ordinary direct invocation of the selected pinned Python, with the existing profile guards; no explicit ld.so CLI prepend input. This array is report evidence, not an operational variant document or runtime selector.',
    'independent_decision_owner': '/root/loader_review',
    'operational_plan_adopted': False,
    'operational_inventory_created': False,
    'h1_started': False,
    'runtime_installation': False,
    'downloaded_or_target_code_executed': False,
    'git_or_index_modified': False,
    'canonical_or_product_edits': False,
    'library_writes': False,
    'publication': False,
    'nested_agents_spawned': False,
    'allowed_writes_directory': str(BASE),
    'active_operations': [],
    'retrieval_limits': ['Exact build-ID/hash search did not provide a direct indexed match.', 'Web-format and inaccessible-URL failures retained; exact package and source retrieval later succeeded through allowed ordinary HTTPS.', 'Generic current package page was deb13u5 and excluded.'],
    'unestablished_claims': ['Local OpenPGP signature validation', 'Exact amd64 compiler environment or binary buildinfo attestation', 'Reproduced build equality', 'Operational plan/input eligibility', 'Complete dependency closure or directory inventory'],
    'next_action': 'Independent reviewer assesses the report/manifest and decides the P13 source-completeness gate. Root alone proceeds to the next actual H0 prerequisite if authorized; stop before H1.'
})

manifest = {'schema': 'ontokin.c271.p15-source-provenance-final-manifest/1', 'worker': '/root/state_reconciliation', 'frozen_at_utc': NOW, 'scope': 'All regular files under this assigned output directory except this manifest itself; no post-freeze mutations intended.', 'files': []}
for path in sorted(BASE.rglob('*')):
    if path.is_file() and path.name != 'FINAL-MANIFEST.json':
        row = binding(path)
        row['relative_path'] = path.relative_to(BASE).as_posix()
        manifest['files'].append(row)
write('FINAL-MANIFEST.json', manifest)
print(json.dumps({'frozen_at_utc': NOW, 'file_count': len(manifest['files']), 'bindings': [binding(BASE / name) for name in ['REPORT.md', 'RAW-RESPONSES-MANIFEST.json', 'READSET.json', 'AUDIT.json', 'SOURCES.json', 'FINAL-MANIFEST.json']], 'active_operations_after_exit': []}, indent=2))
