from pathlib import Path
import hashlib
import json
import tarfile

BASE = Path('/workspace/scratch/5041e572c132/p15-session/source-provenance')
OUT = BASE / 'source-inspection-attempt001'
ORIG = BASE / 'downloads-attempt001/glibc_2.41.orig.tar.xz'
DEBIAN = BASE / 'downloads-attempt001/glibc_2.41-12+deb13u4.debian.tar.xz'
assert hashlib.sha256(ORIG.read_bytes()).hexdigest() == 'f24aa441021121a79266f0d75242706cab8843a47901fefe74527491807f1998'
assert hashlib.sha256(DEBIAN.read_bytes()).hexdigest() == 'dda4153511bfd543502d18e5bc9323110996fe9c531f14ae3fad6eb17f027c7d'

symbols = ['_dl_important_hwcaps', 'glibc_hwcaps_prepend', 'glibc_hwcaps_mask', '_dl_hwcaps_subdirs']
hits = []
scanned_files = 0
scanned_bytes = 0
with tarfile.open(ORIG, 'r:xz') as archive:
    for member in archive:
        if not member.isfile() or not member.name.endswith(('.c', '.h', '.S', '.s', '.ac')):
            continue
        data = archive.extractfile(member).read()
        scanned_files += 1
        scanned_bytes += len(data)
        if not any(symbol.encode() in data for symbol in symbols):
            continue
        matches = []
        for number, line in enumerate(data.decode('utf-8', errors='replace').splitlines(), 1):
            present = [symbol for symbol in symbols if symbol in line]
            if present:
                matches.append({'line': number, 'text': line, 'symbols': present})
        hits.append({'member': member.name, 'sha256': hashlib.sha256(data).hexdigest(), 'matches': matches})
scan = {'method': 'Complete regular C/header/assembly/configure-ac member byte-stream symbol scan of pinned original archive; not a claim of full manual source reading.', 'symbols': symbols, 'scanned_files': scanned_files, 'scanned_bytes': scanned_bytes, 'hits': hits}
(OUT / 'SYMBOL-REFERENCE-SCAN.json').write_text(json.dumps(scan, indent=2) + '\n')

critical = ['elf/dl-hwcaps.c', 'elf/dl-hwcaps.h', 'elf/dl-hwcaps_split.c', 'elf/dl-main.h', 'sysdeps/x86_64/dl-hwcaps-subdirs.c']
related = critical + ['elf/rtld.c', 'elf/dl-load.c', 'sysdeps/x86/get-isa-level.h']
patch_records = []
with tarfile.open(DEBIAN, 'r:xz') as archive:
    series = archive.extractfile('debian/patches/series').read()
    lines = [line.split() for line in series.decode().splitlines() if line.strip() and not line.lstrip().startswith('#')]
    assert len(lines) == 80
    assert all(len(line) == 1 for line in lines), 'Unexpected series option; must review before p1 interpretation'
    for line in lines:
        name = 'debian/patches/' + line[0]
        data = archive.extractfile(name).read()
        headers = []
        matches = []
        for number, text in enumerate(data.decode('utf-8', errors='replace').splitlines(), 1):
            if text.startswith(('--- ', '+++ ')):
                original = text[4:].split('\t')[0].split(' ')[0]
                normalized = None if original == '/dev/null' else original.split('/', 1)[-1]
                headers.append({'line': number, 'original': original, 'p1_path': normalized})
            found = [symbol for symbol in symbols if symbol in text]
            if found:
                matches.append({'line': number, 'text': text, 'symbols': found})
        paths = sorted({header['p1_path'] for header in headers if header['p1_path'] is not None})
        patch_records.append({'patch': line[0], 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'headers': headers, 'critical_hits': [p for p in paths if p in critical], 'related_hits': [p for p in paths if p in related], 'symbol_matches': matches})
coverage = {'method': 'All active patch bytes scanned; unified diff old/new headers normalized by the first component (-p1). No patch application or build was executed.', 'series_sha256': hashlib.sha256(series).hexdigest(), 'active_count': len(patch_records), 'critical_paths': critical, 'critical_hits': [r['patch'] for r in patch_records if r['critical_hits']], 'patches': patch_records}
(OUT / 'PATCH-COVERAGE-REVIEW.json').write_text(json.dumps(coverage, indent=2) + '\n')
print(json.dumps({'scanned_source_files': scanned_files, 'scanned_source_bytes': scanned_bytes, 'source_hit_members': [r['member'] for r in hits], 'active_patches': len(patch_records), 'critical_patch_hits': coverage['critical_hits'], 'related_patch_hits': [{'patch': r['patch'], 'paths': r['related_hits']} for r in patch_records if r['related_hits']], 'patch_symbol_hits': [{'patch': r['patch'], 'matches': r['symbol_matches']} for r in patch_records if r['symbol_matches']]}, indent=2))
