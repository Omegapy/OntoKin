from pathlib import Path
import tarfile, hashlib, json, re

BASE=Path('/workspace/scratch/5041e572c132/p15-session/source-provenance')
DIR=BASE/'downloads-attempt001'
OUT=BASE/'source-inspection-attempt001'
OUT.mkdir(parents=True,exist_ok=False)
need=[
'elf/dl-hwcaps.c','elf/dl-hwcaps.h','elf/dl-load.c','elf/rtld.c',
'sysdeps/x86_64/dl-hwcaps-subdirs.c','sysdeps/generic/dl-hwcaps-subdirs.c',
'sysdeps/x86_64/Makefile','sysdeps/x86_64/Implies','sysdeps/x86_64/configure.ac',
'sysdeps/unix/sysv/linux/x86_64/Implies','sysdeps/unix/sysv/linux/Makefile',
'elf/dl-tunables.list','sysdeps/x86/dl-tunables.list','sysdeps/generic/ldsodefs.h',
'sysdeps/generic/dl-cache.h','sysdeps/unix/sysv/linux/x86_64/dl-cache.h',
'Makeconfig','elf/Makefile'
]
records=[]
with tarfile.open(DIR/'glibc_2.41.orig.tar.xz','r:xz') as archive:
    members=archive.getmembers()
    names={m.name:m for m in members}
    prefixes=sorted({m.name.split('/')[0] for m in members})
    print(json.dumps({'orig_prefixes':prefixes,'orig_members':len(members)}))
    root=prefixes[0]
    for relative in need:
        name=root+'/'+relative
        member=names.get(name)
        if member is None:
            records.append({'archive':'orig','member':name,'present':False})
            continue
        if not member.isfile():raise ValueError('Selected source is not regular: '+name)
        data=archive.extractfile(member).read()
        dest=OUT/'upstream'/relative
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(data);dest.chmod(0o644)
        records.append({'archive':'orig','member':name,'present':True,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'saved':str(dest)})
with tarfile.open(DIR/'glibc_2.41-12+deb13u4.debian.tar.xz','r:xz') as archive:
    members=archive.getmembers();names={m.name:m for m in members}
    series=archive.extractfile(names['debian/patches/series']).read()
    dest=OUT/'debian/patches/series';dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(series)
    active=[l.split()[0] for l in series.decode().splitlines() if l.strip() and not l.lstrip().startswith('#')]
    patch_index=[]
    for name in active:
        member=names['debian/patches/'+name]
        if not member.isfile():raise ValueError('Active patch not regular')
        data=archive.extractfile(member).read()
        text=data.decode('utf-8',errors='replace')
        touched=[]
        for line in text.splitlines():
            if line.startswith(('--- ','+++ ')):
                p=line[4:].split('\t')[0].split(' ')[0]
                if p.startswith(('a/','b/')):p=p[2:]
                if p!='/dev/null' and p not in touched:touched.append(p)
        relevant=[p for p in touched if p in need or 'hwcap' in p or 'rtld' in p or 'dl-load' in p or p.endswith('dl-cache.h')]
        row={'patch':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'touched_paths':touched,'relevant_paths':relevant}
        if relevant:
            dest=OUT/'debian/patches'/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);dest.chmod(0o644);row['saved']=str(dest)
        patch_index.append(row)
    build_candidates=[m for m in members if m.isfile() and (m.name.startswith('debian/rules') or (m.name.startswith('debian/sysdeps/') and any(s in m.name for s in ['amd64','linux','any']))) ]
    for member in build_candidates:
        data=archive.extractfile(member).read()
        dest=OUT/member.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);dest.chmod(0o644)
        records.append({'archive':'debian','member':member.name,'present':True,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'saved':str(dest)})
    (OUT/'ACTIVE-PATCHES.json').write_text(json.dumps({'series_sha256':hashlib.sha256(series).hexdigest(),'active_count':len(active),'patches':patch_index},indent=2)+'\n')
    print(json.dumps({'debian_members':len(members),'active_patches':len(active),'relevant_patches':[{'patch':p['patch'],'paths':p['relevant_paths']} for p in patch_index if p['relevant_paths']],'build_files':[m.name for m in build_candidates]},indent=2))
(OUT/'SELECTED-SOURCE-MANIFEST.json').write_text(json.dumps({'schema':'ontokin.c271.p15-selected-source-inputs/1','method':'Only selected regular files read from hash-bound tar data; no source scripts run, no archive path extraction','selected':records},indent=2)+'\n')
print(json.dumps({'selected_sources':len(records),'missing':[r['member'] for r in records if not r['present']]}))
