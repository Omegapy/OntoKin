# C271 P15: actual-loader source provenance and suffix rationale

## Scoped result

The captured host loader has an exact byte-for-byte match in the official Debian `libc6` package for `2.41-12+deb13u4`, architecture `amd64`. That package declares source `glibc`. The exact source descriptor and its checksum-bound upstream and Debian patch archives were retrieved and inspected as inert data. This supplies a concrete package/source correspondence and an implementation rationale for the four possible search suffixes below. It does not rely on the loader's embedded version string alone.

This is the Investigator's candidate evidence for the P13 independent-review gate. `/root/loader_review` owns the independent completeness decision. This report neither adopts an operational plan nor asserts that directory inventory, dependency closure, environment guards, or H1 have passed.

Worker: `/root/state_reconciliation`. Phase: `C271-P15-H0-loader-source-and-plan-review`. All worker output is confined to this directory. The previously frozen startup report is unchanged.

## Exact identity and correspondence

| Evidence | Bound value or observation |
| --- | --- |
| Actual resolved loader | `/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2` |
| ELF identity | ELF64, little endian, x86-64; GNU build ID `86f7eb4ff495ed3f2831c6d3d662e4321762a2a3` |
| Loader size and SHA256 | 225,672 bytes; `c8438e4fde1934e61c88311633f00949ff645d5c04cdb8671fa3d78164d2f307` |
| Official binary package | `https://deb.debian.org/debian/pool/main/g/glibc/libc6_2.41-12+deb13u4_amd64.deb` |
| Package size and SHA256 | 2,846,580 bytes; `967aa62605721081c3eb2a17650611a792aa802d76a6511d1840242623d204c9` |
| Matching package member | `./usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2`; root's archive inspection records complete byte equality and original-mtime equality with the captured host loader |
| Package control fields | `Package: libc6`; `Source: glibc`; `Version: 2.41-12+deb13u4`; `Architecture: amd64` |

The actual loader identity comes from `../host-evidence-attempt002/IDENTITY.json` and its inert capture. The package transport record is `../package-retrieval/RESULT.json`; the complete member comparison and control metadata are in `../package-inspection/RESULT.json`. This investigator read those records. Root performed the archive/member comparison; the independent reviewer separately corroborated it. This investigator did not re-execute the loader or duplicate that target test.

The embedded Debian version text and the matching three-name hardware-capability constant at offset 181136 are supporting observations in `../LOADER-PROVENANCE-OBSERVATIONS.json`. Neither observation by itself establishes the source correspondence.

### Official source artifacts

All three URLs use the official pool prefix `https://deb.debian.org/debian/pool/main/g/glibc/`.

| Artifact | Bytes | SHA256 |
| --- | ---: | --- |
| `glibc_2.41-12+deb13u4.dsc` | 7,576 | `0915324aa646bb99abfaa9aa6ecb734b30babd28454a3e51f3152912370fbd3e` |
| `glibc_2.41.orig.tar.xz` | 20,323,540 | `f24aa441021121a79266f0d75242706cab8843a47901fefe74527491807f1998` |
| `glibc_2.41-12+deb13u4.debian.tar.xz` | 499,524 | `dda4153511bfd543502d18e5bc9323110996fe9c531f14ae3fad6eb17f027c7d` |

The descriptor digest and Debian patch-archive digest match Debian's exact source-acceptance notice: `https://tracker.debian.org/news/1773909/accepted-glibc-241-12deb13u4-source-into-proposed-updates/` (web reference `turn296821242view2`). The original-source digest was read from the already-verified descriptor before accepting that archive. `downloads-attempt001/SOURCE-PINS.json` and `DOWNLOADS.json` retain this order, actual checksums, HTTP status, URLs, headers, and times. All responses were HTTP 200 at the exact requested official URLs.

The evidence establishes Debian's declared binary-package-to-source-version association, plus exact retained source and patch bytes. Trust rests on official HTTPS retrieval and published checksums. The descriptor's OpenPGP signature was not locally verified. An exact amd64 binary build log/buildinfo and compiler environment were not obtained; the tracker notice is a source upload, and its source-only buildinfo is not a binary-build attestation. No build was reproduced, and no cryptographic compiler-output proof is claimed. These are explicit evidence limits for the independent reviewer to assess.

## Candidate finite suffix union

For the bound x86-64 loader under the existing profile's ordinary, direct invocation of the selected Python executable, the candidate sorted union is:

1. `""` — the base directory itself.
2. `glibc-hwcaps/x86-64-v2`
3. `glibc-hwcaps/x86-64-v3`
4. `glibc-hwcaps/x86-64-v4`

This is a union over every possible built-in hardware selection. It is not a measurement of which subset is active on the present CPU. The loader's search priority is v4, v3, v2, then base when all three are active; sorted inventory order has a different purpose. The source appends a trailing slash when constructing nonempty search prefixes. The proposed inventory strings represent relative directory names without that separator.

The supporting source files are exact regular-file bytes copied from the checksum-bound archives into `source-inspection-attempt001/`. They were inspected without compiling, installing, or running downloaded code.

### Why the union covers the implementation

1. **The directory-name source is finite.** `upstream/sysdeps/x86_64/dl-hwcaps-subdirs.c`, read in full, contains the three built-in names and a count of three (lines 24–25). Its active-selection function returns a bitmask for those names (lines 28–52). `sysdeps/x86/get-isa-level.h`, also read in full, derives ISA capability bits from CPU features. Such feature selection can select or omit names from the fixed table; it cannot synthesize another directory name.

2. **The complete constructor has only two list inputs and the base entry.** In the fully read `upstream/elf/dl-hwcaps.c`, `_dl_important_hwcaps` counts and copies the optional prepend list and the selected built-in list, then appends one empty-string entry. `copy_hwcaps` forms a prefix from `glibc-hwcaps/`, one list segment, and `/`. The fully read `dl-hwcaps.h` and `dl-hwcaps_split.c` show that masking filters existing list segments; it does not create new names. This constructive argument covers every emitted prefix, rather than relying on the absence of a keyword in a search.

3. **Arbitrary prepend strings require explicit loader invocation.** In `upstream/elf/rtld.c`, both prepend and mask fields initialize to null (lines 293–303). Assignments from `--glibc-hwcaps-prepend` and `--glibc-hwcaps-mask` occur only inside the branch where the loader is itself the program entry point (lines 1329–1590). The complete default and secure environment handlers (lines 2486–2718) do not populate those fields. `upstream/elf/dl-main.h`, read in full, passes these fields directly into `_dl_init_paths`. The existing P11/P13 profile requires direct Python invocation and excludes explicit loader command invocation. That restriction must remain an operational guard: allowing arbitrary loader CLI prepend arguments would invalidate this four-entry union.

4. **The RPATH lookup consumes this one prefix array.** `upstream/elf/dl-load.c` assigns `capstr` from `_dl_important_hwcaps` in `_dl_init_paths` (lines 675–750). The complete `open_path` body (lines 1736–1893) joins each search root, one `capstr` entry, and the requested object name. The RPATH and RUNPATH routes call that same function (inspected lines 1965–2118). There is no second recursive hardware/TLS combination generator in this construction path. Non-SHARED code has only the base-directory case; the bound ELF interpreter is the shared-loader case being reviewed.

5. **Legacy TLS and platform combinations are not additional names here.** The complete constructor, splitter, fixed x86-64 table, and consuming path loop account for all name construction under the stated invocation. They do not add `tls`, legacy platform/capability permutations, or nested combinations. TLS memory-allocation tunables are not directory-list inputs. The generic `elf/dl-hwcaps-subdirs.c` fallback, also read in full, declares an empty built-in list; it does not introduce an omitted default suffix. Other architectures' implementations are inapplicable to the bound amd64 package and x86-64 ELF identity.

6. **Archive-wide symbol and patch checks corroborate the bounded reading.** `SYMBOL-REFERENCE-SCAN.json` records a complete scan of 16,560 regular C/header/assembly/configure-ac source members (66,999,661 bytes) for the constructor, subdirectory table, and prepend/mask symbols. It found no other constructor or assignment path that supplies additional direct-invocation names. This was an automated symbol scan, not a claim that every source file was manually read. `PATCH-COVERAGE-REVIEW.json` records all 80 active Debian patches and normalized old/new file headers. None touches the core constructor, header, splitter, state header, or x86-64 subdirectory table; none adds the scanned suffix-construction symbols.

## Debian patch and build review

The complete active series and patch hashes are retained. The relevant modifications were read as source text:

| Input | Effect relevant to this review |
| --- | --- |
| `git-updates.diff` selected complete hunks for `dl-load.c`, `rtld.c`, `Makeconfig`, `dl-tunables.list`, and `ldsodefs.h` | Debug-state changes, executable-stack handling, program-header setup, and a build-time rpath-link addition. They do not alter the suffix constructor, its CLI assignments, or the `open_path` prefix loop. The exact selected hunks are retained in `git-updates-suffix-context.diff`. |
| `arm/unsubmitted-ldso-multilib.diff` | ARM-specific ABI rejection in object validation; no new suffix generator. |
| `any/unsubmitted-ldso-machine-mismatch.diff` | Object-machine validation/fallback handling; no new suffix generator. |
| `any/local-ld-multiarch.diff` | Adds default library roots and adjusts `$LIB` generation. It does not add suffix names. |
| `debian/rules`, `debian/sysdeps/linux.mk`, `debian/sysdeps/amd64.mk`, `debian/rules.d/build.mk` | Declare the libc/amd64 build pass, per-architecture source selection, `--enable-multi-arch`, library/loader installation directories, and the Debian package-version configure string. The i386 and x32 passes are separate. These are the exact published build recipe, not a recovered invocation log. |

Default roots and `/etc/ld.so.cache` are separate lookup routes. They still require their existing declared-plan, inventory, and closure checks. A complete suffix union for the selected `$ORIGIN/../lib` root does not approve default roots, cache entries, any library member, or a successful launch. The existing profile also retains its audit/preload/environment and direct-invocation constraints; this source review does not waive them.

## Retrieval limits and preserved failures

The four original web request/result snapshots remain unchanged. Exact hash/build-ID web searches did not yield a direct indexed match. The Debian debuginfod and snapshot queries, raw source-file URLs, and the attempted exact buildinfo URL failed in that tool. The web tool rejected the exact `.deb` and `.dsc` MIME formats. Those outcomes describe the web tool's retrieval limits; they did not establish that the files were globally unavailable. Root's authorized ordinary HTTPS package download and this worker's ordinary HTTPS source downloads subsequently succeeded.

The generic Debian package-download page had advanced to `deb13u5`. Its size/checksum was explicitly excluded from the `deb13u4` binding. No alternative loader, runtime, source version, installation, or network bypass was used.

## Handoff and retained evidence

The next action is independent assessment of this exact report and manifest by `/root/loader_review`, followed by root's next actual H0 prerequisite only if that decision permits it. No worker operation is active. No further provenance research is pending from this investigator.

`READSET.json` distinguishes full manual reads, selected ranges/hunks, retained-only inputs, and automated complete scans. `SOURCES.json` maps official URLs and web references. `RAW-RESPONSES-MANIFEST.json` binds the exact saved web request/result snapshots and source-response bodies. `AUDIT.json` records scope and evidence limits. `FINAL-MANIFEST.json` binds all files in this output directory except itself. Global instructions and the frozen startup readset remain separately preserved under `../state-review/`.
