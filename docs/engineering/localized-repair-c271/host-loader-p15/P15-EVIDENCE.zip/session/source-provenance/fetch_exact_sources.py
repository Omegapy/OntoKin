from pathlib import Path
import datetime
import hashlib
import json
import urllib.request

BASE = Path('/workspace/scratch/5041e572c132/p15-session/source-provenance')
OUT = BASE / 'downloads-attempt001'
OUT.mkdir(parents=True, exist_ok=False)
ROOT = 'https://deb.debian.org/debian/pool/main/g/glibc/'
records = []

def retrieve(name, expected_size, expected_sha256):
    record = {'url': ROOT + name, 'name': name, 'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'expected_bytes': expected_size, 'expected_sha256': expected_sha256, 'target_execution': False}
    records.append(record)
    try:
        with urllib.request.urlopen(record['url'], timeout=25) as response:
            record['http_status'] = response.status
            record['response_url'] = response.geturl()
            record['headers'] = dict(response.headers)
            data = response.read(expected_size + 1)
        record['bytes'] = len(data)
        record['sha256'] = hashlib.sha256(data).hexdigest()
        record['matches_expected_bytes'] = len(data) == expected_size
        record['matches_expected_sha256'] = record['sha256'] == expected_sha256
        path = OUT / name
        path.write_bytes(data)
        path.chmod(0o644)
        record['local_path'] = str(path)
        if not record['matches_expected_bytes'] or not record['matches_expected_sha256']:
            raise ValueError('Downloaded source artifact does not match the predeclared descriptor')
        record['outcome'] = 'retrieved_inert_and_exact_digest_verified'
        return data
    except Exception as exc:
        record['outcome'] = 'failed'
        record['error'] = repr(exc)
        raise
    finally:
        record['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        (OUT / 'DOWNLOADS.json').write_text(json.dumps({'schema':'ontokin.c271.p15-source-downloads/1', 'worker':'/root/state_reconciliation', 'transport':'ordinary HTTPS urllib; no escalation, installation, execution or proxy change', 'signature_verification':'not performed; HTTPS source record and published checksums only', 'records':records}, indent=2) + '\n')

dsc = retrieve('glibc_2.41-12+deb13u4.dsc', 7576, '0915324aa646bb99abfaa9aa6ecb734b30babd28454a3e51f3152912370fbd3e')
lines = dsc.decode('utf-8').splitlines()
index = lines.index('Checksums-Sha256:') + 1
pins = {}
while index < len(lines) and lines[index].startswith(' '):
    digest, size, filename = lines[index].split()
    pins[filename] = {'sha256':digest, 'bytes':int(size)}
    index += 1
selected = ['glibc_2.41.orig.tar.xz', 'glibc_2.41-12+deb13u4.debian.tar.xz']
(OUT / 'SOURCE-PINS.json').write_text(json.dumps({'schema':'ontokin.c271.p15-source-pins/1', 'descriptor_sha256':hashlib.sha256(dsc).hexdigest(), 'selected':{name:pins[name] for name in selected}}, indent=2) + '\n')
for name in selected:
    retrieve(name, pins[name]['bytes'], pins[name]['sha256'])
print(json.dumps({'outcome':'passed', 'records':[{'name':r['name'], 'bytes':r['bytes'], 'sha256':r['sha256']} for r in records]}, indent=2))
