#!/usr/bin/env python3
"""Preserve scoped raw evidence as inert data with exact external-object records."""
from pathlib import Path, PurePosixPath
import datetime, hashlib, json, stat, zipfile

ROOT=Path('/workspace/scratch/5041e572c132'); SESSION=ROOT/'p15-session'
OUT=ROOT/'OntoKin/docs/engineering/localized-repair-c271/host-loader-p15'
DEST=OUT/'P15-EVIDENCE.zip'
assert not DEST.exists(), 'Immutable evidence bundle already exists'
def enc(x):return (json.dumps(x,indent=2,sort_keys=True)+'\n').encode()
def sha(x):return hashlib.sha256(x).hexdigest()
derived=['receipt-review/scratch/early-extraction/','receipt-review/scratch/early-attempt002-extraction/',
         'receipt-review/scratch/post-freeze/','receipt-review/scratch/publication-evidence/']
external_paths={
    'source-provenance/downloads-attempt001/glibc_2.41.orig.tar.xz':{
        'url':'https://deb.debian.org/debian/pool/main/g/glibc/glibc_2.41.orig.tar.xz',
        'reason':'Exact20323540-byte public source archive retained in full in the final recovery ZIP; avoid known GitHub connector request limit.'},
    'early-history/attempt001/OntoKin_C271_P15_H0_Review_Early_Recovery_2026-11-21.zip':{
        'reason':'Original failed early attempt retained once in the final recovery ZIP and within the confirmed early Attempt002 archive.'},
}
payloads={}; records=[]; external=[]
for base,prefix in [(SESSION,'session'),(ROOT/'reconciliation','reconciliation')]:
    for p in sorted(base.rglob('*')):
        if not p.is_file() or p.is_symlink():continue
        rel=p.relative_to(base).as_posix()
        if base==SESSION and (any(rel.startswith(x) for x in derived) or rel.startswith(('verification/','publication/','final-package-review/'))):continue
        if '__pycache__' in p.parts or p.suffix=='.pyc':continue
        data=p.read_bytes(); record={'member':prefix+'/'+rel,'bytes':len(data),'sha256':sha(data),'original_mode':oct(stat.S_IMODE(p.stat().st_mode))}
        if base==SESSION and rel in external_paths:
            external.append({**record,**external_paths[rel],'recovery_member':'recovery/session/'+rel});continue
        payloads[record['member']]=data;records.append(record)
payloads['EXTERNAL-OBJECTS.json']=enc(external)
records.append({'member':'EXTERNAL-OBJECTS.json','bytes':len(payloads['EXTERNAL-OBJECTS.json']),'sha256':sha(payloads['EXTERNAL-OBJECTS.json']),'original_mode':'0o644'})
manifest={'schema':'ontokin.c271.p15-evidence-bundle/1','created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source_revision':'875c81c506d4e5431b909e190ce294c61312029e','payloads':records,
          'inert_transport_mode':'0644','external_object_count':len(external),
          'scope':'Detailed technical/startup evidence at the technical stop; later documentary, publication and delivery records are separate.'}
payloads['MANIFEST.json']=enc(manifest)
with zipfile.ZipFile(DEST,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,data in sorted(payloads.items()):
        pp=PurePosixPath(name);assert not pp.is_absolute() and '..' not in pp.parts
        info=zipfile.ZipInfo(name,(2026,11,21,0,0,0));info.create_system=3;info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,data)
with zipfile.ZipFile(DEST) as z:
    assert z.testzip() is None and set(z.namelist())==set(payloads)
    for item in records:
        data=z.read(item['member']);assert len(data)==item['bytes'] and sha(data)==item['sha256']
data=DEST.read_bytes();receipt={'schema':'ontokin.c271.p15-evidence-descriptor/1','file':DEST.name,'bytes':len(data),'sha256':sha(data),'members':len(payloads),'manifest_payloads':len(records),'crc_and_all_payload_hashes_verified':True,'external_objects':external,'source_revision':manifest['source_revision']}
(OUT/'P15-EVIDENCE.json').write_bytes(enc(receipt))
(SESSION/'EVIDENCE-BUNDLE-VERIFICATION.json').write_bytes(enc(receipt))
print(json.dumps({k:v for k,v in receipt.items() if k!='external_objects'}))
