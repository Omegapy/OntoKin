#!/usr/bin/env python3
"""One bounded ordinary HTTPS retrieval; retained package is inert data only."""
from pathlib import Path
import datetime, hashlib, json, time, urllib.request

out=Path('/workspace/scratch/5041e572c132/p15-session/package-retrieval')
out.mkdir(exist_ok=False)
url='https://deb.debian.org/debian/pool/main/g/glibc/libc6_2.41-12+deb13u4_amd64.deb'
record={'url':url,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'method':'Ordinary HTTPS via the default environment networking; no escalation, bypass or alternative host.',
        'timeout_seconds':20,'maximum_bytes':8*1024*1024,'retry_count':0,'executable_started':False}
partial=out/'package.deb.inert.partial'
started=time.monotonic()
try:
    with urllib.request.urlopen(url,timeout=20) as response, partial.open('xb') as target:
        record.update({'status':response.status,'final_url':response.url,
                       'response_headers':{k:response.headers.get(k) for k in ['Content-Length','Content-Type','Last-Modified','ETag']}})
        total=0
        while True:
            if time.monotonic()-started>25:raise TimeoutError('25-second total retrieval bound reached')
            chunk=response.read(65536)
            if not chunk:break
            total+=len(chunk)
            if total>record['maximum_bytes']:raise ValueError('8 MiB inert download bound exceeded')
            target.write(chunk)
    data=partial.read_bytes()
    assert data.startswith(b'!<arch>\n'), 'Expected Debian ar package bytes'
    dest=out/'libc6_2.41-12+deb13u4_amd64.deb.inert'
    partial.rename(dest);dest.chmod(0o644)
    record.update({'outcome':'downloaded_inert_package','file':str(dest),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
except Exception as exc:
    record.update({'outcome':'retrieval_failed','error_type':type(exc).__name__,'error':str(exc),
                   'partial_bytes':partial.stat().st_size if partial.exists() else 0})
record['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
