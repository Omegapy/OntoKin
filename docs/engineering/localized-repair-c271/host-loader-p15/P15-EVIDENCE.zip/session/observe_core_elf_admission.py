#!/usr/bin/env python3
"""Observe unchanged static-reader admission; stop at the first concrete refusal."""
from pathlib import Path
import datetime, hashlib, importlib.util, json, os, stat, struct, time

SESSION=Path('/workspace/scratch/5041e572c132/p15-session')
REPO=Path('/workspace/scratch/5041e572c132/OntoKin')
OUT=SESSION/'h0-static-admission-attempt001'
OUT.mkdir(exist_ok=False)
acceptance=json.loads((SESSION/'SOURCE-COMPLETENESS-ACCEPTANCE.json').read_text())
assert acceptance['accepted'] is True
source=REPO/'prototypes/static_tray_v01/current_host_inspection_v01.py'
source_hash=hashlib.sha256(source.read_bytes()).hexdigest()
assert source_hash=='a8274d56076562a91d26b3cdd2f614fce6fd509733e4939b225dff2ddca09db4'
started=time.monotonic()
def check():
    if time.monotonic()-started>60:raise TimeoutError('Existing 60-second static bound reached')

def raw_dynamic(data):
    assert data[:6]==b'\x7fELF\x02\x01'
    h=struct.unpack_from('<HHIQQQIHHHHHH',data,16)
    assert h[8]==56 and h[9]<=1024
    rows=[]
    for i in range(h[9]):
        p=struct.unpack_from('<IIQQQQQQ',data,h[4]+i*h[8])
        if p[0]==2:
            assert p[5]<=65536 and p[5]%16==0 and p[2]+p[5]<=len(data)
            for off in range(p[2],p[2]+p[5],16):
                tag,value=struct.unpack_from('<qQ',data,off)
                rows.append({'offset':off,'tag':tag,'value':value,'value_hex':hex(value)})
                if tag==0:break
    return rows

maps=[]
for line in Path('/proc/self/maps').read_text().splitlines():
    fields=line.split(maxsplit=5)
    if len(fields)==6 and fields[5].startswith('/'):
        maps.append(fields[5])
libcs=sorted(set(p for p in maps if Path(p).name=='libc.so.6'))
assert len(libcs)==1, 'Actual current Python libc path is not unambiguous'
loader=json.loads((SESSION/'host-evidence-attempt002/IDENTITY.json').read_text())['loader']['resolved_path']
inputs=[('bound-loader',loader),('current-python-loaded-libc',libcs[0])]
intent={'schema':'ontokin.c271.p15-static-admission-intent/1','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_revision':'875c81c506d4e5431b909e190ce294c61312029e','source_sha256':source_hash,
        'source_completeness_acceptance_sha256':hashlib.sha256((SESSION/'SOURCE-COMPLETENESS-ACCEPTANCE.json').read_bytes()).hexdigest(),
        'inputs':inputs,'method':'Read actual files and invoke unchanged public read_elf_metadata; no image execution. Stop on first HostInspectionError or other exception.',
        'scope':'Actual static input-admission observations, not a unit-test cohort or H0 plan acceptance',
        'target_starts_expected':0,'expected_pass_claim':False}
(OUT/'INTENT.json').write_text(json.dumps(intent,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('p15_unchanged_static_inspector',source)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
results=[]
for role,name in inputs:
    check();p=Path(name);before=p.stat();data=p.read_bytes();after=p.stat()
    assert (before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
    captured=OUT/(role+'.elf.inert');captured.write_bytes(data);captured.chmod(0o644)
    raw=raw_dynamic(data)
    record={'role':role,'path':name,'canonical_path':str(p.resolve()),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
            'mode':oct(stat.S_IMODE(before.st_mode)),'device':before.st_dev,'inode':before.st_ino,'raw_dynamic':raw,
            'raw_DT_FLAGS':[x['value'] for x in raw if x['tag']==30],
            'raw_DT_FLAGS_1':[x['value'] for x in raw if x['tag']==0x6ffffffb]}
    try:
        record['metadata']=module.read_elf_metadata(p,check=check,require_interpreter=False)
        record['outcome']='metadata_returned'
    except module.HostInspectionError as exc:
        record.update({'outcome':'typed_refusal','refusal':exc.as_dict()})
    except Exception as exc:
        record.update({'outcome':'unexpected_exception','exception':{'type':type(exc).__name__,'message':str(exc)}})
    results.append(record)
    (OUT/(role+'-RESULT.json')).write_text(json.dumps(record,indent=2)+'\n')
    if record['outcome']!='metadata_returned':break
result={'schema':'ontokin.c271.p15-static-admission-outcome/1','recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_sha256':source_hash,'elapsed_seconds':time.monotonic()-started,'observations':results,
        'stopped_at_first_refusal':results[-1]['outcome']!='metadata_returned','remaining_input_checks':'not_run',
        'python_tool_process_ran':True,'production_module_imported_and_data_reader_called':True,
        'Node_starts':0,'ldd_starts':0,'direct_loader_starts':0,'installation':False,'H0_accepted':False,'H1_approved':False}
(OUT/'OUTCOME.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'results':[{'role':x['role'],'outcome':x['outcome'],'sha256':x['sha256'],'raw_DT_FLAGS':x['raw_DT_FLAGS'],'refusal':x.get('refusal')} for x in results],
                  'stopped_at_first_refusal':result['stopped_at_first_refusal'],'elapsed_seconds':result['elapsed_seconds']},indent=2))
