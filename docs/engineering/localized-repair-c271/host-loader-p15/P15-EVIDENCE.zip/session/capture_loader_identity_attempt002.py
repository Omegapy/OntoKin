#!/usr/bin/env python3
"""Read inert ELF identity and available local provenance; execute no inspected file."""
from pathlib import Path
import datetime, hashlib, json, os, stat, struct, sys

OUT = Path('/workspace/scratch/5041e572c132/p15-session/host-evidence-attempt002')
OUT.mkdir(exist_ok=False)

def digest(data, alg='sha256'):
    return hashlib.new(alg, data).hexdigest()

def identity(path):
    st = os.stat(path)
    return {'device':st.st_dev,'inode':st.st_ino,'mode':oct(stat.S_IMODE(st.st_mode)),
            'nlink':st.st_nlink,'bytes':st.st_size,'mtime_ns':st.st_mtime_ns,'ctime_ns':st.st_ctime_ns}

def inert_read(path):
    before = identity(path)
    assert stat.S_ISREG(os.stat(path).st_mode) and before['bytes'] <= 128 * 1024 * 1024
    data = Path(path).read_bytes()
    after = identity(path)
    assert before == after and len(data) == before['bytes']
    return data, {'named_path':str(path),'resolved_path':str(Path(path).resolve()),**before,
                  'sha256':digest(data),'md5':digest(data,'md5'),'unchanged_during_read':True}

def path_chain(path):
    result=[]
    p=Path(path)
    for item in [*reversed(p.parents),p]:
        st=item.lstat()
        result.append({'path':str(item),'mode':oct(stat.S_IMODE(st.st_mode)),
                       'kind':'symlink' if stat.S_ISLNK(st.st_mode) else 'directory' if stat.S_ISDIR(st.st_mode) else 'file',
                       'target':os.readlink(item) if stat.S_ISLNK(st.st_mode) else None,
                       'device':st.st_dev,'inode':st.st_ino})
    return result

def elf(data):
    assert data[:6] == b'\x7fELF\x02\x01'
    fields=struct.unpack_from('<HHIQQQIHHHHHH',data,16)
    phoff, phsize, phnum=fields[4],fields[8],fields[9]
    assert phsize==56 and phnum<=1024 and phoff+phsize*phnum<=len(data)
    ph=[];interp=[];notes=[]
    for i in range(phnum):
        typ,flags,offset,vaddr,paddr,filesz,memsz,align=struct.unpack_from('<IIQQQQQQ',data,phoff+i*phsize)
        assert offset+filesz<=len(data)
        ph.append({'type':typ,'flags':flags,'offset':offset,'virtual_address':vaddr,'file_size':filesz,'memory_size':memsz})
        if typ==3:
            value=data[offset:offset+filesz];assert value.endswith(b'\0');interp.append(value[:-1].decode('ascii'))
        if typ==4:
            end=offset+filesz;cursor=offset
            while cursor+12<=end:
                namesz,descsz,ntype=struct.unpack_from('<III',data,cursor);cursor+=12
                assert cursor+namesz<=end
                name=data[cursor:cursor+namesz].rstrip(b'\0');cursor=(cursor+namesz+3)&~3
                assert cursor+descsz<=end
                desc=data[cursor:cursor+descsz];cursor=(cursor+descsz+3)&~3
                notes.append({'name':name.decode('ascii','backslashreplace'),'type':ntype,'descriptor_hex':desc.hex()})
    return {'elf_class':64,'endianness':'little','machine':fields[1],'interpreter':interp,'program_headers':ph,
            'notes':notes,'gnu_build_ids':[x['descriptor_hex'] for x in notes if x['name']=='GNU' and x['type']==3]}

named=sys.executable
python_data,python_id=inert_read(named)
python_meta=elf(python_data)
assert len(python_meta['interpreter'])==1
loader_named=python_meta['interpreter'][0]
loader_data,loader_id=inert_read(loader_named)
loader_meta=elf(loader_data)
(OUT/'loader.elf.inert').write_bytes(loader_data)
(OUT/'loader.elf.inert').chmod(0o644)
pin={'sha256':'fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7','bytes':30894944,'mode':'0o755'}
proc_exe=os.readlink('/proc/self/exe')
status_path=Path('/var/lib/dpkg/status')
raw_status=status_path.read_text() if status_path.is_file() else ''
packages=[]
for block in raw_status.split('\n\n'):
    lines=block.splitlines()
    fields={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in lines if ':' in line and not line.startswith(' ')}
    if fields.get('Package') in {'libc6','libc-bin','libc6-dev','libc-dev-bin','libc6-dbg'}:
        packages.append(fields)
(OUT/'dpkg-selected-status.txt').write_text('\n\n'.join(block for block in raw_status.split('\n\n') if any(block.startswith('Package: '+n+'\n') for n in ['libc6','libc-bin','libc6-dev','libc-dev-bin','libc6-dbg']))+'\n')
copied=[]
for src in ['/etc/os-release','/var/lib/dpkg/info/libc6:amd64.md5sums','/usr/share/doc/libc6/changelog.Debian.gz','/usr/share/doc/libc6/copyright']:
    path=Path(src)
    if path.is_file():
        data=path.read_bytes();dest=OUT/(src.strip('/').replace('/','__'));dest.write_bytes(data);dest.chmod(0o644)
        copied.append({'source':src,'member':dest.name,'bytes':len(data),'sha256':digest(data)})
maps=[line for line in Path('/proc/self/maps').read_text().splitlines() if loader_id['resolved_path'] in line or loader_named in line]
record={'schema':'ontokin.c271.p15-inert-loader-identity/1','observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'collector':str(Path(__file__).resolve()),'collector_sha256':digest(Path(__file__).read_bytes()),
        'python':python_id,'python_elf':python_meta,'selected_python_pin':pin,
        'selected_python_pin_matches':all(python_id[k]==v for k,v in pin.items()),'python_path_chain':path_chain(named),
        'canonical_python_path_chain':path_chain(python_id['resolved_path']),'proc_self_exe':proc_exe,
        'proc_self_exe_matches_canonical_python':proc_exe==python_id['resolved_path'],
        'loader':loader_id,'loader_elf':loader_meta,'loader_path_chain':path_chain(loader_named),
        'canonical_loader_path_chain':path_chain(loader_id['resolved_path']),'current_process_loader_map_lines':maps,
        'package_database_observation':{'path':'/var/lib/dpkg/status','present':status_path.is_file()},'installed_package_claims':packages,'retained_metadata':copied,
        'claims_boundary':'Local file/package observations only; package metadata alone is not authenticated binary-to-source or suffix-completeness proof.',
        'target_executions':[],'product_imports':[],'operational_plan_created':False}
(OUT/'IDENTITY.json').write_text(json.dumps(record,indent=2)+'\n')
manifest={p.name:{'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())} for p in sorted(OUT.iterdir()) if p.is_file()}
(OUT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'selected_python_pin_matches':record['selected_python_pin_matches'],'python':python_id,'loader':loader_id,
                  'loader_build_ids':loader_meta['gnu_build_ids'],'package_versions':[(x['Package'],x.get('Version'),x.get('Source')) for x in packages],
                  'manifest':str(OUT/'MANIFEST.json'),'inspected_targets_executed':0},indent=2))
