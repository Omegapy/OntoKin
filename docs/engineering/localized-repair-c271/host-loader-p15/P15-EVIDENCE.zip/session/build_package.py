#!/usr/bin/env python3
"""Freeze a scoped online handoff without executing any enclosed payload."""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, stat, subprocess, zipfile

ROOT = Path('/workspace/scratch/5041e572c132')
REPO = ROOT / 'OntoKin'
SESSION = ROOT / 'p15-session'
P14_ID = 'libfile_fde3_f-44039f6b44e48191b554a512fbee6920_2ab2a24d43748191957f9bcc356b59de'
P14_URL = 'https://chatgpt.com/library?file_id=' + P14_ID + '&account_id=personal'

def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--kind', choices=['early', 'final'], required=True)
    parser.add_argument('--revision', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    dest = Path(args.output)
    assert not dest.exists(), 'Never overwrite a frozen package'
    dest.parent.mkdir(parents=True, exist_ok=True)
    phase = json.loads((SESSION / 'PHASE.json').read_text())
    if args.kind == 'final':
        assert (SESSION / 'HANDOFF.md').is_file(), 'Final mode requires an outcome-specific handoff'
        assert phase['status'] not in {'startup_early_recovery_pending','source_completeness_review_in_progress'}, 'Final mode requires a resolved phase outcome'
    phase['package_type'] = 'browser-session handoff for online GitHub continuation'
    phase['package_kind'] = args.kind
    phase['source_revision'] = args.revision
    phase['source_tree'] = git('rev-parse', args.revision + '^{tree}').decode().strip()
    phase['delivery']['status'] = 'save_pending_at_freeze'
    phase['source_snapshot_timing'] = 'Later external receipt and terminal confirmation reconcile publication/save fields without modifying this ZIP.'
    payloads = {}
    sources = []
    exclusions = []
    def put(name, data):
        p = PurePosixPath(name)
        assert name and not p.is_absolute() and '..' not in p.parts and '\\' not in name
        assert name not in payloads
        payloads[name] = data
    source_paths = [
        'CHATGPT-START-HERE.md','AGENTS.md','GOAL.md','STATUS.md','ROLE.md',
        'docs/workflow/registry.json','docs/workflow/CURRENT.json','docs/workflow/PROTOCOL.md',
        'docs/workflow/HANDOFF.md','docs/workflow/BROWSER-PROMPTS.md',
        'docs/workflow/prompts/CONTINUE.md','docs/workflow/prompts/RECOVER.md',
        '.agents/skills/ontokin-session/SKILL.md','.agents/skills/ontokin-delivery/SKILL.md',
        '.agents/skills/ontokin-learning/SKILL.md',
        'docs/engineering/OK-ENG-006-local-validation-and-hosted-ci-policy.md',
        'docs/engineering/OK-ENG-009-development-integration-and-branch-lifecycle.md',
        'docs/engineering/localized-repair-c271/current-host-p05/CONTRACT.md',
        'docs/engineering/localized-repair-c271/current-host-p05/CONTRACT.json',
        'docs/engineering/localized-repair-c271/current-host-p05/ADOPTION.json',
        'docs/engineering/localized-repair-c271/host-inspection-p07/HOST-INSPECTION-DESIGN.md',
        'docs/engineering/localized-repair-c271/host-inspection-p07/QUALIFICATION-PLAN.md',
        'docs/engineering/localized-repair-c271/host-inspection-p07/ADOPTION.json',
        'docs/engineering/localized-repair-c271/loader-path-p11/design/candidate004/DECISION.md',
        'docs/engineering/localized-repair-c271/loader-path-p11/design/candidate004/CONTROL-CONTRACT.md',
        'docs/engineering/localized-repair-c271/loader-path-p11/design/candidate004/FUTURE-SURFACE.json',
        'docs/engineering/localized-repair-c271/loader-path-p11/ADOPTION.json',
        'docs/engineering/localized-repair-c271/review-boundary-p13/ADOPTION.json',
        'docs/engineering/localized-repair-c271/review-boundary-p13/design/candidate001/DECISION.md',
        'docs/engineering/localized-repair-c271/review-boundary-p13/design/candidate001/CONTROL-CONTRACT.md',
        'docs/engineering/localized-repair-c271/loader-path-p14/P14-DELIVERY.json',
        'docs/engineering/localized-repair-c271/loader-path-p14/P14-TERMINAL-CONFIRMATION.json',
        'prototypes/static_tray_v01/current_host_inspection_v01.py',
    ]
    source_paths += git('ls-tree','-r','--name-only',args.revision,'docs/workflow/tasks/C271').decode().splitlines()
    source_paths += git('ls-tree','-r','--name-only',args.revision,'docs/engineering/localized-repair-c271/host-loader-p15').decode().splitlines()
    for name in sorted(set(source_paths)):
        data = git('show', args.revision + ':' + name)
        entry = git('ls-tree', args.revision, '--', name).decode().strip().split()
        member = 'repository/' + name
        put(member, data)
        sources.append({'member':member,'path':name,'commit':args.revision,'tree':phase['source_tree'],
                        'git_mode':entry[0],'git_blob':entry[2],'bytes':len(data),'sha256':digest(data)})
    recovery_map = []
    for base, prefix in [(SESSION,'recovery/session'),(ROOT/'reconciliation','recovery/reconciliation'),
                         (ROOT/'input/p14-saved/OntoKin','predecessor/saved-receipts')]:
        for path in sorted(base.rglob('*')):
            if not path.is_file() or path.is_symlink():
                continue
            derived_roots = ['receipt-review/scratch/early-extraction',
                             'receipt-review/scratch/early-attempt002-extraction',
                             'receipt-review/scratch/post-freeze',
                             'receipt-review/scratch/publication-evidence']
            relative = path.relative_to(base).as_posix()
            derived = next((x for x in derived_roots if base == SESSION and relative.startswith(x + '/')), None)
            if derived:
                if not any(x.get('path') == str(base / derived) for x in exclusions):
                    exclusions.append({'path':str(base / derived),'reason':'Byte-identical derived extraction; original immutable P14 saved receipt/confirmation or retained early Attempt001 supplies all bytes.'})
                continue
            if '__pycache__' in path.parts or path.suffix == '.pyc':
                exclusions.append({'path':str(path),'reason':'Reproducible interpreter cache'})
                continue
            member = prefix + '/' + path.relative_to(base).as_posix()
            data = path.read_bytes()
            put(member, data)
            recovery_map.append({'member':member,'original_path':str(path),'bytes':len(data),'sha256':digest(data),'mode':oct(stat.S_IMODE(path.stat().st_mode))})
    dirty = git('diff','--binary',args.revision)
    if dirty:
        put('recovery/unpublished-tracked.patch',dirty)
    untracked = git('ls-files','--others','--exclude-standard','-z').decode().split('\0')
    for name in filter(None,untracked):
        path=REPO/name
        assert path.is_file() and not path.is_symlink()
        put('recovery/unpublished/'+name,path.read_bytes())
    current=json.loads(git('show',args.revision+':docs/workflow/CURRENT.json'))
    historical={'schema':'ontokin.c271.p15-historical-dependencies/1',
        'purpose':'Online GitHub continuation; full offline restoration is not established.',
        'C262':current['historical_handoff'],
        'P14':{'library_file_id':P14_ID,'file_id':'file_00000000287481f59ce6ef69164ac870',
               'file_name':'OntoKin_C271_P14_Loader_Path_Implementation_Handoff_2026-11-21.zip',
               'version':0,'bytes':88651427,'sha256':'96dd48ac7cfe01219f57a48a3adfaacb1faa21325f72c5ad06ca19fcd54760cd',
               'url':P14_URL,'source_revision':'e26dc6369a8d6ba88ea779b26a8c655121ae5dbc',
               'purpose':'Retained implementation/fixture/failure/session history; immutable saved ZIP, not duplicated here.'}}
    put('CHECKPOINT.json',encoded(phase))
    put('SOURCE-MANIFEST.json',encoded(sources))
    put('RECOVERY-FILE-MAP.json',encoded(recovery_map))
    put('RECOVERY-EXCLUSIONS.json',encoded(exclusions))
    put('HISTORICAL-DEPENDENCIES.json',encoded(historical))
    readme=f'''# OntoKin C271 P15 {'Early Recovery' if args.kind=='early' else 'H0 Loader Review Handoff'}

This is a **browser-session handoff for online GitHub continuation**, usable without the preceding conversation.

Repository: https://github.com/Omegapy/OntoKin
Source: `{args.revision}`; tree `{phase['source_tree']}`.
Branch: `work/c271-missing-import-digest-control`. Observed main: `{phase['observed_main']['commit']}`.

Read CHECKPOINT.json, HANDOFF.md, RECOVERY-STATUS.md and NEXT-TASK.md, then reconcile live CHATGPT-START-HERE.md and its required instructions. Main retains completed C270; the live C271 branch and PR274 govern the unfinished scope. Reuse unchanged verified reads, including the retained delegated read-set.

P14 delivery is confirmed by its later receipt and terminal/publication confirmation. Do not replay those completed writes. P15 assesses exact-loader source completeness before operational plan eligibility. No generic glibc version, synthetic control or JSON label can establish that external review gate.

SOURCE-MANIFEST.json binds repository snapshots to exact Git blobs. Verify safe paths, exact inventory, every size/hash and ZIP integrity before extracting to a new directory. Files are inert 0644; do not execute payloads or apply recovered patches automatically. Recover unpublished changes only against their declared base after live reconciliation.

HISTORICAL-DEPENDENCIES.json retains immutable earlier archive identities. Actual host paths and facts must be rebound on a new host. This package does not establish complete offline restoration or H0/H1 acceptance. A saved ZIP cannot contain its own future receipt; reconcile the separate P15-DELIVERY.json and any later terminal confirmation on GitHub.
'''
    put('README-START-HERE.md',readme.encode())
    handoff=(SESSION/'HANDOFF.md').read_bytes() if (SESSION/'HANDOFF.md').exists() else f'''# P15 early recovery

Phase: {phase['scope']}

Acceptance and stopping point are recorded in CHECKPOINT.json. Startup reconciliation is being completed; no technical host/source work has begun. Confirm this early save before proceeding. Detailed startup observations and worker read-sets are retained under recovery/session and recovery/reconciliation. The existing P14 records govern its already completed delivery.

R01/R02 remain done; R03/R04/R05 remain not_done; P02 remains in_progress. C271, issue273 and draft PR274 remain open. No main lease is held. H0 is unaccepted; H1, installations, Node/ldd, original-seven/full routine and integration are unrun. Historical failures and unknown operations remain distinct from current worker states.
'''.encode()
    put('HANDOFF.md',handoff)
    put('NEXT-TASK.md',('# First remaining action\n\n'+phase['exact_next_action']+'\n\n'+phase['stop']+'\n').encode())
    recovery=f'''# Recovery status

This is a {args.kind} package. Its source is retained by exact Git revision. Session and unique unpublished bytes are included under recovery/; RECOVERY-FILE-MAP.json provides original paths and hashes. Apply no recovered delta over newer GitHub work. P14 implementation and failed history remain recoverable through the exact prior saved ZIP and pinned Git sources.

CHECKPOINT.json records actual workers and current unknown operations. Historical C270 broad-driver completion, global prior-process termination and P13 read-only difflib completion remain unknown; no write is implied by the latter. Do not repeat that historical difflib operation.

This package's save is pending at freeze. Its external receipt must establish actual save/readback. Completed P14 writes must not be repeated. After phase delivery, stop and use a fresh main chat for the first remaining development action.
'''
    put('RECOVERY-STATUS.md',recovery.encode())
    continue_text=git('show',args.revision+':docs/workflow/prompts/CONTINUE.md').decode()
    recover_text=git('show',args.revision+':docs/workflow/prompts/RECOVER.md').decode()
    if args.kind=='early':
        continue_text=continue_text.replace('[PASTE LINK]',P14_URL).replace('[LEAVE BLANK TO RESUME CURRENT TASK]','Resume C271 P15 from the attached early recovery ZIP '+dest.name+'; reconcile its later receipt first.')
        recover_text=recover_text.replace('[PASTE LINK]',P14_URL).replace('[PASTE LINK OR NONE]','Attach '+dest.name+'; use its exact confirmed save receipt.').replace('[DESCRIBE BRIEFLY OR UNKNOWN]','C271 P15 early recovery; reconcile the live first unmet gate without duplicating completed P14 work.')
    else:
        continue_text=continue_text.replace('[PASTE LINK]','Attach '+dest.name+'; its exact confirmed Library link and digest are in docs/engineering/localized-repair-c271/host-loader-p15/P15-DELIVERY.json on the retained branch.').replace('[LEAVE BLANK TO RESUME CURRENT TASK]','Resume C271 at the first remaining action recorded in this handoff after reconciling its later receipt.')
        recover_text=recover_text.replace('[PASTE LINK]','Attach '+dest.name+'; confirm its exact identity from the separate P15 delivery receipt.').replace('[PASTE LINK OR NONE]','Use any later confirmed recovery file; otherwise none.').replace('[DESCRIBE BRIEFLY OR UNKNOWN]','Resume only the first unmet C271 gate. If P15 delivery remains pending, finish delivery only and stop.')
    put('PROMPT-1-CONTINUE.md',continue_text.encode())
    put('PROMPT-2-RECOVER.md',recover_text.encode())
    manifest={name:{'bytes':len(data),'sha256':digest(data)} for name,data in sorted(payloads.items())}
    put('MANIFEST-SHA256.json',encoded(manifest))
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,data in sorted(payloads.items()):
            info=zipfile.ZipInfo(name,(2026,11,21,0,0,0));info.create_system=3
            info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,data)
    extracted=dest.parent/(dest.stem+'-verified-extraction')
    extracted.mkdir()
    with zipfile.ZipFile(dest) as z:
        names=z.namelist();assert len(names)==len(set(names))==len(manifest)+1
        assert set(names)==set(manifest)|{'MANIFEST-SHA256.json'}
        assert z.testzip() is None
        for name,row in manifest.items():
            data=z.read(name);assert len(data)==row['bytes'] and digest(data)==row['sha256']
            target=extracted/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data);target.chmod(0o644)
        for row in sources:
            assert z.read(row['member'])==git('show',row['commit']+':'+row['path'])
    result={'schema':'ontokin.c271.p15-package-verification/1','file_name':dest.name,'path':str(dest),'kind':args.kind,
            'bytes':dest.stat().st_size,'sha256':digest(dest.read_bytes()),'members':len(payloads),'payloads':len(manifest),
            'source_files':len(sources),'recovery_files':len(recovery_map),'source_revision':args.revision,
            'source_tree':phase['source_tree'],'integrity_and_all_payload_hashes':True,'exact_source_bindings':True,
            'fresh_extraction':str(extracted),'verification_scope':'Package mechanics and exact source bytes, not independent semantic review or host qualification'}
    (dest.parent/'PACKAGE-VERIFICATION.json').write_bytes(encoded(result))
    for key,suffix in [('PROMPT-1-CONTINUE.md','_Continue.md'),('PROMPT-2-RECOVER.md','_Recover.md')]:
        (dest.parent/(dest.stem+suffix)).write_bytes(payloads[key])
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    main()
