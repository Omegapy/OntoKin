# P15 early recovery package review

Reviewer: `/root/receipt_reconciliation`. Candidate: `OntoKin_C271_P15_H0_Review_Early_Recovery_2026-11-21.zip`, 2065064 bytes, SHA-256 `d123dd96c01bb8a74cc6f448bfbc017c3e259def7cce510f4beadc6715026274`.

**Verdict: changes_required_before_early_save.**

The independent audit verified all 81 ZIP members, all 80 manifest payloads, CRCs, safe unique relative paths, inert 0644 modes, fresh extraction/readback, all 53 exact Git blob bindings, all 16 mapped recovery files and both standalone prompt byte matches. The four prior saved P14 files match intake bytes. P14 and C262 dependencies retain exact identities and online-continuation limits.

## Mandatory finding

P15-EARLY-001: `CHECKPOINT.json.observed_main` records main SHA/tree and the observation file, but no observation time. HANDOFF explicitly requires observed main SHA/tree/time. `declared_at_utc` identifies phase declaration and must not silently be relabelled as the Git observation time. Record a verified observation timestamp in a distinct corrected candidate; preserve this frozen candidate.

No other mandatory finding was identified. Recovery instructions are executable and bounded: verify the exact external receipt, finish startup reconciliation, review exact-loader source/build completeness, proceed to plan eligibility only on acceptance, and stop at the first concrete blocker or before H1. P14 completed delivery is correctly separated from P15's pending early save. Parent C271 stays blocked/open; no lease or integration authority is asserted.

The old audit helper captured at package freeze has changed during subsequent review; its exact frozen bytes also remain in `scratch/audit_startup_attempt001.py`. Later review outputs and helper corrections belong in the final handoff, not a silent alteration of this early archive.

No host/runtime target, recovered script, test or package payload was executed. Git use was local read-only; no publication or Library save occurred. No active job remains in this review. Root owns correction, new candidate verification and eventual save/readback.
