from pathlib import Path
import collections, datetime, hashlib, json, os, platform, shutil, subprocess, sys
ROOT=Path('/workspace/scratch/5041e572c132');OUT=ROOT/'p15-session/receipt-review';SCRATCH=OUT/'scratch';REPO=ROOT/'OntoKin';SAVED=ROOT/'input/p14-saved/OntoKin';package=ROOT/'input/p14-package'
MAIN='e1a48f7d0635e9aa4f4b6d6a586e7305eb81999d';HEAD='875c81c506d4e5431b909e190ce294c61312029e';ZIP_NAME='OntoKin_C271_P14_Loader_Path_Implementation_Handoff_2026-11-21.zip';ZIP=ROOT/'input'/ZIP_NAME
receipt_path=SAVED/'OntoKin_C271_P14_Delivery_Receipt_2026-11-21.json';confirmation_path=SAVED/'OntoKin_C271_P14_Publication_Confirmation_2026-11-21.json'
def js(b):return json.loads(b)
def digest(b):return hashlib.sha256(b).hexdigest()
def ident(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':digest(p.read_bytes())}
def write_json(p,d):p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
def git(*args,data=None):return subprocess.run(['git','-C',str(REPO),*args],input=data,env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0'),check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
shutil.copyfile(OUT/'AUDIT.json',SCRATCH/'audit-attempt002-failed-local-read.json')
audit=js((OUT/'AUDIT.json').read_bytes());audit['checks']=[r for r in audit['checks'] if r['name']!='audit_completion'];audit['mandatory_findings']=[];audit.pop('failure',None)
audit['reviewer_local_read_failure']={'preserved_audit':str(SCRATCH/'audit-attempt002-failed-local-read.json'),'command':['git','-C',str(REPO),'cat-file','blob','33e0e60292721efadd67acfeba17e8c791b8b89e'],'exit_code':128,'source_record_number':307,'path':'docs/workflow/CURRENT.json','commit':'e26dc6369a8d6ba88ea779b26a8c655121ae5dbc','repository_is_partial_clone':True,'explicit_fetch_issued':False,'remote_write':False,'disposition':'Failed historical object read; no missing archive payload. Resolve exact source identity with existing Git tree metadata and SHA-1 Git-blob framing. Read only locally enumerated objects thereafter; never request absent blobs.'}
def check(n,ok,d):
 audit['checks'].append({'name':n,'passed':bool(ok),'detail':d})
 if not ok:audit['mandatory_findings'].append({'check':n,'detail':d})
receipt=js(receipt_path.read_bytes());confirmation=js(confirmation_path.read_bytes());source=js((package/'SOURCE-MANIFEST.json').read_bytes())
trees={};tree_ids={}
for rev in sorted({r['commit'] for r in source}):
 tree_ids[rev]=git('rev-parse',rev+'^{tree}').decode().strip();t={}
 for row in git('ls-tree','-rz',rev).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);mode,kind,oid=meta.decode().split();t[path.decode()]={'mode':mode,'kind':kind,'oid':oid}
 trees[rev]=t
available=set(git('cat-file','--batch-all-objects','--batch-check=%(objectname)').decode().splitlines());wanted=sorted({r['git_blob']for r in source} & available)
raw=git('cat-file','--batch',data=('\n'.join(wanted)+'\n').encode());cursor=0;blobs={}
while cursor<len(raw):
 end=raw.index(b'\n',cursor);oid,kind,size=raw[cursor:end].decode().split();size=int(size);cursor=end+1;blobs[oid]=raw[cursor:cursor+size];cursor+=size+1
results=[]
for r in source:
 b=(package/r['member']).read_bytes();computed=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();local=blobs.get(r['git_blob']);ok=(computed==r['git_blob'] and trees[r['commit']].get(r['path'])=={'mode':r['git_mode'],'kind':'blob','oid':r['git_blob']} and tree_ids[r['commit']]==r['tree'] and len(b)==r['bytes'] and digest(b)==r['sha256'] and (local is None or local==b))
 results.append({'member':r['member'],'path':r['path'],'commit':r['commit'],'git_blob':r['git_blob'],'computed_git_blob':computed,'locally_stored_blob_compared':local is not None,'passed':ok})
write_json(SCRATCH/'source-blob-comparisons.json',results)
audit['source_snapshot_bindings']={'records':len(results),'passed':sum(r['passed']for r in results),'locally_stored_blob_comparisons':sum(r['locally_stored_blob_compared']for r in results),'cryptographic_tree_bindings':len(results),'commits':tree_ids,'manifest':ident(package/'SOURCE-MANIFEST.json'),'details':ident(SCRATCH/'source-blob-comparisons.json'),'local_object_read_limit':[{'member':r['member'],'git_blob':r['git_blob']}for r in results if not r['locally_stored_blob_compared']]}
check('all_source_snapshots_equal_exact_committed_tree_blob_identities',all(r['passed']for r in results),audit['source_snapshot_bindings'])
final_manifest=js((package/'MANIFEST-SHA256.json').read_bytes());recovery_map=js((package/'RECOVERY-FILE-MAP.json').read_bytes());map_bad=[r['member']for r in recovery_map if r['member']not in final_manifest or any(r[k]!=final_manifest[r['member']][k]for k in ['bytes','sha256'])]
audit['original_recovery']={'mapped_regular_files':len(recovery_map),'mismatches':map_bad,'declared_symlinks_preserved_as_metadata':len(js((package/'RECOVERY-SYMLINKS.json').read_bytes())),'declared_exclusions':len(js((package/'RECOVERY-EXCLUSIONS.json').read_bytes())),'unpublished_tracked_patch_bytes':(package/'recovery/unpublished-tracked.patch').stat().st_size,'unpublished_new_file_members':sum(r['member'].startswith('recovery/unpublished/')for r in recovery_map),'historical_exclusion_policy_revalidated':False}
check('original_unpublished_file_map_payload_agreement',not map_bad,audit['original_recovery'])
library = js((ROOT / 'reconciliation/library-recent.json').read_bytes())
listed = {r['name']: r for r in library['items'] if r.get('name')}
saved_records = list(receipt['saved_final_files']) + [confirmation['saved_terminal_receipt']]
pub_list = listed[confirmation_path.name]
saved_records.append({'role':'publication_confirmation','file_name':confirmation_path.name,'bytes':confirmation_path.stat().st_size,
                      'sha256':digest(confirmation_path.read_bytes()),'file_id':pub_list['file_id'],
                      'library_file_id':pub_list['library_file_id'],'version':int(pub_list['version_id']),
                      'path':pub_list['path'],'url':'https://chatgpt.com/library?file_id='+pub_list['library_file_id']+'&account_id=personal'})
saved_bindings = []
for record in saved_records:
    name = record.get('file_name',record.get('name'))
    local = ZIP if name == ZIP_NAME else SAVED / name
    actual = ident(local); listed_item = listed[name]
    fields = {k: record.get(k) for k in ('role','file_name','file_id','library_file_id','path','version','bytes','sha256','url')}
    fields['local'] = actual
    fields['saved_listing_match'] = (listed_item['file_id'] == record['file_id'] and listed_item['library_file_id'] == record['library_file_id'] and listed_item['size_bytes'] == record['bytes'] and int(listed_item['version_id']) == record['version'])
    fields['byte_identity_match'] = actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256']
    fields['prompt_equals_zip_member'] = ((package / record['archive_member']).read_bytes() == local.read_bytes()) if record.get('archive_member') else None
    saved_bindings.append(fields)
audit['prior_saved_files'] = saved_bindings
check('five_saved_files_and_prompt_members_reconciled', all(r['saved_listing_match'] and r['byte_identity_match'] and r['prompt_equals_zip_member'] is not False for r in saved_bindings), {'files':len(saved_bindings),'library_inventory_complete':library.get('next_cursor') is None,'known_files_present':True})
check('receipt_and_confirmation_final_identities_agree', receipt['saved_final_files'] == confirmation['saved_final_files'], {'three_saved_final_records_exactly_equal':receipt['saved_final_files'] == confirmation['saved_final_files']})
check('confirmation_binds_exact_receipt', confirmation['saved_terminal_receipt']['sha256'] == digest(receipt_path.read_bytes()) and confirmation['saved_terminal_receipt']['bytes'] == receipt_path.stat().st_size, ident(receipt_path))

issue = js((ROOT / 'reconciliation/issue273.json').read_bytes())
prs = js((ROOT / 'reconciliation/open-prs.json').read_bytes())
pr_items = prs['issues'] if isinstance(prs,dict) else prs
pr = next(item for item in pr_items if item.get('number') == 274)
marker_start='<!-- C271-P14-TERMINAL-CONFIRMATION -->'; marker_end='<!-- /C271-P14-TERMINAL-CONFIRMATION -->'
markers=[]
for kind, item in [('issue',issue),('pr',pr)]:
    body=item['body']; start=body.find(marker_start); end=body.find(marker_end,start)
    if start < 0 or end < 0 or body.count(marker_start)!=1: raise ValueError('missing/ambiguous terminal marker in ' + kind)
    marker=body[start:end+len(marker_end)]
    marker_path=SCRATCH / (kind+'-p14-terminal-marker.md'); marker_path.write_text(marker)
    marker_ok=all(str(value) in marker for value in [pub_list['file_id'],pub_list['library_file_id'],digest(confirmation_path.read_bytes()),HEAD,MAIN])
    markers.append({'kind':kind,'number':item['number'],'state':item['state'],'source':str(ROOT / 'reconciliation' / ('issue273.json' if kind=='issue' else 'open-prs.json')),'marker':ident(marker_path),'confirmation_identity_and_heads_present':marker_ok})
audit['terminal_markers'] = markers
check('both_live_terminal_markers_reconcile_confirmation_self_save', all(m['confirmation_identity_and_heads_present'] for m in markers) and markers[0]['marker']['sha256']==markers[1]['marker']['sha256'], {'matching_markers':markers[0]['marker']['sha256']==markers[1]['marker']['sha256'],'confirmation_save_at_utc':'2026-11-22T05:10:02.917496+00:00'})

commits = [confirmation['implementation'],confirmation['core_publication'],confirmation['terminal_publication']]
commit_results=[]
for row in commits:
    actual_tree=git('rev-parse',row['commit']+'^{tree}').decode().strip()
    actual_parents=git('rev-list','--parents','-n','1',row['commit']).decode().strip().split()[1:]
    good=actual_tree==row['tree'] and ('parent' not in row or actual_parents==[row['parent']])
    commit_results.append({'commit':row['commit'],'tree':actual_tree,'parents':actual_parents,'passed':good})
audit['publication_history'] = commit_results
check('implementation_core_terminal_commit_identity',all(row['passed'] for row in commit_results),commit_results)
status=js((ROOT / 'reconciliation/head-status.json').read_bytes()); runs=js((ROOT / 'reconciliation/head-runs.json').read_bytes())
audit['observed_current_state']={'main':MAIN,'branch':'work/c271-missing-import-digest-control','head':HEAD,'head_tree':git('rev-parse',HEAD+'^{tree}').decode().strip(),'pr':{'number':274,'state':pr['state'],'draft':pr.get('draft','see Director exact PR observation')},'issue':{'number':273,'state':issue['state']},'integration_authority':False,'head_status_contexts':status['total_count'],'head_workflow_runs':runs['total_count'],'empty_hosted_results_are_not_pass':True}
audit['historical_unknowns']=receipt['operations']['historical_unknowns']
audit['outstanding_parent_gates']=confirmation['scope_and_stop']
audit['source_time_pending_disposition']='Final ZIP save_pending, receipt self-save pending, and confirmation self-save pending are superseded only by matching later saved-file records and current PR/issue terminal markers. Historical technical limits and parent gates remain unchanged.'
audit['unpublished_work_disposition']='Original session recovery files remain in the verified final ZIP; 144 post-freeze payloads are preserved inside the exact terminal receipt; 56 terminal evidence payloads are preserved inside the exact publication confirmation. Source revision and both later documentary commits exist in the checkout object database. No current unknown write is reported by the terminal marker. Global termination and named historical process completions remain unknown.'
audit['technical_tests_executed_in_this_audit']=[]
audit['publications_or_library_mutations']=[]
audit['verdict']='accepted_for_startup_reconciliation' if not audit['mandatory_findings'] else 'findings_require_disposition'

cp=js((package/'CHECKPOINT.json').read_bytes());audit['prior_early_recovery_files']=[]
for row in [cp['early_recovery'],receipt['early_recovery']]:
 item={k:row.get(k)for k in ['file_name','file_id','library_file_id','path','version','bytes','sha256','url','source_revision','source_tree']};observed=listed.get(item['file_name']);item['listed_identity_size_version_match']=bool(observed and observed['file_id']==item['file_id'] and observed['library_file_id']==item['library_file_id'] and observed['size_bytes']==item['bytes'] and int(observed['version_id'])==item['version']);member='recovery/confirmed-early/'+item['file_name'];item['fresh_byte_identity_verified']=member in final_manifest and final_manifest[member]['bytes']==item['bytes'] and final_manifest[member]['sha256']==item['sha256'];item['verification_limit']=None if item['fresh_byte_identity_verified'] else 'External recovery wrapper was not downloaded/rehashed; exact identity is retained from receipt and current listing.';audit['prior_early_recovery_files'].append(item)
aliases=js((SCRATCH/'post-freeze/RECOVERY-ALIASES.json').read_bytes());alias_results=[{'member':r['archive_member'],'passed':r['archive_sha256']==audit['final_archive']['sha256'] and final_manifest[r['archive_member']]['bytes']==r['bytes'] and final_manifest[r['archive_member']]['sha256']==r['sha256']}for r in aliases['files']];check('both_post_freeze_external_aliases_have_exact_verified_bytes',all(r['passed']for r in alias_results),alias_results)
audit['actual_outstanding_operations']={'prior_P14_current_writes':[],'prior_P14_current_worker_jobs':[],'current_reviewer_jobs':[],'current_P15_other_work':'Owned and tracked by Director; this startup audit does not infer current execution from old P14 workers.','first_unmet_technical_gate':'Actual-loader source completeness and independent source-and-plan review before H0 eligibility; H1 remains outside this phase.'}
audit['learning_disposition']='Skipped new canonical learning capture: this read-only reconciliation confirms existing delivery records; no new product finding or changed contract. Director owns any later memory publication.'
audit['verdict']='accepted_for_startup_reconciliation' if not audit['mandatory_findings'] else 'findings_require_disposition';audit['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();write_json(OUT/'AUDIT.json',audit)
reads=[]
for folder,rev,paths in [('governing-main',MAIN,['AGENTS.md','GOAL.md','ROLE.md','docs/workflow/PROTOCOL.md','docs/workflow/HANDOFF.md','CHATGPT-START-HERE.md']),('governing-branch',HEAD,['.agents/skills/ontokin-delivery/SKILL.md','.agents/skills/ontokin-learning/SKILL.md','docs/workflow/templates/WORKER.md'])]:
 for name in paths:
  p=ROOT/folder/name;reads.append({**ident(p),'repository_path':name,'revision':rev,'method':'Full governing text read; no omitted prose','complete':True})
for p in [ZIP,*sorted(SAVED.iterdir()),*sorted((ROOT/'reconciliation').glob('*.json'))]:
 reads.append({**ident(p),'method':'Full bytes/JSON parsed; exact relevant metadata and terminal marker reviewed; embedded payloads mechanically verified. Historical body prose not independently re-reviewed.','complete_for_assigned_scope':True})
write_json(OUT/'READSET.json',{'schema':'ontokin.c271.p15-receipt-review-readset/1','reader':'/root/receipt_reconciliation','read_set':reads,'archive_payload_read_scope':{'P14_members':21972,'P14_source_snapshots':360,'post_freeze_members':145,'publication_evidence_members':57},'known_gaps':['No new historical exclusion-policy re-audit or runtime execution; no full Library inventory claim; one missing historical object was cryptographically bound to the existing exact Git tree instead of fetched.'],'global_startup_owner':'Director'})
(OUT/'REPORT.md').write_text(f"""# P14 saved-handoff startup reconciliation

**Verdict: accepted for startup reconciliation.** Reviewer: `/root/receipt_reconciliation`. No mandatory package or delivery finding remains.

The final P14 ZIP is exactly 88,651,427 bytes, SHA-256 `96dd48ac7cfe01219f57a48a3adfaacb1faa21325f72c5ad06ca19fcd54760cd`. All 21,972 members pass CRC, safe unique path and regular-file checks. The exact 21,971 payload inventory, every size/hash and inert 0644 extraction were verified. Extracted input is `/workspace/scratch/5041e572c132/input/p14-package`.

All 360 source snapshots bind to their recorded commit trees, modes and Git blob identities. {audit['source_snapshot_bindings']['locally_stored_blob_comparisons']} records additionally compare to available local object bytes. The historical CURRENT.json read at record 307 failed in this partial clone; its archived bytes still produce the exact Git blob ID recorded in the existing commit tree. No further absent-object read or fetch was issued. The failed read is retained in `scratch/audit-attempt002-failed-local-read.json`; it indicates no missing archive payload or remote write.

The final ZIP, Continue, Recover, separate receipt and publication confirmation match all five exact saved identities/versions/byte counts. Both prompts match their ZIP members. PR274 and issue273 contain equal terminal markers binding the publication confirmation to its later saved ID/hash. These markers resolve the frozen P14 pending save/worker fields. No P14 delivery retry remains.

The receipt's 145-member embedded recovery archive has 144 verified payloads; the publication confirmation has 57 members and 56 verified payloads. Both were strictly decoded, CRC/hash checked and extracted inertly. Both external recovery aliases match exact final-ZIP members. The original session retains 21,595 mapped files; its tracked unpublished patch is empty and no extra unpublished file member exists. Thirty fixture symlinks remain inert metadata.

Main remains `{MAIN}`; implementation `e26dc6369a8d6ba88ea779b26a8c655121ae5dbc`, core receipt `f0fb9a634269b515476f2fc467556ccea789c2d8` and terminal head `{HEAD}` have matching recorded trees/parents. PR274 is draft/open/unmerged, issue273 is open, and the branch is retained. Empty status/workflow lists establish no CI pass.

Actual-loader completeness, H0/H1, original-seven/full routine and integration remain unaccepted or unrun. R01/R02 are done; R03–R05 are not_done; P02 stays in_progress. No current P14 worker job or unknown write is reported by the terminal marker. C270 broad-driver completion, global prior-process termination and P13 read-only difflib completion remain historical unknowns.

The initial audit helper incorrectly compared total logical ZIP bytes with a payload sum excluding the manifest; the exact total includes that manifest. The helper failure and correction are preserved. The separate P15 early-package review found and corrected an omitted main observation timestamp; its accepted Attempt002 review is in `early-attempt002/`.

This audit executed no runtime tests, target, recovered script, publication, index update or Library mutation. It does not re-audit old exclusion policy, claim complete offline restoration, or prove global process termination. Full saved IDs/digests, evidence paths and read scope are in `AUDIT.json` and `READSET.json`. No current reviewer job remains. Director owns early save/readback and the declared next technical gate.
""")
print(json.dumps({'verdict':audit['verdict'],'checks':len(audit['checks']),'failed':len(audit['mandatory_findings']),'source_bindings':audit['source_snapshot_bindings']['records'],'direct_local_blob_comparisons':audit['source_snapshot_bindings']['locally_stored_blob_comparisons'],'saved_files':len(audit['prior_saved_files']),'report':str(OUT/'REPORT.md')}))
