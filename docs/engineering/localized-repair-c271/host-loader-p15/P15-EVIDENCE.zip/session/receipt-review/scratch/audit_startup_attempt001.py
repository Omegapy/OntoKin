from pathlib import Path, PurePosixPath
import base64, collections, datetime, hashlib, io, json, os, platform, stat, subprocess, sys, zipfile

ROOT = Path('/workspace/scratch/5041e572c132')
OUT = ROOT / 'p15-session/receipt-review'
SCRATCH = OUT / 'scratch'
REPO = ROOT / 'OntoKin'
SAVED = ROOT / 'input/p14-saved/OntoKin'
ZIP_NAME = 'OntoKin_C271_P14_Loader_Path_Implementation_Handoff_2026-11-21.zip'
ZIP = ROOT / 'input' / ZIP_NAME
MAIN = 'e1a48f7d0635e9aa4f4b6d6a586e7305eb81999d'
HEAD = '875c81c506d4e5431b909e190ce294c61312029e'
SCRATCH.mkdir(parents=True, exist_ok=True)

def unique(pairs):
    out = {}
    for key, value in pairs:
        if key in out:
            raise ValueError('duplicate JSON key: ' + key)
        out[key] = value
    return out

def js(data):
    return json.loads(data, object_pairs_hook=unique)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def ident(path):
    with path.open('rb') as handle:
        return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': hashlib.file_digest(handle, 'sha256').hexdigest()}

def write_json(path, data):
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')

audit = {'schema': 'ontokin.c271.p15-p14-startup-reconciliation/1', 'reviewer': '/root/receipt_reconciliation',
         'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'scope': 'Independent startup saved-handoff reconciliation only; no technical implementation, integration, publication, Library mutation or target execution.',
         'environment': {'python': sys.version, 'executable': sys.executable, 'platform': platform.platform()},
         'checks': [], 'mandatory_findings': [], 'current_jobs': [], 'current_unknown_writes': []}

def check(name, result, detail):
    audit['checks'].append({'name': name, 'passed': bool(result), 'detail': detail})
    if not result:
        audit['mandatory_findings'].append({'check': name, 'detail': detail})

def validate_zip(source, expected, destination):
    raw = source.read_bytes() if isinstance(source, Path) else source
    summary = {'bytes': len(raw), 'sha256': digest(raw), 'destination': str(destination)}
    if summary['bytes'] != expected['bytes'] or summary['sha256'] != expected['sha256']:
        raise ValueError('archive identity mismatch')
    with zipfile.ZipFile(io.BytesIO(raw)) as z:
        infos = z.infolist()
        names = [i.filename for i in infos]
        if len(names) != len(set(names)):
            raise ValueError('duplicate ZIP member names')
        nameset = set(names)
        for info in infos:
            name = info.filename
            parts = name.split('/')
            if not name or name.startswith('/') or '\\' in name or ':' in name or '\x00' in name or any(part in ('', '.', '..') for part in parts):
                raise ValueError('unsafe ZIP path: ' + repr(name))
            if PurePosixPath(name).as_posix() != name:
                raise ValueError('nonnormal ZIP path: ' + repr(name))
            if info.is_dir() or stat.S_IFMT(info.external_attr >> 16) not in (0, stat.S_IFREG) or info.flag_bits & 1:
                raise ValueError('nonregular/directory/encrypted ZIP member: ' + name)
            if any('/'.join(parts[:n]) in nameset for n in range(1, len(parts))):
                raise ValueError('file/parent collision: ' + name)
        manifest_bytes = z.read('MANIFEST-SHA256.json')
        manifest = js(manifest_bytes)
        if isinstance(manifest, dict) and isinstance(manifest.get('files'), list):
            rows = manifest['files']
            if len(rows) != len({r['path'] for r in rows}):
                raise ValueError('duplicate manifest path')
            entries = {r['path']: r for r in rows}
        else:
            entries = manifest
        if nameset != set(entries) | {'MANIFEST-SHA256.json'} or 'MANIFEST-SHA256.json' in entries:
            raise ValueError('manifest inventory mismatch')
        logical_bytes = 0
        for info in infos:
            sha = hashlib.sha256(); size = 0
            with z.open(info, 'r') as handle:
                while piece := handle.read(1024 * 1024):
                    sha.update(piece); size += len(piece)
            if size != info.file_size:
                raise ValueError('ZIP file size mismatch: ' + info.filename)
            if info.filename in entries:
                record = entries[info.filename]
                if size != record['bytes'] or sha.hexdigest() != record['sha256']:
                    raise ValueError('manifest size/hash mismatch: ' + info.filename)
                logical_bytes += size
        if destination.exists() or destination.is_symlink():
            raise ValueError('extraction destination must be absent: ' + str(destination))
        destination.mkdir(parents=True, mode=0o700)
        for info in infos:
            target = destination.joinpath(*info.filename.split('/'))
            target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
            fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
            with os.fdopen(fd, 'wb') as handle, z.open(info, 'r') as incoming:
                while piece := incoming.read(1024 * 1024):
                    handle.write(piece)
            os.chmod(target, 0o644)
            observed = ident(target)
            record = entries.get(info.filename, {'bytes': len(manifest_bytes), 'sha256': digest(manifest_bytes)})
            if observed['bytes'] != record['bytes'] or observed['sha256'] != record['sha256'] or not stat.S_ISREG(target.lstat().st_mode) or stat.S_IMODE(target.lstat().st_mode) != 0o644:
                raise ValueError('inert extracted file verification failed: ' + info.filename)
        summary.update({'members': len(infos), 'payloads': len(entries), 'logical_payload_bytes': logical_bytes,
                        'manifest_sha256': digest(manifest_bytes), 'safe_unique_paths': True, 'crc_all_members': True,
                        'exact_manifest_inventory': True, 'all_payload_sizes_hashes': True,
                        'fresh_extraction': True, 'all_extracted_regular_0644': True, 'symlinks_created': 0})
        for key in ('manifest_payloads', 'members', 'manifest_sha256', 'logical_payload_bytes'):
            if key in expected:
                actual = summary['payloads'] if key == 'manifest_payloads' else summary[key]
                if actual != expected[key]:
                    raise ValueError('embedded declared count/hash mismatch: ' + key)
    return summary, entries

def git(*args):
    env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0')
    return subprocess.run(['git', '-C', str(REPO), *args], env=env, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout

try:
    package = ROOT / 'input/p14-package'
    final_info, final_manifest = validate_zip(ZIP, {'bytes': 88651427, 'sha256': '96dd48ac7cfe01219f57a48a3adfaacb1faa21325f72c5ad06ca19fcd54760cd'}, package)
    audit['final_archive'] = final_info
    check('final_archive_integrity_and_inert_extraction', True, final_info)
    receipt_path = SAVED / 'OntoKin_C271_P14_Delivery_Receipt_2026-11-21.json'
    confirmation_path = SAVED / 'OntoKin_C271_P14_Publication_Confirmation_2026-11-21.json'
    receipt = js(receipt_path.read_bytes()); confirmation = js(confirmation_path.read_bytes())
    audit['embedded_recovery'] = []
    for label, obj in [('post-freeze', receipt['post_freeze_recovery']), ('publication-evidence', confirmation['evidence'])]:
        decoded = base64.b64decode(obj['base64'], validate=True)
        info, entries = validate_zip(decoded, obj, SCRATCH / label)
        info['role'] = label; audit['embedded_recovery'].append(info)
        check(label + '_complete_inert_recovery', True, info)

    source = js((package / 'SOURCE-MANIFEST.json').read_bytes())
    trees = {}; tree_ids = {}; source_results = []
    for record in source:
        commit = record['commit']
        if commit not in trees:
            tree_ids[commit] = git('rev-parse', commit + '^{tree}').decode().strip()
            tree = {}
            for line in git('ls-tree', '-rz', commit).split(b'\0'):
                if not line: continue
                meta, path = line.split(b'\t', 1)
                mode, kind, oid = meta.decode().split(' ')
                tree[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
            trees[commit] = tree
        meta = trees[commit].get(record['path'])
        data = (package / record['member']).read_bytes()
        blob = git('cat-file', 'blob', record['git_blob'])
        passed = (meta == {'mode': record['git_mode'], 'kind': 'blob', 'oid': record['git_blob']}
                  and tree_ids[commit] == record['tree'] and data == blob
                  and len(data) == record['bytes'] and digest(data) == record['sha256'])
        source_results.append({'member': record['member'], 'commit': commit, 'path': record['path'], 'passed': passed})
    write_json(SCRATCH / 'source-blob-comparisons.json', source_results)
    audit['source_snapshot_bindings'] = {'records': len(source), 'passed': sum(r['passed'] for r in source_results),
                                        'commits': tree_ids, 'manifest': ident(package / 'SOURCE-MANIFEST.json'),
                                        'details': ident(SCRATCH / 'source-blob-comparisons.json')}
    check('all_source_snapshots_equal_exact_committed_blobs', all(r['passed'] for r in source_results), audit['source_snapshot_bindings'])

    recovery_map = js((package / 'RECOVERY-FILE-MAP.json').read_bytes())
    map_bad = [r['member'] for r in recovery_map if r['member'] not in final_manifest or any(r[k] != final_manifest[r['member']][k] for k in ('bytes','sha256'))]
    audit['original_recovery'] = {'mapped_regular_files': len(recovery_map), 'mismatches': map_bad,
        'declared_symlinks_preserved_as_metadata': len(js((package / 'RECOVERY-SYMLINKS.json').read_bytes())),
        'declared_exclusions': len(js((package / 'RECOVERY-EXCLUSIONS.json').read_bytes())),
        'symlinks_materialized': False, 'exclusion_policy_revalidated': False}
    check('original_unpublished_file_map_payload_agreement', not map_bad and len(recovery_map) == len({r['member'] for r in recovery_map}), audit['original_recovery'])

    library = js((ROOT / 'reconciliation/library-recent.json').read_bytes())
    listed = {r['name']: r for r in library['items'] if r.get('name')}
    saved_records = list(receipt['saved_final_files']) + [confirmation['saved_terminal_receipt']]
    pub_list = listed[confirmation_path.name]
    saved_records.append({'role':'publication_confirmation','file_name':confirmation_path.name,'bytes':confirmation_path.stat().st_size,
                          'sha256':digest(confirmation_path.read_bytes()),'file_id':pub_list['file_id'],
                          'library_file_id':pub_list['library_file_id'],'version':int(pub_list['version_id']),
                          'path':pub_list['path'],'url':'https://chatgpt.com/library?file_id='+pub_list['library_file_id']+'&account_id=personal'})
    saved_bindings = []
    for record in saved_records:
        name = record.get('file_name',record.get('name'))
        local = ZIP if name == ZIP_NAME else SAVED / name
        actual = ident(local); listed_item = listed[name]
        fields = {k: record.get(k) for k in ('role','file_name','file_id','library_file_id','path','version','bytes','sha256','url')}
        fields['local'] = actual
        fields['saved_listing_match'] = (listed_item['file_id'] == record['file_id'] and listed_item['library_file_id'] == record['library_file_id'] and listed_item['size_bytes'] == record['bytes'] and int(listed_item['version_id']) == record['version'])
        fields['byte_identity_match'] = actual['bytes'] == record['bytes'] and actual['sha256'] == record['sha256']
        fields['prompt_equals_zip_member'] = ((package / record['archive_member']).read_bytes() == local.read_bytes()) if record.get('archive_member') else None
        saved_bindings.append(fields)
    audit['prior_saved_files'] = saved_bindings
    check('five_saved_files_and_prompt_members_reconciled', all(r['saved_listing_match'] and r['byte_identity_match'] and r['prompt_equals_zip_member'] is not False for r in saved_bindings), {'files':len(saved_bindings),'library_inventory_complete':library.get('next_cursor') is None,'known_files_present':True})
    check('receipt_and_confirmation_final_identities_agree', receipt['saved_final_files'] == confirmation['saved_final_files'], {'three_saved_final_records_exactly_equal':receipt['saved_final_files'] == confirmation['saved_final_files']})
    check('confirmation_binds_exact_receipt', confirmation['saved_terminal_receipt']['sha256'] == digest(receipt_path.read_bytes()) and confirmation['saved_terminal_receipt']['bytes'] == receipt_path.stat().st_size, ident(receipt_path))

    issue = js((ROOT / 'reconciliation/issue273.json').read_bytes())
    prs = js((ROOT / 'reconciliation/open-prs.json').read_bytes())
    pr_items = prs['issues'] if isinstance(prs,dict) else prs
    pr = next(item for item in pr_items if item.get('number') == 274)
    marker_start='<!-- C271-P14-TERMINAL-CONFIRMATION -->'; marker_end='<!-- /C271-P14-TERMINAL-CONFIRMATION -->'
    markers=[]
    for kind, item in [('issue',issue),('pr',pr)]:
        body=item['body']; start=body.find(marker_start); end=body.find(marker_end,start)
        if start < 0 or end < 0 or body.count(marker_start)!=1: raise ValueError('missing/ambiguous terminal marker in ' + kind)
        marker=body[start:end+len(marker_end)]
        marker_path=SCRATCH / (kind+'-p14-terminal-marker.md'); marker_path.write_text(marker)
        marker_ok=all(str(value) in marker for value in [pub_list['file_id'],pub_list['library_file_id'],digest(confirmation_path.read_bytes()),HEAD,MAIN])
        markers.append({'kind':kind,'number':item['number'],'state':item['state'],'source':str(ROOT / 'reconciliation' / ('issue273.json' if kind=='issue' else 'open-prs.json')),'marker':ident(marker_path),'confirmation_identity_and_heads_present':marker_ok})
    audit['terminal_markers'] = markers
    check('both_live_terminal_markers_reconcile_confirmation_self_save', all(m['confirmation_identity_and_heads_present'] for m in markers) and markers[0]['marker']['sha256']==markers[1]['marker']['sha256'], {'matching_markers':markers[0]['marker']['sha256']==markers[1]['marker']['sha256'],'confirmation_save_at_utc':'2026-11-22T05:10:02.917496+00:00'})

    commits = [confirmation['implementation'],confirmation['core_publication'],confirmation['terminal_publication']]
    commit_results=[]
    for row in commits:
        actual_tree=git('rev-parse',row['commit']+'^{tree}').decode().strip()
        actual_parents=git('rev-list','--parents','-n','1',row['commit']).decode().strip().split()[1:]
        good=actual_tree==row['tree'] and ('parent' not in row or actual_parents==[row['parent']])
        commit_results.append({'commit':row['commit'],'tree':actual_tree,'parents':actual_parents,'passed':good})
    audit['publication_history'] = commit_results
    check('implementation_core_terminal_commit_identity',all(row['passed'] for row in commit_results),commit_results)
    status=js((ROOT / 'reconciliation/head-status.json').read_bytes()); runs=js((ROOT / 'reconciliation/head-runs.json').read_bytes())
    audit['observed_current_state']={'main':MAIN,'branch':'work/c271-missing-import-digest-control','head':HEAD,'head_tree':git('rev-parse',HEAD+'^{tree}').decode().strip(),'pr':{'number':274,'state':pr['state'],'draft':pr.get('draft','see Director exact PR observation')},'issue':{'number':273,'state':issue['state']},'integration_authority':False,'head_status_contexts':status['total_count'],'head_workflow_runs':runs['total_count'],'empty_hosted_results_are_not_pass':True}
    audit['historical_unknowns']=receipt['operations']['historical_unknowns']
    audit['outstanding_parent_gates']=confirmation['scope_and_stop']
    audit['source_time_pending_disposition']='Final ZIP save_pending, receipt self-save pending, and confirmation self-save pending are superseded only by matching later saved-file records and current PR/issue terminal markers. Historical technical limits and parent gates remain unchanged.'
    audit['unpublished_work_disposition']='Original session recovery files remain in the verified final ZIP; 144 post-freeze payloads are preserved inside the exact terminal receipt; 56 terminal evidence payloads are preserved inside the exact publication confirmation. Source revision and both later documentary commits exist in the checkout object database. No current unknown write is reported by the terminal marker. Global termination and named historical process completions remain unknown.'
    audit['technical_tests_executed_in_this_audit']=[]
    audit['publications_or_library_mutations']=[]
    audit['verdict']='accepted_for_startup_reconciliation' if not audit['mandatory_findings'] else 'findings_require_disposition'
except Exception as exc:
    audit['verdict']='startup_audit_incomplete'
    audit['failure']={'type':type(exc).__name__,'message':str(exc)}
    check('audit_completion',False,audit['failure'])
    write_json(OUT / 'AUDIT.json',audit)
    raise
finally:
    audit['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    write_json(OUT / 'AUDIT.json',audit)

print(json.dumps({'verdict':audit['verdict'],'checks':len(audit['checks']),'failed':len(audit['mandatory_findings']),'archive':audit['final_archive'],'source_bindings':audit['source_snapshot_bindings']['records'],'saved_files':len(audit['prior_saved_files']),'audit':str(OUT/'AUDIT.json')}))
