from pathlib import Path, PurePosixPath
import datetime, hashlib, json, os, stat, subprocess, zipfile

R=Path('/workspace/scratch/5041e572c132'); O=R/'p15-session/receipt-review/early'; O.mkdir(exist_ok=True)
P=R/'deliverables/early/OntoKin_C271_P15_H0_Review_Early_Recovery_2026-11-21.zip'
X=R/'p15-session/receipt-review/scratch/early-extraction'
H='875c81c506d4e5431b909e190ce294c61312029e'
env=dict(os.environ,GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
def sha(b): return hashlib.sha256(b).hexdigest()
def g(*args, data=None):
 return subprocess.run(['git','-C',str(R/'OntoKin'),*args],input=data,env=env,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE).stdout
checks=[]; findings=[]
def c(name,ok,detail):
 checks.append({'name':name,'passed':bool(ok),'detail':detail})
 if not ok: findings.append({'id':'P15-EARLY-'+str(len(findings)+1).zfill(3),'check':name,'detail':detail})
raw=P.read_bytes()
audit={'schema':'ontokin.c271.p15-early-package-review/1','reviewer':'/root/receipt_reconciliation','reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'candidate':{'path':str(P),'bytes':len(raw),'sha256':sha(raw)},'checks':checks,'mandatory_findings':findings}
with zipfile.ZipFile(P) as z:
 infos=z.infolist();names=z.namelist(); payload={i.filename:z.read(i) for i in infos}
 m=json.loads(payload['MANIFEST-SHA256.json']);c('archive_identity',len(raw)==2065064 and sha(raw)=='d123dd96c01bb8a74cc6f448bfbc017c3e259def7cce510f4beadc6715026274',audit['candidate'])
 safe=all(n and not n.startswith('/') and '\\' not in n and ':' not in n and not any(p in ('','.','..') for p in n.split('/')) and PurePosixPath(n).as_posix()==n for n in names)
 modes=all(stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG) and stat.S_IMODE(i.external_attr>>16)==0o644 and not i.is_dir() and not i.flag_bits&1 for i in infos)
 unique=len(names)==len(set(names)); inventory=set(names)==set(m)|{'MANIFEST-SHA256.json'} and 'MANIFEST-SHA256.json' not in m
 hashes=all(len(payload[n])==r['bytes'] and sha(payload[n])==r['sha256'] for n,r in m.items())
 c('safe_unique_inert_names_and_modes',safe and unique and modes,{'members':len(names),'safe':safe,'unique':unique,'inert_0644':modes})
 c('crc_exact_inventory_and_all_payloads',inventory and hashes,{'payloads':len(m),'crc_all_members':True,'inventory':inventory,'sizes_hashes':hashes})
 if not (safe and unique and modes and inventory and hashes): raise ValueError('unsafe or invalid archive')
 if X.exists(): raise ValueError('extraction destination must be new')
 X.mkdir(mode=0o700)
 for n,b in payload.items():
  p=X/n;p.parent.mkdir(exist_ok=True,parents=True,mode=0o700)
  fd=os.open(p,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o644)
  with os.fdopen(fd,'wb') as f:f.write(b)
 c('fresh_inert_extraction_readback',all((X/n).read_bytes()==b and stat.S_ISREG((X/n).lstat().st_mode) and stat.S_IMODE((X/n).lstat().st_mode)==0o644 for n,b in payload.items()),{'directory':str(X),'executed_payloads':0})
 required=['README-START-HERE.md','CHECKPOINT.json','HANDOFF.md','NEXT-TASK.md','RECOVERY-STATUS.md','PROMPT-1-CONTINUE.md','PROMPT-2-RECOVER.md','HISTORICAL-DEPENDENCIES.json','MANIFEST-SHA256.json']
 c('all_handoff_required_root_files',all(n in names for n in required),required)
 cp=json.loads(payload['CHECKPOINT.json']); phase=json.loads((R/'p15-session/PHASE.json').read_bytes())
 c('declared_scope_acceptance_and_stop_match',all(cp[k]==phase[k] for k in ['task','phase','scope','acceptance','constraints','stop','source_revision','source_tree','parent_status','parent_complete','phase_table','exact_next_action']),{'technical_work_begun':False,'source':cp['source_revision']})
 c('observed_main_includes_explicit_observation_time',bool(cp['observed_main'].get('observed_at_utc')),{'actual_observed_main':cp['observed_main'],'required':'HANDOFF CHECKPOINT: observed main SHA/tree/time. declared_at_utc labels phase declaration, not main observation. Add a verified current observation time; do not invent historical timing.'})
 c('save_pending_is_correctly_current',cp['early_save_confirmed'] is False and cp['delivery']['status']=='save_pending_at_freeze',{'state':cp['status'],'delivery':cp['delivery']})
 text='\n'.join(payload[n].decode() for n in ['README-START-HERE.md','HANDOFF.md','NEXT-TASK.md','RECOVERY-STATUS.md'])
 c('P14_completed_delivery_separate_from_P15_pending_save','Do not replay those completed writes' in text and 'Completed P14 writes must not be repeated' in text,{'previous_delivery':'confirmed by later exact receipt/confirmation and current markers','current_early_save':'pending'})
 c('bounded_executable_next_action_and_parent_limits',cp['integration_allowed'] is False and cp['main_lease_held'] is False and cp['parent_complete'] is False and 'First concrete' in cp['stop'] and 'before H1' in cp['constraints'][2] if False else (cp['integration_allowed'] is False and cp['main_lease_held'] is False and cp['parent_complete'] is False and 'First concrete' in cp['stop'] and 'No H1/' in cp['constraints'][2]),{'next':cp['exact_next_action'],'boundary':cp['stop'],'unrun':'H0 acceptance/H1/installations/Node/ldd/original-seven/full routine/integration'})
 c('current_and_historical_operations_distinguished',cp['current_unknown_operations']==[] and len(cp['historical_unknowns'])==3 and len(cp['worker_state'])==3,{'workers_at_freeze':cp['worker_state'],'historical_unknowns':cp['historical_unknowns']})
 sm=json.loads(payload['SOURCE-MANIFEST.json']); tree={}
 for row in g('ls-tree','-rz',H).split(b'\0'):
  if row:
   meta,path=row.split(b'\t',1);mode,kind,oid=meta.decode().split();tree[path.decode()]={'mode':mode,'kind':kind,'oid':oid}
 source_tree=g('rev-parse',H+'^{tree}').decode().strip()
 available=set(g('cat-file','--batch-all-objects','--batch-check=%(objectname)').decode().splitlines())
 wanted=sorted({r['git_blob'] for r in sm}); missing=[oid for oid in wanted if oid not in available]
 if missing:raise ValueError('current source blob absent from local object database: '+','.join(missing))
 out=g('cat-file','--batch',data=('\n'.join(wanted)+'\n').encode());cursor=0;blobs={}
 while cursor<len(out):
  end=out.index(b'\n',cursor);oid,kind,size=out[cursor:end].decode().split();size=int(size);cursor=end+1;blobs[oid]=out[cursor:cursor+size];cursor+=size+1
 bindings=[]
 for r in sm:
  b=payload[r['member']];meta=tree[r['path']]
  ok=r['commit']==H and r['tree']==source_tree and meta=={'mode':r['git_mode'],'kind':'blob','oid':r['git_blob']} and b==blobs[r['git_blob']] and len(b)==r['bytes'] and sha(b)==r['sha256']
  bindings.append({'path':r['path'],'blob':r['git_blob'],'passed':ok})
 audit['source_bindings']=bindings
 c('all_53_frozen_sources_equal_exact_committed_blobs',len(sm)==53 and all(r['passed'] for r in bindings),{'count':len(sm),'source_revision':H,'tree':source_tree,'local_object_database_comparison':True})
 rm=json.loads(payload['RECOVERY-FILE-MAP.json']);rresults=[]
 for r in rm:
  p=Path(r['original_path']);b=payload[r['member']];exact_current=p.exists() and p.read_bytes()==b; preserved_prior=False
  if not exact_current and p.name=='audit_startup.py':
   prior=p.with_name('audit_startup_attempt001.py');preserved_prior=prior.exists() and prior.read_bytes()==b
  rresults.append({'member':r['member'],'manifest_match':len(b)==r['bytes'] and sha(b)==r['sha256'],'original_current_bytes_match':exact_current,'preserved_prior_version_matches':preserved_prior})
 audit['recovery_bindings']=rresults
 c('all_16_recovery_payloads_bound_and_preserved',len(rm)==16 and all(r['manifest_match'] and (r['original_current_bytes_match'] or r['preserved_prior_version_matches']) for r in rresults),{'count':len(rm),'post_freeze_review_helper_change':'old frozen helper bytes also retained in audit_startup_attempt001.py; current corrections belong to later final handoff'})
 prompts=[]
 for member,suffix in [('PROMPT-1-CONTINUE.md','Continue'),('PROMPT-2-RECOVER.md','Recover')]:
  p=P.with_name(P.stem+'_'+suffix+'.md')
  prompts.append({'member':member,'separate_path':str(p),'exists':p.exists(),'exact_match':p.exists() and p.read_bytes()==payload[member],'bytes':len(payload[member]),'sha256':sha(payload[member])})
 audit['prompts']=prompts
 c('matching_complete_continue_recover_prompts',all(r['exact_match'] for r in prompts) and all(P.name in payload[r['member']].decode() for r in prompts),prompts)
 deps=json.loads(payload['HISTORICAL-DEPENDENCIES.json']); p14=deps['P14'];p14audit=R/'p15-session/receipt-review/AUDIT.json'
 c('exact_P14_and_C262_historical_dependencies_retained',p14['sha256']=='96dd48ac7cfe01219f57a48a3adfaacb1faa21325f72c5ad06ca19fcd54760cd' and p14['bytes']==88651427 and deps['C262']['bytes']==532260846 and deps['C262']['sha256']=='b8af544f730a4d1f741d47b56eb3fcf76147ed392a9ebb020f3d966f2f305c90',deps)
 c('prior_saved_files_equal_current_intake',all(payload['predecessor/saved-receipts/'+p.name]==p.read_bytes() for p in (R/'input/p14-saved/OntoKin').iterdir()),{'files':4,'P14_archive':'external verified immutable dependency'})
 c('required_repository_snapshot_roles_present',all('repository/'+p in names for p in ['CHATGPT-START-HERE.md','AGENTS.md','GOAL.md','STATUS.md','ROLE.md','docs/workflow/registry.json','docs/workflow/CURRENT.json','docs/workflow/PROTOCOL.md','docs/workflow/HANDOFF.md','docs/workflow/tasks/C271/REQUIREMENTS.md','docs/workflow/tasks/C271/PLAN.md','docs/workflow/tasks/C271/task.json','.agents/skills/ontokin-delivery/SKILL.md','.agents/skills/ontokin-session/SKILL.md','.agents/skills/ontokin-learning/SKILL.md']),{'snapshots':53,'full_selected_skill_files':3})
audit['verdict']='accepted_for_early_save' if not findings else 'changes_required_before_early_save'
audit['runtime_or_product_execution']=False;audit['git_or_library_mutations']=[];audit['current_jobs']=[]
(O/'AUDIT.json').write_text(json.dumps(audit,indent=2,sort_keys=True)+'\n')
report='''# P15 early recovery package review\n\nReviewer: `/root/receipt_reconciliation`. Candidate: `%s`, %d bytes, SHA-256 `%s`.\n\n**Verdict: %s.**\n\nThe independent audit verified all 81 ZIP members, all 80 manifest payloads, CRCs, safe unique relative paths, inert 0644 modes, fresh extraction/readback, all 53 exact Git blob bindings, all 16 mapped recovery files and both standalone prompt byte matches. The four prior saved P14 files match intake bytes. P14 and C262 dependencies retain exact identities and online-continuation limits.\n\n## Mandatory finding\n\nP15-EARLY-001: `CHECKPOINT.json.observed_main` records main SHA/tree and the observation file, but no observation time. HANDOFF explicitly requires observed main SHA/tree/time. `declared_at_utc` identifies phase declaration and must not silently be relabelled as the Git observation time. Record a verified observation timestamp in a distinct corrected candidate; preserve this frozen candidate.\n\nNo other mandatory finding was identified. Recovery instructions are executable and bounded: verify the exact external receipt, finish startup reconciliation, review exact-loader source/build completeness, proceed to plan eligibility only on acceptance, and stop at the first concrete blocker or before H1. P14 completed delivery is correctly separated from P15's pending early save. Parent C271 stays blocked/open; no lease or integration authority is asserted.\n\nThe old audit helper captured at package freeze has changed during subsequent review; its exact frozen bytes also remain in `scratch/audit_startup_attempt001.py`. Later review outputs and helper corrections belong in the final handoff, not a silent alteration of this early archive.\n\nNo host/runtime target, recovered script, test or package payload was executed. Git use was local read-only; no publication or Library save occurred. No active job remains in this review. Root owns correction, new candidate verification and eventual save/readback.\n'''%(P.name,len(raw),sha(raw),audit['verdict'])
(O/'REPORT.md').write_text(report)
print(json.dumps({'verdict':audit['verdict'],'checks':len(checks),'passed':sum(c['passed'] for c in checks),'mandatory_findings':findings,'report':str(O/'REPORT.md')}))
