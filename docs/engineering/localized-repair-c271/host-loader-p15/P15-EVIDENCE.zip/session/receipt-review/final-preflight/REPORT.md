# Final-package selection preflight

The current builder will retain one unnecessary derived tree: `receipt-review/scratch/early-attempt002-extraction`. It contains 101 files and 5,690,391 logical bytes, including another copy of the first early ZIP. Add a verified exclusion for that tree before final freeze. Do not delete its source history.

I compared all four recovery extraction trees against their exact source ZIP bytes. Every inventory and byte comparison passed. The four trees contain 384 files and 30,352,601 logical bytes; all are reconstructible from retained or confirmed saved inputs.

| Session-relative tree | Files | Logical bytes | Exact source |
| --- | ---: | ---: | --- |
| `receipt-review/scratch/early-extraction` | 81 | 3,486,658 | retained_archive |
| `receipt-review/scratch/post-freeze` | 145 | 19,645,560 | embedded_archive |
| `receipt-review/scratch/publication-evidence` | 57 | 1,529,992 | embedded_archive |
| `receipt-review/scratch/early-attempt002-extraction` | 101 | 5,690,391 | confirmed_external_archive |

The JSON recommendation file records each archive digest, outer receipt identity where applicable, precise embedded field, saved IDs and recovery path. The first three trees are already excluded. The fourth is recoverable from the confirmed early Attempt002 archive, SHA-256 `503ce4e25414612739a0259236bf37134c254987d494dfcfaab4d727fd5d0004`, bound by the included early receipt. Recheck these trees at freeze: added or modified files are unique evidence and must be preserved separately.

Keep every unique script, report, review, read-set, failed helper/host/retrieval attempt, publication/save record and actual source/build input. Retain selected source text and patch context as reviewed evidence, even when original archives also exist. Keep the inert loader/package/source archives and their manifests. Preserve the original early ZIP once under `early-history/attempt001`; avoid selecting copies inside derived extractions. Do not place final archives, readbacks or verifier extractions under the builder's recursively selected session root.

Before final mode, require an outcome-specific `HANDOFF.md` and updated PHASE gates, next action, observations, worker and unknown-operation states. The current fallback would label a final package with early-startup prose if HANDOFF is absent. No technical conclusion is made here.

## Review gates

The final independent audit will verify exact source/tree/blob identities, required handoff contents, honest phase/parent limits, complete unique-byte preservation, explicit recoverable exclusions, safe ZIP/CRC/manifest/hash checks, fresh extraction and matching prompts. The separate receipt audit will bind actual saved IDs/versions/readbacks to the frozen ZIP and published source, preserve unique post-freeze evidence without embedding the final ZIP again, and leave its own future save to a later exact confirmation.

This inventory was observed while other workers remained active; it is not the final selection snapshot. I changed only this report and its JSON recommendation file. No builder, archive, canonical record, Git/index or Library changes occurred. No reviewer process remains active. Await the Director's exact final candidate.
