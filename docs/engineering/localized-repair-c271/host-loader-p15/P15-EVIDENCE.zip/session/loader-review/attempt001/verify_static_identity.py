"""Independent bounded byte review; import and execute no product/target file."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import stat
import struct
import sys

ROOT = Path('/workspace/scratch/5041e572c132')
CANDIDATE = ROOT / 'p15-session/host-evidence-attempt002'
OUTPUT = ROOT / 'p15-session/loader-review/attempt001/STATIC-IDENTITY-REVIEW.json'
PYTHON = Path('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_regular(path, limit):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_size <= limit
        with os.fdopen(os.dup(fd), 'rb') as stream:
            raw = stream.read(limit + 1)
        after = os.fstat(fd)
        fields = ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns')
        assert all(getattr(before, key) == getattr(after, key) for key in fields)
        assert len(raw) == before.st_size
        return raw, {key: getattr(before, key) for key in fields}
    finally:
        os.close(fd)


def elf_identity(raw):
    assert len(raw) >= 64 and raw[:7] == b'\x7fELF\x02\x01\x01'
    _, machine, version = struct.unpack_from('<HHI', raw, 16)
    assert version == 1 and machine == 62
    offset = struct.unpack_from('<Q', raw, 32)[0]
    entry_size, count = struct.unpack_from('<HH', raw, 54)
    assert entry_size == 56 and 0 < count <= 1024
    assert offset + entry_size * count <= len(raw)
    interpreters, build_ids = [], []
    for index in range(count):
        row = struct.unpack_from('<IIQQQQQQ', raw, offset + index * entry_size)
        kind, begin, length = row[0], row[2], row[5]
        assert begin + length <= len(raw)
        if kind == 3:
            data = raw[begin:begin + length]
            assert data.endswith(b'\0') and b'\0' not in data[:-1]
            interpreters.append(data[:-1].decode('ascii'))
        elif kind == 4:
            cursor, end = begin, begin + length
            while cursor < end:
                assert cursor + 12 <= end
                name_size, value_size, note_type = struct.unpack_from('<III', raw, cursor)
                name_at = cursor + 12
                value_at = name_at + ((name_size + 3) // 4) * 4
                next_at = value_at + ((value_size + 3) // 4) * 4
                assert name_at + name_size <= end and value_at + value_size <= end and next_at <= end
                if raw[name_at:name_at + name_size] == b'GNU\0' and note_type == 3:
                    build_ids.append(raw[value_at:value_at + value_size].hex())
                cursor = next_at
    return {'machine': machine, 'interpreter': interpreters, 'gnu_build_ids': build_ids}


def path_rows(paths):
    rows = []
    for value in paths:
        path = Path(value)
        observed = path.lstat()
        rows.append({'path': str(path), 'device': observed.st_dev, 'inode': observed.st_ino,
                     'mode': oct(stat.S_IMODE(observed.st_mode)),
                     'kind': 'symlink' if stat.S_ISLNK(observed.st_mode) else 'directory' if stat.S_ISDIR(observed.st_mode) else 'file',
                     'target': os.readlink(path) if stat.S_ISLNK(observed.st_mode) else None})
    return rows


manifest_raw, _ = read_regular(CANDIDATE / 'MANIFEST.json', 65536)
manifest = json.loads(manifest_raw)
assert set(manifest) == {'IDENTITY.json', 'dpkg-selected-status.txt', 'etc__os-release',
                         'loader.elf.inert', 'usr__share__doc__libc6__copyright'}
assert {p.name for p in CANDIDATE.iterdir()} == set(manifest) | {'MANIFEST.json'}
verified_members = []
for name, expected in manifest.items():
    raw, details = read_regular(CANDIDATE / name, 1024 * 1024)
    assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256']
    verified_members.append({'path': name, 'bytes': len(raw), 'sha256': sha(raw),
                             'mode': oct(stat.S_IMODE(details['st_mode']))})
identity = json.loads((CANDIDATE / 'IDENTITY.json').read_bytes())
collector, _ = read_regular(identity['collector'], 1024 * 1024)
assert sha(collector) == identity['collector_sha256']

python_bytes, python_stat = read_regular(PYTHON, 64 * 1024 * 1024)
assert sha(python_bytes) == identity['selected_python_pin']['sha256']
assert len(python_bytes) == identity['selected_python_pin']['bytes']
assert oct(stat.S_IMODE(python_stat['st_mode'])) == identity['selected_python_pin']['mode']
assert python_stat['st_nlink'] == 1
python_elf = elf_identity(python_bytes)
assert python_elf['interpreter'] == ['/lib64/ld-linux-x86-64.so.2']
assert python_elf['gnu_build_ids'] == identity['python_elf']['gnu_build_ids']
python_chain = path_rows([*reversed(PYTHON.parents), PYTHON])
assert all(row['kind'] != 'symlink' for row in python_chain)
assert python_chain == identity['canonical_python_path_chain']

named_loader = Path(python_elf['interpreter'][0])
resolved_loader = named_loader.resolve(strict=True)
assert str(resolved_loader) == identity['loader']['resolved_path']
loader_bytes, loader_stat = read_regular(resolved_loader, 1024 * 1024)
inert_bytes, inert_stat = read_regular(CANDIDATE / 'loader.elf.inert', 1024 * 1024)
assert loader_bytes == inert_bytes
assert len(loader_bytes) == identity['loader']['bytes'] and sha(loader_bytes) == identity['loader']['sha256']
assert loader_stat['st_dev'] == identity['loader']['device'] and loader_stat['st_ino'] == identity['loader']['inode']
assert stat.S_IMODE(inert_stat['st_mode']) & 0o111 == 0
loader_elf = elf_identity(inert_bytes)
assert loader_elf['gnu_build_ids'] == ['86f7eb4ff495ed3f2831c6d3d662e4321762a2a3']
assert loader_elf['interpreter'] == []
loader_chain = path_rows(['/', '/lib64', '/usr', '/usr/lib64',
                         '/usr/lib64/ld-linux-x86-64.so.2', '/usr/lib',
                         '/usr/lib/x86_64-linux-gnu', str(resolved_loader)])
assert os.readlink('/lib64') == 'usr/lib64'
assert os.readlink('/usr/lib64/ld-linux-x86-64.so.2') == '../lib/x86_64-linux-gnu/ld-linux-x86-64.so.2'

version_offset = inert_bytes.index(b'ld.so (Debian GLIBC ')
version_end = inert_bytes.index(b'\0', version_offset)
version_string = inert_bytes[version_offset:version_end].decode('ascii')
metadata_absence = []
for name in ['/var/lib/dpkg/status', '/var/lib/dpkg/info/libc6:amd64.md5sums',
             '/usr/share/doc/libc6/changelog.Debian.gz']:
    try:
        Path(name).lstat()
    except FileNotFoundError:
        metadata_absence.append({'path': name, 'state': 'absent'})
    else:
        metadata_absence.append({'path': name, 'state': 'present'})

report = {
    'schema': 'ontokin.c271.p15-independent-static-loader-identity/1',
    'reviewer': '/root/loader_review',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'static_identity_correspondence_verified_only',
    'candidate_manifest': {'path': str(CANDIDATE / 'MANIFEST.json'), 'bytes': len(manifest_raw), 'sha256': sha(manifest_raw)},
    'verified_members': verified_members,
    'collector': {'path': identity['collector'], 'sha256': sha(collector), 'source_inspected': True},
    'python': {'path': str(PYTHON), 'bytes': len(python_bytes), 'sha256': sha(python_bytes),
               'elf': python_elf, 'path_chain': python_chain},
    'loader': {'path': str(resolved_loader), 'bytes': len(loader_bytes), 'sha256': sha(loader_bytes),
               'elf': loader_elf, 'path_chain_including_intermediate_alias_directory': loader_chain,
               'inert_copy_identical_to_current_resolved_file': True,
               'raw_version_string': {'offset': version_offset, 'value': version_string}},
    'package_metadata': metadata_absence,
    'observation_interpreter': {'sys_executable': sys.executable, 'proc_self_exe': os.readlink('/proc/self/exe')},
    'limits': ['This identifies bytes and their present Python-to-loader path relation only.',
               'The raw embedded version and GNU build ID do not independently authenticate a corresponding source/build.',
               'No compiled/default/hardware/TLS suffix completeness or operational plan eligibility has been accepted.',
               'No product module, inspected loader, Node or ldd was executed.'],
    'active_jobs': [],
    'next_action': 'Await the frozen provenance mapping or gap report; independently decide the first external source-completeness gate.'
}
OUTPUT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'verdict': report['verdict'], 'manifest_payloads_verified': len(verified_members),
                  'python_sha256': sha(python_bytes), 'loader_sha256': sha(loader_bytes),
                  'raw_version_string': report['loader']['raw_version_string'],
                  'report': str(OUTPUT)}, indent=2))
