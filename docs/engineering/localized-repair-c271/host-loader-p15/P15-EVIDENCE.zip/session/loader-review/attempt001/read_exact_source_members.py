"""Materialize explicitly selected source text as inert review data only."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import re
import tarfile

ROOT = Path('/workspace/scratch/5041e572c132/p15-session')
DOWNLOADS = ROOT / 'source-provenance/downloads-attempt001'
OUT = ROOT / 'loader-review/attempt001/source-text'
OUT.mkdir(exist_ok=False)


def sha(data):
    return hashlib.sha256(data).hexdigest()


dsc = (DOWNLOADS / 'glibc_2.41-12+deb13u4.dsc').read_bytes()
assert sha(dsc) == '0915324aa646bb99abfaa9aa6ecb734b30babd28454a3e51f3152912370fbd3e'
assert b'\nSource: glibc\n' in dsc and b'\nVersion: 2.41-12+deb13u4\n' in dsc
sha_section = dsc.decode('ascii').split('Checksums-Sha256:\n', 1)[1].split('Files:\n', 1)[0]
pins = {}
for line in sha_section.splitlines():
    digest, size, name = line.split()
    pins[name] = {'sha256': digest, 'bytes': int(size)}
selected = {
    'elf/dl-hwcaps.c', 'elf/dl-hwcaps.h', 'elf/dl-hwcaps_split.c',
    'elf/dl-hwcaps-subdirs.c', 'elf/dl-load.c', 'elf/dl-main.h', 'elf/rtld.c',
    'elf/Makefile', 'sysdeps/x86_64/dl-hwcaps-subdirs.c',
    'sysdeps/x86/get-isa-level.h', 'sysdeps/x86/isa-level.h',
    'sysdeps/unix/sysv/linux/dl-origin.c', 'sysdeps/x86_64/Implies',
    'sysdeps/unix/sysv/linux/x86_64/Implies', 'sysdeps/unix/sysv/linux/x86_64/64/Implies'
}
archive_records, source_members, patch_data = [], [], {}
for archive_name in pins:
    archive_path = DOWNLOADS / archive_name
    raw = archive_path.read_bytes()
    assert len(raw) == pins[archive_name]['bytes'] and sha(raw) == pins[archive_name]['sha256']
    seen, total, count = set(), 0, 0
    with tarfile.open(archive_path, 'r|xz') as archive:
        for member in archive:
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts and member.name not in seen
            seen.add(member.name)
            count += 1
            total += member.size
            assert count <= 50000 and member.size <= 16 * 1024 * 1024 and total <= 512 * 1024 * 1024
            if not member.isfile():
                continue
            original_rel = member.name.removeprefix('glibc-2.41/')
            wanted = (member.name.startswith('glibc-2.41/') and original_rel in selected)
            wanted |= member.name in {'debian/patches/series', 'debian/rules', 'debian/rules.d/build.mk',
                                     'debian/sysdeps/amd64.mk', 'debian/sysdeps/linux.mk'}
            is_patch = member.name.startswith('debian/patches/')
            if not wanted and not is_patch:
                continue
            data = archive.extractfile(member).read()
            assert len(data) == member.size
            if is_patch:
                patch_data[member.name.removeprefix('debian/patches/')] = data
            if wanted:
                local_rel = original_rel if member.name.startswith('glibc-2.41/') else member.name
                destination = OUT / local_rel
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_bytes(data)
                destination.chmod(0o644)
                source_members.append({'archive': archive_name, 'member': member.name, 'local_path': str(destination),
                                       'bytes': len(data), 'sha256': sha(data), 'human_read_status': 'materialized_for_review'})
    archive_records.append({'archive': archive_name, **pins[archive_name], 'members_seen': count, 'declared_total_bytes': total})

active = []
for line in patch_data['series'].decode('utf-8').splitlines():
    line = line.strip()
    if line and not line.startswith('#'):
        active.append(line.split()[0])
patches = []
for name in active:
    data = patch_data[name]
    text = data.decode('utf-8')
    paths = sorted(set(re.findall(r'^(?:---|\+\+\+)\s+([^\t\n ]+)', text, flags=re.M)))
    normalized = [path[2:] if path.startswith(('a/', 'b/')) else path for path in paths]
    relevant = any(any(token in path for token in ['dl-hwcaps', 'dl-load.c', 'rtld.c', 'dl-main.h', 'dl-origin.c',
                                                  'dl-cache.h', 'Makeconfig', 'elf/Makefile', 'configure']) for path in normalized)
    row = {'patch': name, 'bytes': len(data), 'sha256': sha(data), 'paths': paths, 'relevant_by_path': relevant}
    if relevant:
        destination = OUT / 'active-patches' / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        destination.chmod(0o644)
        row['local_path'] = str(destination)
    patches.append(row)
report = {'schema': 'ontokin.c271.p15-independent-source-member-readset/1',
          'source_dsc_sha256': sha(dsc), 'archives': archive_records, 'members': source_members,
          'active_patch_count': len(active), 'active_patches': patches,
          'signature_check': 'OpenPGP signature retained but not locally validated; no signature verification is claimed.',
          'limits': 'Materialized source text and active patch paths only; no configure, compiler, patch application or target execution.'}
(OUT.parent / 'SOURCE-MEMBERS.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'archives': archive_records, 'source_files': len(source_members), 'active_patches': len(active),
                  'relevant_patches': [x for x in patches if x['relevant_by_path']],
                  'report': str(OUT.parent / 'SOURCE-MEMBERS.json')}, indent=2))
