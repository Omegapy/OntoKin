"""Read Debian ar/tar members in memory; never install or extract a target."""
from pathlib import Path, PurePosixPath
import datetime
import hashlib
import io
import json
import tarfile

ROOT = Path('/workspace/scratch/5041e572c132/p15-session')
OUT = ROOT / 'loader-review/attempt001'
PACKAGE = ROOT / 'package-retrieval/libc6_2.41-12+deb13u4_amd64.deb.inert'
EXPECTED = '967aa62605721081c3eb2a17650611a792aa802d76a6511d1840242623d204c9'


def sha(value):
    return hashlib.sha256(value).hexdigest()


raw = PACKAGE.read_bytes()
assert len(raw) == 2846580 and sha(raw) == EXPECTED
assert raw[:8] == b'!<arch>\n'
offset, members, ar_records = 8, {}, []
while offset < len(raw):
    header = raw[offset:offset + 60]
    assert len(header) == 60 and header[-2:] == b'`\n'
    name = header[:16].decode('ascii').strip().rstrip('/')
    size = int(header[48:58])
    assert name and '/' not in name and name not in members and 0 <= size <= 8 * 1024 * 1024
    begin, end = offset + 60, offset + 60 + size
    assert end <= len(raw)
    payload = raw[begin:end]
    members[name] = payload
    ar_records.append({'name': name, 'bytes': len(payload), 'sha256': sha(payload)})
    offset = end + (size % 2)
assert offset == len(raw) and set(members) == {'debian-binary', 'control.tar.xz', 'data.tar.xz'}
assert members['debian-binary'] == b'2.0\n'


def read_selected_tar(payload, selected):
    result, rows, seen, total = {}, [], set(), 0
    with tarfile.open(fileobj=io.BytesIO(payload), mode='r|xz') as archive:
        for member in archive:
            name = str(PurePosixPath(member.name))
            assert not name.startswith('/') and '..' not in PurePosixPath(name).parts
            assert name not in seen and len(seen) < 10000
            seen.add(name)
            total += member.size
            assert 0 <= member.size <= 64 * 1024 * 1024 and total <= 128 * 1024 * 1024
            if name not in selected:
                continue
            assert member.isfile()
            stream = archive.extractfile(member)
            assert stream is not None
            data = stream.read(member.size + 1)
            assert len(data) == member.size
            result[name] = data
            rows.append({'member': member.name, 'normalized_member': name, 'bytes': len(data),
                         'sha256': sha(data), 'mode': oct(member.mode), 'mtime': member.mtime,
                         'uid': member.uid, 'gid': member.gid, 'type': 'regular_file'})
    assert set(result) == set(selected)
    return result, rows, {'member_count': len(seen), 'declared_bytes': total}


control_files, control_rows, control_inventory = read_selected_tar(members['control.tar.xz'], {'control', 'md5sums'})
loader_name = 'usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2'
loader_files, loader_rows, data_inventory = read_selected_tar(members['data.tar.xz'], {loader_name})
loader = loader_files[loader_name]
actual = (ROOT / 'host-evidence-attempt002/loader.elf.inert').read_bytes()
assert loader == actual
assert len(loader) == 225672 and sha(loader) == 'c8438e4fde1934e61c88311633f00949ff645d5c04cdb8671fa3d78164d2f307'
assert loader_rows[0]['mode'] == '0o755'
control = control_files['control'].decode('utf-8')
fields = {}
for line in control.splitlines():
    if line and not line.startswith((' ', '\t')):
        key, value = line.split(':', 1)
        fields[key] = value.strip()
required = {'Package': 'libc6', 'Source': 'glibc', 'Version': '2.41-12+deb13u4', 'Architecture': 'amd64'}
assert {key: fields[key] for key in required} == required
md5_rows = dict((line.split(None, 1)[1], line.split(None, 1)[0]) for line in control_files['md5sums'].decode('ascii').splitlines())
assert md5_rows[loader_name] == hashlib.md5(loader).hexdigest()
(OUT / 'PACKAGE-CONTROL.txt').write_bytes(control_files['control'])
report = {
    'schema': 'ontokin.c271.p15-independent-package-loader-binding/1',
    'reviewer': '/root/loader_review',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'exact_package_member_correspondence_verified',
    'package': {'path': str(PACKAGE), 'bytes': len(raw), 'sha256': sha(raw),
                'reported_origin': 'https://deb.debian.org/debian/pool/main/g/glibc/libc6_2.41-12+deb13u4_amd64.deb',
                'origin_receipt': str(ROOT / 'package-retrieval/RESULT.json')},
    'ar_members': ar_records,
    'control_members': control_rows,
    'control_inventory': control_inventory,
    'package_control_fields': required,
    'loader_member': loader_rows[0],
    'data_inventory': data_inventory,
    'loader_member_equals_bound_host_inert_copy': True,
    'internal_md5_matches_loader_member': True,
    'method': 'Independent ar container parsing and in-memory xz tar reading; member/control bytes checked without filesystem extraction or package execution.',
    'limits': ['Package identity and source-package/version metadata provide a concrete binary correspondence; they do not alone establish suffix semantics.',
               'Source algorithm, architecture/build configuration, Debian patches and suffix completeness still require independent review.',
               'Root HTTPS origin receipt is retained; this report does not claim a separate package-signature verification.',
               'Python standard-library review script ran; no installation, direct loader/Node/ldd or product inspector ran.'],
    'active_jobs': []
}
(OUT / 'PACKAGE-BINDING-REVIEW.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'verdict': report['verdict'], 'package_sha256': sha(raw),
                  'loader_member': loader_rows[0], 'control_fields': required,
                  'report': str(OUT / 'PACKAGE-BINDING-REVIEW.json')}, indent=2))
