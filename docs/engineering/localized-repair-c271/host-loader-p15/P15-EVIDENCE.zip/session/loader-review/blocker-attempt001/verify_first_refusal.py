"""Static independent crosscheck of the already recorded first refusal.

Does not import the product, rerun its helper, launch an inspected image,
evaluate subsequent gates, or modify any input.
"""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import stat
import struct

SESSION = Path('/workspace/scratch/5041e572c132/p15-session')
HERE = SESSION / 'loader-review/blocker-attempt001'
ADMISSION = SESSION / 'h0-static-admission-attempt001'
SOURCE = Path('/workspace/scratch/5041e572c132/OntoKin/prototypes/static_tray_v01/current_host_inspection_v01.py')
EXPECTED_SOURCE = 'a8274d56076562a91d26b3cdd2f614fce6fd509733e4939b225dff2ddca09db4'
EXPECTED_LIBC = '9792e3cbb541c8f44c7acf5f14f4022ea62998ecc787d326bed4d8b6547dfd92'
INPUTS = []


def read(path):
    raw = path.read_bytes()
    INPUTS.append({'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    return raw


def document(path):
    return json.loads(read(path))


intent = document(ADMISSION / 'INTENT.json')
outcome = document(ADMISSION / 'OUTCOME.json')
libc = document(ADMISSION / 'current-python-loaded-libc-RESULT.json')
loader = document(ADMISSION / 'bound-loader-RESULT.json')
acceptance = read(SESSION / 'SOURCE-COMPLETENESS-ACCEPTANCE.json')
collector = read(SESSION / 'observe_core_elf_admission.py')
source = read(SOURCE)
assert hashlib.sha256(source).hexdigest() == EXPECTED_SOURCE
assert intent['source_sha256'] == outcome['source_sha256'] == EXPECTED_SOURCE
assert hashlib.sha256(acceptance).hexdigest() == intent['source_completeness_acceptance_sha256']
assert outcome['observations'] == [loader, libc]
assert intent['inputs'] == [[loader['role'], loader['path']], [libc['role'], libc['path']]]
assert loader['outcome'] == 'metadata_returned'
assert libc['outcome'] == 'typed_refusal'
assert libc['refusal'] == {'code': 'CHI-UNSUPPORTED', 'reason': 'Unreviewed ELF dynamic loader feature',
                           'state': 'REJECTED', 'cause': None, 'details': {}}
assert outcome['stopped_at_first_refusal'] is True and outcome['remaining_input_checks'] == 'not_run'
assert outcome['H0_accepted'] is False and outcome['H1_approved'] is False
assert outcome['production_module_imported_and_data_reader_called'] is True

# Read the product as text/AST only. The fixed allowlist below is independently
# compared with its literal assignment, without executing any product code.
text = source.decode('utf-8')
tree = ast.parse(text)
fn = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_read_elf_metadata')
assignment = next(n for n in ast.walk(fn) if isinstance(n, ast.Assign)
                  and any(isinstance(t, ast.Name) and t.id == 'ordinary' for t in n.targets))
allowed = set(range(1, 31)) | {32, 33, 34, 35, 36, 37, 0x6FFFFEF5, 0x6FFFFFF0,
                            0x6FFFFFF9, 0x6FFFFFFA, 0x6FFFFFFB, 0x6FFFFFFC,
                            0x6FFFFFFD, 0x6FFFFFFE, 0x6FFFFFFF}
expected_assignment = ast.parse('ordinary = set(range(1, 31)) | {32, 33, 34, 35, 36, 37, 0x6FFFFEF5, 0x6FFFFFF0, 0x6FFFFFF9, 0x6FFFFFFA, 0x6FFFFFFB, 0x6FFFFFFC, 0x6FFFFFFD, 0x6FFFFFFE, 0x6FFFFFFF}').body[0]
assert ast.dump(assignment, include_attributes=False) == ast.dump(expected_assignment, include_attributes=False)
require_calls = [n for n in ast.walk(fn) if isinstance(n, ast.Call)
                 and isinstance(n.func, ast.Name) and n.func.id == '_require']
feature = next(n for n in require_calls if len(n.args) >= 3
               and isinstance(n.args[2], ast.Constant)
               and n.args[2].value == 'Unreviewed ELF dynamic loader feature')
flags = next(n for n in require_calls if len(n.args) >= 3
             and isinstance(n.args[2], ast.Constant)
             and n.args[2].value == 'Unsupported dynamic flags')
assert ast.unparse(feature.args[0]) == 'all((tag in ordinary for tag, _ in entries))'
assert feature.lineno == 1162 and flags.lineno > feature.lineno

raw = read(ADMISSION / 'current-python-loaded-libc.elf.inert')
assert len(raw) == libc['bytes'] == 1995216
assert hashlib.sha256(raw).hexdigest() == libc['sha256'] == EXPECTED_LIBC
assert raw[:7] == b'\x7fELF\x02\x01\x01'
elf_type, machine, version = struct.unpack_from('<HHI', raw, 16)
assert (elf_type, machine, version) == (3, 62, 1)
phoff = struct.unpack_from('<Q', raw, 32)[0]
ehsize, phentsize, phnum = struct.unpack_from('<HHH', raw, 52)
assert ehsize == 64 and phentsize == 56 and 0 < phnum <= 256
tables = []
for index in range(phnum):
    kind, _, offset, _, _, length, _, _ = struct.unpack_from('<IIQQQQQQ', raw, phoff + index * phentsize)
    if kind == 2:
        assert 0 < length <= 65536 and length % 16 == 0 and offset + length <= len(raw)
        tables.append((offset, length))
assert len(tables) == 1
entries = []
offset, length = tables[0]
for at in range(offset, offset + length, 16):
    tag, value = struct.unpack_from('<qQ', raw, at)
    entries.append({'offset': at, 'tag': tag, 'value': value, 'value_hex': hex(value)})
    if tag == 0:
        break
assert entries[-1]['tag'] == 0 and entries == libc['raw_dynamic']
excluded = [dict(row, tag_hex=hex(row['tag'])) for row in entries if row['tag'] and row['tag'] not in allowed]
assert [row['tag'] for row in excluded] == [0x70000000, 0x70000001, 0x70000003]
assert excluded[0]['offset'] == 1980896

# Tie the preserved bytes back to the recorded actual pathname without launching
# the image. This is a current-file comparison, not a replay of historical maps.
actual_path = Path(libc['path'])
assert str(actual_path.resolve()) == libc['canonical_path'] == str(actual_path)
fd = os.open(actual_path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
try:
    before = os.fstat(fd)
    assert stat.S_ISREG(before.st_mode) and before.st_size == len(raw)
    actual = os.pread(fd, before.st_size, 0)
    after = os.fstat(fd)
finally:
    os.close(fd)
identity = lambda s: (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)
assert identity(before) == identity(after) == identity(actual_path.lstat())
assert (before.st_dev, before.st_ino) == (libc['device'], libc['inode'])
assert actual == raw

result = {
    'schema': 'ontokin.c271.p15-independent-first-refusal-crosscheck/1',
    'reviewer': '/root/loader_review',
    'recorded_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'inputs': INPUTS,
    'source_revision': intent['source_revision'],
    'source_sha256': EXPECTED_SOURCE,
    'recorded_observation_order': [row['role'] for row in outcome['observations']],
    'actual_libc': {'path': str(actual_path), 'bytes': len(raw), 'sha256': EXPECTED_LIBC,
                    'device': before.st_dev, 'inode': before.st_ino,
                    'current_bytes_equal_capture': True,
                    'mapped_role_evidence': 'Recorded collector selects its sole libc.so.6 path from /proc/self/maps before recording INTENT; this review does not reconstruct its historical process maps.'},
    'dynamic_table': {'offset': offset, 'bytes': length, 'entries_through_DT_NULL': len(entries),
                      'all_entries_equal_recorded_observation': True},
    'first_failed_predicate': {'line': feature.lineno, 'source': ast.get_source_segment(text, feature),
                               'first_falsifying_entry': excluded[0], 'all_excluded_entries': excluded,
                               'typed_refusal': libc['refusal']},
    'later_flags_predicate': {'line': flags.lineno, 'reached': False,
                             'recorded_DT_FLAGS': libc['raw_DT_FLAGS'],
                             'explanation': 'Preserved raw value only; not the observed refusal cause. No later-predicate evaluation was performed by this reviewer.'},
    'verdict': 'confirmed_first_actual_static_admission_refusal_phase_must_stop',
    'source_completeness_acceptance_preserved': True,
    'H0_accepted': False, 'operational_plan_adopted': False, 'H1_approved': False,
    'reviewer_execution': {'python_standard_library_static_review_ran': True,
                          'product_imported': False, 'original_helper_retried': False,
                          'direct_image_target_starts': 0, 'later_gates_investigated': False,
                          'repairs_or_product_changes': False},
    'active_jobs': []}
with (HERE / 'CROSSCHECK.json').open('x') as out:
    json.dump(result, out, indent=2)
    out.write('\n')
print(json.dumps({'verdict': result['verdict'], 'first_falsifying_entry': excluded[0],
                  'flags_predicate_reached': False, 'active_jobs': []}, indent=2))
