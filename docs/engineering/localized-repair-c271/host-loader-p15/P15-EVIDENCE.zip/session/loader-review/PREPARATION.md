# C271 P15 independent loader/source review preparation

Reviewer: `/root/loader_review`. Director: `/root`.
Prepared against supplied retained-branch revision `875c81c506d4e5431b909e190ce294c61312029e`; observed-main identity supplied by the Director is `e1a48f7d0635e9aa4f4b6d6a586e7305eb81999d`.

## Current disposition

Preparation only. The initial phase record says early recovery confirmation is pending. Technical review is not started until the Director explicitly confirms the early save and sends GO. This document makes no actual-host observation, source-completeness finding, operational-plan approval or runtime result.

## First prerequisite and exact input request

The first technical gate is P15-A02: an independently reviewable, source-complete suffix argument for the exact actual loader of the already selected Python. Supply an immutable candidate manifest covering:

1. Inert observations binding the selected Python and its ELF interpreter: original named paths, all alias hops, resolved canonical files, file sizes/modes/digests and raw ELF interpreter evidence. The selected Python pin remains SHA-256 `fa67443527ed9647f760d807e2a38f26340757123e643c4639cf273ed15d5ea7`, 30,894,944 bytes and operational mode `0o755`.
2. The actual loader's inert bytes or independently readable byte binding, identity/build evidence, and exact source/build or inspected implementation evidence. Explain the correspondence between that evidence and the actual binary, including any relevant distribution patches, build settings and architecture-specific code. Version strings and generic glibc references are insufficient.
3. Exact retained source locations and the argument deriving the complete finite suffix union, including the base empty suffix, compiled/default choices, hardware-capability directories and legacy hardware/TLS alternatives. Explain why every omitted alternative is impossible in the admitted setting. Distinguish observations from source-based inferences.
4. The candidate suffix inventory and rationale identities. Bind the conclusion to the exact loader descriptor and, if one is available and eligible, the corresponding proposed plan. Missing plan identity cannot be represented as approval of a future unknown plan.

A missing or contradictory correspondence/completeness argument is the first concrete blocker. Stop there; do not search for alternative runtimes, substitute inputs, repair implementation or invent a runtime refusal.

## Review checklist

| Order | Independent check | Required disposition |
| --- | --- | --- |
| 0 | Director confirms independently verified early save and GO; identify exact candidate bytes. | No technical work before this gate. |
| 1 | Verify actual Python-to-loader binding and the loader-to-source/build/implementation correspondence. Inspect the relevant exact evidence rather than relying on summaries or metadata strings. | First concrete mismatch or missing evidence stops technical review. |
| 2 | Challenge completeness of compiled/default, hardware and TLS suffix alternatives; verify complete finite union and justified exclusions. | External P13 review decision only. No runtime approval, completeness Boolean, fabricated exception or N57 runtime pass. |
| 3 | Only after source completeness passes, assess selected Python eligibility: exact pin, direct-main context, one exact raw RPATH, no RUNPATH, canonical guarded ASCII paths and nonsymlink origin/parent/lib directory chain. | No substitute image or execution origin derived from an inert evidence copy. |
| 4 | Check current kernel witness and file identity, `AT_SECURE=0`, complete admitted author/extension/inspector/Git/loader dependency closure and exact metadata pins. | An unresolved input or unsupported path blocks eligibility. |
| 5 | Derive the exact union of every admitted image's needed names; inspect complete present-directory entries and first-missing-component guards for every reviewed suffix. | Any needed-name entry of any filesystem kind, omitted relevant alternative or changed guard blocks the nonselecting proof. |
| 6 | Check new schema/profile pairing, four-key variant document, rationale descriptor equality, all finite limits and immutable bindings. Review fresh evidence paths, clean environment, source inventory and exact future command shapes only if prior gates pass. | Expected plan digest belongs outside the plan. No self-approval field, H1 execution or operational adoption with unresolved inputs. |
| 7 | Record inspected candidate identities, concrete first blocker or bounded acceptance, unassessed later gates, all failures and exact next action. | Review acceptance cannot claim H1, host qualification, R03, integration or parent completion. |

## Governing interpretation

P05 `CONTRACT.md` and its adoption retain source, runtime, scientific and dependency obligations. P07 `HOST-INSPECTION-DESIGN.md` sections 1–4 and `QUALIFICATION-PLAN.md` sections 1–2 separate H0 from H1 and require exact finite closure. P11 candidate004 `DECISION.md` sections 3–7 and its adoption define the selected image, suffix proof, nonselection and finite bounds. P13 candidate001 `DECISION.md` sections 2–5 and its adoption assign source completeness exclusively to actual independent review; 96 runtime obligations and one external review obligation remain distinct.

## Ownership and exclusions

Only this assigned review directory may be written. The Director owns canonical records, Git/index, publication and delivery. No nested workers, target execution, Node/ldd, installation, original-seven/full routine, native/model/hosted execution, product/test/contract edits, main lease or integration. No active background jobs were launched for preparation. Await Director GO and the exact candidate evidence.
