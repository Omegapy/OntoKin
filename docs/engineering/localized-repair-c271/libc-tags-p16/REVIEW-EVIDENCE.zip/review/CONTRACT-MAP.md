# C271 P16 existing-contract and acceptance map

Reviewer: `/root/design_review`. This preparation records existing requirements and observed source facts only. It proposes no tag interpretation or new compatibility policy. Root owns source changes, canonical state, publication and saving. No early-save release has yet been received by this worker.

## Revision and current-state boundary

Authentic retained checkout: `0d5a3053ced2805f4cc04b77f361bb07dbdc7999`, tree `429b01242d98329e32dbe31be45e9f7c2f52aed4`, branch `work/c271-missing-import-digest-control`. Root supplied live main `70ca7e68ff95df876f801137369d176fe5b2bab3`; local `refs/heads/main` is absent. Main's C270 records are current main bytes because C271 has not merged. They do not replace the retained branch's unfinished C271 state. Main lease is released; this reviewer has no lease or publication authority.

`docs/workflow/tasks/C271/{task.json,REQUIREMENTS.md,PLAN.md}` retains R01/R02 done, R03–R05 not_done; P01 done, P02 in_progress, parent blocked. P15 partial delivery is confirmed. The selected next phase is an exact-tag source-backed decision/control set, stopping before implementation or further H0/H1. PR274 draft/open and issue273 open are root-supplied observations, not independent live observations by this worker.

## Binding contracts

| Source | Acceptance consequence |
| --- | --- |
| `AGENTS.md`, `GOAL.md`, `ROLE.md`, `docs/workflow/PROTOCOL.md`, `docs/workflow/templates/WORKER.md` | One bounded phase; verified early recovery before substantial work; exact revision/input/environment/evidence; independent review of exact candidate; preserve failed evidence; stop at concrete unplanned expansion. Root is sole canonical/Git writer. |
| `docs/engineering/OK-ENG-006-local-validation-and-hosted-ci-policy.md` §§2,4,5 | Documentary scope requires preservation/link and workflow checks. No hosted/paid execution. Local success supports only checked scope. Later runtime/integration gates retain complete applicable regression and exact provenance. |
| `docs/engineering/OK-ENG-009-development-integration-and-branch-lifecycle.md` §§1–3 | Explicit enforceable experimental entry boundaries; no changed earlier defaults/diagnostics/limits. Design/evidence adoption is neither implementation nor integration/release acceptance. New/worsened failures block later integration. |
| `docs/engineering/localized-repair-c271/current-host-p05/{ADOPTION.json,CONTRACT.md}` §§3–8 | Separately approved digest outside configuration, exact selected runtime/dependencies/source/host closure, all original seven outcomes/scientific/lifecycle predicates retained. Node `v24.22.1` exact build; no substitution. No current-host qualification follows from inspection metadata. |
| `docs/engineering/localized-repair-c271/host-inspection-p07/{ADOPTION.json,HOST-INSPECTION-DESIGN.md}` §§1–4,6–8 | Predeclared finite loader map; exact closed operational schemas and independently selected plan digest; audit/filter/auxiliary/unknown loader semantics refuse. No general loader emulator or silent format broadening. Exact command/env/path/closure/absence bindings and no-replace evidence remain mandatory. |
| `docs/engineering/localized-repair-c271/host-inspection-p07/QUALIFICATION-PLAN.md` §§1–3 | HI, H0, H1, H2, H3 and full routine/R03 are distinct gates. No runtime or operational-plan approval in P16; later H0 needs complete actual closure and independent exact-plan review. |
| `docs/engineering/localized-repair-c271/loader-path-p11/ADOPTION.json` and `design/candidate004/{DECISION.md,CONTROL-CONTRACT.md}` | Default public parser and old plan/profile remain unchanged. Opt-in origin interpretation is exact schema `/0.1.1` + `linux-glibc-declared-python-origin-rpath-v1`, only exact selected direct-Python subject; all current tag/flag predicates retained. Synthetic primitive positives never prove a real host. |
| `docs/engineering/localized-repair-c271/review-boundary-p13/{ADOPTION.json,design/candidate001/DECISION.md}` | Only N57 applicability changed: 96 runtime obligations plus one external completeness-review obligation. All 97 original records/131 fixtures unchanged; historical N57 oracle remains unsatisfied. No approval/completeness Boolean or fabricated runtime exception. |

## Exact existing tag and flag predicates

The unchanged source is `prototypes/static_tray_v01/current_host_inspection_v01.py`, SHA-256 `a8274d56076562a91d26b3cdd2f614fce6fd509733e4939b225dff2ddca09db4`. Read as text only; no product import or parser call occurred.

At lines1157–1162, `ordinary` is `set(range(1,31)) | {32,33,34,35,36,37,0x6FFFFEF5,0x6FFFFFF0,0x6FFFFFF9,0x6FFFFFFA,0x6FFFFFFB,0x6FFFFFFC,0x6FFFFFFD,0x6FFFFFFE,0x6FFFFFFF}`. Every non-NULL dynamic entry must belong. Otherwise the exact refusal is `CHI-UNSUPPORTED / Unreviewed ELF dynamic loader feature`.

At lines1164–1167, at most one `DT_FLAGS` and one `DT_FLAGS_1` is permitted. `DT_FLAGS` allows only bit `0x8`; `DT_FLAGS_1` allows only `0x1 | 0x08000000`. Other bits or duplicates produce `CHI-UNSUPPORTED / Unsupported dynamic flags`. P11 explicitly preserves these masks, including origin-bit refusals. A compatibility decision cannot silently expand a mask merely because a newly admitted tag would reach it.

Public `read_elf_metadata` preserves its signature and metadata keys. Private origin parsing changes only the exact subject RPATH interpretation; shared structural/tag/flag checks still run first. Existing callers validate raw metadata and declared closure, with complete pre/postflight rechecks. Review must distinguish primitive admission, bound plan eligibility and operational execution.

## Finite bounds and preserved evidence

ELF source bounds: regular file ≤512 MiB; one read ≤16 MiB; ELF64 little-endian System V/Linux; admitted machine62/183; type2/3; program headers1–256 at56 bytes; interpreter1–4096 bytes; exactly one nonempty dynamic table ≤65536 bytes divisible by16 and NULL terminated; exact dynamic file/virtual mapping; string table1–4 MiB; strings ≤4096 bytes; ≤256 unique needed names; no duplicate required metadata. P10's interval proof permits identical mappings but rejects gaps/conflicting overlaps. Short-read, stable before/after identity, callback and descriptor-close obligations remain.

P07 limits remain: 16 MiB documents, 8 MiB inspection/HOST, 4 MiB logs, 64 MiB/2048-entry stage; static60000ms, publication30000ms; preparation command5000ms including2000ms cleanup. Source execution remains100000 operations/30000ms. P11 adds one origin subject,4096 needed names,128 suffixes,32768 candidate pairs,4096 ASCII path bytes/128 components and256 auxv pairs; it adds no second document cap.

Preexisting tests include `tests/test_current_host_inspection_v01.py:case_HI08` architecture/ELF/tag/path refusals, the40 mapping controls and135 inspection methods, plus the96 adopted runtime controls in `tests/test_current_host_loader_path_v01.py`. None ran in this review. Old expectations must not be rewritten to manufacture compatibility.

## P15 established facts and unproved gates

`docs/engineering/localized-repair-c271/host-loader-p15/{BLOCKER-DECISION.json,BLOCKER-REVIEW.md}` binds captured libc:1995216 bytes, SHA-256 `9792e3cbb541c8f44c7acf5f14f4022ea62998ecc787d326bed4d8b6547dfd92`. First unsupported tag `0x70000000`, value`0x28000`, offset1980896; other excluded tags `0x70000001` value`0x3d0` offset1980912 and `0x70000003` value`0x10` offset1980928. P15 never reached the later flags check. Its raw `DT_FLAGS=24` is retained evidence only, not P15's observed refusal cause.

`SOURCE-COMPLETENESS-{DECISION,ACCEPTANCE}.json` and `SOURCE-COMPLETENESS-REVIEW.md` accept only the exact loader's suffix union: base plus `glibc-hwcaps/x86-64-v2/v3/v4`. Loader SHA-256 `c8438e4fde1934e61c88311633f00949ff645d5c04cdb8671fa3d78164d2f307`; official Debian package-member match and exact source/patch association were inspected in P15. This does not establish arbitrary libc-tag semantics, whole H0, plan adoption or H1. Full source-build reproduction/signature validation was not claimed.

## Review checkpoints and scope blockers

Before release: governance/source identity inspection only. After root confirms early save: independently inspect source-backed semantics and exact author candidate/control manifest; compare claims against primary source/build/ABI evidence, byte constructions, source predicates and preserved contracts. Require exact identities, positive/boundary/refusal expectations and isolated control mutations; review all mandatory findings on the exact corrected candidate. Static structural counts are not behavioral execution.

Potential blockers: unproved tag meaning for the exact architecture/build; no defensible source-to-captured-libc relation; any required expansion of flag masks or other loader semantics beyond selected exact tags; ambiguous default/legacy behavior; controls whose expected refusal actually arises earlier for an unrelated defect; unbounded table interpretation; synthetic helper admission presented as real closure or host eligibility. No such design conclusion is asserted yet. Root must stop or explicitly narrow the current decision at an unplanned expansion; implementation and further H0 remain separate.

`READ-SET.json` retains full and partial reading scopes, exact hashes, revisions and initial read failures/truncation boundaries. No publication, Library write, product/test execution, Node/ldd, installation or active job occurred.
