"""Read-only independent review of the R02 receipt-only candidate.

Only writes within the assigned receipt_review directory. Does not rerun archive
or product audits, change canonical files, or contact remote services.
"""
from pathlib import Path
import datetime
import hashlib
import json
import platform
import subprocess
import sys

ROOT = Path('/workspace/scratch/002c49ccf480')
REPO = ROOT / 'OntoKin'
OUT = ROOT / 'session/reviews/receipt_review'
BASE = '942096d22248fd84b7ac3a638e02aa1e66340519'
TREE = '3f8eba2e0de338a76fdb39aac373ed618c633c3c'
EVIDENCE = 'docs/engineering/localized-repair-c271/p28-recovery-r02-20261123'

def load(path):
    return json.loads(Path(path).read_bytes())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def ident(path, relative=None):
    data = path.read_bytes()
    return {'path': relative or str(path.relative_to(ROOT)), 'bytes': len(data), 'sha256': sha(data), 'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}

checks = []
def check(name, condition, detail=None):
    checks.append({'name': name, 'passed': bool(condition), 'detail': detail})

task_path = 'docs/workflow/tasks/C271/task.json'
current_path = 'docs/workflow/CURRENT.json'
task = load(REPO / task_path)
old_task = json.loads(git('show', BASE + ':' + task_path))
current = load(REPO / current_path)
old_current = json.loads(git('show', BASE + ':' + current_path))
delivery = load(REPO / EVIDENCE / 'DELIVERY.json')
audit = load(REPO / EVIDENCE / 'FINAL-ARCHIVE-REVIEW.json')
published = load(REPO / EVIDENCE / 'PUBLISHED-CHECKS.json')
uploads = load(ROOT / 'session/FINAL-UPLOAD-RESULT.json')['results']
readbacks = load(ROOT / 'session/FINAL-READBACK-VERIFICATION.json')
freeze = load(ROOT / 'session/FINAL-IDENTITY.json')
tracked = git('diff', '--name-only', BASE).decode().splitlines()
untracked = git('ls-files', '--others', '--exclude-standard').decode().splitlines()
paths = sorted(set(tracked + untracked))
inventory = [ident(REPO / p, p) for p in paths]
(OUT / 'CANDIDATE-MANIFEST.json').write_text(json.dumps(inventory, indent=2) + '\n')
(OUT / 'candidate.diff').write_bytes(git('diff', '--no-ext-diff', BASE))

check('exact_core_base', git('rev-parse', 'HEAD').decode().strip() == BASE and git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE)
check('receipt_documentary_scope_only', set(tracked) == {task_path, current_path} and all(p.startswith(EVIDENCE + '/') for p in untracked), {'modified': tracked, 'new': untracked})
task_changed = [k for k in old_task if old_task[k] != task.get(k)]
current_changed = [k for k in old_current if old_current[k] != current.get(k)]
check('task_history_unchanged', set(task_changed) == {'session_phase', 'delivery'} and set(task) == set(old_task), {'changed_top_level': task_changed, 'unchanged_fields': 33})
check('current_history_unchanged', set(current_changed) == {'snapshot_date', 'latest_handoff', 'p28_r02_recovery'} and set(current) == set(old_current), {'changed_top_level': current_changed, 'unchanged_fields': 24})
phase = task['session_phase']
old_phase = old_task['session_phase']
check('phase_changes_delivery_only', {k for k in old_phase if old_phase[k] != phase.get(k)} == {'status', 'phase_complete'} and set(phase) - set(old_phase) == {'packaged_source_commit', 'delivery_receipt', 'delivery_state', 'current_workers'} and all(k in phase for k in old_phase))
check('parent_gates_preserved', task['status'] == 'blocked' and task['requirements'] == old_task['requirements'] and task['plan'] == old_task['plan'] and task['completion'] == old_task['completion'] and phase['parent_complete'] is False and delivery['parent_complete'] is False and delivery['parent_status'] == 'blocked' and current['active_task'] == 'C271')
check('phase_only_saved_state', phase['status'] == 'delivered_parent_blocked' and phase['phase_complete'] is True and task['delivery']['status'] == 'saved' and task['delivery']['phase_complete'] is True and task['delivery']['parent_complete'] is False and current['p28_r02_recovery']['phase_complete'] is True and current['p28_r02_recovery']['parent_complete'] is False)
check('unknown_original_uploads_preserved', phase['current_unknown_operations'] == old_phase['current_unknown_operations'] and phase['historical_unknown_operations'] == old_phase['historical_unknown_operations'] and delivery['unknown_original_uploads'] == {'intended_parent': '360c80062e769230199602326fa8de25660df714', 'resulting_tree_sha': None, 'resulting_commit_sha': None, 'replayed': False})
check('no_technical_acceptance_promotion', phase['original_p28_implementation_verified'] is False and phase['reported_but_not_reverified'] == old_phase['reported_but_not_reverified'] and delivery['original_p28_implementation_verified'] is False and delivery['product_tests_executed'] == 0 and delivery['pr_state'] == 'draft_open_unmerged' and delivery['issue_state'] == 'open' and delivery['main_lease_held'] is False)
check('saved_identity_copies_consistent', task['delivery']['archive'] == delivery['archive'] and task['delivery']['prompts'] == delivery['prompts'] and all(current['latest_handoff'][k] == v for k, v in delivery['archive'].items()) and delivery['readback_verification'] == readbacks)

files = [delivery['archive']] + delivery['prompts']
byte_evidence = []
for item in files:
    upload = next(x for x in uploads if x['file_name'] == item['file_name'])
    readback = next(x for x in readbacks['files'] if x['file_name'] == item['file_name'])
    original = Path(upload['local_path']).read_bytes()
    saved = (ROOT / 'session/final-readback' / item['file_name']).read_bytes()
    same_fields = all(item[k] == upload[k] == readback[k] for k in ['file_name', 'library_file_id', 'file_id'])
    check('saved_file_' + item['file_name'], same_fields and item['version'] == upload['current_version_number'] == readback['version'] == 0 and item['path'] == upload['path'] and upload['status'] == 'succeeded' and original == saved and len(saved) == item['bytes'] == readback['bytes'] and sha(saved) == item['sha256'] == readback['sha256'] and item['saved_bytes_readback_equal'] is True and readback['byte_equal'] is True and readback['identity_attributes_verified'] is True)
    byte_evidence.append({'file_name': item['file_name'], 'library_file_id': item['library_file_id'], 'bytes': len(saved), 'sha256': sha(saved), 'download_matches_generated_bytes': original == saved})
check('frozen_archive_unchanged', freeze['bytes'] == delivery['archive']['bytes'] == audit['archive']['bytes'] == 9962453 and freeze['sha256'] == delivery['archive']['sha256'] == audit['archive']['sha256'] == '113cf92489c6579168c57f816b8347ab99f8874f187de74b8434bb10ef701f3b' and readbacks['zip_unchanged_after_freeze'] is True)
check('archive_audit_exact_copy', (REPO / EVIDENCE / 'FINAL-ARCHIVE-REVIEW.json').read_bytes() == (ROOT / 'session/reviews/final_archive/AUDIT.json').read_bytes() and len(audit['checks']) == audit['checks_passed'] == 430 and audit['checks_failed'] == 0 and all(x['passed'] is True for x in audit['checks']))
copies = []
for p in sorted((REPO / EVIDENCE / 'final-archive-review').iterdir()):
    if p.is_file():
        copies.append({'path': p.name, 'same': p.read_bytes() == (ROOT / 'session/reviews/final_archive' / p.name).read_bytes()})
check('final_archive_supporting_copies_exact', all(x['same'] for x in copies) and {x['path'] for x in copies} == {'REPORT.md', 'audit_final.py', 'SOURCE-BINDINGS.json'}, copies)
check('published_checks_exact_copy', (REPO / EVIDENCE / 'PUBLISHED-CHECKS.json').read_bytes() == (ROOT / 'session/published-checks/CHECKS.json').read_bytes() and published['source_revision'] == BASE and published['source_tree'] == TREE and all(c['exit_code'] == 0 for c in published['checks']) and published['product_tests'] == 0)
check('source_identity_is_existing_core_not_self', delivery['source_commit'] == phase['packaged_source_commit'] == current['latest_handoff']['source_revision'] == audit['source_commit'] == BASE and delivery['source_tree'] == audit['source_tree'] == TREE and 'receipt_commit' not in delivery and 'receipt_tree' not in delivery)
check('source_time_boundary_explicit', 'precedes its own conditional publication and terminal ownership release' in delivery['source_time_boundary'] and delivery['ownership']['state'] == 'release_after_matching_verified_terminal_comments' and 'pending' in phase['delivery_state'] and 'observed externally' not in phase['delivery_state'] and 'Receipt publication/readback, final ownership release' in task['delivery']['remaining'], phase['delivery_state'])
check('next_action_unchanged', delivery['next_action'] == task['next_action'] == old_task['next_action'] == current['next_action']['summary'] and current['next_action'] == old_current['next_action'])
check('old_early_save_and_phase_evidence_unchanged', delivery['early_recovery'] == load(REPO / EVIDENCE / 'EARLY-RECOVERY-RECEIPT.json') and (REPO / EVIDENCE / 'OUTCOME.json').read_bytes() == git('show', BASE + ':' + EVIDENCE + '/OUTCOME.json'))
for p in paths:
    if p.endswith('.json'):
        load(REPO / p)
check('candidate_json_parse', True)

result = {
    'schema': 'ontokin.c271.p28-r02-receipt-candidate-review/1',
    'reviewer': '/root/checkpoint_review',
    'role': 'Independent Reviewer; final receipt-only candidate within existing R02 phase',
    'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'candidate_base': {'commit': BASE, 'tree': TREE},
    'verdict': 'ACCEPTED_RECEIPT_ONLY_CANDIDATE' if all(x['passed'] for x in checks) else 'CORRECTION_REQUIRED',
    'checks_passed': sum(x['passed'] for x in checks),
    'checks_failed': sum(not x['passed'] for x in checks),
    'checks': checks,
    'candidate_manifest': {'path': 'CANDIDATE-MANIFEST.json', 'files': len(inventory), 'sha256': sha((OUT / 'CANDIDATE-MANIFEST.json').read_bytes())},
    'candidate_files': inventory,
    'saved_byte_evidence': byte_evidence,
    'resolved_finding': {'id': 'R02-RECEIPT-001', 'location': 'task.json#/session_phase/delivery_state', 'initial_problem': 'Wording described receipt publication and ownership release as already observed externally while they remained pending.', 'correction': phase['delivery_state'], 'status': 'resolved' if 'pending' in phase['delivery_state'] and 'observed externally' not in phase['delivery_state'] else 'unresolved'},
    'environment': {'python': sys.version, 'platform': platform.platform()},
    'command': 'python3 session/reviews/receipt_review/review_receipt.py',
    'instruction_continuity': 'Retained full reads of assigned governing main AGENTS/ROLE/PROTOCOL/HANDOFF/EPHEMERAL-HOST and worker template from the earlier R02 checkpoint review; no changed governing instructions or new technical phase supplied.',
    'coverage': ['Complete current receipt diff and new DELIVERY/PUBLISHED-CHECKS records', 'Final archive audit report, metadata, count consistency and exact copied bytes; no re-execution', 'All modified receipt/canonical JSON compared with existing core', 'Actual generated/downloaded archive and prompt bytes compared and hashed against saved identities', 'Supporting final audit report/script/bindings copied byte-exactly; no full second semantic audit of the script or every archived source binding'],
    'limits': ['No fresh remote observations or mutations by this reviewer.', 'The 430 archive audit assertions are prior independent artifact-review evidence, not 430 checks re-executed here.', 'No product tests or archive audits rerun.', 'Receipt publication, separately saved actual receipt and terminal ownership release remain future Director actions. This acceptance does not attest those outcomes.', 'The original P28 candidate remains missing; parent C271 remains blocked and original unknown operations remain unresolved.'],
    'permitted_following_metadata': 'Copy this exact review, record reviewer stopped, and add/check final receipt validation evidence. Reconcile the final staged inventory before conditional publication; do not change accepted saved identities or technical gates.',
    'next_action': 'Conditionally publish/read back this receipt-only candidate from the exact core base, save the separate actual external receipt, verify terminal ownership release, and stop.',
    'disposition': 'Stopped; only assigned receipt_review outputs written; no canonical/remote changes, children, pending writes or active jobs.'
}
(OUT / 'REVIEW.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['verdict', 'checks_passed', 'checks_failed', 'candidate_manifest']}, indent=2))
if result['checks_failed']:
    print(json.dumps([x for x in checks if not x['passed']], indent=2))
    raise SystemExit(1)
