#!/usr/bin/env python3
"""Independently inspect exact C271 P03 candidate evidence without test replay."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess

BASE = Path('/workspace/scratch/7010345bc259')
REPO = BASE / 'OntoKin'
VAL = BASE / 'validation'
WORKSPACE = VAL / 'isolated-documents/workspace'
OUT = BASE / 'review/final'
SHA = 'fea1aa6fb3712c5283dde197295b2d3cbf925d36'
TREE = 'd4fe9aa7f2166a46d7a141ad001b13c71d43a6b6'
PARENT = '72084140cd3ae64defc698e410f8806a8b338b72'
checks = []
reads = []
git_reads = []


def identity(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read(path):
    raw = Path(path).read_bytes()
    reads.append({'path': str(path), **identity(raw)})
    return raw


def jread(path):
    return json.loads(read(path))


def git(*args, repo=REPO):
    argv = ['git', '--no-optional-locks', '-c', 'core.fsmonitor=false', '-C', str(repo), *args]
    result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})
    git_reads.append({'argv': argv, 'returncode': result.returncode,
                      'stdout_identity': identity(result.stdout), 'stderr': result.stderr.decode()})
    if result.returncode:
        raise RuntimeError(git_reads[-1])
    return result.stdout


def check(predicate, passed, **details):
    checks.append({'check': predicate, 'passed': bool(passed), **details})


OUT.mkdir(parents=True, exist_ok=True)
commit = git('cat-file', 'commit', SHA)
check('exact_commit_hash', hashlib.sha1(b'commit ' + str(len(commit)).encode() + b'\0' + commit).hexdigest() == SHA)
check('exact_commit_tree', commit.splitlines()[0].decode() == 'tree ' + TREE)
check('exact_candidate_parent', commit.splitlines()[1].decode() == 'parent ' + PARENT)
working_review = jread(BASE / 'review/candidate/CANDIDATE-AUDIT.json')
for path, expected in working_review['reviewed_working_files'].items():
    check('published_repair_equals_reviewed_working_bytes', identity(git('show', SHA + ':' + path)) == expected, path=path)
check('working_review_had_no_code_findings', working_review['mandatory_code_findings'] == [] and working_review['failed_predicates'] == 0)

changed = git('diff-tree', '--no-commit-id', '--name-only', '-r', SHA).decode().splitlines()
allowed = {'tools/check_local.py', 'tests/test_local_checks.py', 'docs/workflow/CURRENT.json'}
unexpected = [p for p in changed if p not in allowed
              and not p.startswith('docs/workflow/tasks/C271/')
              and not p.startswith('docs/engineering/localized-repair-c271/validation-recovery-20261120/')]
check('candidate_changed_paths_are_bounded', not unexpected, changed_files=changed, unexpected=unexpected)

summary = jread(VAL / 'CHECKS.json')
for label in ('source', 'source_after'):
    row = summary[label]
    check('recorded_clean_candidate_identity', row['available'] and row['local_head'] == SHA and row['local_tree'] == TREE
          and not row['tracked_worktree_status'] and not row['untracked_source_files'], role=label)
check('source_unchanged_claim', summary['source_unchanged'] is True and summary['source'] == summary['source_after'])
by_name = {row['name']: row for row in summary['checks']}
expected_names = {'focused-local-driver', 'workflow', 'native-reader-setup', 'isolated-documents', 'readback-prerequisites'}
check('exact_selected_check_inventory', set(by_name) == expected_names and len(summary['checks']) == len(expected_names))
logs = {}
for name, row in by_name.items():
    receipt = jread(VAL / (name + '.receipt.json'))
    check('check_receipt_equals_summary', receipt == row, name=name)
    logs[name] = {}
    for stream in ('stdout', 'stderr'):
        data = read(VAL / row[stream])
        check('check_log_hash', hashlib.sha256(data).hexdigest() == row[stream + '_sha256'], name=name, stream=stream)
        logs[name][stream] = data.decode()
    check('expected_exit_observed', row['returncode'] == (1 if name == 'readback-prerequisites' else 0), name=name)
    check('exact_verification_interpreter', row['command'][0] == summary['python_executable']
          == str(BASE / 'validation_env/bin/python'), name=name)

tests = ast.parse(git('show', SHA + ':tests/test_local_checks.py'))
cls = next(n for n in tests.body if isinstance(n, ast.ClassDef) and n.name == 'LocalChecksTests')
methods = [n.name for n in cls.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
focused_log = logs['focused-local-driver']['stderr']
logged_methods = re.findall(r'^(test_\w+) \(tests\.test_local_checks\.LocalChecksTests\.\w+\) \.\.\. ok$', focused_log, re.M)
check('fresh_focused_cohort_all_31_methods_once', len(methods) == 31 and Counter(methods) == Counter(logged_methods))
check('fresh_focused_complete_without_skips', re.findall(r'^Ran (\d+) tests in ([0-9.]+)s$', focused_log, re.M) == [('31', '1.926')]
      and re.findall(r'^(OK|FAILED.*)$', focused_log, re.M) == ['OK'])
document_result = json.loads(logs['isolated-documents']['stdout'])
check('isolated_documents_pass_without_failures', document_result['status'] == 'passed' and document_result['failures'] == [])
check('workflow_structure_pass_observed', logs['workflow']['stdout'].startswith('Workflow structure passed (12 tasks).'))
check('native_reader_pillow_preflight_observed', 'Pillow 13.0.0' in logs['native-reader-setup']['stdout'])
check('documentation_step_uses_actual_isolated_workspace', by_name['isolated-documents']['cwd'] == str(WORKSPACE)
      and by_name['isolated-documents']['command'] == [summary['python_executable'], '-B', 'docs/maintenance/reorganization-2026-10-17/verify_reorganization.py'])

before_raw = read(VAL / 'SOURCE-BEFORE.json')
after_raw = read(VAL / 'SOURCE-AFTER.json')
before = json.loads(before_raw)
after = json.loads(after_raw)
check('source_inventory_before_after_exact', before_raw == after_raw and before == after)
encoded = json.dumps(before['files'], sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode()
check('source_inventory_canonical_digest', before['sha256'] == 'sha256:' + hashlib.sha256(encoded).hexdigest()
      and before['file_count'] == len(before['files']))
git_tree = {}
for record in git('ls-tree', '-rz', '--full-tree', SHA).split(b'\0'):
    if record:
        fields, path = record.split(b'\t', 1)
        mode, kind, oid = fields.decode().split(' ')
        git_tree[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
driver = ast.parse(git('show', SHA + ':tools/check_local.py'))
constants = {n.targets[0].id: ast.literal_eval(n.value) for n in driver.body
             if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)
             and n.targets[0].id in ('SOURCE_DIRS', 'ROOT_FILES', 'IGNORED')}
def ignored(name):
    return name in constants['IGNORED'] or name == '.env' or name.startswith('.env.') or name.endswith(('.pyc', '.pyo'))
def selected(path):
    parts = path.split('/')
    return path in constants['ROOT_FILES'] or (parts[0] in constants['SOURCE_DIRS'] and not any(ignored(p) for p in parts))
declared_paths = [e['path'] for e in before['files']]
selected_git_paths = {p for p, e in git_tree.items() if e['kind'] == 'blob' and selected(p)}
check('source_inventory_equals_selected_candidate_git_paths', len(declared_paths) == len(set(declared_paths))
      and set(declared_paths) == selected_git_paths, inventory_count=len(declared_paths), selected_git_count=len(selected_git_paths),
      missing=sorted(selected_git_paths - set(declared_paths)), extra=sorted(set(declared_paths) - selected_git_paths))
inventory_errors = []
for row in before['files']:
    path = WORKSPACE / row['path']
    raw = path.read_bytes()
    value = identity(raw)
    oid = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    expected_git = git_tree.get(row['path'])
    if path.is_symlink() or not path.is_file() or value['bytes'] != row['bytes'] or 'sha256:' + value['sha256'] != row['sha256'] or not expected_git or oid != expected_git['oid']:
        inventory_errors.append({'path': row['path'], 'actual': value, 'git_blob': oid})
check('all_isolated_inventory_bytes_equal_record_and_candidate', not inventory_errors,
      verified_files=len(before['files']), failures=inventory_errors)
for row in summary['copy_verification']['required_files']:
    raw = (WORKSPACE / row['path']).read_bytes()
    check('required_instruction_exact_candidate_copy', identity(raw) == {k: row[k] for k in ('bytes', 'sha256')}
          and raw == git('show', SHA + ':' + row['path']), path=row['path'])
check('isolated_git_identity_preserved', git('rev-parse', 'HEAD', repo=WORKSPACE).decode().strip() == SHA
      and git('rev-parse', 'HEAD^{tree}', repo=WORKSPACE).decode().strip() == TREE
      and not git('status', '--porcelain=v1', '--untracked-files=no', repo=WORKSPACE))
check('isolated_index_is_separate', summary['copy_verification']['source_index_independent'] is True
      and not (REPO / '.git/index').samefile(WORKSPACE / '.git/index'))

preflight = jread(VAL / 'readback-preflight.json')
check('readback_preflight_matches_summary', preflight == summary['readback_preflight'])
check('readback_refusal_is_exact_runtime_binding', preflight['passed'] is False and preflight['outcome'] == 'REFUSED_OR_FAILED'
      and preflight['error'] == 'ValueError: Binding differs: /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node')
check('readback_preflight_no_apply_or_execution', preflight['apply_requested'] is False
      and '--apply' not in by_name['readback-prerequisites']['command'] and preflight['operation_log'] == []
      and all(v == 0 for v in preflight['execution_counts'].values()) and preflight['rollback'] == [])
check('readback_preflight_exact_clean_candidate', preflight['source_commit'] == SHA and preflight['source_tree'] == TREE and preflight['source_clean'] is True)
for path, expected in preflight['source_bindings'].items():
    value = identity(git('show', SHA + ':' + path))
    check('readback_source_binding_equals_candidate', value['bytes'] == expected['size_bytes']
          and value['sha256'] == expected['sha256'], path=path)
check('required_routine_honestly_not_run', summary['required_routine']['status'] == 'not_run'
      and summary['required_routine']['prior_P02_result'] == 'failed and preserved')

task = json.loads(git('show', SHA + ':docs/workflow/tasks/C271/task.json'))
old_task = json.loads(git('show', PARENT + ':docs/workflow/tasks/C271/task.json'))
check('requirements_acceptance_not_weakened', [(r['id'], r['acceptance']) for r in task['requirements']]
      == [(r['id'], r['acceptance']) for r in old_task['requirements']])
statuses = {r['id']: r['status'] for r in task['requirements']}
check('parent_gates_still_open', task['status'] != 'done' and statuses == {'R01': 'done', 'R02': 'done', 'R03': 'not_done', 'R04': 'not_done', 'R05': 'not_done'}
      and task['completion']['merge_commit'] is None and task['completion']['branch_disposition'] == 'retained')
check('phase_excludes_integration', task['session_phase']['phase'] == 'C271-P03-validation-recovery'
      and task['session_phase']['main_lease_held'] is False and 'No R04 integration' in task['session_phase']['stop'])
early = json.loads(git('show', SHA + ':docs/engineering/localized-repair-c271/validation-recovery-20261120/EARLY-RECOVERY-RECEIPT.json'))
red = jread(BASE / 'preparation/copy-repair/red/EXECUTION.json')
py_setup = jread(BASE / 'environment/PYTHON-PREPARATION.json')
check('recorded_early_save_precedes_substantial_work', early['status'] == 'saved'
      and datetime.fromisoformat(early['save_confirmed_at_utc']) < datetime.fromisoformat(red['started_at_utc'])
      and datetime.fromisoformat(early['save_confirmed_at_utc']) < datetime.fromisoformat(py_setup['started_at_utc']))
old_evidence = 'docs/engineering/localized-repair-c271/finalization-20261120/verification/RAW-EVIDENCE.zip'
check('original_P02_raw_failure_archive_unchanged', git('rev-parse', SHA + ':' + old_evidence)
      == git('rev-parse', PARENT + ':' + old_evidence))
script = read(BASE / 'session/run_candidate_checks.py')
check('candidate_check_driver_source_retained', b'check_local.prepare_workspace(' in script and b'check_local.build_plan(' in script
      and b"'status': 'not_run'" in script)
publication = jread(BASE / 'session/PUBLISH-01-READBACK.json')
check('durable_publication_receipt_matches_candidate', publication['created_commit'] == SHA
      and publication['intended_parent'] == PARENT and publication['intended_tree'] == TREE
      and publication['tree_result']['sha'] == TREE and publication['ref_result']['success'] is True
      and publication['outcome'] == 'succeeded_and_read_back')
check('durable_PR_readback_retains_open_draft_candidate', publication['remote_pr']['head_sha'] == SHA
      and publication['remote_pr']['base_sha'] == 'e1a48f7d0635e9aa4f4b6d6a586e7305eb81999d'
      and publication['remote_pr']['number'] == 274 and publication['remote_pr']['state'] == 'open'
      and publication['remote_pr']['draft'] is True and publication['remote_pr']['merged'] is False)
file_readback = publication['exact_file_readback']
check('durable_exact_file_readback_matches_local_git_object', file_readback['revision'] == SHA
      and git('rev-parse', SHA + ':' + file_readback['path']).decode().strip() == file_readback['blob'])

result = {'schema': 'ontokin.c271.p03-final-evidence-review/1', 'reviewer': '/root/intake_review',
          'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
          'candidate': {'commit': SHA, 'tree': TREE, 'parent': PARENT},
          'check_count': len(checks), 'failed_count': sum(not r['passed'] for r in checks),
          'checks': checks,
          'source_inventory_verified_files': len(before['files']),
          'source_inventory_identity': identity(before_raw),
          'focused_methods': len(methods),
          'isolated_documentation': {'documents': document_result['links']['documents'], 'local_links': document_result['links']['local_links'],
                                     'external_links_not_checked': document_result['links']['external_skipped']},
          'product_replays_by_reviewer': 0,
          'scope': 'Exact candidate and executed evidence; later working canonical records and final save are not reviewed here.',
          'remote_publication': {'director_observed_pr274_head': SHA, 'independent_remote_read_by_this_worker': False,
                                 'receipt': str(BASE / 'session/PUBLISH-01-READBACK.json'),
                                 'note': 'Director successful remote readback is durably recorded and reconciles the preserved pending intent; local source/object identity independently verified.'}}
(OUT / 'EVIDENCE-AUDIT.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'READ-SET.json').write_text(json.dumps({'reviewer': '/root/intake_review', 'files': reads}, indent=2) + '\n')
(OUT / 'GIT-READS.json').write_text(json.dumps(git_reads, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('candidate', 'check_count', 'failed_count', 'source_inventory_verified_files', 'focused_methods')}))
