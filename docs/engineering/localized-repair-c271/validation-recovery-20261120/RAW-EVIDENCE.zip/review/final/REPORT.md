# C271 P03 final independent technical review

## Decision

**Approve the minimal instruction-copy repair for the retained partial result. Do not accept R03, integrate the branch, or close C271.** The required historical Node binding remains unresolved, and the complete required routine driver has not passed. The original P02 failures remain preserved and unwaived.

Reviewer: `/root/intake_review`. Exact reviewed candidate: `fea1aa6fb3712c5283dde197295b2d3cbf925d36`, tree `d4fe9aa7f2166a46d7a141ad001b13c71d43a6b6`, parent `72084140cd3ae64defc698e410f8806a8b338b72`. The machine decision is `FINAL-ACCEPTANCE.json`.

The final evidence audit passed **73 predicates with zero failed final predicates**. A separate prepared-record audit passed **18 predicates with zero failures**. These are evidence checks, not additional product tests. The reviewer executed no product behavior and made no repository, Git, remote, dependency or runtime changes.

## Repair and evidence accepted

The published two-file repair is byte-identical to the independently reviewed working candidate:

| File | SHA-256 |
| --- | --- |
| `tools/check_local.py` | `7b70944c6181a8df8900bb2b9b8df3bca6753be11e5fa62368e9302dc6fd3b51` |
| `tests/test_local_checks.py` | `36b06e8d1ef4195d3a615c1acc6a2f067d1703fa6d6efd6d54223c4de0997082` |

The driver adds `.agents` to its source directories and the two omitted root instruction files to its root inventory. The prior AST review established that all other driver statements remain unchanged. The test module adds one regression method and preserves every existing test. The same new test failed against the original driver with exactly the five omitted paths, then passed after the minimal repair.

Fresh verification on the clean published candidate used the prepared CPython 3.12.14 environment:

| Check | Observed outcome | Scope |
| --- | --- | --- |
| Local-driver test module | 31 tests, `OK`, exit 0 | All 31 source methods appear exactly once as successful log records; no skip or failure footer. |
| Workflow structure | Passed, exit 0 | Structure of 12 tasks; not independent proof of every cited claim. |
| Native-reader setup | Passed, exit 0 | Pillow 13.0.0 setup only. The separate dependency audit establishes the seven Python pins. |
| Actual isolated documentation step | Passed, exit 0 | 1,348 documents and 5,916 local links; no reported failure. Its 960 external links remain outside that check's scope. |
| Unchanged C225 prerequisite helper | Refused, exit 1 | Exact Node binary binding differs; no `--apply`, installation or runtime/product execution. |
| Complete required routine | Not run in P03 | Known prerequisites remained unqualified; P02 failed result is retained. |

The isolated documentation result used `check_local.prepare_workspace` and the actual `documents` command selected by `check_local.build_plan`. It was not merely a complete-checkout documentation run. All five instruction files matched exact candidate bytes. The isolated checkout retained the candidate commit/tree, a clean tracked state and a separate Git index.

The reviewer independently checked **all 18,811 inventoried files** in the isolated workspace against both the preserved source manifests and exact candidate Git blob identities. The inventory equals the candidate's selected source paths. Before/after source inventories are byte-identical, and recorded source Git metadata is unchanged. Complete stdout/stderr and every per-check receipt match their recorded hashes. `EVIDENCE-AUDIT.json`, `GIT-READS.json` and `READ-SET.json` retain the verification details.

The Director's durable `session/PUBLISH-01-READBACK.json` records successful publication and PR274 readback at this exact candidate, with main `e1a48f7d0635e9aa4f4b6d6a586e7305eb81999d`, draft/open/unmerged state and the exact driver blob. That receipt reconciles the retained earlier `ref_update: pending` intent. The reviewer verified these recorded identities against local Git objects; it did not independently query GitHub.

## Mandatory unresolved requirements

### C271-P03-B01-exact-node-build

The unchanged C225 helper refused the current runtime after confirming the clean candidate and all six source bindings. It reported:

`ValueError: Binding differs: /opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node`

The required historical executable is **126,939,688 bytes**, SHA-256 `61ab14cd750fc24d5db53490ec5fc40f756e4b6e136b78cf7004265471d9bd1d`. The current host binary and the downloaded same-version binary both differ. The earlier independent preparation review recomputed those identities, verified nine other runtime file bindings and all ten aliases, and confirmed successful installation/integrity of all seven Python packages.

The no-apply helper report records zero Node, `ldd`, test-method, native and product-source executions, an empty operation log, and no rollback. It created no historical prerequisite installation. That refusal is correct evidence of an unmet prerequisite; it is not a successful preparation result.

The bounded C262 search identified no directly retained matching binary. Its historical records do not reconstruct that binary, and the search establishes no global absence. A private namespace could preserve an exact runtime path if the required binary becomes available. It cannot qualify different bytes under the current pin.

### C271-P03-B02-complete-routine-unmet

P03 correctly did not consume a full routine attempt with known unqualified prerequisites. Consequently it provides no completed full-suite result. P02's 900-second timeout still has no completed-suite footer, and its failed aggregate remains failed. Historical affected-cohort success and the present focused repair checks do not waive that requirement.

The demonstrated cause of P02 finding `C271-P02-RV-002` is repaired and the actual isolated documentation step now passes at this exact candidate. Its original failure is preserved. P02 finding `C271-P02-RV-001` remains unresolved because no complete successful unit-suite execution replaces the timeout. Future completion must preserve every required test, original failures, frozen controls, dependency locks and the 100,000-operation/30,000-ms per-source limits.

## Prepared blocked records

The Director's prepared task, CURRENT, phase/outcome, requirements, plan, P03 session, result, evidence-location and learning records were reviewed separately at their exact working-file hashes in `WORKING-RECORD-REVIEW.json`. No substantive mandatory record defect was found.

They preserve the original requirement acceptance text and historical check records. C271 is blocked/open; R01/R02 are done and R03–R05 remain not done. P01 is done and P02 remains in progress. The new records distinguish successful focused checks, failed historical preparation and the unrun full routine. They record a retained unmerged branch, draft PR274, open issue273, no main lease and no integration. The copied `EXECUTION-CHECKS.json` is byte-identical to the original validation summary. Prior task prose is retained with new outcome text appended.

The prepared `pending_final_acceptance_record` field is intentional before this review is attached. Before publication, replace it with this observed not-eligible verdict and exact evidence references. Include the actual raw evidence archive and its verified manifest/identity. A later publication must receive applicable fresh record checks; these working-file checks do not claim that later revision was published or verified.

## Preservation and delivery boundary

The original P02 raw failure archive remains the same Git object. The early P03 save receipt precedes both dependency installation and the first regression execution. Prior independent reviews, failed red test, environment observations and failed prerequisite evidence remain available. One initial reviewer-checker naming collision is preserved in `ATTEMPT-01-*` and `REVIEW-ATTEMPTS.json`; the corrected checker passed without changing candidate or execution evidence and without replaying product behavior.

This review supports an honest partial handoff of the repair and blocker. It does **not** approve R03 completion, R04 integration, parent closure, a final saved archive that has not yet been inspected, full H22/C260 acceptance, release qualification, compatibility, native execution or comparative claims.

Finish the phase's accurate publication, fresh applicable record checks, verified saved partial ZIP and matching prompts, and external receipt; then stop. A fresh bounded phase must qualify exact retained prerequisites or establish a separately reviewed current-host qualification approach before attempting the complete required routine. It must not replace frozen pins merely to obtain a pass.
