# C271 P03 independent intake review

Reviewer: `/root/intake_review`. Scope: incoming P02 recovery package, frozen Git identity metadata, prior acceptance evidence, and R03 prerequisites. The Director owns the new P03 phase declaration, shared Git/index, publication, task records and all saves.

## Verdict

The incoming package is suitable as preserved evidence for the authorized C271 P03 validation-recovery phase. **No archive, manifest, frozen Git identity, or external-receipt byte mismatch was found. R03 remains unmet.** This intake is not an acceptance review of a repaired candidate and does not authorize integration.

The independently executed integrity audit passed **1,040 predicates with zero failures**. It checked ZIP CRC, safe unique regular-file paths, exact manifest inventory, a fresh extraction, all payload sizes and SHA-256 values, all 157 snapshot bytes and Git tree modes/blob identities, all 118 session/recovery map entries, three declared commit/tree identities, saved-prompt identities, and recovery of the exact unpublished commit identity without writing a Git object. These counts describe evidence checks, not product tests. Full results are in `INTEGRITY-AUDIT.json`; read-only Git command identities are in `GIT-READS.json`.

## Reconciled identities

| Evidence role | Identity |
| --- | --- |
| Incoming ZIP | `OntoKin_C271_P02_Validation_Blocked_Handoff_2026-11-20.zip` |
| ZIP bytes / SHA-256 | `19975795` / `f9cd741651c271a31cbe6fa691b07080dcc531f6fc35ea62adf6186cb0091b7a` |
| Frozen source / tree | `70a658c31085bf8dd78d79663c57f8e3cdb28ceb` / `77ee621cdfb00acf637828ce71f3384b4dd8275c` |
| Executed P02 source / tree | `88bc8b51b3963b7072375edac6400b6e6a4532e4` / `755f366d1091beb71b5421b14fdac0b9b868cfb0` |
| Separately observed main / tree | `e1a48f7d0635e9aa4f4b6d6a586e7305eb81999d` / `9345594c980f121fae2f087b40e4c78adb8f7925` |
| Later receipt publication | `72084140cd3ae64defc698e410f8806a8b338b72` |
| Saved Library identity | `libfile_fde3_f-b14e79917ee8819184206c7d300f0466_2ab2a24d43748191957f9bcc356b59de` |
| Saved file identity / version | `file_000000002f94822f83b1f727c17239fe` / `0` |

The last two identities were observed by the Director and supplied to this reviewer. They match `P02-DELIVERY.json` read from exact commit `72084140cd3ae64defc698e410f8806a8b338b72`. Its declared archive size/hash independently match the actual incoming ZIP. Both archived prompts match the receipt's saved prompt hashes. This worker did not independently query Library or live GitHub. `EXTERNAL-IDENTITY-RECONCILIATION.json` records this source distinction.

The ZIP's `save_pending` state, P02 task delivery flags and pending-delivery prose describe the immutable `70a658...` source boundary. The later receipt records `saved` and `complete_partial_delivery`. This is the protocol's intended external-receipt design, not missing work requiring a duplicate save or a reason to rewrite the old ZIP. The parent remained blocked with R01/R02 done, R03–R05 not done, P01 done and P02 in progress. Draft PR274, open issue273 and the unmerged branch remain the recovery context; live state is governed by the Director's current observations.

The unpublished CLI commit bytes recompute to `01b2013fc13ec872fd029d13766e19e86d0eb618`. Its tree equals published API checkpoint `15b1dd985b59cf037ebbeae733c16a54ca87f83d`: `5e3e6a54a64f91a49e124bac7f11e6c73c024129`. No distinct unpublished content tree was found. The diagnosed unavailable CLI publication route must not be blindly retried.

## Mandatory findings retained from P02

| Finding | Observed evidence | Required resolution |
| --- | --- | --- |
| `C271-P02-RV-001` | The required unit process exceeded 900 seconds, returned `-15`, and has no completed unittest footer. | A complete passing required-suite result with truthful skip/error accounting and justified command timeout. |
| `C271-P02-RV-002` | The isolated documentation step failed on 21 links to five source files excluded by the driver copy inventory. | Correct copy/inventory preservation, prove the focused regression, and pass the isolated documentation step within the required driver. |

The omitted paths are `CHATGPT-START-HERE.md`, `ROLE.md`, `.agents/skills/ontokin-session/SKILL.md`, `.agents/skills/ontokin-delivery/SKILL.md` and `.agents/skills/ontokin-learning/SKILL.md`. They exist in the authentic candidate. The initial copied workspace already recorded their deletion. A direct full-checkout documentation pass does not close the isolated-copy finding.

The original unit report's `tests_run=0` is a missing-footer parser result, not a count of tests that executed. Partial `ok` lines and the last unfinished method establish neither a full pass nor the cause of total run time. Do not blame or remove a test from that boundary alone.

The affected cohort completed all 12 checks and 282 methods with zero failures, errors or skips. This is retained successful evidence of its exact P02 execution. It does not satisfy the separate failed routine gate. The five passing routine process stages also retain their named pending external/release obligations.

Sources: incoming `repository/docs/workflow/tasks/C271/{REQUIREMENTS.md,PLAN.md,task.json,LEARNING-P02.md}` and `repository/docs/engineering/localized-repair-c271/finalization-20261120/{PHASE-OUTCOME.json,verification/REPORT.md,verification/RESULTS.json,verification/DOCUMENTS-FAILURE-INSPECTION.json,independent-review/INTEGRATION-REVIEW.json,independent-review/REPORT.md}`. `READ-SET.json` preserves exact bytes/hashes and read modes.

## Exact R03 prerequisites for P03

1. Confirm the new verified early recovery save before substantial repair, preparation or execution. Record one bounded P03 phase ending at R03 acceptance or the first concrete blocker. The Director has selected this boundary; no R04 integration belongs to P03.
2. Identify the exact candidate and preserve every original failure and frozen control. The copy repair must include both root files and the required `.agents` subtree in isolated copying and source identity accounting. Focused coverage must fail for the demonstrated omission and prove preserved bytes without weakening isolation, tests or documentation checks.
3. Prepare the declared verification dependencies without editing the pins. P02 recorded `attrs 26.1.0`, `jsonschema 4.26.0`, `jsonschema-specifications 2025.9.1`, `referencing 0.37.0`, `rpds-py 2026.5.1`, `typing_extensions 4.16.0`, and `Pillow 13.0.0`; its installed `rpds-py 2026.6.3` was a mismatch. Bind actual dependency artifacts and environment to the new execution.
4. Prepare and authenticate the historical inputs needed by all three `ReadbackCPUControls` methods. P02 lacked `/workspace/scratch/801d9d641f68/incoming-audit/work/prior-replay/evidence/c195-validation/receiving` and `/workspace/scratch/801d9d641f68/c199-independent-preflight/HOST-RUNTIME-INVENTORY.json`. The methods were not reached before timeout; their potential skips were not observed skips. Existence alone will not prove correct historical/runtime binding. The Director's requested Node-binding assessment awaits the preparation evidence.
5. Use the preserved timeout evidence to justify a sufficient outer command budget for the complete routine driver. An outer test-process timeout is distinct from the unchanged per-source limits of 100,000 operations and 30,000 ms. Preserve those limits and every test; do not add skips or reclassify incomplete execution as passed.
6. Execute the complete required routine driver and inspect every planned stage. A complete unit footer, zero unfulfilled required obligations, successful isolated documentation, full command/environment/source/artifact/log evidence and final process disposition are required. Git LFS preparation is conditional on selecting an LFS archive route; P02 selected none. Optional `--full`, `--force-agent`, other-Python and native qualifications must not be claimed from the ordinary driver.
7. Run the focused validation-tool tests and applicable fresh documentation/workflow checks for the actual P03 edits. Reuse P01 and the affected-cohort execution only after exact implementation, dependency, fixture, test, command and relevant environment identity checks; rerun checks invalidated by actual changes. No blanket reuse decision is made at intake.
8. Obtain an actual independent review of the identified repaired candidate and final evidence, explicitly resolving both mandatory findings. If a required result remains failed, incomplete, skipped or materially unprepared, R03 stays open. At the declared acceptance/blocker boundary, preserve the candidate, publish an honest partial handoff and separate delivery receipt, then stop this phase.

## Metadata and interpretation notes

No substantive package/source inconsistency was found. One source-map flag is ambiguous: 43 entries carry `reuse_identical_git_snapshot: true` while their actual `package_path` points to a separately stored session/review file absent from `SNAPSHOT-SOURCES.json`; they also have no alias `representation` text. Every such file exists and its declared size/hash passes. The flag alone should therefore not be used to infer that its bytes can be dropped from a successor package. Preserve the actual mapped file unless an explicit new byte-identical durable alias is verified. `METADATA-NOTES.json` lists these paths. This is a recovery interpretation note, not a corruption finding or a reason to modify frozen P02 evidence.

Current P02 processes have recorded positive completion with no active/unknown validation operation. Historical C270 interruption/global-process uncertainties remain historical unknowns. They cannot be resolved from this package's current-process closure.

## Limits and disposition

This worker ran only archive, hash and read-only Git identity checks. It did not run product behavior, edit repository files, mutate Git, contact a remote service, install packages, acquire a lease, spawn workers or save external files. All output belongs under `/workspace/scratch/7010345bc259/review/intake/`. The next assignment is the bounded historical Node-binding assessment when the preparation report is available, followed only by separately assigned exact-candidate review.
