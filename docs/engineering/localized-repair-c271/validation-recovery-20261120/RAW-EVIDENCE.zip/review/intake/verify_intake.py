#!/usr/bin/env python3
"""Read-only independent C271 P02 package/Git identity audit.

Only /review/intake is written. No validation behavior, Git mutation, or network
operation is invoked. Counts describe integrity predicates, not product tests.
"""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha1, sha256
from pathlib import Path, PurePosixPath
import json
import os
import stat
import subprocess
import zipfile

BASE = Path('/workspace/scratch/7010345bc259')
OUT = BASE / 'review/intake'
ZIP = BASE / 'incoming/OntoKin_C271_P02_Validation_Blocked_Handoff_2026-11-20.zip'
INCOMING = BASE / 'incoming/p02'
REPO = BASE / 'OntoKin'
HEAD = '72084140cd3ae64defc698e410f8806a8b338b72'
FRESH = OUT / 'fresh-extraction'
rows = []
git_reads = []


def check(name, passed, **detail):
    rows.append({'check': name, 'passed': bool(passed), **detail})


def identity(data):
    return {'bytes': len(data), 'sha256': sha256(data).hexdigest()}


def git(*args):
    argv = ['git', '--no-optional-locks', '-C', str(REPO), *args]
    result = subprocess.run(argv, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})
    git_reads.append({'argv': argv, 'returncode': result.returncode,
                      'stdout_identity': identity(result.stdout),
                      'stderr': result.stderr.decode(errors='replace')})
    if result.returncode:
        raise RuntimeError(git_reads[-1])
    return result.stdout


def safe(name):
    return (name != '' and not name.startswith('/') and '\\' not in name
            and all(p not in ('..', '') for p in PurePosixPath(name).parts))


def readjson(path):
    return json.loads(path.read_bytes())


OUT.mkdir(parents=True, exist_ok=True)
if FRESH.exists():
    raise RuntimeError('Fresh extraction target already exists; do not overwrite audit evidence')
FRESH.mkdir()
receipt_path = 'docs/engineering/localized-repair-c271/finalization-20261120/P02-DELIVERY.json'
receipt_raw = git('show', f'{HEAD}:{receipt_path}')
(OUT / 'P02-DELIVERY-at-72084140.json').write_bytes(receipt_raw)
receipt = json.loads(receipt_raw)
archive_identity = identity(ZIP.read_bytes())
check('outer_archive_matches_external_receipt',
      archive_identity == {k: receipt['archive'][k] for k in ('bytes', 'sha256')},
      actual=archive_identity, receipt_commit=HEAD, receipt_path=receipt_path)

with zipfile.ZipFile(ZIP) as archive:
    infos = archive.infolist()
    names = [e.filename for e in infos]
    duplicates = [n for n, count in Counter(names).items() if count > 1]
    invalid = [e.filename for e in infos if not safe(e.filename)
               or stat.S_ISLNK(e.external_attr >> 16) or e.is_dir()]
    check('archive_paths_safe_regular_payloads', not invalid, invalid=invalid)
    check('archive_names_unique', not duplicates, duplicates=duplicates)
    bad_crc = archive.testzip()
    check('archive_crc_integrity', bad_crc is None, first_bad_member=bad_crc)
    if invalid or duplicates or bad_crc is not None:
        raise RuntimeError('Unsafe or corrupt archive; extraction refused')
    manifest = json.loads(archive.read('MANIFEST-SHA256.json'))
    payloads = manifest['files']
    manifest_paths = [e['path'] for e in payloads]
    check('manifest_paths_unique', len(manifest_paths) == len(set(manifest_paths)))
    check('manifest_exact_inventory', set(names) == set(manifest_paths) | {'MANIFEST-SHA256.json'},
          members=len(names), payloads=len(payloads))
    required = ['README-START-HERE.md', 'CHECKPOINT.json', 'HANDOFF.md',
                'NEXT-TASK.md', 'RECOVERY-STATUS.md', 'PROMPT-1-CONTINUE.md',
                'PROMPT-2-RECOVER.md', 'HISTORICAL-DEPENDENCIES.json',
                'MANIFEST-SHA256.json']
    check('required_root_files_present', all(n in names for n in required))
    for entry in infos:
        target = FRESH / entry.filename
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(archive.read(entry))
    for entry in payloads:
        rel = entry['path']
        expected = {k: entry[k] for k in ('bytes', 'sha256')}
        actual = identity((FRESH / rel).read_bytes())
        check('fresh_extracted_payload_identity', actual == expected, path=rel,
              actual=actual, expected=expected)
        source = INCOMING / rel
        check('supplied_extraction_matches_archive', source.is_file() and identity(source.read_bytes()) == expected,
              path=rel)

checkpoint = readjson(FRESH / 'CHECKPOINT.json')
build = readjson(FRESH / 'metadata/BUILD-BOUNDARY.json')
snapshots = readjson(FRESH / 'metadata/SNAPSHOT-SOURCES.json')['files']
session = readjson(FRESH / 'metadata/SESSION-AND-RECOVERY-SOURCES.json')['files']
trees = {}
for revision in sorted({e['revision'] for e in snapshots}):
    index = {}
    for record in git('ls-tree', '-rz', '--full-tree', revision).split(b'\0'):
        if record:
            head, path = record.split(b'\t', 1)
            mode, kind, oid = head.decode().split(' ')
            index[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
    trees[revision] = index
for entry in snapshots:
    data = (FRESH / entry['package_path']).read_bytes()
    expected = {k: entry[k] for k in ('bytes', 'sha256')}
    object_id = sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    actual_tree = trees[entry['revision']].get(entry['repository_path'])
    expected_tree = {'mode': entry['git_mode'], 'kind': 'blob', 'oid': entry['git_blob']}
    check('snapshot_declared_identity', identity(data) == expected and object_id == entry['git_blob'],
          package_path=entry['package_path'], revision=entry['revision'])
    check('snapshot_path_in_declared_git_tree', actual_tree == expected_tree,
          repository_path=entry['repository_path'], revision=entry['revision'],
          actual=actual_tree, expected=expected_tree)
    check('snapshot_equals_available_git_object', git('cat-file', 'blob', entry['git_blob']) == data,
          package_path=entry['package_path'], revision=entry['revision'])
for entry in session:
    data = (FRESH / entry['package_path']).read_bytes()
    check('session_recovery_source_map_identity', identity(data) == {k: entry[k] for k in ('bytes', 'sha256')},
          package_path=entry['package_path'], source_path=entry['source_path'])
for label, revision, expected_tree in [
    ('observed_main', checkpoint['observed_main']['sha'], checkpoint['observed_main']['tree']),
    ('frozen_repository', checkpoint['repository_snapshot']['sha'], checkpoint['repository_snapshot']['tree']),
    ('executed_source', checkpoint['executed_source']['sha'], checkpoint['executed_source']['tree']),
]:
    raw = git('cat-file', 'commit', revision)
    actual_oid = sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    actual_tree = raw.splitlines()[0].decode().split(' ', 1)[1]
    check('declared_commit_and_tree', actual_oid == revision and actual_tree == expected_tree,
          role=label, commit=revision, tree=actual_tree)
check('build_checkpoint_source_agreement',
      build['source_revision'] == checkpoint['repository_snapshot']['sha']
      and build['source_tree'] == checkpoint['repository_snapshot']['tree']
      and build['observed_main'] == checkpoint['observed_main'])
check('external_receipt_frozen_source_agreement',
      receipt['source_revision'] == checkpoint['repository_snapshot']['sha']
      and receipt['source_tree'] == checkpoint['repository_snapshot']['tree'])
for rel, entry in zip(['PROMPT-1-CONTINUE.md', 'PROMPT-2-RECOVER.md'], receipt['prompts']):
    check('packaged_prompt_matches_saved_receipt', identity((FRESH / rel).read_bytes()) ==
          {k: entry[k] for k in ('bytes', 'sha256')}, path=rel)

unpublished = readjson(FRESH / 'recovery/UNPUBLISHED-COMMIT-IDENTITY.json')
raw_entry = next(e for e in session if e['source_path'].endswith('/UNPUBLISHED-AFFECTED-COMMIT.txt'))
raw = (FRESH / raw_entry['package_path']).read_bytes()
raw_oid = sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
raw_tree = raw.splitlines()[0].decode().split(' ', 1)[1]
published_tree = git('rev-parse', unpublished['published_equivalent_commit'] + '^{tree}').decode().strip()
check('unpublished_commit_exact_recovery', raw_oid == unpublished['local_commit']
      and len(raw) == unpublished['raw_commit_bytes']
      and sha256(raw).hexdigest() == unpublished['raw_commit_sha256']
      and raw_tree == published_tree == unpublished['same_tree'],
      raw_path=raw_entry['package_path'], computed_commit=raw_oid, tree=raw_tree)

result = {'schema': 'ontokin.c271.validation-recovery-intake/1',
          'reviewer': '/root/intake_review', 'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
          'archive': {'path': str(ZIP), **archive_identity},
          'fresh_extraction': str(FRESH), 'snapshot_count': len(snapshots),
          'session_source_count': len(session),
          'check_count': len(rows), 'failed_count': sum(not e['passed'] for e in rows),
          'checks': rows,
          'limits': ['Integrity predicates are not behavioral test results.',
                     'Git objects were read from the Director-provided local clone; no live remote read was performed by this worker.',
                     'Saved-file existence is not independently queried here; external receipt and supplied archive bytes agree.',
                     'No repository/Git mutation, network operation, product test, or nested worker was invoked.']}
(OUT / 'INTEGRITY-AUDIT.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'GIT-READS.json').write_text(json.dumps(git_reads, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ('archive', 'snapshot_count', 'session_source_count', 'check_count', 'failed_count')}))
