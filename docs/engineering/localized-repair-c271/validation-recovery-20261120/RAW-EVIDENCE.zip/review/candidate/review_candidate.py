#!/usr/bin/env python3
"""Read-only inspection of C271 P03 working repair and preparation evidence."""
import ast
import base64
from collections import Counter
import copy
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import json
import os
from pathlib import Path
import re
import stat
import subprocess

BASE = Path('/workspace/scratch/7010345bc259')
REPO = BASE / 'OntoKin'
OUT = BASE / 'review/candidate'
PREP = BASE / 'preparation'
PARENT = '72084140cd3ae64defc698e410f8806a8b338b72'
FILES = ('tools/check_local.py', 'tests/test_local_checks.py')
METHOD = 'test_workflow_instruction_targets_survive_workspace_isolation'
rows = []
reads = []


def digest(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def read(path):
    data = Path(path).read_bytes()
    reads.append({'path': str(path), **digest(data)})
    return data


def jsonfile(path):
    return json.loads(read(path))


def check(name, passed, **details):
    rows.append({'check': name, 'passed': bool(passed), **details})


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(REPO), *args],
                                   env={**os.environ, 'GIT_OPTIONAL_LOCKS': '0'})


OUT.mkdir(parents=True, exist_ok=True)
current = {p: read(REPO / p) for p in FILES}
original = {p: git('show', f'{PARENT}:{p}') for p in FILES}
source = {}
for path in FILES:
    target = OUT / 'reviewed-source' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(current[path])
    source[path] = digest(current[path])
    check('preserved_baseline_equals_git', read(PREP / 'copy-repair/source-before' / path) == original[path], path=path)
(OUT / 'reviewed-diff.patch').write_bytes(git('diff', PARENT, '--', *FILES))
base_receipt = jsonfile(PREP / 'copy-repair/BASE.json')
check('baseline_receipt_commit_tree', base_receipt['base_head'] == PARENT and
      base_receipt['base_tree'] == git('rev-parse', PARENT + '^{tree}').decode().strip())
for item in base_receipt['files']:
    check('baseline_file_receipt', digest(original[item['path']]) == {k: item[k] for k in ('bytes', 'sha256')}, path=item['path'])

old_driver = ast.parse(original[FILES[0]])
new_driver = ast.parse(current[FILES[0]])
def assignments(tree):
    return {node.targets[0].id: node for node in tree.body
            if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)}
old_constants = assignments(old_driver)
new_constants = assignments(new_driver)
expected_additions = {'SOURCE_DIRS': {'.agents'}, 'ROOT_FILES': {'CHATGPT-START-HERE.md', 'ROLE.md'}}
for name, additions in expected_additions.items():
    before = ast.literal_eval(old_constants[name].value)
    after = ast.literal_eval(new_constants[name].value)
    check('minimal_inventory_addition', set(after) - set(before) == additions and
          set(before) <= set(after) and len(after) == len(before) + len(additions), constant=name)
    new_constants[name].value = copy.deepcopy(old_constants[name].value)
check('driver_ast_otherwise_unchanged', ast.dump(old_driver) == ast.dump(new_driver))
old_tests = ast.parse(original[FILES[1]])
new_tests = ast.parse(current[FILES[1]])
new_class = next(n for n in new_tests.body if isinstance(n, ast.ClassDef) and n.name == 'LocalChecksTests')
all_methods = [n.name for n in new_class.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
new_method = [n for n in new_class.body if isinstance(n, ast.FunctionDef) and n.name == METHOD]
check('one_added_regression_test', len(new_method) == 1 and len(all_methods) == 31)
new_class.body = [n for n in new_class.body if n not in new_method]
check('all_preexisting_tests_unchanged', ast.dump(old_tests) == ast.dump(new_tests))
values = {n.targets[0].id: ast.literal_eval(n.value) for n in new_method[0].body
          if isinstance(n, ast.Assign) and len(n.targets) == 1 and isinstance(n.targets[0], ast.Name)
          and n.targets[0].id in ('paths', 'excluded')}
expected_paths = {'CHATGPT-START-HERE.md', 'ROLE.md', '.agents/skills/ontokin-session/SKILL.md',
                  '.agents/skills/ontokin-delivery/SKILL.md', '.agents/skills/ontokin-learning/SKILL.md'}
check('focused_test_covers_five_observed_omissions', set(values['paths']) == expected_paths)
check('focused_test_preserves_existing_exclusions', set(values['excluded']) == {
    '.agents/.env', '.agents/.env.local', '.agents/.cache/session.tmp',
    '.agents/node_modules/package/index.js', '.agents/.venv/installed.py',
    '.agents/__pycache__/module.pyc', 'temporary-worker/notes.txt'})

executions = {}
for stage in ('red', 'green', 'local-driver-cohort'):
    root = PREP / 'copy-repair' / stage
    receipt = jsonfile(root / 'EXECUTION.json')
    executions[stage] = receipt
    logs = {}
    for stream in ('stdout', 'stderr'):
        raw = read(root / (stream + '.log'))
        logs[stream] = raw.decode()
        check('execution_log_identity', digest(raw) == receipt[stream], stage=stage, stream=stream)
    expected_files = original if stage == 'red' else current
    for path in FILES:
        expected_bytes = current[path] if path == FILES[1] else expected_files[path]
        check('execution_input_identity', digest(expected_bytes) == receipt['input_files'][path], stage=stage, path=path)
    footer = re.findall(r'^Ran (\d+) tests? in ([0-9.]+)s$', logs['stderr'], re.M)
    check('execution_footer', len(footer) == 1 and int(footer[0][0]) == (31 if stage == 'local-driver-cohort' else 1), stage=stage)
    if stage == 'red':
        match = re.search(r'AssertionError: False is not true : (\{[^\n]+\})', logs['stderr'])
        missing = ast.literal_eval(match.group(1)) if match else None
        check('red_fails_exact_observed_omission', receipt['returncode'] == 1 and missing == expected_paths
              and 'FAILED (failures=1)' in logs['stderr'])
    else:
        check('passing_execution_has_no_skip_footer', receipt['returncode'] == 0 and
              re.findall(r'^(OK|FAILED.*)$', logs['stderr'], re.M) == ['OK'], stage=stage)
    if stage == 'local-driver-cohort':
        logged = re.findall(r'^(test_\w+) \(tests\.test_local_checks\.LocalChecksTests\.\w+\) \.\.\. ok$', logs['stderr'], re.M)
        check('full_module_inventory_exactly_once', Counter(logged) == Counter(all_methods), discovered_source_methods=len(all_methods), logged_methods=len(logged))
check('red_green_test_identical', executions['red']['input_files'][FILES[1]] == executions['green']['input_files'][FILES[1]])
check('red_green_same_focused_command', executions['red']['argv'] == executions['green']['argv'])
outcome = jsonfile(PREP / 'REPAIR-OUTCOME.json')
check('repair_outcome_binds_reviewed_bytes', outcome['changed_files'] == source)

lock_path = 'tools/native-reader-verification-linux-cp312.lock'
lock = read(REPO / lock_path)
check('python_hash_lock_unchanged', lock == git('show', f'{PARENT}:{lock_path}'))
python_receipt = jsonfile(BASE / 'environment/PYTHON-PREPARATION.json')
check('preparation_lock_identity', hashlib.sha256(lock).hexdigest() == python_receipt['lock_sha256'])
for command in python_receipt['commands']:
    raw = read(command['log'])
    check('python_preparation_command_log', hashlib.sha256(raw).hexdigest() == command['sha256'] and command['returncode'] == 0,
          command=command['command'])
pins = dict(re.findall(r'^([A-Za-z0-9_-]+)==(\S+) --hash=sha256:[0-9a-f]{64}$', lock.decode(), re.M))
def normalize(name):
    return re.sub(r'[-_.]+', '-', name).lower()
site = BASE / 'validation_env/lib/python3.12/site-packages'
distributions = {normalize(d.metadata['Name']): d for d in metadata.distributions(path=[str(site)])}
installed = []
for name, expected in pins.items():
    dist = distributions.get(normalize(name))
    actual = dist.version if dist else None
    check('installed_python_version_matches_pin', actual == expected, package=name, expected=expected, actual=actual)
    failures = []
    file_count = 0
    bound = []
    if dist:
        for file in dist.files or []:
            path = Path(dist.locate_file(file)).resolve()
            data = path.read_bytes()
            value = digest(data)
            bound.append({'path': str(path), **value})
            if file.hash:
                computed = base64.urlsafe_b64encode(hashlib.new(file.hash.mode, data).digest()).rstrip(b'=').decode()
                if computed != file.hash.value:
                    failures.append(str(path))
            if file.size is not None and len(data) != file.size:
                failures.append(str(path))
            file_count += 1
    check('installed_distribution_record_integrity', bool(dist) and not failures, package=name, files=file_count, mismatches=failures)
    installed.append({'package': name, 'expected': expected, 'installed': actual, 'files': bound})

external_path = 'docs/engineering/static-tray-qualification-c199/EXTERNAL-INPUTS.json'
external_raw = read(REPO / external_path)
check('historical_external_manifest_unchanged', external_raw == git('show', f'{PARENT}:{external_path}'))
external = json.loads(external_raw)
runtime_rows = []
for path, expected in external['runtime']['files'].items():
    p = Path(path)
    actual = {**digest(p.read_bytes()), 'mode': oct(stat.S_IMODE(p.stat().st_mode))}
    matched = actual['sha256'] == expected['sha256'] and actual['bytes'] == expected['size_bytes'] and actual['mode'] == expected['mode']
    runtime_rows.append({'path': path, 'expected': expected, 'actual': actual, 'matches_historical': matched})
aliases = []
for path, expected in external['runtime']['aliases'].items():
    p = Path(path)
    actual = {'resolved_path': str(p.resolve(strict=True)), 'symlink': p.is_symlink(), 'link_target': os.readlink(p) if p.is_symlink() else None}
    aliases.append({'path': path, 'expected': expected, 'actual': actual, 'matches_historical': actual == expected})
download = jsonfile(BASE / 'environment/NODE-DOWNLOAD.json')
node_raw = read(download['binary_path'])
node_actual = digest(node_raw)
check('downloaded_node_receipt_identity', node_actual['sha256'] == download['binary_sha256'] and node_actual['bytes'] == download['binary_bytes'])
node_path = '/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node'
node_expected = external['runtime']['files'][node_path]
node_mismatch_confirmed = node_actual['sha256'] != node_expected['sha256'] and node_actual['bytes'] != node_expected['size_bytes']
check('reported_downloaded_node_mismatch_is_correct', node_mismatch_confirmed and not download['matches_historical_pin'])
helper_path = 'docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py'
helper_raw = read(REPO / helper_path)
check('restoration_helper_unchanged', helper_raw == git('show', f'{PARENT}:{helper_path}'))
check('readback_tests_unchanged', read(REPO / 'tests/test_static_tray_readback_v01.py') == git('show', f'{PARENT}:tests/test_static_tray_readback_v01.py'))

for path in FILES:
    check('reviewed_source_stable_during_inspection', read(REPO / path) == current[path], path=path)
result = {'schema': 'ontokin.c271.p03-working-candidate-review/1',
          'reviewer': '/root/intake_review', 'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
          'base_commit': PARENT, 'reviewed_working_files': source,
          'verdict': 'minimal_repair_supported_R03_not_accepted',
          'mandatory_code_findings': [],
          'required_gate_blocker': 'Exact historical Node binary binding is not supplied by the downloaded official v24.22.1 binary.',
          'check_count': len(rows), 'failed_predicates': sum(not row['passed'] for row in rows), 'checks': rows,
          'node': {'required_path': node_path, 'required': node_expected, 'downloaded': node_actual,
                   'downloaded_matches_required': not node_mismatch_confirmed},
          'current_host_runtime': runtime_rows, 'current_host_aliases': aliases,
          'historical_input_paths': {
              'dependencies': {'path': external['dependencies_root'], 'exists': Path(external['dependencies_root']).exists()},
              'host_inventory': {'path': external['runtime']['host_inventory'], 'exists': Path(external['runtime']['host_inventory']).exists()}},
          'full_routine_executed_by_reviewer': False,
          'scope_limit': 'Working-file/evidence review; final published candidate and fresh record checks remain separate.'}
(OUT / 'CANDIDATE-AUDIT.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'INSTALLED-PYTHON-BINDINGS.json').write_text(json.dumps(installed, indent=2) + '\n')
(OUT / 'READ-SET.json').write_text(json.dumps({'reviewer': '/root/intake_review', 'files': reads}, indent=2) + '\n')
print(json.dumps({'verdict': result['verdict'], 'check_count': len(rows), 'failed_predicates': result['failed_predicates'],
                  'installed_packages': len(installed), 'runtime_mismatches': [r['path'] for r in runtime_rows if not r['matches_historical']],
                  'alias_mismatches': [r['path'] for r in aliases if not r['matches_historical']],
                  'downloaded_node_matches_required': result['node']['downloaded_matches_required']}))
