# C271 P03 independent repair and preparation review

Reviewer: `/root/intake_review`. This is a review of identified working files and retained preparation evidence above base `72084140cd3ae64defc698e410f8806a8b338b72`. It does not identify a new published candidate or replace the later final acceptance review.

## Verdict

**The minimal copy repair is supported, with no mandatory code findings. R03 is not accepted.** Exact historical Node preparation remains blocked. Do not launch the complete routine driver with the downloaded substitute binary.

The independent audit passed **59 evidence/identity predicates, zero failures**. Those predicates verify source changes, existing execution records and preparation identities; this reviewer did not execute product behavior or repeat tests. Full machine evidence is in `CANDIDATE-AUDIT.json`, installed Python file bindings are in `INSTALLED-PYTHON-BINDINGS.json`, and the reviewed bytes and patch are retained under `reviewed-source/` and `reviewed-diff.patch`.

## Exact reviewed implementation

| File | Bytes | SHA-256 |
| --- | ---: | --- |
| `tools/check_local.py` | 33,251 | `7b70944c6181a8df8900bb2b9b8df3bca6753be11e5fa62368e9302dc6fd3b51` |
| `tests/test_local_checks.py` | 32,436 | `36b06e8d1ef4195d3a615c1acc6a2f067d1703fa6d6efd6d54223c4de0997082` |

The driver adds `.agents` to `SOURCE_DIRS` and `CHATGPT-START-HERE.md` and `ROLE.md` to `ROOT_FILES`. Both inventory and copying use these constants. AST comparison against the baseline proves that every other driver statement is unchanged. The test module adds one method; AST comparison proves all preexisting tests and support code are unchanged.

The new test reproduces the five recorded omissions using an actual temporary Git repository. It verifies copied bytes and inventory equality, source commit/tree retention, a separate writable workspace index, unchanged source index bytes and modification time, and unchanged-source reporting. It also verifies exclusion of `.env` files, caches, dependencies, virtual environments, bytecode and an unrelated temporary top-level directory. The test exercises a concrete copy failure and the surrounding preservation behavior; it does not mirror only the new constants.

## Existing execution evidence inspected

| Execution | Result | Independent inspection |
| --- | --- | --- |
| New test with unchanged driver | One test, one failure, exit 1 | Missing-path set is exactly the five historical omissions; driver equals baseline Git bytes. |
| Same test after repair | One test, `OK`, exit 0 | Test-file hash and command match the failed invocation; driver matches reviewed bytes. |
| Full local-driver module | 31 tests, `OK`, exit 0 | All 31 source methods appear exactly once as successful log records; no skip footer. |

All stdout/stderr hashes match their receipts, all input-file identities match their declared stage, and the working files remained stable during this review. These were the implementation worker's original executions, not reviewer replays. The receipts name base HEAD plus working-file hashes; they correctly avoid claiming the base commit contains the repair.

Sources: `preparation/copy-repair/{BASE.json,red/EXECUTION.json,green/EXECUTION.json,local-driver-cohort/EXECUTION.json}` and their original logs; `preparation/COPY-REPAIR-REPORT.md` and `REPAIR-OUTCOME.json`.

## Python preparation is now supported

The Director's clean virtual environment installation completed with the unchanged `tools/native-reader-verification-linux-cp312.lock`, using binary wheels and `--require-hashes`. The lock hash and both command logs match `environment/PYTHON-PREPARATION.json`. Independent read-only distribution inspection confirms all seven required versions, including `rpds-py 2026.5.1`, and every hashed/sized installed distribution file matches its `RECORD`. The installed-file identities are retained in this review.

The earlier preparation reports accurately describe their earlier unprepared environment. Their Python blocker statements are historical and should be superseded by the new preparation receipt, not silently rewritten. No full-suite success follows from successful dependency installation.

## Exact Node prerequisite remains unresolved

The unchanged C225 restoration helper checks all ten runtime file bindings by SHA-256, size and mode, and checks all ten aliases. Its source inputs and the historical external-input manifest remain unchanged. The ordinary readback test class also uses the fixed historical Node/dependency/HOST paths and skips three methods when prerequisites are absent. The routine driver rejects an incomplete suite with skips.

| Node candidate | Bytes | SHA-256 | Historical binding |
| --- | ---: | --- | --- |
| Required historical executable | 126,939,688 | `61ab14cd750fc24d5db53490ec5fc40f756e4b6e136b78cf7004265471d9bd1d` | Required |
| Current host executable | 126,951,512 | `acbe4b8d9153b841ed0697cbfc4f93e767386620edb745ab9358306c0a6f31aa` | Mismatch |
| Downloaded `node-v24.22.1` executable | 126,879,696 | `e32e2d16081cf644f88392934288086e7662529d0d43277c34f7aad2207cfafb` | Mismatch |

This reviewer recomputed both current-host and downloaded-file identities. Nine other runtime files and all ten aliases match the historical records. The historical dependency directory and HOST destination are still absent at review time.

A private mount namespace can be truthful isolated environment preparation if it provides the **exact** required binary at the required path and all unchanged file/mode/alias checks pass in the same namespace inherited by the helper and test children. The host namespace must remain unchanged and the actual namespace/environment must be recorded. The successful capability probe shows that such isolation is available; it does not prove historical runtime qualification. Mounting the downloaded binary cannot satisfy the failed byte/size binding.

The Director's bounded C262 archive search is recorded in `environment/C262-NODE-SEARCH.json`: 16,422 physical members and 246 selected JSON manifest/alias/dependency/environment records were inspected; no directly retained matching executable was identified. The two hash matches are historical runtime records, not executable recovery. That search expressly excludes full reconstruction and nested source-bundle object traversal. This reviewer inspected the search receipt but did not independently replay that archive search, and makes no claim that the binary is globally unavailable.

Sources: unchanged `docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py`, `docs/engineering/static-tray-qualification-c199/EXTERNAL-INPUTS.json`, and `tests/test_static_tray_readback_v01.py`; current `environment/{NODE-DOWNLOAD.json,ISOLATION-CAPABILITIES.json,C262-NODE-SEARCH.json}`; independent runtime identities in `CANDIDATE-AUDIT.json`.

## Remaining acceptance and phase boundary

The copy defect can be preserved as a narrowly reviewed repair. Its focused success does not close the full isolated-driver finding or resolve the original missing unit-suite outcome. R03 remains open until all required preparation, a complete passing routine run, applicable exact-candidate checks and independent final acceptance succeed.

The Director has stopped technical expansion at this concrete prerequisite blocker. The remaining work in P03 is exact candidate publication, fresh focused/isolated-documentation/workflow verification, unchanged-helper preflight with truthful refusal if the runtime remains mismatched, final independent partial-state review, and verified saved handoff with an external receipt. No complete routine run, R04 integration or parent closure is approved by this report. A future qualified environment must preserve the original failures, frozen controls, dependency locks, tests and 100,000-operation/30,000-ms per-source limits.

All reviewer writes are confined to `/workspace/scratch/7010345bc259/review/candidate/`. No Git/index/remote mutations, package installations, host-runtime replacements, product tests or nested workers were performed.
