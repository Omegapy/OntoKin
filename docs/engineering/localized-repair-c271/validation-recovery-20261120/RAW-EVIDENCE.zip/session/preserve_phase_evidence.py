from pathlib import Path
import datetime
import hashlib
import json
import shutil
import zipfile

BASE = Path('/workspace/scratch/7010345bc259')
EVIDENCE = BASE / 'OntoKin/docs/engineering/localized-repair-c271/validation-recovery-20261120'
ARCHIVE = EVIDENCE / 'RAW-EVIDENCE.zip'
assert not ARCHIVE.exists()
selected = {}
for directory in ['preparation', 'review/intake', 'review/candidate', 'review/final',
                  'environment', 'candidate-preflight', 'validation']:
    for path in sorted((BASE / directory).rglob('*')):
        if not path.is_file():
            continue
        relative = path.relative_to(BASE)
        if any(part in {'fresh-extraction', 'workspace', '__pycache__', '.git'} for part in relative.parts):
            continue
        if directory == 'environment' and path.name in {'node-v24.22.1', 'node-v24.22.1-linux-x64.tar.xz'}:
            continue
        assert not path.is_symlink()
        selected[str(relative)] = path
session_names = ['PHASE.json', 'STARTUP-OBSERVATION.json', 'READ-SET.json', 'REMOTE-READBACK.json',
                 'EARLY-UPLOAD-RESULT.json', 'EARLY-LIBRARY-METADATA.json',
                 'PUBLISH-01-INTENT.json', 'PUBLISH-01-COMMIT.json', 'PUBLISH-01-READBACK.json',
                 'P03-PR-ISSUE-PUBLICATION.json', 'PRESERVATION.json', 'ACTIVE-OPERATIONS.json',
                 'run_candidate_checks.py', 'CANDIDATE-CHECKS-RUN.log', 'preserve_phase_evidence.py']
for name in session_names:
    path = BASE / 'session' / name
    assert path.is_file(), path
    selected['session/' + name] = path
assert (BASE / 'review/final/FINAL-ACCEPTANCE.json').is_file()
entries = []
for relative, path in sorted(selected.items()):
    data = path.read_bytes()
    entries.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
manifest = {'schema': 'ontokin.c271.p03-raw-evidence/1', 'payloads': entries,
            'boundary': 'Commands, original logs, raw records and reviews. Clean reproducible checkouts, Git objects, downloaded official Node binary/archive and installed Python environment excluded.'}
with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for relative, path in sorted(selected.items()):
        archive.writestr(relative, path.read_bytes())
    archive.writestr('MANIFEST-SHA256.json', json.dumps(manifest, indent=2) + '\n')
verification = {'schema': 'ontokin.c271.p03-raw-verification/1', 'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                'archive': {'filename': ARCHIVE.name, 'bytes': ARCHIVE.stat().st_size,
                            'sha256': hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()},
                'payloads': len(entries), 'members': len(entries) + 1, 'passed': True,
                'checks': ['CRC', 'safe unique relative paths', 'exact manifest inventory', 'all size/hash bindings', 'fresh extraction comparison'],
                'excluded': manifest['boundary']}
fresh = BASE / 'raw-evidence-verification'
assert not fresh.exists()
with zipfile.ZipFile(ARCHIVE) as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    assert len(names) == len(set(names))
    assert set(names) == set(selected) | {'MANIFEST-SHA256.json'}
    assert all(not Path(name).is_absolute() and '..' not in Path(name).parts for name in names)
    archive.extractall(fresh)
for entry in entries:
    data = (fresh / entry['path']).read_bytes()
    assert len(data) == entry['bytes']
    assert hashlib.sha256(data).hexdigest() == entry['sha256']
    assert data == selected[entry['path']].read_bytes()
(EVIDENCE / 'RAW-EVIDENCE-VERIFICATION.json').write_text(json.dumps(verification, indent=2) + '\n')
(EVIDENCE / 'RAW-EVIDENCE-MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(verification))
