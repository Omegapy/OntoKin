from pathlib import Path
import datetime
import hashlib
import json
import platform
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/7010345bc259')
REPO = BASE / 'OntoKin'
OUT = BASE / 'validation'
OUT.mkdir(exist_ok=True)
sys.path.insert(0, str(REPO))
from tools import check_local

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def execute(name, command, cwd=REPO, timeout=120):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    start = time.monotonic()
    result = subprocess.run(command, cwd=cwd, capture_output=True, timeout=timeout)
    stdout = OUT / (name + '.stdout.log')
    stderr = OUT / (name + '.stderr.log')
    stdout.write_bytes(result.stdout)
    stderr.write_bytes(result.stderr)
    row = {'name': name, 'command': list(map(str, command)), 'cwd': str(cwd),
           'started_at_utc': started, 'seconds': round(time.monotonic() - start, 3),
           'returncode': result.returncode, 'stdout': stdout.name, 'stderr': stderr.name,
           'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
           'stderr_sha256': hashlib.sha256(result.stderr).hexdigest()}
    write(OUT / (name + '.receipt.json'), row)
    print(json.dumps(row), flush=True)
    return row

before_git = check_local.git_metadata(REPO)
assert before_git['local_head'] == 'fea1aa6fb3712c5283dde197295b2d3cbf925d36'
assert not before_git['tracked_worktree_status'] and not before_git['untracked_source_files']
before = check_local.inventory(REPO)
write(OUT / 'SOURCE-BEFORE.json', before)
summary = {'source': before_git, 'python': sys.version, 'python_executable': sys.executable,
           'platform': platform.platform(), 'checks': [],
           'scope': 'Focused repair verification and prerequisite diagnosis; not a complete routine driver run'}
summary['checks'].append(execute('focused-local-driver', [sys.executable, '-B', '-m', 'unittest', 'tests.test_local_checks', '-v']))
summary['checks'].append(execute('workflow', [sys.executable, '-B', 'tools/chat_workflow.py', 'check']))
summary['checks'].append(execute('native-reader-setup', [sys.executable, '-I', '-B', 'tools/check_native_reader_setup.py']))
isolated = OUT / 'isolated-documents'
check_local.prepare_output(REPO, isolated)
workspace = check_local.prepare_workspace(REPO, isolated, False, source_git=before_git)
workspace_git = check_local.git_metadata(workspace)
required = ['CHATGPT-START-HERE.md', 'ROLE.md', '.agents/skills/ontokin-session/SKILL.md',
            '.agents/skills/ontokin-delivery/SKILL.md', '.agents/skills/ontokin-learning/SKILL.md']
copy_checks = []
for relative in required:
    data = (workspace / relative).read_bytes()
    assert data == (REPO / relative).read_bytes()
    copy_checks.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
assert workspace_git['local_head'] == before_git['local_head']
assert workspace_git['local_tree'] == before_git['local_tree']
assert not workspace_git['tracked_worktree_status']
document_step = next(step for step in check_local.build_plan(workspace, isolated, False, python=sys.executable) if step.id == 'documents')
summary['checks'].append(execute('isolated-documents', document_step.argv, workspace))
summary['copy_verification'] = {'required_files': copy_checks, 'workspace_git': workspace_git,
                                'source_index_independent': not (REPO / '.git/index').samefile(workspace / '.git/index')}
readback_report = OUT / 'readback-preflight.json'
summary['checks'].append(execute('readback-prerequisites', [sys.executable, '-B',
    'docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py',
    '--repo', str(REPO), '--report', str(readback_report)]))
summary['readback_preflight'] = json.loads(readback_report.read_text())
after = check_local.inventory(REPO)
after_git = check_local.git_metadata(REPO)
write(OUT / 'SOURCE-AFTER.json', after)
summary['source_after'] = after_git
summary['source_unchanged'] = before == after and before_git == after_git
summary['required_routine'] = {'status': 'not_run', 'reason': 'Exact historical Node runtime binding unresolved; no unprepared aggregate attempt or skipped prerequisite waiver', 'prior_P02_result': 'failed and preserved'}
write(OUT / 'CHECKS.json', summary)
assert summary['source_unchanged']
assert all(item['returncode'] == 0 for item in summary['checks'] if item['name'] != 'readback-prerequisites')
assert summary['checks'][-1]['returncode'] != 0
print('Completed focused verification; exact prerequisite blocker retained', flush=True)
