# C271 P03: validation preparation investigation

Worker: `/root/validation_prepare`. Role: read-only investigator. Source inspected: `72084140cd3ae64defc698e410f8806a8b338b72` on the existing C271 work branch. This report is preparation evidence, not a test result or integration approval. The Director owns the phase records, Git/index, publication and saved delivery.

This report records the initial investigation. The subsequent authorized header probe and copy repair are recorded separately in `RPDS-WHEEL-HEAD.json` and `COPY-REPAIR-REPORT.md`; the no-execution statements below describe the investigation before that follow-up assignment.

## Verdict

The copy-preservation repair and a justified longer routine-run plan can be prepared within the selected scope. A complete routine run is currently blocked by an additional, observed host prerequisite: the installed Node binary is **v24.22.3**, while the unchanged CPU readback controls require **v24.22.1**. The existing recovery helper also requires the historical binary's exact hash. It cannot legitimately restore the readback prerequisites on this host as observed.

The Python environment also repeats P02's mismatch: installed `rpds-py==2026.6.3`, required `2026.5.1`. Six other installed versions match the seven-package lock. Matching versions alone do not establish the prescribed clean, hash-verified installation.

No test methods, native readers, product evaluations, installation commands or repository edits were run during this investigation. `node --version` was used only to identify the installed runtime. All new files are confined to the assigned `preparation/` directory. Original evidence was read in place and preserved.

## Governing boundary

The complete assigned AGENTS, GOAL, ROLE, PROTOCOL, HANDOFF, START, delivery skill, OK-ENG-006, C271 LEARNING-P02 and P02 outcome were read. Global startup and saved recovery belong to the Director. P03 may repair the local driver's copying and prepare declared verification dependencies, then stop at R03 acceptance or a concrete blocker. No integration, later H group or second phase is authorized here.

The ordinary per-source ceilings remain **100,000 operations and 30,000 ms**. Existing fixture-specific budgets, frozen controls, assertions, skips, source stability and exact dependency guards must also retain their meanings. A longer **validation-command** timeout changes the allowance for executing thousands of separate tests; it does not change any source execution budget.

## Original evidence preserved and interpreted

The P02 raw archive is 4,965,080 bytes with SHA-256 `c4c973d40c4f6571def93b257877de69568bcd5fdca43bcfed92ff6acfc61e20`. Its retained unit log is 655,857 bytes with SHA-256 `727232296a766d1af6edae14343966fa15e8b3389ea04e1efb44e6652cbe78d7`. The archive and member identities were recomputed without extracting or modifying them.

The unit step ended at 900.025 seconds with return code -15. It has no final unittest footer. The driver's `tests_run=0` is the result of parsing an absent footer, not evidence that no tests executed. The prior independent inspection records 3,370 strict single-line method success records and 60 additional docstring continuation success lines; these are partial log counts, not a complete method inventory or an aggregate pass.

The unfinished final log entry names `ReachSamplingScalarReuseTests.test_p16_prefix_keeps_the_complete_original_glb`. Its source performs two GLB exports and compares their bytes while retaining an assertion on the original 100,000-operation ceiling. The log has no per-method timing. The final entry therefore identifies where observation stopped; it does **not** establish that this method caused the whole-suite timeout, hung, or regressed.

The remaining P02 command durations were source 0.769 s, Agent 0.869 s, construction 36.597 s, surface 21.694 s, impulse 53.316 s and documentation 2.271 s. The first five passed at their existing scopes. Documentation failed because the isolated copy omitted five instruction targets. Complete-checkout success does not waive the isolated-driver failure.

Sources: `finalization-20261120/verification/RAW-EVIDENCE.zip`, its `routine-candidate/summary.json` and unit log; `independent-review/UNIT-TIMEOUT-INSPECTION.json`; `verification/REPORT.md`; current `tests/test_reach_sampling_scalar_reuse.py`.

## Exact Python preparation

OK-ENG-006 §3 prescribes a clean environment outside the checkout and binary wheels checked with the unchanged `tools/native-reader-verification-linux-cp312.lock`.

| Package | Required | Observed |
| --- | --- | --- |
| attrs | 26.1.0 | 26.1.0 |
| jsonschema | 4.26.0 | 4.26.0 |
| jsonschema-specifications | 2025.9.1 | 2025.9.1 |
| referencing | 0.37.0 | 0.37.0 |
| rpds-py | 2026.5.1 | **2026.6.3** |
| typing_extensions | 4.16.0 | 4.16.0 |
| Pillow | 13.0.0 | 13.0.0 |

Observed interpreter: CPython 3.12.14; platform Linux x86-64, glibc 2.41. The lock's intended platform matches this interpreter/platform family. The required rpds wheel is `rpds_py-2026.5.1-cp312-cp312-manylinux_2_17_x86_64.manylinux2014_x86_64.whl`, 376,280 bytes, SHA-256 `b6825cc329b290e93c5f6a9be2393118a763f6ccf6abd83704e0c102ca583644`.

Concrete preparation, once the Director confirms early recovery and dependency availability:

1. Obtain the exact seven wheels through an available authorized package source or retained archive. Preserve download/source identity and compare each wheel hash with the lock. Do not substitute an installed newer package, change the lock or recreate a wheel from installed files.
2. Create a new CPython 3.12 virtual environment outside the source checkout. Install with `python -I -m pip install --only-binary=:all: --require-hashes -r <checkout>/tools/native-reader-verification-linux-cp312.lock`. For local wheels, add `--no-index --find-links <verified-wheel-directory>`. Save complete stdout/stderr, exit code and package identities externally.
3. Check all seven installed versions and bind their installed distribution files. Run the existing `python -I -B tools/check_native_reader_setup.py` preflight from that environment. Its implementation checks Pillow only; a success cannot establish the other six exact pins.
4. Record interpreter identity, platform, wheel hashes, package versions, environment overrides and exact command before any full discovery or aggregate launch.

The historical `docs/engineering/force-agent-local-validation-2026-10-19/prerequisites/pip-install.json` contains source URLs and matching hashes for six wheels, including the required rpds wheel. C224 `evidence/PREFLIGHT.json` identifies all seven wheel names, sizes and hashes. The required rpds URL is:

`https://files.pythonhosted.org/packages/f4/1e/2c9096fc19d5fd084b0184ca2b651e659aa0a37e6fdbecf6ece47f147fe1/rpds_py-2026.5.1-cp312-cp312-manylinux_2_17_x86_64.manylinux2014_x86_64.whl`

No network download was attempted. Searches of the current scratch tree, primary runtime, `/tmp`, and the current user's pip/uv cache locations found no required verification wheels. The pip/uv cache locations were absent. This is a scoped search result, not proof that no retained archive exists elsewhere. Network policy and actual package retrieval remain separate feasibility checks.

## Historical readback prerequisites

The three `ReadbackCPUControls` methods use fixed historical paths:

- Node: `/opt/codex/runtimes/codex-primary-runtime/dependencies/node/bin/node`.
- Dependencies: `/workspace/scratch/801d9d641f68/incoming-audit/work/prior-replay/evidence/c195-validation/receiving`.
- HOST inventory: `/workspace/scratch/801d9d641f68/c199-independent-preflight/HOST-RUNTIME-INVENTORY.json`.

Both input destinations are currently absent. The class's unchanged guard would skip the three methods if they remained absent; the routine driver rejects a suite with skips. Preparing only the Python packages therefore cannot produce complete routine acceptance.

The repository already has a reviewed recovery helper: `docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py`. It is dry-run by default. It verifies six source identities, the retained archive, exactly 24 dependency files, the historical HOST file, ten runtime files and ten aliases. It permits installation only when both historical destinations are absent, verifies exact existing inputs without replacement, and refuses partial, changed, extra or symlinked installations. Its only installation option is `--apply`; there is no alternate-host or re-observation option.

The 24 JS files are preserved in `docs/engineering/ownership-recovery-c195/evidence/recorded-evidence.tar.xz`, SHA-256 `b1e54a6cfef133f7004b1988c90bc718fc954409843c2bcac3772d42e904a0c9`. The original HOST inventory is preserved in the C199 preflight directory, SHA-256 `2ed86412f09c74f5d3fb038f50e6417872b8eace0f89d7f168c79923efb14994`, 2,706,604 bytes. Restoring that file keeps it historical; it cannot be relabeled as a current whole-host attestation.

### Concrete runtime mismatch

| Binding | Required | Observed |
| --- | --- | --- |
| Node version | v24.22.1 | **v24.22.3** |
| Node bytes | 126,939,688 | **126,951,512** |
| Node SHA-256 | `61ab14cd750fc24d5db53490ec5fc40f756e4b6e136b78cf7004265471d9bd1d` | `acbe4b8d9153b841ed0697cbfc4f93e767386620edb745ab9358306c0a6f31aa` |
| Other runtime file bindings | Ten total, including Node | Nine of nine other bindings match |
| Runtime aliases | Ten | All ten match |

The helper will refuse on the Node binding before restoring either input. The product-side `prototypes/static_tray_v01/format_check.py` independently requires version v24.22.1 in both `build_manifest` and `verify_manifest`. Although `build_manifest` records actual files, it provides no supported path for the current v24.22.3 runtime. Recreating a current HOST record would not resolve the version guard.

The C195 archive was inspected and contains no Node executable or Node distribution archive. The single installed runtime, relevant scratch and temporary locations contained no identified v24.22.1 binary. Do not replace the shared host Node, alter the historical HOST record, or relax the helper/version guards as part of the narrow copy repair. A supported isolated verification environment with the required runtime at the required path would resolve this prerequisite without changing tests; its availability has not been established. Otherwise, preserve this blocker and require a separately reviewed portability decision.

If that environment becomes available, run the unchanged helper with a fresh external report, inspect the dry-run, and only then run `--apply` when both targets are absent. Preserve both reports and the exact bytes. C225's instructions expressly avoid repeating the focused CPU cohort just because a handoff is restored; the selected aggregate can execute those methods once all prerequisites are ready.

## Bounded full routine completion plan

Recommend **one default core attempt with `--timeout 3600`**, no automatic retry, on a frozen identified source after the copy repair and all prerequisites pass. This is the complete routine driver; it does not select the optional `--full` visual role or `--force-agent` role.

This limit has direct precedent. C228 used it and completed all seven commands in 1,315.673 s, retaining its actual single-method failure. C233 used it and passed 4,685 methods and all seven commands in 1,171.106 s; its unittest footer recorded 1,066.688 s. These observed runtimes exceed 900 s without approaching 3,600 s. OK-ENG-006 also documents a 3,600-second command allowance. Those historical results support a declared larger suite-command allowance, not reuse as evidence that today's source passes.

The driver applies the timeout independently to each command and continues after an ordinary failed command. Preserve that behavior and collect all seven final outcomes. A whole-driver failsafe of **25,800 seconds** follows the existing C228/C233 plan: seven command ceilings plus 600 seconds for copy/preparation/cleanup. This is an upper bound, not a runtime forecast or permission to proceed through a new scope. A shorter operational deadline could be selected explicitly, but it would create a separate possible outer-timeout outcome. A command budget cannot guarantee completion on an unmeasured host.

Before launch, save actual discovery identities using the prepared environment, with failed-import placeholders, declared skips and fixture setup conditions accounted for. Static inspection found 372 `test*.py` files and 4,689 test-prefixed function definitions; this is **not** a discovery inventory because dynamic and inherited cases may differ. Do not extrapolate a completion count or time from those definitions.

Record the exact source commit/tree, clean-state/input inventories, interpreter/packages, dependency closure, commands and settings, fresh external output, permitted attempt count and prelaunch review. Use `PYTHONDONTWRITEBYTECODE=1`, the prepared interpreter with `-B`, and preserve readback artifacts through `STATIC_TRAY_READBACK_CPU_OUTPUT` at a fresh external path. Keep the executed checkout immutable. Confirm early recovery before the long run.

Acceptance requires every inventoried method to be reconciled to the single attempt, no skips/expected failures/unrun methods/setup or import errors, all seven default steps passed, source and Git unchanged, and positively observed process completion. Inspect individual reports and preserve their pending external gates. If the attempt fails, retain the complete log and actual outcome; do not stitch partial passes, infer timeout cause from the last line or replay automatically.

## Immediate next action and stop

The Director can proceed with the narrow copy inventory repair and focused preservation check after early recovery confirmation. The full routine launch remains blocked until exact Python packages and the historical Node/readback closure are legitimately available. Do not consume an expensive aggregate attempt while an already observed prerequisite guarantees skips or setup failure.

Detailed machine-readable evidence: `ENVIRONMENT-PREFLIGHT-READONLY.json`. Source and governing read identities: `READSET.json`. This investigation stops for the Director's follow-up assignment.
