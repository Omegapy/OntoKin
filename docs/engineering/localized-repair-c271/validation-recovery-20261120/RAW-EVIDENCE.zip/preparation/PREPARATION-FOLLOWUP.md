# C271 P03 prerequisite follow-up

This updates the initial preparation diagnosis without changing its historical observations. Copy repair evidence is complete in `COPY-REPAIR-REPORT.md`. The Director owns subsequent environment preparation and candidate publication.

## Python preparation observed

The Director's `environment/PYTHON-PREPARATION.json` was inspected. It records successful creation of `/workspace/scratch/7010345bc259/validation_env` and successful binary-only, hash-required installation using the original seven-package lock (SHA-256 `a7f17491000c2e139ccc5d213ca0e8a6f917e5befb4b878fef29f5ff72ae780f`). Both commands exited 0. This supersedes the initial package-availability obstacle for the new environment; the original host environment and P02 mismatch remain historical facts. Final package/decoder readiness and execution evidence remain the Director's responsibility.

## Exact readback helper commands

Only run these after the identified verification environment satisfies the historical runtime binding. Run them from the clean published candidate checkout. Use the prepared interpreter and new external report paths; these commands have not been executed by this worker.

```bash
PYTHONDONTWRITEBYTECODE=1 GIT_OPTIONAL_LOCKS=0 /workspace/scratch/7010345bc259/validation_env/bin/python -B docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py --repo /workspace/scratch/7010345bc259/OntoKin --report /workspace/scratch/7010345bc259/preparation/readback/dry-run.json
```

After inspecting a passing dry-run with both target locations absent:

```bash
PYTHONDONTWRITEBYTECODE=1 GIT_OPTIONAL_LOCKS=0 /workspace/scratch/7010345bc259/validation_env/bin/python -B docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py --repo /workspace/scratch/7010345bc259/OntoKin --apply --report /workspace/scratch/7010345bc259/preparation/readback/restoration.json
```

Then verify the restored state without another installation:

```bash
PYTHONDONTWRITEBYTECODE=1 GIT_OPTIONAL_LOCKS=0 /workspace/scratch/7010345bc259/validation_env/bin/python -B docs/engineering/readback-prerequisites-c225/restore_readback_prerequisites.py --repo /workspace/scratch/7010345bc259/OntoKin --report /workspace/scratch/7010345bc259/preparation/readback/after-verify.json
```

The helper requires a clean Git checkout, exact source hashes, runtime bytes/modes/aliases, non-symlink path ancestors, and report/staging on the same filesystem as installation destinations. Both historical inputs must be absent or both already exact; a partial installation is refused. Its own preflight, restoration and verification do not start test methods or Node readers. A separately repeated focused CPU cohort is unnecessary solely for handoff restoration; the selected complete aggregate can execute the three methods. The aggregate and its descendants must see the same verified runtime and historical input paths. `STATIC_TRAY_READBACK_CPU_OUTPUT` should name a fresh absent external directory so the actual aggregate preserves its readback outputs.

The retained archive and helper source identities were recorded during the initial inspection. A later optional attempt to automate comparison of all embedded source hashes and 24 dependency payloads stopped at an AST parsing error before producing a result; `READBACK-INSPECTION-ATTEMPT01.json` preserves that failure. No comparison success is claimed from that attempt. It was not retried after the Director declared the concrete-blocker stop. No archive payload was extracted or installed.

## Node identity remains unresolved

The Director reports that the official Node v24.22.1 Linux x64 distribution downloaded successfully, but its binary is 126,879,696 bytes with SHA-256 `e32e2d16081cf644f88392934288086e7662529d0d43277c34f7aad2207cfafb`. This differs from the required 126,939,688 bytes and SHA-256 `61ab14cd750fc24d5db53490ec5fc40f756e4b6e136b78cf7004265471d9bd1d`. Equal version strings do not satisfy this exact binding. This worker did not use, mount or execute the substituted binary.

The narrow repository search found the expected Node hash/size only in six C199/C200/C225 binding/receipt JSONs. It found no identified stored Node binary. The C195 retained-input tar contains no Node executable or Node distribution archive. C225's raw manifest lists 53 files totaling 4,747,801 bytes, with no runtime binary. C199's archive component inventory describes Blender components; its HOST inventory does not contain a Node executable binding. These are scoped findings, not proof that no historical copy exists elsewhere.

C262 was a legitimate external search candidate. Its archive identity is 532,260,846 bytes, SHA-256 `b8af544f730a4d1f741d47b56eb3fcf76147ed392a9ebb020f3d966f2f305c90`. C263's migration record explicitly states that not all historical packaging contents were imported into GitHub. The Director now reports that a scan of the exact archive found no directly retained expected Node binary; its evidence is `environment/C262-NODE-SEARCH.json`. This worker has not independently inspected the archive's member/manifest contents. No full historical restoration or nested Git traversal was performed or claimed. The Director has declared the concrete-blocker stop.

The exact historical runtime must be recovered through a supported path. Do not change version/hash guards, rebuild an approximation, replace the shared host runtime, or run a known-blocked aggregate. A verified isolated mount environment would be suitable only if it presents the exact required bytes and preserves all existing checks. No such environment is claimed ready by this report.

The worker has stopped with no active operations. The Director retains ownership of further preparation, independent acceptance, publication and saved delivery.
