# C271 P03: minimal instruction-copy repair

Worker: `/root/validation_prepare`. Initial source commit: `72084140cd3ae64defc698e410f8806a8b338b72`; tree `c372590d4bdaf4882bdc0eb0683783991dbce649`. Work followed the Director's confirmation of the saved early recovery checkpoint and explicit assignment of `tools/check_local.py`, `tests/test_local_checks.py` and external preparation reports. This worker made no Git/index, phase-record or publication changes.

## Change and result

The driver now includes `.agents` in `SOURCE_DIRS` and includes `CHATGPT-START-HERE.md` and `ROLE.md` in `ROOT_FILES`. Those same inventories feed source hashing and workspace copying, so the five required instruction targets are now both recorded and copied. No generic audit framework or copying of the entire checkout was added.

The focused test `LocalChecksTests.test_workflow_instruction_targets_survive_workspace_isolation` exercises actual temporary Git checkout copying. It covers:

- Exact bytes for the two root instruction files and the three `.agents/skills/*/SKILL.md` targets.
- Presence in the source inventory and equality of source/workspace inventories.
- Existing exclusions for `.env`, `.env.local`, cache directories, dependency directories, Python bytecode and an unrelated top-level temporary directory.
- Preserved source commit/tree, an independent writable workspace Git index, and unchanged source index bytes/mtime when the workspace index is modified.
- The existing `source_unchanged` result.

The test was added before modifying the driver. Its first invocation failed with a set containing exactly the five omitted paths. The unchanged driver hash in that receipt matches the original source. After the two inventory changes, the exact same test file passed. The full local-driver test module then passed all 31 tests, including its existing source isolation, failure reporting, skip rejection, timeout, dependency-preflight, external-output and Git provenance controls.

| Execution | Actual result | Evidence |
| --- | --- | --- |
| Focused test before fix | 1 test; 1 failure; child exit 1 | `copy-repair/red/EXECUTION.json` and stderr log |
| Same focused test after fix | 1 test; passed; child exit 0 | `copy-repair/green/EXECUTION.json` and stderr log |
| Entire local-driver module | 31 tests; passed in 2.082 s; zero skips; child exit 0 | `copy-repair/local-driver-cohort/EXECUTION.json` and stderr log |

The shell inspection wrappers completed successfully while recording the actual subprocess return codes. The preserved red failure is therefore a real test failure, not the wrapper's outer exit status.

All executions used CPython 3.12.14 with `-B`, `PYTHONDONTWRITEBYTECODE=1` and `GIT_OPTIONAL_LOCKS=0`. Input file hashes are captured before each invocation and were unchanged through the final cohort. The exact baseline copies are under `copy-repair/source-before/`; `copy-repair/BASE.json` binds their source revision, bytes and hashes. `copy-repair/copy-repair.patch` contains the complete change from that baseline.

Final driver identity: 33,251 bytes; SHA-256 `7b70944c6181a8df8900bb2b9b8df3bca6753be11e5fa62368e9302dc6fd3b51`.

Final test-module identity: 32,436 bytes; SHA-256 `36b06e8d1ef4195d3a615c1acc6a2f067d1703fa6d6efd6d54223c4de0997082`.

These are checked working-file identities above the stated base revision, not a claim that the base commit contains the new code. The Director will publish the candidate before exact aggregate verification.

## Dependency availability follow-up

After explicit authorization for a short read-only network probe, the exact historical rpds-py 2026.5.1 wheel URL returned HTTP 200 with `Content-Length: 376280`, matching the historical wheel size. The request was HEAD-only, used no credentials or escalation, followed no redirects, and did not download a wheel or install a package. `RPDS-WHEEL-HEAD.json` preserves the source URL, argv, timestamps, headers, stderr and return code. Header success establishes current endpoint availability; it does not verify payload bytes or installation.

No official Node distribution URL was found in the inspected repository sources. This worker did not invent or probe a distribution URL. The observed Node v24.22.3 versus required v24.22.1 mismatch remains documented in `ENVIRONMENT-PREFLIGHT-READONLY.json`. The unchanged restoration helper has no alternate-host path and the unchanged reader independently enforces v24.22.1.

## Remaining gates and stop

This result establishes the focused copy repair. It does not establish the complete routine driver, R03 acceptance, integration or release qualification. No full driver, full test discovery, optional visual/force role, package installation, historical input restoration or native/model trial ran here. The default 900-second driver value, test expectations, frozen controls, dependency locks and all per-source limits remain unchanged.

The initial report recommends a predeclared `--timeout 3600` for one complete default routine attempt, supported by earlier complete 1,171-second and 1,316-second aggregate runs. The Director must first resolve exact Python/readback prerequisites, publish and identify the repaired candidate, and obtain the required independent acceptance. Preserve the earlier 900-second failure separately. No automatic retry is authorized by this report.

The worker stops with no running test or network process. The Director owns independent review, any permitted dependency preparation, publication, phase evidence and saved delivery.
