"""Data-integrity checks only. Does not import OntoKin or evaluate its policy."""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import platform
import stat
import struct
import sys
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('--candidate', required=True)
parser.add_argument('--repo', required=True)
parser.add_argument('--historical-inputs', required=True)
parser.add_argument('--report', required=True)
args = parser.parse_args()
candidate, repo, historical = Path(args.candidate), Path(args.repo), Path(args.historical_inputs)
groups = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(path.read_text())

def bound(base, row, size_key='bytes', mode=True):
    path = base / row['path']
    pure = PurePosixPath(row['path'])
    assert not pure.is_absolute() and '..' not in pure.parts
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode)
    data = path.read_bytes()
    assert len(data) == row[size_key] and sha(data) == row['sha256'], str(path)
    if mode:
        assert oct(stat.S_IMODE(info.st_mode)) == row['mode'], str(path)
        assert not info.st_mode & 0o111, str(path)
    return data

manifest = load(candidate / 'CANDIDATE-MANIFEST.json')
assert len({row['path'] for row in manifest['files']}) == len(manifest['files'])
actual = sorted(str(path.relative_to(candidate)) for path in candidate.rglob('*') if path.is_file())
assert actual == sorted([row['path'] for row in manifest['files']] + ['CANDIDATE-MANIFEST.json'])
for row in manifest['files']:
    bound(candidate, row)
groups.append({'name': 'candidate_inventory_and_exact_bytes', 'passed': True,
               'payload_files': len(manifest['files']), 'payload_bytes': sum(row['bytes'] for row in manifest['files'])})

fixtures = load(candidate / 'FIXTURE-MANIFEST.json')['files']
for row in fixtures:
    bound(candidate, row)
construction = load(candidate / 'CONSTRUCTION.json')['images']
for row in construction:
    data = bound(candidate, row['image'])
    assert data[:16] == b'\x7fELF\x02\x01\x01' + bytes(9)
    assert struct.unpack_from('<HH', data, 16) == (row['type'], row['machine'])
    assert struct.unpack_from('<Q', data, 32)[0] == 64
    assert struct.unpack_from('<HHH', data, 52) == (64, 56, 2)
    for index, header in enumerate(row['program_headers']):
        assert list(struct.unpack_from('<IIQQQQQQ', data, 64 + index * 56)) == header
    for index, entry in enumerate(row['dynamic_entries']):
        assert list(struct.unpack_from('<qQ', data, row['dynamic_offset'] + index * 16)) == entry
    strings = bytes.fromhex(row['strings_hex'])
    assert data[row['strings_offset']:row['strings_offset'] + len(strings)] == strings
    assert len(data) == 2048
groups.append({'name': 'inert_fixture_identity_and_declared_construction', 'passed': True,
               'fixtures': len(fixtures), 'distinct_elf_images': len(construction)})

controls = load(candidate / 'CONTROLS.json')['cases']
expect = load(candidate / 'EXPECTATIONS.json')['cases']
assert len({row['id'] for row in controls}) == len(controls)
assert set(expect) == {row['id'] for row in controls}
for row in controls:
    value = load(candidate / row['context'])
    assert value['case_id'] == row['id'] and value['route'] == row['route']
    assert value['operational'] is False
    if 'image' in value:
        bound(candidate, value['image'])
        assert value['actual_fixture_bytes'] == {key: val for key, val in value['image'].items() if key != 'path'}
    oracle = expect[row['id']]
    assert oracle['current_execution'] == 'not_run'
    assert oracle['host_qualified'] is False and oracle['operational_plan_accepted'] is False
    assert oracle['expected_node_starts'] == oracle['expected_ldd_starts'] == oracle['expected_direct_loader_starts'] == 0
assert len(controls) == 41 and len(construction) == 22 and len(fixtures) == 63
groups.append({'name': 'literal_oracle_and_control_inventory', 'passed': True,
               'controls': len(controls), 'policy_results_computed': False})

inputs = load(candidate / 'INPUTS.json')
archive_row = inputs['p16_candidate_archive']
archive_bytes = bound(repo, archive_row, mode=False)
with zipfile.ZipFile(repo / archive_row['path']) as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    assert len(names) == len(set(names))
    for name in names:
        pure = PurePosixPath(name)
        assert not pure.is_absolute() and '..' not in pure.parts
    old_manifest = archive.read('candidate001/CANDIDATE-MANIFEST.json')
    assert sha(old_manifest) == inputs['p16_candidate_manifest_sha256']
    old = json.loads(old_manifest)
    assert set(names) == {'candidate001/CANDIDATE-MANIFEST.json'} | {'candidate001/' + row['path'] for row in old['files']}
    for row in old['files']:
        data = archive.read('candidate001/' + row['path'])
        assert len(data) == row['size_bytes'] and sha(data) == row['sha256']
    original_expectations = archive.read('candidate001/EXPECTATIONS.json')
    assert sha(original_expectations) == inputs['p16_expectations_sha256']
    original_n16 = json.loads(original_expectations)['cases']['N16_flags_0x18_preserved']
    assert original_n16['reason'] == 'Unsupported dynamic flags' and original_n16['outcome'] == 'typed_refusal'
    for row in controls:
        value = load(candidate / row['context'])
        if 'derived_from' in value:
            source = value['derived_from']
            data = archive.read('candidate001/' + source['p16_path'])
            assert len(data) == source['bytes'] and sha(data) == source['sha256']
groups.append({'name': 'immutable_p16_predecessor_and_derived_context_sources', 'passed': True,
               'p16_payload_files': len(old['files']), 'p16_original_controls': len(json.loads(original_expectations)['cases'])})

protected = load(candidate / 'PROTECTED-SOURCES.json')['files']
for row in protected:
    bound(repo, row, size_key='size_bytes', mode=False)
groups.append({'name': 'protected_product_tests_pins_and_old_oracles', 'passed': True,
               'files_compared': len(protected), 'imports_or_tests_run': False})

for row in inputs['historical_inputs']:
    bound(historical, row, mode=False)
facts = load(candidate / 'sources/RETAINED-LIBC-FACTS.json')
libc = (historical / 'current-python-loaded-libc.elf.inert').read_bytes()
assert libc[:7] == b'\x7fELF\x02\x01\x01'
for row in facts['flags'] + facts['selected_trio']:
    assert struct.unpack_from('<qQ', libc, row['offset']) == (row['tag'], row['value'])
for row in load(candidate / 'sources/SOURCE-MEMBERS.json')['members']:
    bound(candidate / 'sources', row, mode=False)
patches = load(candidate / 'sources/PATCH-COVERAGE.json')
assert patches['active_count'] == len(patches['patches']) == 80
assert all(not row['selected_files'] for row in patches['patches'])
groups.append({'name': 'retained_source_and_historical_byte_bindings', 'passed': True,
               'historical_inputs': len(inputs['historical_inputs']), 'current_host_paths_opened': 0,
               'primary_source_files': len(load(candidate / 'sources/SOURCE-MEMBERS.json')['members'])})

for row in load(candidate / 'READSET.json')['repository_reads']:
    bound(repo, row, mode=False)
groups.append({'name': 'required_readset_exact_repository_identities', 'passed': True,
               'repository_files': len(load(candidate / 'READSET.json')['repository_reads'])})

report = {'schema': 'ontokin.c271.p17-author-static-integrity/1', 'worker': '/root/flags_design',
          'candidate_manifest_sha256': sha((candidate / 'CANDIDATE-MANIFEST.json').read_bytes()),
          'expectations_sha256': sha((candidate / 'EXPECTATIONS.json').read_bytes()),
          'command': [sys.executable, *sys.argv], 'python': sys.version, 'platform': platform.platform(),
          'groups': groups, 'passed_groups': len(groups), 'failed_groups': 0,
          'product_tests_run': 0, 'policy_evaluations_run': 0, 'host_inspection_run': False,
          'limits': ['Identity/layout/inventory checks only.', 'Independent semantic review remains required.',
                     'No metadata reader, adapter, executable fixture or recovered source was executed.']}
with Path(args.report).open('x') as stream:
    json.dump(report, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'passed_groups': len(groups), 'controls': len(controls), 'product_tests_run': 0,
                  'candidate_manifest_sha256': report['candidate_manifest_sha256']}))
