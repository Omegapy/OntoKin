"""Construct inert bytes and literal oracles; no product import or policy evaluator."""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import struct

p = argparse.ArgumentParser()
p.add_argument('--output', required=True)
p.add_argument('--p16', required=True)
a = p.parse_args()
OUT, P16 = Path(a.output), Path(a.p16)
(OUT / 'elf').mkdir(exist_ok=False)
(OUT / 'contexts').mkdir(exist_ok=False)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(path, data):
    with (OUT / path).open('xb') as stream:
        stream.write(data)
    (OUT / path).chmod(0o600)
    return {'path': path, 'bytes': len(data), 'sha256': sha(data), 'mode': '0o600'}

def dump(path, value):
    return write(path, (json.dumps(value, indent=2, sort_keys=True) + '\n').encode())

PAIR = {'plan_schema': 'ontokin.current-host-readback-inspection-plan/0.1.3',
        'profile': 'linux-glibc-declared-python-origin-rpath-libc-plt-static-tls-v1'}
OLDPAIR = {'plan_schema': 'ontokin.current-host-readback-inspection-plan/0.1.2',
           'profile': 'linux-glibc-declared-python-origin-rpath-libc-plt-v1'}
META = {'class': 64, 'endian': 'little', 'machine': 62, 'type': 3,
        'interpreter': None, 'needed': ['ld-linux-x86-64.so.2'],
        'soname': 'libc.so.6', 'rpath': [], 'runpath': []}
EXPECT = {}
CONTROLS = []
FIXTURES = []
CONSTRUCTION = []
image_cache = {}

def success():
    return {'outcome': 'metadata_returned', 'metadata': copy.deepcopy(META),
            'opened_descriptor_close_count': 1, 'tls_or_relocation_validation_performed': False}

def reject(code='CHI-UNSUPPORTED', reason='Unsupported dynamic flags', details=None, closes=1):
    return {'outcome': 'typed_refusal', 'code': code, 'reason': reason,
            'state': 'REJECTED', 'details': details or {}, 'cause': None,
            'opened_descriptor_close_count': closes}

def context(case, route, mutation, expected, values):
    row = {'schema': 'ontokin.c271.p17-inert-control-context/1', 'case_id': case,
           'route': route, 'operational': False, 'mutation': mutation, **values}
    descriptor = dump('contexts/' + case + '.json', row)
    FIXTURES.append(descriptor)
    CONTROLS.append({'id': case, 'route': route, 'context': descriptor['path'],
                     'purpose': mutation})
    EXPECT[case] = {**expected, 'current_execution': 'not_run', 'host_qualified': False,
                    'operational_plan_accepted': False, 'expected_node_starts': 0,
                    'expected_ldd_starts': 0, 'expected_direct_loader_starts': 0}

def image(flags=(24,), flags1=(1,), trio=True, extra=None, machine=62,
          bad_strings=False, token_path=False):
    strings = b'\0ld-linux-x86-64.so.2\0libc.so.6\0$ORIGIN/lib\0'
    entries = [(5, 0x400400 if not bad_strings else 0x900000), (10, len(strings)),
               (1, 1), (14, strings.index(b'libc.so.6'))]
    if trio:
        entries += [(0x70000000, 0x28000), (0x70000001, 0x3d0), (0x70000003, 0x10)]
    entries += [(30, value) for value in flags]
    entries += [(0x6ffffffb, value) for value in flags1]
    if extra is not None:
        entries.append(extra)
    if token_path:
        entries.append((15, strings.index(b'$ORIGIN/lib')))
    entries.append((0, 0))
    raw = bytearray(2048)
    raw[:16] = b'\x7fELF\x02\x01\x01' + bytes(9)
    struct.pack_into('<HHIQQQIHHHHHH', raw, 16, 3, machine, 1, 0, 64, 0, 0,
                     64, 56, 2, 0, 0, 0)
    struct.pack_into('<IIQQQQQQ', raw, 64, 1, 4, 0, 0x400000, 0x400000, 2048, 2048, 4096)
    struct.pack_into('<IIQQQQQQ', raw, 120, 2, 4, 512, 0x400200, 0x400200,
                     16 * len(entries), 16 * len(entries), 8)
    for index, (tag, value) in enumerate(entries):
        struct.pack_into('<qQ', raw, 512 + 16 * index, tag, value)
    raw[1024:1024 + len(strings)] = strings
    digest = sha(raw)
    if digest not in image_cache:
        desc = write('elf/image-' + digest[:16] + '.bin', bytes(raw))
        FIXTURES.append(desc)
        CONSTRUCTION.append({'image': desc, 'machine': machine, 'type': 3,
             'dynamic_offset': 512, 'dynamic_entries': entries, 'strings_offset': 1024,
             'strings_hex': strings.hex(), 'program_headers': [
                 [1, 4, 0, 0x400000, 0x400000, 2048, 2048, 4096],
                 [2, 4, 512, 0x400200, 0x400200, 16 * len(entries), 16 * len(entries), 8]],
             'scope': 'Synthetic metadata only; no PT_TLS or executable entry is constructed.'})
        image_cache[digest] = desc
    return image_cache[digest]

def meta(case, mutation, expected, route='static_tls_metadata', extra_context=None, **kwargs):
    desc = image(**kwargs)
    context(case, route, mutation, expected, {'image': desc, 'require_interpreter': False,
            'actual_fixture_bytes': {k: v for k, v in desc.items() if k != 'path'},
            **(extra_context or {})})

# The expected results are literal author decisions. No predicate evaluates these values.
meta('P01_exact_18', 'Exact retained flags combination, synthetic metadata-only positive.', success())
meta('P02_absent_flags', 'Both optional flags entries absent; prior absence behavior retained.', success(), flags=(), flags1=())
meta('P03_zero_flags', 'Explicit DT_FLAGS zero remains accepted.', success(), flags=(0,))
meta('P04_bind_now', 'Prior DT_FLAGS 8 remains accepted.', success(), flags=(8,))
meta('P05_flags1_allowed', 'Exact 24 combined with all previously allowed flags1 bits.', success(), flags1=(0x08000001,))
for case, value, purpose in [
    ('N01_static_only', 16, 'Lone static-TLS bit is outside the exact extra combination.'),
    ('N02_origin_bit', 25, 'Added DF_ORIGIN bit remains refused.'),
    ('N03_symbolic_bit', 26, 'Added DF_SYMBOLIC bit remains refused.'),
    ('N04_textrel_bit', 28, 'Added DF_TEXTREL bit remains refused.'),
    ('N05_unknown_bit', 56, 'Added unknown bit 0x20 remains refused.'),
    ('N06_high_bit', 0x8000000000000018, 'High unsigned bit is not truncated into an accepted value.'),
    ('N07_u64_max', 0xffffffffffffffff, 'Maximum encoded unsigned value remains refused.')]:
    meta(case, purpose, reject(), flags=(value,))
meta('N08_duplicate_equal', 'Equal duplicate flags do not become one entry.', reject(), flags=(24, 24))
meta('N09_duplicate_mixed', 'Mixed duplicate flags remain refused.', reject(), flags=(8, 24))
meta('N10_flags1_origin', 'Unchanged flags1 policy refuses DF_1_ORIGIN.', reject(), flags1=(0x80,))
meta('N11_flags1_duplicate', 'Unchanged flags1 multiplicity refuses equal duplicates.', reject(), flags1=(1, 1))
meta('N12_unknown_before_flags', 'Unknown tag remains earlier than a separately bad flags value.',
     reject(reason='Unreviewed ELF dynamic loader feature'), flags=(16,), extra=(0x70000002, 0))
meta('N13_trio_before_flags', 'P16 missing-trio check remains earlier than bad flags.',
     reject(reason='Libc PLT metadata requires one complete tag trio',
            details={'stage': 'libc_plt_tags', 'rule_id': 'PLT-TRIO'}), flags=(16,), trio=False)
meta('N14_arch_before_flags', 'P16 architecture check remains earlier than bad flags.',
     reject(reason='Libc PLT metadata requires x86-64 ET_DYN',
            details={'stage': 'libc_plt_tags', 'rule_id': 'PLT-ARCH'}), flags=(16,), machine=183)
meta('N15_later_strings', 'Accepted flags do not bypass the following string-table mapping guard.',
     reject(reason='Ambiguous/unmapped ELF string table'), bad_strings=True)
meta('N16_later_token', 'Accepted flags do not authorize token expansion in libc RPATH.',
     reject(reason='Unreviewed loader token expansion'), token_path=True)
meta('L01_p16_18', 'P16 private trio route keeps its original flags refusal.', reject(), route='p16_libc_plt_metadata')
meta('L02_public_18', 'Tagless public-route control isolates the old flags refusal.', reject(), route='legacy_public_metadata', trio=False)
meta('L03_literal_18', 'Tagless /0.1.0 reader dispatch retains old flags refusal.', reject(), route='legacy_literal_plan_reader', trio=False)
meta('L04_origin_other_18', 'Tagless non-Python /0.1.1 reader retains old flags refusal.', reject(), route='legacy_origin_other_reader', trio=False)

old_shape = json.loads((P16 / 'fixture_inputs/S01_new_pair_and_shape.json').read_text())['libc_plt']
selected_shape = {'selection': PAIR, 'libc_plt': old_shape,
                  'observations': 'selector_only_not_an_operational_plan'}
selector_ok = {'outcome': 'new_fixed_profile_selected_only', 'opened_descriptor_close_count': 0}
selector_error = reject('CHI-PLAN', 'Unsupported libc static-TLS schema/profile pair',
                        {'stage': 'profile_selection', 'rule_id': 'FLAGS-PROFILE'}, 0)
shape_error = reject('CHI-PLAN', 'Invalid libc PLT policy shape',
                     {'stage': 'profile_selection', 'rule_id': 'PLT-SHAPE'}, 0)
context('S01_exact_pair', 'new_profile_rule', 'Select only the new exact pair with unchanged closed object.', selector_ok, selected_shape)
changed = copy.deepcopy(selected_shape); changed['selection']['profile'] = OLDPAIR['profile']
context('S02_new_schema_old_profile', 'new_profile_rule', 'No mixed new-schema / P16-profile pair.', selector_error, changed)
changed = copy.deepcopy(selected_shape); changed['selection']['plan_schema'] = OLDPAIR['plan_schema']
context('S03_old_schema_new_profile', 'new_profile_rule', 'No mixed P16-schema / new-profile pair.', selector_error, changed)
changed = copy.deepcopy(selected_shape); changed['libc_plt']['flags_mask'] = 24
context('S04_extra_mask', 'new_profile_rule', 'No caller-selected flags mask in the unchanged closed object.', shape_error, changed)
changed = copy.deepcopy(selected_shape); del changed['libc_plt']
context('S05_missing_object', 'new_profile_rule', 'The pinned libc/loader object is still required.', shape_error, changed)

# These five contexts transfer exact P16 logical observations to the new selector.
# Their original sources and all original P16 expectations stay unchanged.
binding_ok = {'outcome': 'mocked_binding_relations_accepted_only',
              'actual_file_binding_proved': False, 'opened_descriptor_close_count': 0,
              'raw_libc_parser_calls': 0}
role_error = reject('CHI-INSPECTOR', 'Selected libc is not the bound author-Python dependency',
                    {'stage': 'libc_plt_binding', 'rule_id': 'PLT-ROLE'}, 0)
pin_error = reject('CHI-INSPECTOR', 'Libc PLT input is not the selected libc/loader pair',
                   {'stage': 'libc_plt_binding', 'rule_id': 'PLT-PIN'}, 0)
for case, source, expected, purpose in [
    ('B01_new_mocked_bindings', 'B01_mocked_relations', binding_ok, 'All mocked P16 role/alias/file/image/pin relations remain required.'),
    ('B02_unselected_row', 'B04_unselected_same_hash_row', role_error, 'An unused same-hash row cannot select the new route.'),
    ('B03_wrong_libc_pin', 'B11_coherent_wrong_libc_pin', pin_error, 'Coherent wrong libc pin still refuses before raw admission.'),
    ('B04_wrong_loader_pin', 'B12_coherent_wrong_loader_pin', pin_error, 'Coherent wrong loader pin still refuses before raw admission.'),
    ('B05_synthetic_pin', 'B15_synthetic_cannot_meet_real_pin', pin_error, 'Synthetic bytes cannot satisfy the unchanged real libc pin.')]:
    data = (P16 / ('fixture_inputs/' + source + '.json')).read_bytes()
    values = json.loads(data)
    for key in ['schema', 'case_id', 'route', 'mutation', 'operational', 'operational_approval']:
        values.pop(key, None)
    values['selection'] = copy.deepcopy(PAIR)
    values['derived_from'] = {'p16_path': 'fixture_inputs/' + source + '.json', 'bytes': len(data), 'sha256': sha(data)}
    if expected is not binding_ok:
        expected = {**expected, 'raw_libc_parser_calls': 0}
    context(case, 'new_binding_relations', purpose, expected, values)

data = (P16 / 'fixture_inputs/D01_subject_binding_drift.json').read_bytes()
before_after = json.loads(data)
for key in ['schema', 'case_id', 'route', 'mutation', 'operational', 'operational_approval']:
    before_after.pop(key, None)
before_after['selection'] = copy.deepcopy(PAIR)
before_after['derived_from'] = {'p16_path': 'fixture_inputs/D01_subject_binding_drift.json', 'bytes': len(data), 'sha256': sha(data)}
cause = reject('CHI-INSPECTOR', 'Libc PLT descriptors or aliases disagree',
               {'stage': 'libc_plt_binding', 'rule_id': 'PLT-DESCRIPTORS'}, 0)
cause.pop('opened_descriptor_close_count')
drift = reject('CHI-DRIFT', 'An admitted input changed before/after the command',
               {'stage': 'recheck', 'rule_id': 'LP-RECHECK'}, 0)
drift['cause'] = cause
drift['require_actual_new_binding_primitive_call'] = True
drift['raw_libc_parser_calls_after_fault'] = 0
context('D01_new_recheck', 'new_recheck_boundary', 'Fresh binding drift must reach existing outer wrapper before new raw admission.', drift, before_after)

dispatch = {'selection': PAIR, 'policy_observations': 'mocked_already_bound_internal_policy_only',
            'subject_relation': 'requested_fixture_is_bound_libc',
            'forbidden_claim': 'This is not a real _bound success or operational plan.'}
meta('X01_subject_dispatch', 'New pair dispatches its exact subject to the new fixed raw reader.',
     {**success(), 'reader_route': 'static_tls_metadata'}, route='new_plan_reader_dispatch', extra_context=dispatch)
dispatch = {**dispatch, 'subject_relation': 'requested_fixture_is_other_non_python_image'}
meta('X02_other_dispatch', 'Another image under the new pair keeps its old reader and flags refusal.',
     {**reject(), 'reader_route': 'legacy_public_metadata'}, route='new_plan_reader_dispatch',
     extra_context=dispatch, trio=False)

for case, boundary, kind in [('F01_before_flags', 'before_libc_static_tls_flags', 'RuntimeError'),
                              ('F02_during_flags', 'during_libc_static_tls_flags', 'HostInspectionError'),
                              ('F03_final_identity', 'before_final_elf_identity', 'RuntimeError')]:
    fault = {'at': boundary, 'type': kind, 'message': 'P17 callback sentinel',
             'details': {'stage': 'test_callback', 'rule_id': 'P17-SENTINEL'} if kind == 'HostInspectionError' else None,
             'category': 'UNSUPPORTED' if kind == 'HostInspectionError' else None}
    expected = {'outcome': 'same_callback_exception', 'type': kind, 'same_object': True,
                'callback_boundary_reached': boundary, 'opened_descriptor_close_count': 1,
                'details_unchanged': True}
    meta(case, 'Inject only after the actual reader reaches the named boundary; close that descriptor exactly once.',
         expected, route='new_metadata_fault', extra_context={'fault': fault})

dump('CONTROLS.json', {'schema': 'ontokin.c271.p17-controls/1', 'cases': CONTROLS})
dump('EXPECTATIONS.json', {'schema': 'ontokin.c271.p17-literal-expectations/1',
                         'authoring': 'Literal before product implementation/execution.', 'cases': EXPECT})
dump('CONSTRUCTION.json', {'schema': 'ontokin.c271.p17-construction/1',
                          'method': 'Fixed struct writes; no acceptance predicate.', 'images': CONSTRUCTION})
dump('FIXTURE-MANIFEST.json', {'schema': 'ontokin.c271.p17-fixture-manifest/1', 'files': sorted(FIXTURES, key=lambda row: row['path'])})
print(json.dumps({'controls': len(CONTROLS), 'elf_images': len(CONSTRUCTION),
                  'fixture_files': len(FIXTURES), 'product_tests_run': 0}))
