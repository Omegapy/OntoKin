"""Independent static artifact audit. No product/author module is imported or run.

The case specifications and expected dictionaries are literal reviewer decisions.
This program compares data; it does not implement or call an ELF admission policy.
"""
from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import re
import stat
import struct
import sys
import tarfile
import traceback
import zipfile

ROOT = Path('/workspace/scratch/bbea56c9165d')
OUT = ROOT / 'work/records-review/technical/candidate001'
C = OUT / 'frozen-bytes'
ORIGINAL = ROOT / 'work/flags-design/candidate001'
REPO = ROOT / 'OntoKin'
HIST = ROOT / 'inputs/p15'
MANIFEST_SHA = '5561dcd3cf718362f0716bb0c3ebf7fcf273befa1f6348f9996331d151b7c89b'
checks = []
details = {}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load(path):
    return json.loads(path.read_text())


def check(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})
    if not condition:
        raise RuntimeError(name)


def identity(base, row, size='bytes', verify_mode=False):
    rel = PurePosixPath(row['path'])
    check('safe relative path: ' + row['path'], not rel.is_absolute() and '..' not in rel.parts)
    path = base / rel
    info = path.lstat()
    check('regular nonlink: ' + row['path'], stat.S_ISREG(info.st_mode))
    raw = path.read_bytes()
    check('bytes and hash: ' + row['path'], len(raw) == row[size] and sha(raw) == row['sha256'])
    if verify_mode:
        check('inert mode: ' + row['path'], stat.S_IMODE(info.st_mode) == int(row['mode'], 8) == 0o600)
    return raw


def closed_refusal(code='CHI-UNSUPPORTED', reason='Unsupported dynamic flags', details=None, closes=1):
    return {'outcome': 'typed_refusal', 'code': code, 'reason': reason,
            'state': 'REJECTED', 'details': {} if details is None else details,
            'cause': None, 'opened_descriptor_close_count': closes}


META = {'class': 64, 'endian': 'little', 'machine': 62, 'type': 3,
        'interpreter': None, 'needed': ['ld-linux-x86-64.so.2'],
        'soname': 'libc.so.6', 'rpath': [], 'runpath': []}
COMMON = {'current_execution': 'not_run', 'host_qualified': False,
          'operational_plan_accepted': False, 'expected_node_starts': 0,
          'expected_ldd_starts': 0, 'expected_direct_loader_starts': 0}
POSITIVE = {'outcome': 'metadata_returned', 'metadata': META,
            'opened_descriptor_close_count': 1, 'tls_or_relocation_validation_performed': False}
PAIR = {'plan_schema': 'ontokin.current-host-readback-inspection-plan/0.1.3',
        'profile': 'linux-glibc-declared-python-origin-rpath-libc-plt-static-tls-v1'}


def independent_elf(flags, flags1, *, trio=True, machine=62, unknown=False, bad_strings=False, token=False):
    """Encode only the reviewed fixed synthetic layout, not an acceptance rule."""
    raw = bytearray(2048)
    raw[:16] = b'\x7fELF\x02\x01\x01' + b'\x00' * 9
    def fields(offset, sequence):
        for width, value in sequence:
            raw[offset:offset + width] = int(value).to_bytes(width, 'little')
            offset += width
    fields(16, [(2,3),(2,machine),(4,1),(8,0),(8,64),(8,0),(4,0),
                (2,64),(2,56),(2,2),(2,0),(2,0),(2,0)])
    strings = b'\0ld-linux-x86-64.so.2\0libc.so.6\0$ORIGIN/lib\0'
    entries = [[5, 0x900000 if bad_strings else 0x400400], [10,len(strings)],
               [1,1], [14,22]]
    if trio:
        entries.extend([[0x70000000,0x28000],[0x70000001,0x3d0],[0x70000003,0x10]])
    entries.extend([[30,v] for v in flags])
    entries.extend([[0x6ffffffb,v] for v in flags1])
    if unknown:
        entries.append([0x70000002,0])
    if token:
        entries.append([15,32])
    entries.append([0,0])
    ph = [[1,4,0,0x400000,0x400000,2048,2048,4096],
          [2,4,512,0x400200,0x400200,16*len(entries),16*len(entries),8]]
    for i, row in enumerate(ph):
        fields(64+i*56, list(zip([4,4,8,8,8,8,8,8],row)))
    for i, row in enumerate(entries):
        fields(512+i*16, [(8,row[0]),(8,row[1])])
    raw[1024:1024+len(strings)] = strings
    return bytes(raw), entries, ph, strings


def run():
    manifest = load(C / 'CANDIDATE-MANIFEST.json')
    check('frozen manifest identity', sha((C/'CANDIDATE-MANIFEST.json').read_bytes()) == MANIFEST_SHA)
    names = [r['path'] for r in manifest['files']]
    check('complete unique payload set', len(names) == len(set(names)) == 91 and
          {p.relative_to(C).as_posix() for p in C.rglob('*') if p.is_file()} == set(names) | {'CANDIDATE-MANIFEST.json'})
    for row in manifest['files']:
        identity(C, row, verify_mode=True)
        check('unchanged author payload: ' + row['path'], (ORIGINAL/row['path']).read_bytes() == (C/row['path']).read_bytes())
    check('payload size total', sum(r['bytes'] for r in manifest['files']) == manifest['counts']['payload_bytes'] == 607494)
    fixtures = load(C/'FIXTURE-MANIFEST.json')['files']
    check('fixture denominator', len(fixtures) == len({r['path'] for r in fixtures}) == 63)
    for row in fixtures:
        identity(C, row, verify_mode=True)

    controls = load(C/'CONTROLS.json')['cases']
    contexts = {r['id']: load(C/r['context']) for r in controls}
    expectations = load(C/'EXPECTATIONS.json')['cases']
    check('control and expectation denominator', len(controls) == len(contexts) == 41 and set(contexts) == set(expectations))
    for row in controls:
        ctx = contexts[row['id']]
        check('context identity and nonoperational status: '+row['id'], ctx['case_id'] == row['id'] and ctx['route'] == row['route']
              and ctx['operational'] is False and ctx['mutation'] == row['purpose'])
        if 'image' in ctx:
            identity(C, ctx['image'], verify_mode=True)
            check('authoritative image descriptor: '+row['id'], ctx['actual_fixture_bytes'] == {k:v for k,v in ctx['image'].items() if k!='path'})

    # These values and dispositions were fixed by the reviewer after reading
    # the decision and inherited guards, not computed by a flags predicate.
    specs = {
        'P01_exact_18':([24],[1],{}), 'P02_absent_flags':([],[],{}),
        'P03_zero_flags':([0],[1],{}), 'P04_bind_now':([8],[1],{}),
        'P05_flags1_allowed':([24],[0x08000001],{}),
        'N01_static_only':([16],[1],{}), 'N02_origin_bit':([25],[1],{}),
        'N03_symbolic_bit':([26],[1],{}), 'N04_textrel_bit':([28],[1],{}),
        'N05_unknown_bit':([56],[1],{}), 'N06_high_bit':([0x8000000000000018],[1],{}),
        'N07_u64_max':([0xffffffffffffffff],[1],{}),
        'N08_duplicate_equal':([24,24],[1],{}), 'N09_duplicate_mixed':([8,24],[1],{}),
        'N10_flags1_origin':([24],[128],{}), 'N11_flags1_duplicate':([24],[1,1],{}),
        'N12_unknown_before_flags':([16],[1],{'unknown':True}),
        'N13_trio_before_flags':([16],[1],{'trio':False}),
        'N14_arch_before_flags':([16],[1],{'machine':183}),
        'N15_later_strings':([24],[1],{'bad_strings':True}),
        'N16_later_token':([24],[1],{'token':True}),
        'L01_p16_18':([24],[1],{}), 'L02_public_18':([24],[1],{'trio':False}),
        'L03_literal_18':([24],[1],{'trio':False}), 'L04_origin_other_18':([24],[1],{'trio':False}),
        'X01_subject_dispatch':([24],[1],{}), 'X02_other_dispatch':([24],[1],{'trio':False}),
        'F01_before_flags':([24],[1],{}), 'F02_during_flags':([24],[1],{}), 'F03_final_identity':([24],[1],{})}
    construction = {r['image']['path']:r for r in load(C/'CONSTRUCTION.json')['images']}
    rebuilt = []
    for case,(flags,flags1,kwargs) in specs.items():
        expected_bytes, entries, ph, strings = independent_elf(flags,flags1,**kwargs)
        desc = contexts[case]['image']
        check('entire independently reconstructed ELF: '+case, expected_bytes == (C/desc['path']).read_bytes())
        row = construction[desc['path']]
        check('declared construction matches independent layout: '+case,
              row['dynamic_entries']==entries and row['program_headers']==ph and row['dynamic_offset']==512
              and row['strings_offset']==1024 and row['strings_hex']==strings.hex()
              and row['machine']==kwargs.get('machine',62) and row['type']==3)
        rebuilt.append({'case':case,'image':desc,'literal_flags':flags,'literal_flags1':flags1,
                        'layout_mutations':kwargs,'dynamic_entries':entries,'byte_equality':True})
    check('all distinct ELF images independently reconstructed', len({r['image']['sha256'] for r in rebuilt})==22
          and {r['image']['path'] for r in rebuilt}==set(construction))
    details['reconstructed_images'] = rebuilt

    literal = {}
    for key in ['P01_exact_18','P02_absent_flags','P03_zero_flags','P04_bind_now','P05_flags1_allowed']:
        literal[key] = dict(POSITIVE)
    for key in ['N01_static_only','N02_origin_bit','N03_symbolic_bit','N04_textrel_bit','N05_unknown_bit',
                'N06_high_bit','N07_u64_max','N08_duplicate_equal','N09_duplicate_mixed','N10_flags1_origin',
                'N11_flags1_duplicate','L01_p16_18','L02_public_18','L03_literal_18','L04_origin_other_18']:
        literal[key] = closed_refusal()
    literal['N12_unknown_before_flags'] = closed_refusal(reason='Unreviewed ELF dynamic loader feature')
    literal['N13_trio_before_flags'] = closed_refusal(reason='Libc PLT metadata requires one complete tag trio',
        details={'stage':'libc_plt_tags','rule_id':'PLT-TRIO'})
    literal['N14_arch_before_flags'] = closed_refusal(reason='Libc PLT metadata requires x86-64 ET_DYN',
        details={'stage':'libc_plt_tags','rule_id':'PLT-ARCH'})
    literal['N15_later_strings'] = closed_refusal(reason='Ambiguous/unmapped ELF string table')
    literal['N16_later_token'] = closed_refusal(reason='Unreviewed loader token expansion')
    literal['S01_exact_pair'] = {'outcome':'new_fixed_profile_selected_only','opened_descriptor_close_count':0}
    for key in ['S02_new_schema_old_profile','S03_old_schema_new_profile']:
        literal[key] = closed_refusal('CHI-PLAN','Unsupported libc static-TLS schema/profile pair',
                                    {'stage':'profile_selection','rule_id':'FLAGS-PROFILE'},0)
    for key in ['S04_extra_mask','S05_missing_object']:
        literal[key] = closed_refusal('CHI-PLAN','Invalid libc PLT policy shape',
                                    {'stage':'profile_selection','rule_id':'PLT-SHAPE'},0)
    literal['B01_new_mocked_bindings'] = {'outcome':'mocked_binding_relations_accepted_only',
        'actual_file_binding_proved':False,'opened_descriptor_close_count':0,'raw_libc_parser_calls':0}
    literal['B02_unselected_row'] = {**closed_refusal('CHI-INSPECTOR','Selected libc is not the bound author-Python dependency',
        {'stage':'libc_plt_binding','rule_id':'PLT-ROLE'},0),'raw_libc_parser_calls':0}
    for key in ['B03_wrong_libc_pin','B04_wrong_loader_pin','B05_synthetic_pin']:
        literal[key] = {**closed_refusal('CHI-INSPECTOR','Libc PLT input is not the selected libc/loader pair',
                       {'stage':'libc_plt_binding','rule_id':'PLT-PIN'},0),'raw_libc_parser_calls':0}
    cause = closed_refusal('CHI-INSPECTOR','Libc PLT descriptors or aliases disagree',
                          {'stage':'libc_plt_binding','rule_id':'PLT-DESCRIPTORS'},0)
    del cause['opened_descriptor_close_count']
    literal['D01_new_recheck'] = {**closed_refusal('CHI-DRIFT','An admitted input changed before/after the command',
        {'stage':'recheck','rule_id':'LP-RECHECK'},0),'cause':cause,'require_actual_new_binding_primitive_call':True,
        'raw_libc_parser_calls_after_fault':0}
    literal['X01_subject_dispatch'] = {**POSITIVE,'reader_route':'static_tls_metadata'}
    literal['X02_other_dispatch'] = {**closed_refusal(),'reader_route':'legacy_public_metadata'}
    for key,boundary,kind in [('F01_before_flags','before_libc_static_tls_flags','RuntimeError'),
                             ('F02_during_flags','during_libc_static_tls_flags','HostInspectionError'),
                             ('F03_final_identity','before_final_elf_identity','RuntimeError')]:
        literal[key] = {'outcome':'same_callback_exception','type':kind,'same_object':True,
            'callback_boundary_reached':boundary,'opened_descriptor_close_count':1,'details_unchanged':True}
        check('literal fault boundary and class: '+key, contexts[key]['fault']['at']==boundary and contexts[key]['fault']['type']==kind)
    check('literal independent oracle coverage', set(literal)==set(expectations))
    for case, expected in literal.items():
        check('complete independent literal expectation: '+case, expectations[case]=={**expected,**COMMON})
    details['independent_literal_expectations'] = {case:{**expected,**COMMON} for case,expected in literal.items()}

    inputs = load(C/'INPUTS.json')
    old_archive = identity(REPO,inputs['p16_candidate_archive'])
    with zipfile.ZipFile(REPO/inputs['p16_candidate_archive']['path']) as z:
        oldmanifest = z.read('candidate001/CANDIDATE-MANIFEST.json')
        check('exact P16 manifest', sha(oldmanifest)==inputs['p16_candidate_manifest_sha256']=='61b18ceb15d3ee05d3022c60941ccbbce9c3e08bac148c7750da9f6588091156')
        old = json.loads(oldmanifest)
        check('P16 archive closed membership', len(z.namelist())==len(set(z.namelist())) and set(z.namelist())==
              {'candidate001/'+r['path'] for r in old['files']}|{'candidate001/CANDIDATE-MANIFEST.json'})
        for row in old['files']:
            raw = z.read('candidate001/'+row['path'])
            check('preserved P16 payload: '+row['path'], len(raw)==row['size_bytes'] and sha(raw)==row['sha256'])
        old_expected = z.read('candidate001/EXPECTATIONS.json')
        check('original P16 expectations identity', sha(old_expected)==inputs['p16_expectations_sha256']=='33a17cc66604f8b57be88dae7dd05a4bec066c0eaa191fc08400cfc79e18137e')
        old_cases = json.loads(old_expected)['cases']
        check('P16 denominator and N16 unchanged refusal', len(old_cases)==73 and
              old_cases['N16_flags_0x18_preserved']['reason']=='Unsupported dynamic flags' and
              old_cases['N16_flags_0x18_preserved']['outcome']=='typed_refusal')
        for case,ctx in contexts.items():
            if 'derived_from' not in ctx:
                continue
            desc = ctx['derived_from'];raw = z.read('candidate001/'+desc['p16_path']);source = json.loads(raw)
            check('P16 context provenance: '+case, len(raw)==desc['bytes'] and sha(raw)==desc['sha256'])
            skip = {'schema','case_id','route','mutation','operational','operational_approval'}
            expected_content = {k:v for k,v in source.items() if k not in skip}
            actual_content = {k:v for k,v in ctx.items() if k not in skip|{'selection','derived_from'}}
            check('exact logical inherited context: '+case, actual_content==expected_content and ctx['selection']==PAIR)
        shape = json.loads(z.read('candidate001/fixture_inputs/S01_new_pair_and_shape.json'))['libc_plt']
        check('selector closed object preserved', contexts['S01_exact_pair']['libc_plt']==shape and contexts['S01_exact_pair']['selection']==PAIR)
        for case,key,value in [('S02_new_schema_old_profile','profile','linux-glibc-declared-python-origin-rpath-libc-plt-v1'),
                               ('S03_old_schema_new_profile','plan_schema','ontokin.current-host-readback-inspection-plan/0.1.2')]:
            expected_pair={**PAIR,key:value}
            check('mixed selector isolated mutation: '+case, contexts[case]['selection']==expected_pair and contexts[case]['libc_plt']==shape)
        check('caller mask isolated mutation', contexts['S04_extra_mask']['libc_plt']=={**shape,'flags_mask':24})
        check('missing object isolated mutation', 'libc_plt' not in contexts['S05_missing_object'] and contexts['S05_missing_object']['selection']==PAIR)
        details['p16_payloads_verified'] = len(old['files'])

    for row in load(C/'PROTECTED-SOURCES.json')['files']:
        identity(REPO,row,size='size_bytes')
    for row in load(C/'READSET.json')['repository_reads']:
        identity(REPO,row)
    for row in inputs['historical_inputs']:
        identity(HIST,row)
    prior = load(OUT.parent/'INPUT-VERIFICATION.json')
    check('independent retained package member comparison preserved', len(prior['debian_package']['payload_matches'])==2 and
          all(r['byte_equal'] for r in prior['debian_package']['payload_matches']))
    facts = load(C/'sources/RETAINED-LIBC-FACTS.json')
    check('retained source facts match independently decoded entries', all(row in prior['libc']['dynamic_entries_including_null'] for row in facts['flags']+facts['selected_trio']))
    check('retained dynamic type and machine', facts['machine']==prior['libc']['machine']==62 and facts['elf_type']==prior['libc']['type']==3)

    # Verify exact source members and the full scope/count of textual evidence.
    source_members = load(C/'sources/SOURCE-MEMBERS.json')['members']
    upstream_scan = load(C/'sources/UPSTREAM-SCAN.json')
    pattern = re.compile(rb'\b(?:DF_STATIC_TLS|DT_FLAGS|l_flags)\b')
    scan_rows=[];total=0;count=0
    with tarfile.open(HIST/'glibc_2.41.orig.tar.xz','r:xz') as t:
        selected={r['archive_member']:r for r in source_members}
        for member in t:
            if not member.isfile():
                continue
            raw=t.extractfile(member).read();count+=1;total+=len(raw)
            if member.name in selected:
                row=selected[member.name]
                check('exact original source member: '+member.name, raw==(C/'sources'/row['path']).read_bytes()
                      and len(raw)==row['bytes'] and sha(raw)==row['sha256'])
            matches=[{'line':i+1,'text':line.decode('utf-8','replace')} for i,line in enumerate(raw.splitlines()) if pattern.search(line)]
            if matches:
                scan_rows.append({'member':member.name,'bytes':len(raw),'sha256':sha(raw),
                    'historical_changelog':'/ChangeLog' in member.name,'matches':matches})
    check('full upstream token scan independently reproduced', upstream_scan['regular_members_scanned']==count==20048
          and upstream_scan['regular_bytes_scanned']==total==242115126 and upstream_scan['matches']==scan_rows)
    patches=load(C/'sources/PATCH-COVERAGE.json')
    with tarfile.open(HIST/'glibc_2.41-12+deb13u4.debian.tar.xz','r:xz') as t:
        series=t.extractfile('debian/patches/series').read().decode()
        active=[line.strip().split()[0] for line in series.splitlines() if line.strip() and not line.lstrip().startswith('#')]
        check('exact active patch series', active==[p['patch'] for p in patches['patches']] and len(active)==80)
        for row in patches['patches']:
            raw=t.extractfile('debian/patches/'+row['patch']).read()
            lines=raw.decode('utf-8','replace').splitlines()
            headers=[s for s in lines if s.startswith('--- ') or s.startswith('+++ ')]
            selected=[]
            for target in patches['selected_files']:
                if any(s.split()[1].removeprefix('a/').removeprefix('b/')==target for s in headers):
                    selected.append(target)
            check('patch identity and complete file-header scope: '+row['patch'], len(raw)==row['bytes'] and sha(raw)==row['sha256']
                  and headers==row['file_headers'] and selected==row['selected_files']==[])
            check('patch has no selected exact flags tokens: '+row['patch'], not pattern.search(raw) and row['token_matches']==[])
    details.update({'candidate_payload_files':91,'candidate_payload_bytes':607494,'fixtures':63,
                    'controls':41,'distinct_elf_images':22,'protected_files':26,'active_patches':80,
                    'upstream_regular_members':count,'upstream_regular_bytes':total})
    check('final unchanged candidate manifest', (ORIGINAL/'CANDIDATE-MANIFEST.json').read_bytes()==(C/'CANDIDATE-MANIFEST.json').read_bytes())
    check('final unchanged complete candidate', all((ORIGINAL/r['path']).read_bytes()==(C/r['path']).read_bytes() for r in manifest['files']))


if __name__ == '__main__':
    report_path=OUT/'AUDIT-ATTEMPT002.json'
    if report_path.exists():
        raise SystemExit('Refusing to overwrite a retained audit attempt')
    failure=None
    try:
        run()
    except BaseException as exc:
        failure={'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc()}
    report={'schema':'ontokin.c271.p17-independent-static-artifact-audit/1','reviewer':'/root/records_review',
            'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'candidate_manifest_sha256':MANIFEST_SHA,'audit_source_sha256':sha(Path(__file__).read_bytes()),
            'passed':failure is None,'checks':checks,'passed_checks':sum(x['passed'] for x in checks),
            'failed_checks':sum(not x['passed'] for x in checks),'failure':failure,'details':details,
            'production_imports':0,'product_parser_calls':0,'product_tests':0,'policy_evaluations':0,
            'recovered_script_or_binary_executions':0,'current_host_observations':0,
            'limits':['Static byte reconstruction and literal-oracle comparison only.',
                      'Manual semantic review is separate; no future outcome is claimed.']}
    with report_path.open('x') as f:
        json.dump(report,f,indent=2,sort_keys=True);f.write('\n')
    print(json.dumps({'report':str(report_path),'passed':report['passed'],'passed_checks':report['passed_checks'],
                      'failed_checks':report['failed_checks'],'failure':failure}))
    sys.exit(0 if failure is None else 1)
