# P17 independent review preparation

Status: inherited-boundary and source preparation complete; candidate not yet read or accepted.

All applicable P05/P07/P11/P13/P16 contracts were read completely. Exact original bytes, hashes and recovered truncations are recorded in `READSET.json`; current inspection functions were read statically. P16 adoption preserves the old flags masks and makes its earlier implementation scheduling subordinate to this separate decision.

`INPUT-VERIFICATION.json` independently confirms all eight retained input descriptors, byte equality of libc/loader with their Debian package members, and the historical libc dynamic-entry observation: one `DT_FLAGS=0x18`, one `DT_FLAGS_1=0x1`. The actual P15 failure remains the earlier unknown-tag refusal.

Exact glibc 2.41 sources define `0x18` as `DF_BIND_NOW | DF_STATIC_TLS`. `get-dynamic-info.h` translates binding behavior; `dl-static-tls.h`, `dl-reloc.c` and x86-64 relocation code enforce static TLS availability. Startup allocation and conditional surplus allocation differ. A metadata decision therefore cannot establish runtime TLS safety. Archive hashes, relevant Debian patch sections, source ranges and literal-reference scans are retained separately.

Acceptance questions for the frozen candidate:

- Are exact subject, loader, author-Python dependency role and freshly bound bytes required before the exception?
- Is permitted flag behavior finite, with duplicate tags, other bits, wrong roles and old profiles still refused?
- Are P16 controls, unknown-tag rules, flags-one mask, limits, early ordering and rechecks preserved?
- Do positive, boundary, refusal and fault controls bind their own bytes and exact outcomes, without synthetic approval?
- Do source claims and implementation/runtime boundaries match the actual evidence?

No product or recovered executable ran. H0/H1, Gate H, full routine and parent closure remain unmet.
