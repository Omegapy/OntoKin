"""Data-only provenance and source inspection. Never imports or runs OntoKin."""
from pathlib import Path
import hashlib
import io
import json
import re
import struct
import tarfile

ROOT = Path('/workspace/scratch/bbea56c9165d')
OUT = ROOT / 'work/flags-design/source-attempt002'
OUT.mkdir(exist_ok=False)
INPUT = ROOT / 'inputs/p15'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def save(name, data):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)
    path.chmod(0o600)

def dump(name, value):
    save(name, (json.dumps(value, indent=2, sort_keys=True) + '\n').encode())

materialization = json.loads((INPUT / 'MATERIALIZATION.json').read_text())
for row in materialization['files']:
    data = Path(row['path']).read_bytes()
    assert len(data) == row['bytes'] and digest(data) == row['sha256']

chosen = ['elf/elf.h', 'elf/get-dynamic-info.h', 'elf/dl-static-tls.h',
          'elf/dl-reloc.c', 'sysdeps/x86_64/dl-machine.h', 'COPYING.LIB']
scan = []
source_rows = []
member_count = 0
member_bytes = 0
token = re.compile(rb'\b(?:DF_STATIC_TLS|DT_FLAGS|l_flags)\b')
with tarfile.open(INPUT / 'glibc_2.41.orig.tar.xz', 'r:xz') as archive:
    for member in archive:
        if not member.isfile():
            continue
        data = archive.extractfile(member).read()
        member_count += 1
        member_bytes += len(data)
        short = member.name.removeprefix('glibc-2.41/')
        if short in chosen:
            save('upstream/' + short, data)
            source_rows.append({'path': 'upstream/' + short, 'archive_member': member.name,
                                'bytes': len(data), 'sha256': digest(data)})
        if token.search(data):
            matches = [{'line': number, 'text': line.decode(errors='replace')}
                       for number, line in enumerate(data.splitlines(), 1) if token.search(line)]
            scan.append({'member': member.name, 'bytes': len(data), 'sha256': digest(data),
                         'historical_changelog': short.startswith('ChangeLog'), 'matches': matches})
assert len(source_rows) == len(chosen)
dump('UPSTREAM-SCAN.json', {'regular_members_scanned': member_count,
     'regular_bytes_scanned': member_bytes, 'regex': token.pattern.decode(), 'matches': scan,
     'meaning': 'Exact-token inventory, not full manual source review or build proof.'})

coverage = []
with tarfile.open(INPUT / 'glibc_2.41-12+deb13u4.debian.tar.xz', 'r:xz') as archive:
    series = archive.extractfile('debian/patches/series').read()
    save('debian/series', series)
    active = [line.split()[0] for line in series.decode().splitlines()
              if line.strip() and not line.lstrip().startswith('#')]
    for name in active:
        data = archive.extractfile('debian/patches/' + name).read()
        lines = data.decode().splitlines()
        headers = [line for line in lines if line.startswith(('--- ', '+++ '))]
        affected = [path for path in chosen if any(path in line.split()[1] for line in headers)]
        matches = [{'line': number, 'text': line} for number, line in enumerate(lines, 1)
                   if re.search(r'\b(?:DF_STATIC_TLS|DT_FLAGS|l_flags)\b', line)]
        coverage.append({'patch': name, 'bytes': len(data), 'sha256': digest(data),
                         'file_headers': headers, 'selected_files': affected, 'token_matches': matches})
        if affected or matches:
            save('debian/patches/' + name, data)
assert not any(row['selected_files'] for row in coverage), 'A selected source requires patched-source review'
dump('PATCH-COVERAGE.json', {'active_count': len(active), 'selected_files': chosen,
                           'all_selected_source_files_untouched': True, 'patches': coverage})
dump('SOURCE-MEMBERS.json', {'archive': materialization['files'][0], 'members': source_rows})

# Independently decode the Debian ar/tar package, as data only.
package = (INPUT / 'libc6_2.41-12+deb13u4_amd64.deb.inert').read_bytes()
assert package[:8] == b'!<arch>\n'
members = {}
offset = 8
while offset < len(package):
    header = package[offset:offset + 60]
    assert len(header) == 60 and header[58:] == b'`\n'
    name = header[:16].decode().strip().rstrip('/')
    size = int(header[48:58])
    assert name not in members
    members[name] = package[offset + 60:offset + 60 + size]
    assert len(members[name]) == size
    offset += 60 + size + size % 2
assert offset == len(package)
with tarfile.open(fileobj=io.BytesIO(members['control.tar.xz']), mode='r:xz') as archive:
    control = archive.extractfile('./control').read()
save('PACKAGE-CONTROL.txt', control)
assert b'Source: glibc\n' in control and b'Version: 2.41-12+deb13u4\n' in control
assert b'Architecture: amd64\n' in control
bindings = []
with tarfile.open(fileobj=io.BytesIO(members['data.tar.xz']), mode='r:xz') as archive:
    for member_name, capture in [('./usr/lib/x86_64-linux-gnu/libc.so.6', 'current-python-loaded-libc.elf.inert'),
                                 ('./usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2', 'loader.elf.inert')]:
        data = archive.extractfile(member_name).read()
        assert data == (INPUT / capture).read_bytes()
        bindings.append({'member': member_name, 'capture': capture, 'bytes': len(data),
                         'sha256': digest(data), 'byte_equality': True})
dsc = (INPUT / 'glibc_2.41-12+deb13u4.dsc').read_bytes()
assert b'Version: 2.41-12+deb13u4\n' in dsc
for row in materialization['files'][:2]:
    assert (row['sha256'] + ' ' + str(row['bytes']) + ' ' + Path(row['path']).name).encode() in dsc
save('glibc_2.41-12+deb13u4.dsc', dsc)
dump('PACKAGE-BINDING.json', {'package': materialization['files'][3], 'members': bindings,
     'source_version': '2.41-12+deb13u4', 'architecture': 'amd64',
     'source_association': 'Package control plus checksum-bound dsc and source archives.',
     'limits': ['No signature verification.', 'No reproduced build or compiler-output proof.',
                'No current-host observation or execution of recovered files.']})

# Direct fixed-offset observation of the retained ELF; this is not a product parser.
data = (INPUT / 'current-python-loaded-libc.elf.inert').read_bytes()
phoff = struct.unpack_from('<Q', data, 32)[0]
phentsize, phnum = struct.unpack_from('<HH', data, 54)
programs = [struct.unpack_from('<IIQQQQQQ', data, phoff + i * phentsize) for i in range(phnum)]
dynamic = [row for row in programs if row[0] == 2]
assert len(dynamic) == 1
entries = []
for offset in range(dynamic[0][2], dynamic[0][2] + dynamic[0][5], 16):
    tag, value = struct.unpack_from('<qQ', data, offset)
    if tag == 0:
        break
    entries.append({'offset': offset, 'tag': tag, 'value': value})
assert [row['value'] for row in entries if row['tag'] == 30] == [24]
dump('RETAINED-LIBC-FACTS.json', {'input': materialization['files'][4],
     'elf_type': struct.unpack_from('<H', data, 16)[0], 'machine': struct.unpack_from('<H', data, 18)[0],
     'dynamic_table': {'file_offset': dynamic[0][2], 'size_bytes': dynamic[0][5]},
     'flags': [row for row in entries if row['tag'] in (30, 0x6ffffffb)],
     'selected_trio': [row for row in entries if row['tag'] in (0x70000000, 0x70000001, 0x70000003)],
     'scope': 'Historical inert byte observation only; no product predicate or H0 execution.'})
print(json.dumps({'source_members': len(source_rows), 'active_patches': len(coverage),
                  'selected_source_patches': 0, 'package_members_equal': len(bindings),
                  'retained_flags': 24, 'output': str(OUT)}))
