"""Assemble documentary evidence only; no Git, product or target execution."""
from pathlib import Path
import hashlib
import json
import shutil
import zipfile

ROOT = Path('/workspace/scratch/bbea56c9165d')
W = ROOT / 'work/flags-design'
C = W / 'candidate001'
REPO = ROOT / 'OntoKin'
P16 = W / 'inputs/p16/candidate001'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def descriptor(path, name=None):
    data = path.read_bytes()
    return {'path': name or str(path), 'bytes': len(data), 'sha256': sha(data)}

def write(name, value):
    path = C / name
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')
    path.chmod(0o600)

shutil.copytree(W / 'source-attempt002', C / 'sources')
protected = json.loads((P16 / 'PROTECTED-SOURCES.json').read_text())
for row in protected['files']:
    data = (REPO / row['path']).read_bytes()
    assert len(data) == row['size_bytes'] and sha(data) == row['sha256'], row['path']
write('PROTECTED-SOURCES.json', {'schema': 'ontokin.c271.p17-protected-sources/1',
                               'scope': 'Exact inherited hash-only preservation inventory; no semantic read claim.',
                               'files': protected['files']})
archive_path = 'docs/engineering/localized-repair-c271/libc-tags-p16/design/CANDIDATE001.zip'
archive = descriptor(REPO / archive_path, archive_path)
assert archive['sha256'] == '05d1cbe971678b8f505795e436f2bd096b81848f68b4f9da6adc64392f6fb5af'
with zipfile.ZipFile(REPO / archive_path) as zipped:
    assert zipped.testzip() is None
    manifest = zipped.read('candidate001/CANDIDATE-MANIFEST.json')
    assert sha(manifest) == '61b18ceb15d3ee05d3022c60941ccbbce9c3e08bac148c7750da9f6588091156'
    for row in json.loads(manifest)['files']:
        data = zipped.read('candidate001/' + row['path'])
        assert len(data) == row['size_bytes'] and sha(data) == row['sha256']
        assert data == (P16 / row['path']).read_bytes()
historical = json.loads((ROOT / 'inputs/p15/MATERIALIZATION.json').read_text())
write('INPUTS.json', {'schema': 'ontokin.c271.p17-input-identities/1',
    'source_baseline': '81425ebd42c2b746b1b432231d02a1a7f6b5d6ff',
    'observed_main_director_supplied': '70ca7e68ff95df876f801137369d176fe5b2bab3',
    'documentary_phase_checkpoint_director_supplied': '4d259aff76af30381c0796f1527740f76cca1d9a',
    'source_changed_by_checkpoint': False,
    'p16_candidate_archive': archive,
    'p16_candidate_manifest_sha256': sha(manifest),
    'p16_expectations_sha256': '33a17cc66604f8b57be88dae7dd05a4bec066c0eaa191fc08400cfc79e18137e',
    'p15_saved_archive_sha256': historical['archive_sha256'],
    'historical_inputs': [{**descriptor(Path(row['path']), Path(row['path']).name),
                          'archive_member': row['archive_member']} for row in historical['files']],
    'early_recovery_confirmed_by_director': {'sha256': 'd80a9853eefb522f82e60c9eb7cf05d5fa717a64c6edb4d6fcd52a657384f42e',
                                           'receipt': 'work/EARLY-RECOVERY-RECEIPT.json'},
    'source_evidence_command': 'python3 -I -B work/flags-design/prepare_source_evidence.py',
    'source_evidence_script': descriptor(W / 'prepare_source_evidence.py'),
    'limits': ['Exact historical data and source association only.', 'No signature or reproduced-build proof.',
               'No current-host/product observation or implementation.']})

reads = [
 'AGENTS.md', 'ROLE.md', 'docs/workflow/PROTOCOL.md', 'docs/workflow/HANDOFF.md',
 'docs/workflow/templates/WORKER.md', 'docs/engineering/OK-ENG-006-local-validation-and-hosted-ci-policy.md']
base = 'docs/engineering/localized-repair-c271/'
for directory, names in {
 'current-host-p05': ['ADOPTION.json', 'CONTRACT.md', 'CONTRACT.json'],
 'host-inspection-p07': ['ADOPTION.json', 'HOST-INSPECTION-DESIGN.md', 'QUALIFICATION-PLAN.md'],
 'loader-path-p11': ['ADOPTION.json', 'design/candidate004/DECISION.md', 'design/candidate004/CONTROL-CONTRACT.md', 'design/candidate004/FUTURE-SURFACE.json'],
 'review-boundary-p13': ['ADOPTION.json', 'design/candidate001/DECISION.md', 'design/candidate001/CONTROL-CONTRACT.md'],
 'host-loader-p15': ['BLOCKER-DECISION.json', 'SOURCE-COMPLETENESS-DECISION.json'],
 'libc-tags-p16': ['ADOPTION.json', 'PHASE-OUTCOME.json', 'review/candidate001/REVIEW.json', 'review/attempt001/SOURCE-REVIEW.md']
}.items():
    reads.extend(base + directory + '/' + name for name in names)
repository_reads = [{**descriptor(REPO / path, path), 'reading': 'full',
                     'revision': '81425ebd42c2b746b1b432231d02a1a7f6b5d6ff',
                     'line_ranges': [[1, len((REPO / path).read_text().splitlines())]]} for path in reads]
source_path = 'prototypes/static_tray_v01/current_host_inspection_v01.py'
repository_reads.append({**descriptor(REPO / source_path, source_path), 'reading': 'selected_ranges_only',
                        'revision': '81425ebd42c2b746b1b432231d02a1a7f6b5d6ff',
                        'line_ranges': [[110, 190], [1041, 1270]]})
external_reads = []
for name in ['DECISION.md', 'CONTROL-CONTRACT.md', 'FUTURE-SURFACE.json', 'INPUTS.json', 'PROTECTED-SOURCES.json']:
    external_reads.append({**descriptor(P16 / name), 'reading': 'full', 'provenance': 'Exact authenticated P16 archive member'})
for path in ['work/PHASE.json', 'work/records-review/REPORT.md']:
    data = (ROOT / path).read_bytes()
    target = W / 'readset-bytes' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(data)
    target.chmod(0o600)
    external_reads.append({**descriptor(ROOT / path), 'reading': 'full', 'snapshot': str(target),
                           'provenance': 'Director-owned session assignment; bytes preserved at readset capture'})
source_ranges = {
 'upstream/elf/elf.h': [[990, 1006]], 'upstream/elf/get-dynamic-info.h': [[1, 191]],
 'upstream/elf/dl-static-tls.h': [[1, 51]], 'upstream/elf/dl-reloc.c': [[30, 155], [220, 250]],
 'upstream/sysdeps/x86_64/dl-machine.h': [[345, 420]]}
source_reads = [{**descriptor(C / 'sources' / path, 'sources/' + path),
                  'reading': 'full' if path.endswith(('get-dynamic-info.h', 'dl-static-tls.h')) else 'selected_ranges_only',
                  'line_ranges': ranges} for path, ranges in source_ranges.items()]
write('READSET.json', {'schema': 'ontokin.c271.p17-readset/1', 'worker': '/root/flags_design',
    'repository_reads': repository_reads, 'external_reads': external_reads, 'primary_source_reads': source_reads,
    'automated_read_only_inspections': ['Every169 P16 manifest payload bytes', 'Every protected-source inventory file',
        'All20048 regular upstream archive members for exact-token scan', 'All80 active patch headers/token matches',
        'Exact package members, control and dsc', 'Retained libc dynamic-entry bytes'],
    'full_required_read_gaps': [],
    'truncations_recovered': ['Initial combined governing output: HANDOFF reread fully; PROTOCOL155-193 recovered.',
        'Combined P16 output: DECISION, CONTROL-CONTRACT and FUTURE-SURFACE reread fully; INPUTS tail400-end recovered.'],
    'not_full_read': ['Large recovery file map output was truncated during optional discovery and was not relied upon.',
                      'Hash-only inventories and automated scans are not full semantic source reads.']})
for path in C.rglob('*'):
    if path.is_file():
        path.chmod(0o600)
print(json.dumps({'repository_reads': len(repository_reads), 'protected_files': len(protected['files']),
                  'p16_manifest_sha256': sha(manifest), 'assembly_complete': True}))
