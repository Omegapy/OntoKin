# P17 early recovery audit — EARLY-REVIEW-ATTEMPT001

**Verdict: revision required before save.** 2671 of 2674 assertions passed.

Archive: `OntoKin_C271_P17_Libc_Flags_Early_Recovery_2026-11-22.zip`, 24,625,033 bytes, SHA-256 `30bdf10be0baf2cc0da9e869184e26b0dae57878f3ad1d652f93430c007ee70e`. The package has 886 members, 885 payload entries, 34 exact Git snapshots and 837 recovery-map entries.

All byte, inventory, CRC, path, mode, fresh extraction and authentic-source bindings are recorded in the adjacent JSON audit. The exact predecessor archive, terminal receipt and saved prompts match the independently audited inputs. Parent requirements, open PR/issue, current and historical unknowns, active workers and early save-pending boundary are checked explicitly.

## Mandatory findings

- **E17-001: Early prompts conflate incomplete technical work with delivery-only recovery.** Both root prompts step 2 direct an incomplete P17 phase to finish only remaining delivery gates. The checkpoint explicitly has A02 through A04 not_started and NEXT-TASK requires the selected flags decision. Following the prompt literally would omit the authorized technical phase. Required correction: Distinguish an early checkpoint, which first confirms the early save then resumes the same phase's first unmet gate, from a technically completed checkpoint awaiting only publication or saved delivery. Keep the one-phase stop.

- **E17-002: Repository-relative reusable prompt snapshots are absent.** HANDOFF Required contents requires preserving relative paths for reusable prompts. The archive contains repository/docs/workflow/BROWSER-PROMPTS.md but omits the source prompts at repository/docs/workflow/prompts/CONTINUE.md and RECOVER.md. Required correction: Include the two exact source files in repository/ and SOURCE-MANIFEST.json, and rebuild the immutable archive under a distinct attempt identity.

## Scope limits

Recovery acceptance only; actual early save/readback must be confirmed separately.

Predecessor deep verification reused only after exact ZIP/terminal/prompt identity comparison.

Active worker files are frozen bytes; later unique work belongs in the final package or separate receipt.

No repository code, parser, host qualification or product test executed. No Git/index mutation, remote write or Library write.
