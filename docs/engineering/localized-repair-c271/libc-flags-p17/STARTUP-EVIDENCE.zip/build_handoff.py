from pathlib import Path
import argparse, datetime, hashlib, json, stat, subprocess, zipfile

ROOT = Path('/workspace/scratch/bbea56c9165d')
REPO = ROOT / 'OntoKin'
WORK = ROOT / 'work'
MAIN = '70ca7e68ff95df876f801137369d176fe5b2bab3'
START = '81425ebd42c2b746b1b432231d02a1a7f6b5d6ff'
BRANCH = 'work/c271-missing-import-digest-control'
EVIDENCE = 'docs/engineering/localized-repair-c271/libc-flags-p17'

def enc(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--kind', choices=['early', 'final'], required=True)
    parser.add_argument('--revision', required=True)
    parser.add_argument('--attempt', default='001')
    args = parser.parse_args()
    rev = args.revision
    tree = git('rev-parse', rev + '^{tree}').decode().strip()
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    phase = json.loads((WORK / 'PHASE.json').read_text())
    phase.update(package_kind=args.kind, package_frozen_at_utc=now,
                 source_revision=rev, source_tree=tree,
                 delivery_state_at_freeze='save_pending',
                 external_receipt=EVIDENCE + '/P17-DELIVERY.json',
                 package_type='browser-session handoff for online GitHub continuation')
    phase['exact_recovery_action'] = (
        'Reconcile live GitHub and this phase external receipt before retry. If final delivery is already confirmed, stop this phase and select only NEXT-TASK in a fresh chat. Otherwise resume only the first unmet P17 gate; never replay confirmed writes or change prior evidence.'
    )
    payload = {}
    sources = []
    required = ['CHATGPT-START-HERE.md','AGENTS.md','GOAL.md','STATUS.md','ROLE.md',
        'docs/workflow/registry.json','docs/workflow/CURRENT.json','docs/workflow/PROTOCOL.md',
        'docs/workflow/HANDOFF.md','docs/workflow/BROWSER-PROMPTS.md',
        'docs/workflow/prompts/CONTINUE.md','docs/workflow/prompts/RECOVER.md',
        'docs/workflow/templates/WORKER.md','docs/workflow/memory.json','docs/workflow/knowledge.json',
        'docs/workflow/tasks/C271/task.json','docs/workflow/tasks/C271/REQUIREMENTS.md',
        'docs/workflow/tasks/C271/PLAN.md',
        '.agents/skills/ontokin-session/SKILL.md','.agents/skills/ontokin-delivery/SKILL.md',
        '.agents/skills/ontokin-learning/SKILL.md',
        'docs/engineering/OK-ENG-006-local-validation-and-hosted-ci-policy.md',
        'docs/engineering/OK-ENG-009-development-integration-and-branch-lifecycle.md',
        'docs/engineering/localized-repair-c271/libc-tags-p16/ADOPTION.json',
        'docs/engineering/localized-repair-c271/libc-tags-p16/P16-DELIVERY.json',
        'docs/engineering/localized-repair-c271/libc-tags-p16/EVIDENCE-MATERIALIZATION.md',
        'docs/engineering/localized-repair-c271/libc-tags-p16/design/CANDIDATE001.zip']
    tracked = git('ls-tree','-r','--name-only',rev).decode().splitlines()
    selected = set(required)
    if args.kind == 'final':
        selected.update(p for p in tracked if p.startswith(EVIDENCE + '/'))
    for p in sorted(selected):
        data = git('show',rev + ':' + p)
        name = 'repository/' + p
        payload[name] = data
        sources.append({'archive_path':name,'revision':rev,'path':p,
                        'git_blob':git('rev-parse',rev + ':' + p).decode().strip(),
                        'bytes':len(data),'sha256':digest(data)})
    for p in required[:9]:
        data = git('show',MAIN + ':' + p)
        name = 'observed-main/' + p
        payload[name] = data
        sources.append({'archive_path':name,'revision':MAIN,'path':p,
                        'git_blob':git('rev-parse',MAIN + ':' + p).decode().strip(),
                        'bytes':len(data),'sha256':digest(data)})
    recovery = []
    for p in sorted(WORK.rglob('*')):
        if not p.is_file() or p.is_symlink():
            continue
        rel = p.relative_to(WORK)
        if rel.parts[0] in {'main','package-output','readback'} or '__pycache__' in rel.parts:
            continue
        data = p.read_bytes()
        name = 'recovery/session/' + rel.as_posix()
        payload[name] = data
        recovery.append({'archive_path':name,'original_path':str(p),'bytes':len(data),'sha256':digest(data)})
    predecessor = ROOT/'incoming/OntoKin_C271_P16_Libc_Tag_Decision_Handoff_2026-11-22.zip'
    payload['predecessor/'+predecessor.name] = predecessor.read_bytes()
    for p in sorted((ROOT/'incoming/p16-saved/OntoKin').glob('*')):
        if p.is_file():
            payload['predecessor/'+p.name] = p.read_bytes()
    deps = json.loads((ROOT/'incoming/c271/HISTORICAL-DEPENDENCIES.json').read_text())
    payload['HISTORICAL-DEPENDENCIES.json'] = enc({
        'schema':'ontokin.c271.p17-dependencies/1',
        'purpose':'Online continuation; no complete offline restoration claim',
        'predecessor':{'file_name':predecessor.name,'bytes':predecessor.stat().st_size,
            'sha256':digest(predecessor.read_bytes()),
            'library_file_id':'libfile_fde3_f-f9ec9ea47be081918e2f1ce73223e7c8_2ab2a24d43748191957f9bcc356b59de',
            'file_id':'file_0000000039f481f6a179fb14555ce82c','version':0,'included':True},
        'predecessor_terminal':{'file_name':'OntoKin_C271_P16_Delivery_Receipt_2026-11-22.json',
            'library_file_id':'libfile_fde3_f-f0058776059881918303086a268bfbb2_2ab2a24d43748191957f9bcc356b59de',
            'file_id':'file_0000000044cc81f9a9007a88242d7134','version':0,'bytes':4157216,
            'sha256':'e4a0b79fc1f434bcf4c558eee5271c74238e523039e818284bddd617f944de57','included':True},
        'inherited':deps})
    payload['SOURCE-MANIFEST.json'] = enc({'schema':'ontokin.c271.p17-source-manifest/1','files':sources})
    payload['RECOVERY-FILE-MAP.json'] = enc({'schema':'ontokin.c271.p17-recovery-map/1','files':recovery})
    payload['CHECKPOINT.json'] = enc(phase)
    payload['README-START-HERE.md'] = (f'''# OntoKin C271 P17 {args.kind} handoff

This is a **browser-session handoff for online GitHub continuation**, usable without the preceding chat. It is not a complete offline repository backup.

Repository: https://github.com/Omegapy/OntoKin
Source commit: `{rev}`; tree: `{tree}`.
Retained branch: `{BRANCH}`. Observed main: `{MAIN}`.

Read CHECKPOINT.json, HANDOFF.md, RECOVERY-STATUS.md and NEXT-TASK.md. Then reconcile live CHATGPT-START-HERE.md and its required instructions. GitHub governs current repository state. The observed-main snapshots and retained branch snapshots intentionally differ: C271 is unmerged, and licensing PR275 is on main only.

P17 is one source-backed compatibility decision for retained libc DT_FLAGS=0x18, with frozen inert controls and independent review. Stop before implementation, new H0/H1 or first concrete design blocker. The parent remains open.

Verify safe relative paths, unique names, exact manifest inventory, all size/hash entries, source bindings and ZIP integrity before extraction. All archived files are inert 0644; recovered scripts and ELF bytes are data and must never run automatically. Do not apply a snapshot over newer GitHub work.

The predecessor P16 ZIP and separate terminal receipt are included exactly. Other historical dependencies are identified in HISTORICAL-DEPENDENCIES.json. Readback and source captures are historical; they do not qualify this host. This immutable ZIP cannot contain its own future save receipt. Reconcile `{EVIDENCE}/P17-DELIVERY.json` and the separately saved P17 terminal receipt before retrying delivery.
''').encode()
    handoff = WORK/'HANDOFF-CONTENT.md'
    payload['HANDOFF.md'] = handoff.read_bytes() if handoff.exists() else (
        '# P17 early recovery\n\nStartup and predecessor delivery reconciliation are in progress. No P17 technical design or implementation has begun. This package preserves live observations, the exact P16 dependency, current scope and worker state. Confirm its save and independent audit before substantial work. See CHECKPOINT.json for acceptance criteria and limits.\n').encode()
    nextfile=WORK/'NEXT-TASK.md'
    payload['NEXT-TASK.md'] = nextfile.read_bytes() if nextfile.exists() else (
        '# First remaining action\n\nConfirm this early recovery save and independent audit. Resume only P17: source-backed DT_FLAGS/DF_STATIC_TLS compatibility decision for the exact retained libc, frozen controls, independent review, documentary publication and saved partial handoff. Preserve P16/older expectations. Stop before implementation, new H0/H1 or first concrete design blocker.\n').encode()
    payload['RECOVERY-STATUS.md'] = (
        '# Recovery status\n\nExact source snapshots are bound by SOURCE-MANIFEST.json. Current unique session files are retained under recovery/session and mapped by RECOVERY-FILE-MAP.json. They are inert records, not instructions to overwrite newer work. Reconcile live refs, canonical task, prior and current delivery receipts, and CHECKPOINT worker dispositions before resuming.\n\nHistorical C270 broad-driver completion, global prior-process termination and P13 read-only difflib completion remain unknown; do not replay them blindly. Current operations and any incomplete workers are recorded in CHECKPOINT. This ZIP has save_pending at freeze; its external receipt records the later actual result. C271 remains blocked/open with R03–R05 not_done, PR274 draft/open/unmerged and issue273 open. No main lease or integration is selected.\n').encode()
    for number,mode in [(1,'Continue'),(2,'Recover')]:
        text = f'''# Prompt {number}: {mode} OntoKin

Repository: https://github.com/Omegapy/OntoKin
Latest confirmed development handoff ZIP: [PASTE THE CONFIRMED ZIP LINK FROM THE DELIVERY MESSAGE]
Newer recovery/receipt, if any: [PASTE LINK OR NONE]

In a fresh chat, {mode.lower()} one bounded phase. Save a verified handoff ZIP to my existing OntoKin ChatGPT Library folder, then stop.

1. Open README-START-HERE.md and CHECKPOINT.json. Read live CHATGPT-START-HERE.md and its required instructions at observed main. Read unchanged files once. Reconcile active task/plan, branches/PRs, integration ownership, evidence, saved receipts and unpublished work. GitHub governs repository state.
2. Resolve actual receipts before treating frozen save_pending markers as unfinished work. For an EARLY package, confirm early saving, then resume the first unmet gate of this same P17 phase, including technical design/review when incomplete. For a FINAL package whose technical and publication gates have passed, finish only any remaining delivery gates. Once final P17 delivery is confirmed, a fresh chat may resume the active task through the one approved next phase in NEXT-TASK.md. Declare acceptance and stopping point; follow PROTOCOL.md and HANDOFF.md.
3. Confirm new early recovery before substantial work. Delegate bounded independent assignments to actual subagents, supplying only applicable context. Preserve failures and original evidence. Reconcile uncertain operations before retrying.
4. Verify changes and independent reviews. Save the exact next ZIP plus matching prompts; record actual Library receipt separately. Report actual checks, branch/merge state, limits and first remaining action. Keep parent open until all gates pass. Do not begin another phase.

This P17 package starts from `{START}` on `{BRANCH}`; GitHub may be newer. No implementation, new H0/H1, Node/ldd or full routine is authorized merely by the design artifacts. Follow the separately declared next bounded phase after delivery reconciliation.
'''
        payload[f'PROMPT-{number}-{mode.upper()}.md'] = text.encode()
    payload['MANIFEST-SHA256.json'] = enc({'schema':'ontokin.c271.p17-package-manifest/1','files':[
        {'path':p,'bytes':len(b),'sha256':digest(b)} for p,b in sorted(payload.items())]})
    folder=ROOT/'deliverables'/f'{args.kind}-attempt{args.attempt}'
    folder.mkdir(parents=True,exist_ok=False)
    label='Early_Recovery' if args.kind=='early' else 'Decision_Handoff'
    name=f'OntoKin_C271_P17_Libc_Flags_{label}_2026-11-22'
    archive=folder/(name+'.zip')
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p,b in sorted(payload.items()):
            assert not Path(p).is_absolute() and '..' not in Path(p).parts
            info=zipfile.ZipInfo(p,(2026,11,22,0,0,0));info.create_system=3
            info.external_attr=(stat.S_IFREG|0o644)<<16;info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,b)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        assert len(z.namelist())==len(set(z.namelist()))==len(payload)
        extracted=folder/'verified-extraction';z.extractall(extracted)
        for p,b in payload.items():assert (extracted/p).read_bytes()==b
    for num,mode in [(1,'Continue'),(2,'Recover')]:
        (folder/(name+'_'+mode+'.md')).write_bytes(payload[f'PROMPT-{num}-{mode.upper()}.md'])
    report={'schema':'ontokin.c271.p17-package-verification/1','kind':args.kind,'passed':True,
        'file':str(archive),'bytes':archive.stat().st_size,'sha256':digest(archive.read_bytes()),
        'members':len(payload),'payloads':len(payload)-1,'source_snapshots':len(sources),
        'source_revision':rev,'source_tree':tree,'recovery_files':len(recovery),
        'checks':['safe paths','no duplicate names','exact inventory','all manifest sizes and SHA256',
        'all source bytes from authentic git revision','CRC','fresh extraction and byte equality','inert modes'],
        'limitations':['independent audit and actual save remain separate','online continuation only']}
    (folder/'VERIFICATION.json').write_bytes(enc(report));print(json.dumps(report))

if __name__=='__main__':
    main()
