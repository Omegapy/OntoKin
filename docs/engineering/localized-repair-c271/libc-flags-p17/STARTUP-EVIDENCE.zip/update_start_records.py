from pathlib import Path
import datetime, hashlib, json, shutil, subprocess, zipfile, stat

ROOT=Path('/workspace/scratch/bbea56c9165d')
REPO=ROOT/'OntoKin'
WORK=ROOT/'work'
REL='docs/engineering/localized-repair-c271/libc-flags-p17'
OUT=REPO/REL
OUT.mkdir(parents=True,exist_ok=True)
def write(p,x):p.write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def read(p):return json.loads(p.read_text())
phase=read(WORK/'PHASE.json')
phase['current_workers'].append({'worker':'/root/flags_design','scope':'source-backed flags decision and frozen inert controls','state':'active design; no implementation'})
phase['current_workers'][1]['state']='startup complete; independent technical review active'
write(WORK/'PHASE.json',phase)
write(OUT/'PHASE.json',phase)
shutil.copyfile(WORK/'EARLY-RECOVERY-RECEIPT.json',OUT/'EARLY-RECOVERY-RECEIPT.json')
shutil.copyfile(WORK/'FAILURES.json',OUT/'SESSION-FAILURES.json')
shutil.copyfile(WORK/'MAIN-READ-SET.json',OUT/'MAIN-READ-SET.json')
shutil.copyfile(WORK/'records-review/REPORT.md',OUT/'STARTUP-RECONCILIATION.md')
readsets={'schema':'ontokin.c271.p17-readset-index/1','main':'MAIN-READ-SET.json','active_ledgers':'STARTUP-EVIDENCE.zip:records-review/readset.json','prior_package':'STARTUP-EVIDENCE.zip:handoff-audit/READSET.json','main_full_required_read':'Director read full GitHub main instructions; empty STATUS id-only navigation anchors excluded (50 lines); exact source bytes preserved','delegated_active_full_read':'/root/records_review fully read task.json, REQUIREMENTS.md, PLAN.md, CURRENT.json and P16 supplemental records','governing_differences':'Only CURRENT/current STATUS materially differ; other governing instructions unchanged. Temporary main capture extra newlines were corrected from authentic Git; original actual-reader byte hashes retained.'}
write(OUT/'READSET-INDEX.json',readsets)
chosen=[]
for folder in ['state','saves/early']:
 chosen.extend(p for p in (WORK/folder).rglob('*') if p.is_file())
for name in ['records-review/readset.json','records-review/RESULT.json','records-review/REPORT.md',
 'handoff-audit/INTAKE-AUDIT.json','handoff-audit/INTAKE-REPORT.md','handoff-audit/INTAKE-ATTEMPTS.json',
 'handoff-audit/READSET.json','handoff-audit/EARLY-REVIEW.json','handoff-audit/EARLY-REVIEW.md',
 'handoff-audit/EARLY-REVIEW-ATTEMPT001.json','handoff-audit/EARLY-REVIEW-ATTEMPT001.md',
 'handoff-audit/EARLY-ARTIFACTS.json','build_handoff.py','update_start_records.py','PHASE.json',
 'MAIN-READ-SET.json','EARLY-RECOVERY-RECEIPT.json','FAILURES.json']:
 p=WORK/name
 if p.is_file():chosen.append(p)
manifest=[]
with zipfile.ZipFile(OUT/'STARTUP-EVIDENCE.zip','w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for p in sorted(set(chosen)):
  n=p.relative_to(WORK).as_posix();b=p.read_bytes();i=zipfile.ZipInfo(n,(2026,11,22,0,0,0));i.create_system=3;i.external_attr=(stat.S_IFREG|0o644)<<16;i.compress_type=zipfile.ZIP_DEFLATED;z.writestr(i,b)
  manifest.append({'path':n,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 z.writestr('MANIFEST.json',json.dumps({'files':manifest},indent=2)+'\n')
write(OUT/'STARTUP-EVIDENCE-MANIFEST.json',{'schema':'ontokin.c271.p17-startup-evidence/1','archive':'STARTUP-EVIDENCE.zip','bytes':(OUT/'STARTUP-EVIDENCE.zip').stat().st_size,'sha256':hashlib.sha256((OUT/'STARTUP-EVIDENCE.zip').read_bytes()).hexdigest(),'files':manifest,'rule':'Inert preserved evidence; validate manifest before extracting; never execute recovered scripts automatically'})
session='''# C271 P17: libc flags compatibility decision

The user authorized one bounded continuation phase on the retained C271 branch. Starting branch is `81425ebd42c2b746b1b432231d02a1a7f6b5d6ff`; observed main is `70ca7e68ff95df876f801137369d176fe5b2bab3`. GitHub governs current repository state. Root owner is `c271-p17-bbea56c9165d`; no main integration lease is selected.

## Scope and acceptance

Decide from exact retained primary sources whether libc `DT_FLAGS=0x18`, including `DF_STATIC_TLS`, can have a finite separately versioned admission rule. The decision may retain refusal. Freeze inert positive, boundary and refusal controls before any future implementation; obtain independent exact-artifact review. P16's observed tag refusal and inferred later flag constraint remain distinct.

P17-A01 is passed: exact P16 handoff/prompts/terminal receipt and live refs/checks reconciled; corrected early recovery independently accepted and both accepted/rejected archives saved with exact readback. P17-A02 is the decision/control artifact. P17-A03 is independent review and Director adoption. P17-A04 is documentary verification and conditional publication. P17-A05 is independently verified final ZIP, matching prompts, separate actual receipt and stop. See PHASE.json and EARLY-RECOVERY-RECEIPT.json for exact identities.

## Ownership and limits

Root owns canonical records, Git/index, publication and Library. `/root/flags_design` owns `work/flags-design`; `/root/records_review` owns `work/records-review`; `/root/handoff_audit` owns `work/handoff-audit`. The author and reviewer are separate actual workers. Read-only Git inspection is allowed; workers may not mutate the repository, publish or launch children. No claimed model override.

Keep all existing production/test sources, adopted contracts, dependencies, limits and expectations unchanged. No product parser/test execution, new host inspection/H0, H1, installation, Node/ldd, original-seven/full routine, native/model/hosted execution, main integration or branch deletion. Source and inert-data checks establish no runtime safety or host qualification.

Parent C271 remains blocked/open: R01/R02 done, R03–R05 not_done, P01 done and P02 in_progress. PR274 remains draft/open/unmerged and issue273 open. Licensing PR275 on main is a future integration obligation. Historical C270 broad-driver completion, prior global process termination and P13 read-only difflib completion remain unknown. No current unknown write was observed.

## Stop

Stop technical work at the independently reviewed decision/control boundary or the first concrete design blocker/unplanned expansion. Finish only documentary publication and verified partial delivery in this chat. Do not start implementation or another phase.
'''
(OUT/'SESSION.md').write_text(session)
(OUT/'README.md').write_text('# C271 P17 libc flags decision\n\nOne source-backed decision for exact retained libc flags, with frozen inert controls. See [session](SESSION.md), [phase](PHASE.json), [startup reconciliation](STARTUP-RECONCILIATION.md) and [early receipt](EARLY-RECOVERY-RECEIPT.json). Technical work is in progress; no flag exception or implementation is yet adopted. Parent gates remain open.\n')
taskpath=REPO/'docs/workflow/tasks/C271/task.json';task=read(taskpath)
task.setdefault('prior_session_phases',[]).append(task['session_phase'])
task.setdefault('prior_phase_deliveries',[]).append(task['delivery'])
task['owner']=phase['owner'];task['session_phase']=phase
task['next_action']='Complete only P17 source-backed flags decision and inert controls, independent review, documentary publication and verified partial delivery; stop before implementation/new H0/H1.'
task['delivery']={'required':True,'kind':'browser-session','status':'early_confirmed_final_pending','folder':'OntoKin','partial':True,'early_receipt':REL+'/EARLY-RECOVERY-RECEIPT.json','receipt':REL+'/P17-DELIVERY.json'}
task.setdefault('checks',[]).append({'name':'P17 startup reconciliation and independently verified early recovery','command':'Independent exact ZIP/source/late-evidence audits; ordered prepared saves and exact saved-byte comparisons','result':'passed','required':True,'evidence':[REL+'/EARLY-RECOVERY-RECEIPT.json',REL+'/STARTUP-EVIDENCE-MANIFEST.json']})
write(taskpath,task)
cp=REPO/'docs/workflow/CURRENT.json';cur=read(cp)
cur['active_task']='C271';cur['latest_task']='C271';cur['observed_main']=phase['observed_main']['commit'];cur['snapshot_date']=datetime.datetime.now(datetime.timezone.utc).isoformat()
cur['next_action']={'status':'ready','summary':task['next_action'],'suggested_task':'P17 exact libc flags compatibility decision only','sources':[REL+'/SESSION.md',REL+'/PHASE.json',REL+'/EARLY-RECOVERY-RECEIPT.json']}
if cur.get('previous_recovery'):cur.setdefault('older_recoveries',[]).append(cur['previous_recovery'])
if cur.get('latest_recovery'):cur['previous_recovery']=cur['latest_recovery']
cur['latest_recovery']={**read(WORK/'EARLY-RECOVERY-RECEIPT.json')['accepted_archive'],'receipt':REL+'/EARLY-RECOVERY-RECEIPT.json'}
cur['boundaries'].append('C271 P17 is one flags compatibility decision with inert controls; no implementation, new H0/H1 or full routine. Early recovery confirmed; parent remains blocked/open.')
write(cp,cur)
for filename in ['REQUIREMENTS.md','PLAN.md']:
 p=REPO/'docs/workflow/tasks/C271'/filename
 with p.open('a') as f:
  f.write('\n## P17 flags compatibility decision — November 22, 2026\n\nStart `81425ebd42c2b746b1b432231d02a1a7f6b5d6ff`; Director `c271-p17-bbea56c9165d`. Resume the same task/branch after reconciled P16 delivery and confirmed corrected early recovery. Select only the source-backed DT_FLAGS/DF_STATIC_TLS decision for exact retained libc 0x18. The decision may retain refusal. Require frozen inert positive/boundary/refusal controls, independent exact-artifact review, documentary/whitespace/source-preservation checks, conditional branch publication and independently verified saved partial handoff with matching prompts and separate receipt. See [P17 session](../../../engineering/localized-repair-c271/libc-flags-p17/SESSION.md).\n\nPreserve P16 and older masks/routes/expectations, contracts, pins, limits and historical failures. No production/test implementation, parser/product execution, new H0/H1, installation, Node/ldd, original-seven/full routine, native/model/hosted execution, main lease/integration or branch deletion. Root owns canonical records/Git/publication/saving; separate workers own design, independent review and package audit in disjoint scratch paths. R01/R02 stay done; R03–R05 not_done; P01 done and P02 in_progress. Stop technical work at the accepted finite decision/control boundary or first concrete blocker; finish delivery only, then stop this chat.\n')
p=REPO/'STATUS.md';s=p.read_text();old=next(line for line in s.splitlines() if line.startswith('C271 P16 has'))
new='C271 P17 is in progress on the retained branch after reconciled P16 delivery and confirmed independently reviewed early recovery. The selected scope is one source-backed DT_FLAGS/DF_STATIC_TLS decision for exact retained libc 0x18, with inert controls and independent review; it may retain refusal. [Session](docs/engineering/localized-repair-c271/libc-flags-p17/SESSION.md). No implementation, new H0/H1, full routine or integration is selected. R03–R05 remain unmet, P02 in progress, PR274 draft/open and issue273 open. No main lease; observed main remains `70ca7e68ff95df876f801137369d176fe5b2bab3`, including separate licensing PR275. Finish this bounded decision and verified partial delivery, then stop.'
p.write_text(s.replace(old,new,1))
print(json.dumps({'phase':phase['phase'],'early_confirmed':True,'output':str(OUT),'startup_files':len(manifest)}))
