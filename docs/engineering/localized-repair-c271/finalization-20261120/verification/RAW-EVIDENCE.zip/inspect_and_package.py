#!/usr/bin/env python3
"""Inspect completed C271 executions and preserve their unique evidence."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import tempfile
import zipfile

ROOT = Path('/workspace/scratch/c219bb61a617/validation')
EXPECTED = '88bc8b51b3963b7072375edac6400b6e6a4532e4'


def now():
    return datetime.now(timezone.utc).isoformat()


def load(path):
    return json.loads(path.read_text())


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def ident(path, base=ROOT):
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    return {'path': path.relative_to(base).as_posix(), 'bytes': path.stat().st_size, 'sha256': digest}


def confirm(path, expected):
    actual = ident(path)
    if actual['bytes'] != expected['bytes'] or actual['sha256'] != expected['sha256'].removeprefix('sha256:'):
        raise ValueError('Evidence identity mismatch: ' + str(path))


def report_summary(path):
    data = load(path)
    cases = data.get('cases', [])
    if isinstance(cases, dict):
        cases = list(cases.values())
    cases = [x for x in cases if isinstance(x, dict)]
    return {'identity': ident(path), 'top_level_outcomes': {k: data[k] for k in ['status', 'summary', 'full_gate_complete', 'implementation', 'full_force_release_complete', 'destination_validated'] if k in data},
            'case_status_counts': dict(Counter(x.get('status', 'unspecified') for x in cases)),
            'pending_or_failed_cases': [x for x in cases if x.get('status') in {'pending', 'failed', 'error'}]}


def main():
    receipts = {role: load(ROOT / 'execution-receipts' / (role + '-candidate') / 'EXECUTION.json') for role in ['routine', 'affected']}
    for role, receipt in receipts.items():
        if receipt['status'] == 'running' or receipt['returncode'] is None:
            raise RuntimeError('Execution has not completed: ' + role)
        if receipt['source_before']['commit'] != EXPECTED or not receipt['source_unchanged'] or receipt['source_after']['all_dirty_status']:
            raise RuntimeError('Source invariant failed: ' + role)
        for kind in ['stdout', 'stderr']:
            confirm(Path(receipt[kind]), receipt[kind + '_identity'])
    operations = load(ROOT / 'ACTIVE-OPERATIONS.json')
    if not all(row['status'] == 'completed' for row in operations['operations']):
        raise RuntimeError('Original execution completion must be positively observed before packaging')
    routine = load(ROOT / 'routine-candidate/summary.json')
    affected = load(ROOT / 'affected-candidate/CHECKS.json')
    documents_failure = load(ROOT / 'DOCUMENTS-FAILURE-INSPECTION.json')
    expected_steps = ['unit-tests', 'source', 'agent', 'construction', 'surface', 'impulse', 'documents']
    if routine.get('planned_steps') != expected_steps or [s['id'] for s in routine['steps']] != expected_steps:
        raise RuntimeError('Not every routine driver step reached an observed result')
    if routine.get('source_unchanged') is not True:
        raise RuntimeError('Driver source invariance was not established')
    verified = []
    reports = []
    for step in routine['steps']:
        log = ROOT / 'routine-candidate' / step['log']
        confirm(log, step['log_identity'])
        verified.append(ident(log))
        for row in step['reports']:
            path = ROOT / 'routine-candidate' / row['path']
            confirm(path, row)
            verified.append(ident(path))
            reports.append(report_summary(path))
    if affected['completed_check_count'] != 12 or affected['total_methods'] != 282 or not affected['complete']:
        raise RuntimeError('Affected cohort is incomplete')
    for row in affected['output_files']:
        path = ROOT / 'affected-candidate' / row['path']
        confirm(path, row)
        verified.append(ident(path))
    before = load(ROOT / 'routine-candidate/source-before.json')
    after = load(ROOT / 'routine-candidate/source-after.json')
    if before != after:
        raise RuntimeError('Source inventory changed during driver execution')
    base_map = {row['path']: row for row in before['files']}
    workspace = ROOT / 'routine-candidate/workspace'
    delta, removed, visited = [], [], set()
    for parent, dirs, files in os.walk(workspace):
        dirs[:] = sorted(d for d in dirs if d != '.git')
        for name in sorted(files):
            path = Path(parent) / name
            if path.is_symlink():
                raise RuntimeError('Unclassified workspace symbolic link: ' + str(path))
            current = ident(path, workspace)
            visited.add(current['path'])
            prior = base_map.get(current['path'])
            changed = prior is None or current['bytes'] != prior['bytes'] or current['sha256'] != prior['sha256'].removeprefix('sha256:')
            if changed:
                target = ROOT / 'workspace-recovery' / current['path']
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(path, target)
                delta.append({'kind': 'new' if prior is None else 'modified', 'workspace_path': current['path'],
                              'before': prior, 'after': current, 'preserved_copy': ident(target)})
    removed = [row for path, row in base_map.items() if path not in visited]
    workspace_delta = {'source_revision': EXPECTED, 'workspace_git': routine.get('workspace_git'),
                       'compared_file_count': len(visited), 'new_or_modified_files': delta, 'missing_original_files': removed,
                       'excluded': [{'path': 'candidate-checkout/', 'reason': 'Clean exact Git candidate; complete tree/input identities retained, no unique writes'},
                                    {'path': 'routine-candidate/workspace/.git/', 'reason': 'Driver-owned reconstructed local Git metadata; source commit/tree and storage metadata retained'},
                                    {'path': 'routine-candidate/workspace/', 'reason': 'Copied source, compared byte-for-byte against source-before inventory; every new/modified non-Git byte copied into workspace-recovery/'}],
                       'original_outputs_deleted': False}
    save(ROOT / 'WORKSPACE-RECOVERY-DELTA.json', workspace_delta)
    text = (ROOT / 'routine-candidate/logs/unit-tests.log').read_text(errors='replace')
    failure_headers = re.findall(r'^(?:ERROR|FAIL): .+$', text, re.MULTILINE)
    skips = re.findall(r'^test_.* \.\.\. skipped[^\n]*$', text, re.MULTILINE)
    endings = re.findall(r'^(?:Ran \d+ tests? in [^\n]+|OK(?: \([^\n]+\))?|FAILED(?: \([^\n]+\))?)$', text, re.MULTILINE)
    progress_lines = re.findall(r'^test_.* \.\.\. (ok|ERROR|FAIL|skipped[^\n]*)$', text, re.MULTILINE)
    footer_present = bool(re.search(r'^Ran \d+ tests? in ', text, re.MULTILINE))
    failed_steps = [{'id': row['id'], 'status': row['status'], 'returncode': row['returncode'], 'reason': row.get('reason'),
                     'test_execution': row.get('test_execution'), 'log': row['log']} for row in routine['steps'] if row['status'] != 'passed']
    summary = {'schema': 'ontokin.c271.p02-available-environment-validation/1', 'recorded_at': now(), 'worker': '/root/validation',
               'source_commit': EXPECTED, 'source_tree': receipts['routine']['source_before']['tree'],
               'source_unchanged_and_clean': True, 'integration_eligible': not failed_steps and affected['passed'],
               'affected': {'status': 'passed' if affected['passed'] else 'failed', 'complete': affected['complete'],
                            'checks': affected['completed_check_count'], 'methods': affected['total_methods'],
                            'zero_failures_errors_skips': all(c['result'] == 'passed' for c in affected['checks']),
                            'report': ident(ROOT / 'affected-candidate/CHECKS.json')},
               'routine': {'status': routine['status'], 'returncode': routine['exit_code'], 'step_count': len(routine['steps']),
                           'duration_seconds': routine['duration_seconds'], 'all_planned_steps_observed': True,
                           'steps': [{'id': row['id'], 'status': row['status'], 'returncode': row['returncode'],
                                      'seconds': row['duration_seconds'], 'reason': row.get('reason'),
                                      'test_execution': row.get('test_execution')} for row in routine['steps']],
                           'failed_steps': failed_steps, 'unit_log_endings': endings,
                           'unit_failure_headers': failure_headers, 'unit_skipped_test_lines': skips,
                           'documents_failure_inspection': documents_failure,
                           'pending_external_cases': routine.get('pending_external_cases', []),
                           'unittest_footer_present': footer_present,
                           'observed_test_result_lines': len(progress_lines),
                           'observed_test_result_line_regex': r'^test_.* \.\.\. (ok|ERROR|FAIL|skipped[^\n]*)$',
                           'partial_progress_accounting': 'PARTIAL-UNIT-LOG-ACCOUNTING.json',
                           'result_line_count_limit': 'Log progress only; not a complete method count when the unittest footer is absent. The driver reports tests_run=0 in that case because it cannot parse a final count.',
                           'last_unit_log_lines': text.splitlines()[-8:],
                           'report': ident(ROOT / 'routine-candidate/summary.json')},
               'individual_report_inspection': reports, 'verified_execution_files': verified,
               'environment': receipts['routine']['environment'],
               'known_environment_limits': receipts['routine']['known_environment_limits'],
               'processes': operations['operations'], 'active_processes': [], 'unknown_operations': [],
               'workspace_recovery': {'report': 'WORKSPACE-RECOVERY-DELTA.json', 'unique_files_preserved': len(delta), 'removed_files': len(removed)},
               'not_run': ['Optional --full role', 'Optional --force-agent role', 'Other Python versions', 'Hosted CI', 'C271 control replay',
                           'Native/model trials', 'Source/fixture/dependency repair', 'Resulting-main verification or integration'],
               'failure_accounting': ['Both original authorized entrypoints ran once; no automatic retries.',
                                      'Prelaunch archive-versus-receipt SHA assertion mistake retained in PREEXECUTION-ATTEMPT-01.json; corrected before test launch.',
                                      'All driver/cohort logs, partial and final reports, and unique generated bytes retained.'],
               'acceptance_boundary': 'A failed routine step or skipped required obligation leaves R03 unmet. Affected-cohort success does not waive the routine gate. No product/release/compatibility claim.',
               'next_action': 'Director publishes exact outcomes and verified saved partial handoff; retain branch/issue when required integration gate is unmet; no repair within this phase.'}
    save(ROOT / 'RUN-RESULTS.json', summary)
    lines = ['# C271 P02 validation results', '',
             f"Candidate: `{EXPECTED}`; tree `{summary['source_tree']}`. Both original processes completed and their clean source identity remained unchanged.", '',
             f"Affected observer cohort: **{summary['affected']['status']}**, all 12 checks and 282 test methods, with zero failures, errors or skipped obligations.", '',
             f"Routine driver: **{routine['status']}**, exit {routine['exit_code']}; all seven planned steps have observed outcomes.", '',
             '| Step | Result | Exit | Seconds |', '| --- | --- | ---: | ---: |']
    for step in routine['steps']:
        lines.append(f"| {step['id']} | {step['status']} | {step['returncode']} | {step['duration_seconds']} |")
    lines += ['', '## Required-gate findings', '']
    for step in failed_steps:
        lines.append(f"- `{step['id']}`: {step['reason'] or step['status']}. Driver-parsed footer fields: `{json.dumps(step['test_execution'])}`. Complete log: `routine-candidate/{step['log']}`.")
    for item in failure_headers:
        lines.append('- ' + item)
    for item in skips:
        lines.append('- ' + item)
    if not footer_present:
        lines += ['', 'The unit log has no final `Ran ... tests` footer. The driver therefore records `tests_run=0` because it cannot parse a completed-suite total; this does **not** mean no tests executed. `PARTIAL-UNIT-LOG-ACCOUNTING.json` records two precisely defined progress-line parsers and the retained log hash. Neither progress-line count is a completed method count. No predicted missing-dependency skips are counted as actual skips.']
    lines += ['', 'The driver documentation check reports 21 missing local links to five files: `CHATGPT-START-HERE.md`, `ROLE.md`, and the `ontokin-session`, `ontokin-delivery` and `ontokin-learning` skill files. All five exist in the complete candidate checkout but are absent from the driver copy; its copy lists omit the two root files and `.agents`. The same checker passed in the complete candidate during the affected cohort. `DOCUMENTS-FAILURE-INSPECTION.json` preserves the exact failures and file/copy identities. The driver is unchanged from the observed main baseline, but that static equality is not a baseline execution or a waiver.']
    lines += ['', 'The available environment is CPython 3.12.14 / Linux x86-64. Pillow is 13.0.0. The installed rpds-py is 2026.6.3, while the lock names 2026.5.1. Historical absolute readback dependency and host-inventory paths are absent. No packages, pins, source, contracts, fixtures, expected results or hardcoded paths were changed.', '',
              'A failure in the required routine gate prevents integration acceptance. The full observer cohort passing does not waive that gate. Pending external conformance cases retain their original status; this run establishes no complete release, other-Python compatibility, native/model trial or comparative claim.', '',
              '## Evidence and process closure', '',
              'The original routine execution is session 40272; affected execution is session 52200. `ACTIVE-OPERATIONS.json` records positively observed completion. `execution-receipts/` contains exact commands, timing, environment, source identities, stdout, stderr and return codes. `RUN-RESULTS.json` includes individual report inspection and verified evidence hashes. The C271 control was not replayed.', '',
              f"`WORKSPACE-RECOVERY-DELTA.json` records {len(delta)} new or modified non-Git workspace files and {len(removed)} missing original files. Any unique bytes are preserved in `workspace-recovery/`. Copied clean source and reconstructed `.git` are excluded from the ZIP, with exact source/input manifests retained. No original outputs were deleted.", '',
              'The verified archive identity and extraction audit are external in `RAW-EVIDENCE-VERIFICATION.json`; `RESULTS.json` adds that receipt to the immutable run summary. No integration, publication or final Library delivery was performed by this worker.', '',
              'Next action: Director preserves the complete evidence and delivers the phase handoff. Unmet acceptance requires retained branch/issue and a separately selected next phase; this worker performs no repair or automatic retry.', '']
    (ROOT / 'REPORT.md').write_text('\n'.join(lines))
    exclusions = {'candidate-checkout', 'routine-candidate/workspace', 'archive-verification-extract'}
    external = {'RAW-EVIDENCE.zip', 'RAW-EVIDENCE-MANIFEST.json', 'RAW-EVIDENCE-VERIFICATION.json', 'RESULTS.json'}
    payload = []
    for parent, dirs, files in os.walk(ROOT):
        rel_parent = Path(parent).relative_to(ROOT).as_posix()
        dirs[:] = sorted(d for d in dirs if (Path(parent) / d).relative_to(ROOT).as_posix() not in exclusions)
        for name in sorted(files):
            path = Path(parent) / name
            if path.relative_to(ROOT).as_posix() in external:
                continue
            if path.is_symlink():
                raise RuntimeError('Evidence symbolic link not permitted: ' + str(path))
            payload.append(ident(path))
    manifest = {'schema': 'ontokin.c271.p02-raw-evidence-manifest/1', 'source_revision': EXPECTED,
                'file_count': len(payload), 'payload_bytes': sum(r['bytes'] for r in payload), 'files': payload,
                'exclusions': workspace_delta['excluded'], 'external_receipts': ['RAW-EVIDENCE-VERIFICATION.json', 'RESULTS.json'],
                'manifest_self_excluded_from_hash_listing': True}
    save(ROOT / 'RAW-EVIDENCE-MANIFEST.json', manifest)
    archive = ROOT / 'RAW-EVIDENCE.zip'
    with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for row in payload:
            z.write(ROOT / row['path'], row['path'])
        z.write(ROOT / 'RAW-EVIDENCE-MANIFEST.json', 'RAW-EVIDENCE-MANIFEST.json')
    target = ROOT / 'archive-verification-extract'
    target.mkdir(exist_ok=False)
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
        expected_names = [r['path'] for r in payload] + ['RAW-EVIDENCE-MANIFEST.json']
        if len(set(names)) != len(names) or set(names) != set(expected_names):
            raise RuntimeError('Archive duplicate/inventory mismatch')
        if any(Path(name).is_absolute() or '..' in Path(name).parts for name in names):
            raise RuntimeError('Unsafe archive path')
        if z.testzip() is not None:
            raise RuntimeError('Archive CRC failure')
        z.extractall(target)
    for row in payload:
        confirm(target / row['path'], row)
    if (target / 'RAW-EVIDENCE-MANIFEST.json').read_bytes() != (ROOT / 'RAW-EVIDENCE-MANIFEST.json').read_bytes():
        raise RuntimeError('Extracted manifest differs')
    archive_receipt = {'schema': 'ontokin.c271.p02-raw-evidence-verification/1', 'verified_at': now(),
                       'status': 'passed', 'archive': ident(archive), 'manifest': ident(ROOT / 'RAW-EVIDENCE-MANIFEST.json'),
                       'payload_files_verified': len(payload), 'archive_entries': len(expected_names),
                       'fresh_extraction': str(target), 'safe_relative_paths': True, 'no_duplicates': True,
                       'exact_inventory': True, 'crc_passed': True, 'every_payload_size_sha256_verified': True,
                       'original_outputs_deleted': False, 'source_recovery': workspace_delta}
    save(ROOT / 'RAW-EVIDENCE-VERIFICATION.json', archive_receipt)
    save(ROOT / 'RESULTS.json', dict(summary, raw_evidence_archive=archive_receipt['archive'],
                                  raw_evidence_verification=ident(ROOT / 'RAW-EVIDENCE-VERIFICATION.json')))
    print(json.dumps({'routine': routine['status'], 'affected': summary['affected']['status'],
                      'integration_eligible': summary['integration_eligible'], 'archive': archive_receipt['archive'],
                      'payload_files': len(payload), 'workspace_unique_files': len(delta), 'active_processes': []}, indent=2))


if __name__ == '__main__':
    main()
