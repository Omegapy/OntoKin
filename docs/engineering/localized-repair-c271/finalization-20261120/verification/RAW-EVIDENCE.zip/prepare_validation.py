#!/usr/bin/env python3
"""Record read-only C271 validation preparation; do not execute project tests."""
from __future__ import annotations

import ast
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess
import sys

REPO = Path('/workspace/scratch/c219bb61a617/OntoKin')
OUT = Path('/workspace/scratch/c219bb61a617/validation/preparation')
BASE = 'e1a48f7d0635e9aa4f4b6d6a586e7305eb81999d'
CANDIDATE = '88bc8b51b3963b7072375edac6400b6e6a4532e4'
OUT.mkdir(parents=True, exist_ok=True)


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=REPO)


def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n')


def blob(path, sha=CANDIDATE):
    return git('show', sha + ':' + path)


def identity(path, sha=CANDIDATE):
    raw = blob(path, sha)
    return {'path': path, 'commit': sha, 'git_blob': git('rev-parse', sha + ':' + path).decode().strip(),
            'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


governing = [
    'AGENTS.md', 'GOAL.md', 'ROLE.md', 'docs/workflow/PROTOCOL.md',
    'docs/workflow/HANDOFF.md', '.agents/skills/ontokin-delivery/SKILL.md',
    'docs/engineering/OK-ENG-006-local-validation-and-hosted-ci-policy.md',
    'docs/engineering/OK-ENG-009-development-integration-and-branch-lifecycle.md',
    'docs/workflow/templates/WORKER.md',
]
candidate_reads = [
    'docs/workflow/tasks/C271/task.json', 'docs/workflow/tasks/C271/REQUIREMENTS.md',
    'docs/workflow/tasks/C271/PLAN.md', 'tools/check_local.py',
    'docs/engineering/localized-repair-c268/evidence/run_checks.py',
    'tools/native-reader-verification-linux-cp312.lock', 'tools/check_native_reader_setup.py',
    'tools/force-agent-verification-requirements.txt', 'tools/storage_identity.py',
    'pyproject.toml', 'tests/test_static_tray_readback_v01.py', '.gitattributes',
]
readset = [dict(identity(p, BASE), inspection='full text read') for p in governing]
readset += [dict(identity(p), inspection='full text read') for p in candidate_reads]
for path in ['tests/test_force_agent_delivery_verification.py', 'tests/test_force_agent_verification.py', 'tests/test_reach_agent_verification.py']:
    readset.append(dict(identity(path), inspection='HAS_SCHEMA and skip predicate excerpts read'))
save('READ-SET.json', {'worker': '/root/validation', 'recorded_at': datetime.now(timezone.utc).isoformat(),
                     'applicable_instruction_revision': BASE, 'preparation_candidate': CANDIDATE,
                     'phase_authority': 'Director assigned C271 P02; historical P01 current-chat constraint superseded',
                     'reads': readset, 'tests_executed': False})

tree = []
for raw in git('ls-tree', '-r', '-z', '--long', CANDIDATE).split(b'\0'):
    if not raw:
        continue
    info, name = raw.split(b'\t', 1)
    mode, kind, oid, size = info.decode().split()
    tree.append({'path': name.decode(), 'mode': mode, 'kind': kind, 'git_blob': oid, 'bytes': int(size)})
save('CANDIDATE-GIT-MANIFEST.json', {'commit': CANDIDATE, 'tree': git('rev-parse', CANDIDATE+'^{tree}').decode().strip(),
                                 'basis': 'Git blob identities for complete committed tree; not a claim that every file was read',
                                 'file_count': len(tree), 'files': tree})
(OUT / 'CHANGED-FILES.txt').write_bytes(git('diff', '--name-status', BASE, CANDIDATE))

suites = [(255, 'oracle', 31), (256, 'reader', 29), (257, 'ownership', 23),
          (258, 'follows', 28), (261, 'hinge_glb', 28), (265, 'source_hinges', 49),
          (266, 'hinge_binding', 34), (267, 'hinge_compare', 25), (268, 'endpoint_reader', 35)]
cohort = []
for number, name, expected in suites:
    path = f'docs/engineering/localized-repair-c{number}/test_{name}.py'
    raw = blob(path)
    module = ast.parse(raw)
    methods = []
    for cls in [n for n in ast.walk(module) if isinstance(n, ast.ClassDef)]:
        methods += [f'{cls.name}.{n.name}' for n in cls.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef)) and n.name.startswith('test_')]
    imports = sorted({(n.module or '') if isinstance(n, ast.ImportFrom) else a.name
                      for n in ast.walk(module) if isinstance(n, (ast.Import, ast.ImportFrom))
                      for a in (n.names if isinstance(n, ast.Import) else [None])})
    cohort.append({**identity(path), 'required_methods': expected, 'static_test_def_count': len(methods),
                   'static_test_definitions': methods, 'static_imports': imports})
save('AFFECTED-COHORT-INVENTORY.json', {'candidate': CANDIDATE, 'required_method_total': sum(x[2] for x in suites),
                                     'checks': 12, 'suites': cohort,
                                     'other_checks': ['C253 manifest identity: 14 files / 3 tasks', 'workflow structure', 'documentation preservation and links'],
                                     'zero_skip_requirement': True,
                                     'limit': 'Static inventory only; actual execution and dynamic method totals remain unrun'})

selected = {x['path'] for x in tree if x['path'].split('/')[0] in ['ontokin', 'tests', 'tools', 'prototypes', 'fixtures', 'schemas', 'packaging', '.github']}
for row in tree:
    path = row['path']
    if re.match(r'docs/engineering/localized-repair-c(?:253|255|256|257|258|260|261|265|266|267|268)/[^/]+\.(?:py|json|md)$', path):
        selected.add(path)
    if path.startswith('docs/engineering/localized-repair-c271/control/') or path == 'docs/engineering/localized-repair-c271/run_h22_control.py':
        selected.add(path)
for row in json.loads(blob('docs/engineering/localized-repair-c253/corpus.json'))['files'].values():
    selected.add(row['path'])
for row in json.loads(blob('docs/engineering/localized-repair-c260/INPUTS.json'))['files']:
    selected.add(row['path'])
selected.update(['pyproject.toml', '.gitattributes', '.lfsconfig'])
selected_records = [r for r in tree if r['path'] in selected]
save('REUSE-INPUT-GIT-MANIFEST.json', {'candidate': CANDIDATE, 'scope': 'Runtime/tests/tools/prototypes/fixtures/schemas/packaging/workflows, observer code/contracts/corpus, C271 runner and controls',
                                     'files': selected_records, 'file_count': len(selected_records),
                                     'reuse_rule': 'Compare every later changed path and these Git blob identities; documentation/workflow metadata changes still require fresh record checks. Driver source-before/source-after inventories will add executed-input hashes.'})

pins = []
for line in blob('tools/native-reader-verification-linux-cp312.lock').decode().splitlines():
    match = re.match(r'([A-Za-z0-9_-]+)==([^ ]+) --hash=sha256:([a-f0-9]+)', line)
    if match:
        name, expected, wheel_hash = match.groups()
        try:
            actual = metadata.version(name)
        except metadata.PackageNotFoundError:
            actual = None
        pins.append({'package': name, 'expected': expected, 'installed': actual, 'version_matches': expected == actual, 'wheel_sha256': wheel_hash})
native_paths = ['/workspace/scratch/801d9d641f68/incoming-audit/work/prior-replay/evidence/c195-validation/receiving',
                '/workspace/scratch/801d9d641f68/c199-independent-preflight/HOST-RUNTIME-INVENTORY.json']
binary = Path(sys.executable).resolve()
environment = {'python': sys.version, 'implementation': platform.python_implementation(), 'executable': sys.executable,
               'resolved_executable': str(binary), 'executable_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
               'platform': platform.platform(), 'uname': list(platform.uname()),
               'runtime_bundle': os.environ.get('CODEX_PRIMARY_RUNTIME_BUNDLE_VERSION'), 'packages': pins,
               'node': subprocess.check_output(['node', '--version']).decode().strip(),
               'git_lfs': subprocess.check_output(['git-lfs', 'version']).decode().strip(),
               'missing_historical_readback_inputs': [p for p in native_paths if not Path(p).exists()],
               'wheel_cache_scan': {'roots': ['/tmp','/workspace','/opt/codex/runtimes','/root/.cache/pip','/home/agent/.cache/pip'],
                                    'matching_whl_files_found': [], 'scope': 'Seven locked Python package wheel names; no installation or download attempted'},
               'lfs_archive_tree_paths': [r['path'] for r in tree if r['path'].startswith('docs/engineering/lfs-archives/')],
               'free_disk_bytes': shutil.disk_usage(OUT).free}
save('ENVIRONMENT.json', environment)

routine = [
    ['unit-tests', '-m unittest discover -s tests -v'],
    ['source', '-m ontokin conformance --output REPORT'],
    ['agent', 'tools/run_agent_conformance.py --output REPORT'],
    ['construction', '-m tools.verify_construction_ci --external-evidence docs/engineering/construction-validation/external-gate.json --output REPORT'],
    ['surface', 'tools/run_surface_conformance.py --allow-pending --output REPORT'],
    ['impulse', 'tools/run_impulse_conformance.py --allow-pending --output REPORT'],
    ['documents', 'docs/maintenance/reorganization-2026-10-17/verify_reorganization.py'],
]
save('PLANNED-COMMANDS.json', {'status': 'not_run', 'candidate': 'Await Director-assigned clean worktree and candidate SHA',
                             'prerequisite': 'Director confirms verified early recovery save before any driver/test execution or environment preparation',
                             'commands': [
                                 'PYTHON -I -B tools/check_native_reader_setup.py',
                                 'PYTHON -B tools/check_local.py --output-dir /workspace/scratch/c219bb61a617/validation/routine-candidate --timeout 900',
                                 'PYTHON -B docs/engineering/localized-repair-c268/evidence/run_checks.py --repo IDENTIFIED_REPO --phase C271-P02-integration --output /workspace/scratch/c219bb61a617/validation/affected-candidate --c268-methods 35'],
                             'routine_steps': routine, 'routine_step_count': len(routine),
                             'routine_timeout_seconds_per_command': 900, 'cohort_timeout_seconds_per_command': 300,
                             'no_optional_roles': ['--full', '--force-agent'],
                             'known_gates': ['Three ReadbackCPUControls methods will skip with currently absent historical dependency paths; routine driver rejects skipped tests.',
                                            'rpds-py version differs from lock. No cached wheels found. Clean pinned environment preparation needs bounded authorized source availability.',
                                            'git-lfs 3.6.1 is below conditional storage requirement 3.8.1; current tree has no lfs-archives entries, so that path is not currently selected.'],
                             'nonclaims': ['No tests run', 'No installation', 'No runtime/source/contract/oracle/pin changes', 'No hosted workflow', 'No release or compatibility claim', 'No integration/publication']})
print(json.dumps({'output': str(OUT), 'read_files': len(readset), 'tree_files': len(tree),
                  'reuse_input_files': len(selected_records), 'cohort_methods': sum(x[2] for x in suites),
                  'cohort_static_methods': sum(len(x['static_test_definitions']) for x in cohort),
                  'lfs_archive_files': len(environment['lfs_archive_tree_paths']), 'tests_run': False}, indent=2))
