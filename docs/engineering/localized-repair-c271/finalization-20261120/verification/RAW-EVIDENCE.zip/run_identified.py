#!/usr/bin/env python3
"""Execute one authorized unchanged validation entrypoint with durable receipts."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from importlib import metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

BASE = Path('/workspace/scratch/c219bb61a617/validation')
REPO = BASE / 'candidate-checkout'
EXPECTED = '88bc8b51b3963b7072375edac6400b6e6a4532e4'


def now():
    return datetime.now(timezone.utc).isoformat()


def ident(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def state():
    def git(*args):
        return subprocess.check_output(['git', '--no-optional-locks', *args], cwd=REPO, text=True).strip()
    return {'commit': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'tracked_dirty_status': git('status', '--porcelain', '--untracked-files=no'),
            'all_dirty_status': git('status', '--porcelain'),
            'shallow_checkout': git('rev-parse', '--is-shallow-repository') == 'true'}


def environment():
    versions = {}
    for name in ['attrs', 'jsonschema', 'jsonschema-specifications', 'referencing', 'rpds-py', 'typing_extensions', 'Pillow']:
        try:
            versions[name] = metadata.version(name)
        except metadata.PackageNotFoundError:
            versions[name] = None
    return {'python': sys.version, 'version_info': list(sys.version_info), 'implementation': platform.python_implementation(),
            'executable': sys.executable, 'resolved_executable': ident(Path(sys.executable).resolve()),
            'platform': platform.platform(), 'uname': list(platform.uname()), 'packages': versions,
            'runtime_bundle_version': os.environ.get('CODEX_PRIMARY_RUNTIME_BUNDLE_VERSION'),
            'overrides': {'PYTHONDONTWRITEBYTECODE': '1', 'GIT_OPTIONAL_LOCKS': '0'}}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('role', choices=['routine', 'affected'])
    args = parser.parse_args()
    role = args.role
    evidence = BASE / 'execution-receipts' / (role + '-candidate')
    evidence.mkdir(parents=True, exist_ok=False)
    output = BASE / (role + '-candidate')
    if output.exists():
        raise RuntimeError('Fresh output required: ' + str(output))
    path = 'tools/check_local.py' if role == 'routine' else 'docs/engineering/localized-repair-c268/evidence/run_checks.py'
    command = ([sys.executable, '-B', path, '--output-dir', str(output), '--timeout', '900'] if role == 'routine' else
               [sys.executable, '-B', path, '--repo', str(REPO), '--phase', 'C271-P02-integration', '--output', str(output), '--c268-methods', '35'])
    source = state()
    if source['commit'] != EXPECTED or source['all_dirty_status']:
        raise RuntimeError('Candidate identity or clean-source precondition failed: ' + json.dumps(source))
    receipt = {'schema': 'ontokin.c271.p02-validation-execution/1', 'worker': '/root/validation',
               'phase': 'C271-P02-integration-finalization', 'role': role,
               'created_at': now(), 'status': 'prepared', 'source_before': source,
               'cwd': str(REPO), 'argv': command, 'output': str(output),
               'entrypoint': ident(REPO / path), 'wrapper': ident(Path(__file__).resolve()),
               'early_recovery': json.loads((BASE / 'PREEXECUTION-IDENTITY.json').read_text())['early_receipt'],
               'environment': environment(), 'optional_roles': [],
               'known_environment_limits': ['rpds-py 2026.6.3 differs from lock 2026.5.1; no pin or dependency changed',
                                            'Three ReadbackCPUControls tests require historical absolute inputs absent in this workspace'],
               'scope_limit': 'Executed available-environment evidence; any failed or skipped obligation prevents acceptance; no release/compatibility/hosted CI claim',
               'stdout': str(evidence / 'stdout.log'), 'stderr': str(evidence / 'stderr.log'),
               'returncode': None}
    report = evidence / 'EXECUTION.json'
    def save():
        report.write_text(json.dumps(receipt, indent=2) + '\n')
    save()
    started = time.monotonic()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', GIT_OPTIONAL_LOCKS='0')
    with (evidence / 'stdout.log').open('xb') as stdout, (evidence / 'stderr.log').open('xb') as stderr:
        try:
            process = subprocess.Popen(command, cwd=REPO, env=env, stdout=stdout, stderr=stderr)
            receipt.update(status='running', started_at=now(), pid=process.pid)
            save()
            print(json.dumps({'role': role, 'pid': process.pid, 'receipt': str(report), 'status': 'running'}), flush=True)
            receipt['returncode'] = process.wait()
            receipt['status'] = 'passed' if process.returncode == 0 else 'failed'
        except BaseException as error:
            receipt.update(status='interrupted' if isinstance(error, KeyboardInterrupt) else 'error', error=f'{type(error).__name__}: {error}')
            save()
            raise
        finally:
            receipt.update(finished_at=now(), duration_seconds=round(time.monotonic()-started, 6), source_after=state())
            receipt['source_unchanged'] = receipt['source_after'] == source
            save()
    receipt['stdout_identity'] = ident(evidence / 'stdout.log')
    receipt['stderr_identity'] = ident(evidence / 'stderr.log')
    save()
    print(json.dumps({'role': role, 'status': receipt['status'], 'returncode': receipt['returncode'], 'seconds': receipt['duration_seconds'],
                      'source_unchanged': receipt['source_unchanged'], 'receipt': str(report)}), flush=True)
    return receipt['returncode'] if receipt['returncode'] is not None else 1


if __name__ == '__main__':
    raise SystemExit(main())
