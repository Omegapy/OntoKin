"""Independently inspect a documentary candidate without modifying the repository."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
REPO = ROOT / "repository"
BASE = "360c80062e769230199602326fa8de25660df714"
PREFIX = "docs/engineering/localized-repair-c271/p28-recovery-20261123/"
CANONICAL = ["docs/workflow/CURRENT.json", "docs/workflow/tasks/C271/task.json", "docs/workflow/tasks/C271/REQUIREMENTS.md", "docs/workflow/tasks/C271/PLAN.md"]
checks = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def check(name, passed, detail=None):
    checks.append({"name":name, "passed":bool(passed), "detail":detail})

def git(*args):
    result = subprocess.run(["git", *args], cwd=REPO, capture_output=True)
    if result.returncode:
        raise RuntimeError(result.stderr.decode())
    return result.stdout

def read(path):
    return json.loads(Path(path).read_bytes())

head = git("rev-parse", "HEAD").decode().strip()
check("base HEAD unchanged", head == BASE)
modified = git("diff", "--name-only", BASE).decode().splitlines()
new_paths = [str(p.relative_to(REPO)) for p in (REPO / PREFIX).rglob("*") if p.is_file()]
paths = sorted(set(modified + new_paths))
check("all modified tracked paths are in declared scope", all(p in CANONICAL or p.startswith(PREFIX) for p in modified), modified)
check("all four canonical records are present", all(p in paths for p in CANONICAL))
untracked = git("ls-files", "--others", "--exclude-standard").decode().splitlines()
check("no untracked source outside documentary scope", all(p.startswith(PREFIX) for p in untracked))
payload = {p: (REPO / p).read_bytes() for p in paths}
check("all candidate files regular and not symlinks", all((REPO / p).is_file() and not (REPO / p).is_symlink() for p in paths))
manifest = [{"path":p, "bytes":len(payload[p]), "sha256":sha(payload[p]), "mode":oct((REPO/p).stat().st_mode & 0o777)} for p in paths]
manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
(OUT / "MANIFEST.json").write_bytes(manifest_bytes)
(OUT / "DIFF.patch").write_bytes(git("diff", "--binary", BASE))

old_task = json.loads(git("show", BASE + ":docs/workflow/tasks/C271/task.json"))
task = json.loads(payload["docs/workflow/tasks/C271/task.json"])
old_current = json.loads(git("show", BASE + ":docs/workflow/CURRENT.json"))
current = json.loads(payload["docs/workflow/CURRENT.json"])
for title, old, new, snapshot_key in [
  ("task",old_task,task,"p28_recovery_previous_p27_source_fields"),
  ("CURRENT",old_current,current,"p28_recovery_previous_source_fields")]:
    changed = [k for k in old if new.get(k) != old[k]]
    check(title + " original keys retained", set(old) <= set(new))
    check(title + " replaced fields exactly preserved", all(new[snapshot_key].get(k) == old[k] for k in changed), changed)
    check(title + " snapshots preserve exact source values", all(k in old and v == old[k] for k,v in new[snapshot_key].items()))
for p in CANONICAL[-2:]:
    before = git("show", BASE + ":" + p)
    check(p + " complete original bytes retained as prefix", payload[p].startswith(before))
    check(p + " only one recovery section appended", payload[p][len(before):].decode().count("## P28 interruption recovery") == 1)
check("requirement acceptance and evidence arrays unchanged", task["requirements"] == old_task["requirements"])
check("parent plan unchanged", task["plan"] == old_task["plan"])
check("recorded historical checks unchanged", task["checks"] == old_task["checks"] and task["historical_checks"] == old_task["historical_checks"])
check("blocked parent and active task retained", task["status"] == "blocked" and current["active_task"] == "C271")
check("all predecessor phase/delivery/reconciliation history unchanged", all(task[k] == old_task[k] for k in ["prior_session_phases", "prior_phase_deliveries", "phase_reconciliations", "remaining_h0_constraint", "prior_h0_constraints", "blocked_reason_history"]))
outcome = json.loads(payload[PREFIX + "OUTCOME.json"])
rec = json.loads(payload[PREFIX + "RECONCILIATION.json"])
check("task session exactly equals outcome", task["session_phase"] == outcome)
check("recovery owner exact and consistent", outcome["owner"] == task["owner"] == "c271-p28-recovery-acb73444303d")
check("prior-worker liveness remains unknown", outcome["ownership"]["prior_worker_liveness"] == rec["ownership"]["prior_worker_liveness"] == "unknown")
check("unknown immutable uploads retained consistently", outcome["unknown_operations"] == rec["unknown_operations"] and outcome["unknown_operations"][0]["resulting_tree_sha"] is None and outcome["unknown_operations"][0]["resulting_commit_sha"] is None)
check("no original upload replay claimed", outcome["ownership"]["original_upload_replay"] is False)
check("technical acceptance and final delivery remain pending", outcome["phase_complete"] is False and outcome["parent_complete"] is False and task["delivery"]["phase_complete"] is False and current["pending_phase_delivery"]["parent_complete"] is False)
check("first unmet gate is exact candidate/evidence recovery", outcome["first_unmet_gate"] == "recover_exact_p28_candidate_and_evidence")
check("prior reported passes explicitly unverified", outcome["reported_but_not_reverified"] == rec["reported_unverified"] and "597/597 tests" in outcome["reported_but_not_reverified"])
check("no product tests/runtime changes claimed for recovery", outcome["product_tests_executed_this_recovery"] == outcome["runtime_changes_this_recovery"] == 0)
check("main integration remains excluded", outcome["main_lease_held"] is False and "Main integration" in outcome["exclusions"])

comments = []
for n in ["ownership273", "ownership274"]:
    comments.append(json.loads(read(ROOT / f"records/live/{n}.json")["structuredContent"]["content"]))
check("recovery ownership comments exact", comments[0]["body"] == comments[1]["body"])
check("recovery ownership comment identities exact", {c["id"] for c in comments} == {7113671306,7113671773})
check("recovery comments preserve authority and unknown liveness", all(s in comments[0]["body"] for s in ["owner's fresh recovery request", "c271-p28-recovery-acb73444303d", "Previous worker liveness is unknown", "no upload is replayed"]))

receipt = json.loads(payload[PREFIX + "EARLY-RECOVERY-RECEIPT.json"])
check("early receipt exactly copied", receipt == read(ROOT / "records/EARLY-RECOVERY-RECEIPT.json"))
for key in ["file", "readback_path"]:
    p = Path(receipt[key])
    check("early " + key + " remains in current workspace", p.is_relative_to(ROOT))
    data = p.read_bytes()
    check("early " + key + " size/hash exact", len(data) == receipt["bytes"] and sha(data) == receipt["sha256"])
    check("early " + key + " stable ID/version exact", os.getxattr(p,"user.library-file-id").decode() == receipt["library_file_id"] and os.getxattr(p,"user.library-file-version").decode() == str(receipt["current_version_number"]))
check("early confirmed before repository edits", receipt["early_confirmed_before_repository_edits"] is True)

with zipfile.ZipFile(REPO / PREFIX / "OBSERVATIONS.zip") as z:
    names = z.namelist()
    check("raw observation archive CRC/inventory safe", z.testzip() is None and len(names) == len(set(names)) and all(not PurePosixPath(n).is_absolute() and ".." not in PurePosixPath(n).parts for n in names), len(names))
    for n in names:
        check("archived raw observation exact " + n, z.read(n) == (ROOT / "records" / n).read_bytes())
for name in ["archive-audit", "state-audit"]:
    for suffix in ["REPORT.md","AUDIT.json","audit.py"]:
        check("retained independent review exact " + name + "/" + suffix, payload[PREFIX + "reviews/" + name + "/" + suffix] == (ROOT / "reviews" / name / suffix).read_bytes())

execution = read(ROOT / "checks/candidate/CHECKS.json")
check("executed documentary checks bound to source", execution["source_base"] == BASE and execution["product_tests_run"] == 0)
for row in execution["checks"]:
    check("recorded check passed " + row["name"], row["exit_code"] == 0)
    for stream in ["stdout","stderr"]:
        name = row["name"] + "." + stream + ".log"
        b = (ROOT / "checks/candidate" / name).read_bytes()
        check("check log hash and repository copy exact " + name, sha(b) == row[stream + "_sha256"] and payload[PREFIX + "checks/" + name] == b)
check("check result copied exactly", payload[PREFIX + "checks/CHECKS.json"] == (ROOT / "checks/candidate/CHECKS.json").read_bytes())
doc = read(ROOT / "checks/candidate/documentation.json")
check("documentation verification has no failure", doc["status"] == "passed" and doc["failures"] == [] and doc["sources_verified"] == 29)

ignored = subprocess.run(["git", "check-ignore", "--stdin"], cwd=REPO, input=("\n".join(paths)+"\n").encode(), capture_output=True)
ignored_paths = ignored.stdout.decode().splitlines()
check("all payload files remained stable during audit", all((REPO/p).read_bytes() == b for p,b in payload.items()))
result = {
 "schema":"ontokin.c271.p28-documentary-candidate-review/1", "reviewer":"/root/state_audit",
 "observed_at_utc":datetime.now(timezone.utc).isoformat(), "base_commit":BASE,
 "accepted":all(x["passed"] for x in checks), "candidate_manifest":"MANIFEST.json",
 "candidate_manifest_sha256":sha(manifest_bytes), "candidate_files":len(paths),
 "tracked_files_changed":modified, "checks":checks,
 "documentary_execution":{"workflow_tasks":12,"documentation_sources":doc["sources_verified"],"documents":doc["links"]["documents"],"local_links":doc["links"]["local_links"],"all_three_commands_exit_zero":all(x["exit_code"] == 0 for x in execution["checks"])},
 "mandatory_findings":[],
 "publication_preconditions":[
   "Fresh expected-head/ownership reconciliation and conditional nonforce descendant publication, then exact commit/tree and payload readback.",
   "Include all manifest entries when staging, including ignored raw log files explicitly listed below. A normal git add omits these files.",
   "Evidence/report incorporation after this manifest must be reviewed as an explicit delta; this acceptance does not preapprove unknown future file content.",
   "No missing P28 implementation/test acceptance, completed original upload, final save, parent completion or prior-worker termination follows from this documentary approval."
 ],
 "ignored_payload_paths_requiring_explicit_staging":ignored_paths,
 "limitations":["No product execution, GitHub/Library mutation, previous-host access or repository writes by this worker.","Workflow/documentation execution was performed by the Director; this reviewer verified raw output hashes, exit statuses and exact retained copies.","Complete semantic JSON changes and append-only Markdown differences were inspected; DIFF.patch retains full tracked textual diff."]
}
(OUT / "REVIEW.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"accepted":result["accepted"],"checks":len(checks),"candidate_files":len(paths),"manifest_sha256":result["candidate_manifest_sha256"],"ignored_payloads":ignored_paths,"failures":[x for x in checks if not x["passed"]]}))
