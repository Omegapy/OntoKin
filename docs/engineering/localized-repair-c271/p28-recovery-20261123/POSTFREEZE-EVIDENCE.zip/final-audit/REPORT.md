# P28 recovery final archive audit

**Accepted: 659 checks passed; zero findings.** Reviewer: `/root/archive_audit`.

The frozen `OntoKin_C271_P28_Recovery_Handoff_2026-11-23.zip` is 9,054,965 bytes, SHA-256 `00432c32fc71530cf060ba901330ef38018301363bb2ef378591af540b04ee85`. It contains 87 members, including 86 manifest payloads and 70 source bindings.

The audit verified ZIP integrity, safe unique paths, exact inventory, a fresh extraction, every payload size/hash, all 70 source contents/modes/blob identities against Git objects, and all required root files. The recovery source is `5f340b4f49d13638f3522e201a1e99b93a19358b`, tree `6a85465aa64ba44dbd13e54087191ec2efbf9e05`, with parent `360c80062e769230199602326fa8de25660df714`. Its changes are exactly the 27 reviewed documentary payload files; each matches the frozen staging manifest. Governing snapshots bind main `e43cc6c5777874101a40559e4058ad6826b07e51`.

The original P28 early ZIP is byte-identical to the verified input. Both detached prompts match their ZIP members. README, checkpoint, handoff, recovery status and next action consistently disclose that later P28 implementation bytes, test evidence and immutable upload identities remain unavailable. Prior reported passes are not promoted to verified results. The first unmet gate remains `P28-RECOVERY-BYTES-001`; parent C271, R03–R05, P02, H0/H1/full routine and main integration remain open or unmet. The ZIP explains that its own save, external receipt and recovery-owner release occur after its immutable freeze.

Two audit attempts stopped at local shallow-clone limitations: main was initially unfetched, and `A^` traversal was unavailable at a shallow boundary. Exact attempts/extractions and incident records remain in `attempt001/` and `attempt002/`. A Director-authorized exact-main fetch completed without changing HEAD or the working tree. The final audit used raw commit parent identity and an explicit base-to-source comparison. Neither incident indicated bad archive content or changed the archive.

This accepts the documentary recovery handoff only. It does not accept the missing original P28 candidate or recertify its reported tests. Actual final save/readback and terminal receipt verification remain later gates. No product tests or external mutations were performed.
