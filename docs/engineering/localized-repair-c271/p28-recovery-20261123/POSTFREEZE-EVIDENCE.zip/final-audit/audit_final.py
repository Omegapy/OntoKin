from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/acb73444303d')
OUT = ROOT/'reviews/final-audit'
ZIP = ROOT/'packages/final/OntoKin_C271_P28_Recovery_Handoff_2026-11-23.zip'
EXTRACTED = OUT/'fresh-extraction'
REPO = ROOT/'repository'
checks = []

def check(name, value, detail=None):
    checks.append({'check': name, 'passed': bool(value), 'detail': detail})

def ident(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

with zipfile.ZipFile(ZIP) as z:
    names = z.namelist()
    check('zip-crc', z.testzip() is None)
    check('unique-members', len(names) == len(set(names)))
    check('safe-paths', all(not n.startswith('/') and '..' not in PurePosixPath(n).parts and '\\' not in n for n in names))
    check('no-symlink-members', all(((e.external_attr >> 16) & 0o170000) != 0o120000 for e in z.infolist()))
    required = ['README-START-HERE.md', 'CHECKPOINT.json', 'HANDOFF.md', 'NEXT-TASK.md', 'RECOVERY-STATUS.md', 'PROMPT-1-CONTINUE.md', 'PROMPT-2-RECOVER.md', 'HISTORICAL-DEPENDENCIES.json', 'MANIFEST-SHA256.json', 'SOURCE-MANIFEST.json', 'HOST-ENVIRONMENT.md']
    check('required-root-files', set(required).issubset(names))
    manifest = json.loads(z.read('MANIFEST-SHA256.json'))
    source = json.loads(z.read('SOURCE-MANIFEST.json'))
    cp = json.loads(z.read('CHECKPOINT.json'))
    text = {n: z.read(n).decode() for n in required if n.endswith('.md')}
    check('exact-manifest-inventory', {e['path'] for e in manifest} == set(names) - {'MANIFEST-SHA256.json'})
    check('manifest-unique', len(manifest) == len({e['path'] for e in manifest}))
    check('fresh-extraction', not EXTRACTED.exists())
    if EXTRACTED.exists():
        raise RuntimeError('Preserve existing extraction: use a fresh audit directory for a new candidate')
    EXTRACTED.mkdir(parents=True)
    z.extractall(EXTRACTED)
    for e in manifest:
        b = (EXTRACTED/e['path']).read_bytes()
        check('payload/'+e['path'], ident(b) == {'bytes': e['bytes'], 'sha256': e['sha256']})
        check('zip-extraction/'+e['path'], b == z.read(e['path']))
    for e in source:
        b = (EXTRACTED/e['archive_path']).read_bytes()
        check('source-hash/'+e['archive_path'], ident(b) == {'bytes': e['bytes'], 'sha256': e['sha256']})
        check('source-git-bytes/'+e['archive_path'], b == git('show', e['commit']+':'+e['git_path']))
        entry = git('ls-tree', e['commit'], '--', e['git_path']).decode().split()
        check('source-git-mode/'+e['archive_path'], entry[0] == e['git_mode'])
        check('source-git-blob/'+e['archive_path'], entry[2] == e['git_blob'] == hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest())
        check('source-path/'+e['archive_path'], e['archive_path'] in ['repository/'+e['git_path'], 'governing-main/'+e['git_path']])
        expected_commit = cp['observed_main'] if e['archive_path'].startswith('governing-main/') else cp['source_commit']
        check('source-revision/'+e['archive_path'], e['commit'] == expected_commit)

source_commit = cp['source_commit']
source_tree = git('rev-parse', source_commit+'^{tree}').decode().strip()
intent = json.loads((ROOT/'records/PUBLICATION-INTENT.json').read_text())
staged = json.loads((ROOT/'records/STAGED-PAYLOAD.json').read_text())
changed = git('diff-tree', '--no-commit-id', '--name-only', '-r', intent['expected_head'], source_commit).decode().splitlines()
check('source-tree', source_tree == cp['source_tree'] == intent['expected_tree'])
parents = [line[7:] for line in git('cat-file', '-p', source_commit).decode().split('\n\n',1)[0].splitlines() if line.startswith('parent ')]
check('source-parent', parents == [intent['expected_head']])
check('exact-27-file-documentary-publication', set(changed) == {e['path'] for e in staged} and len(staged) == 27)
check('documentation-only-change', all(n.startswith('docs/') for n in changed))
for e in staged:
    b = git('show', source_commit+':'+e['path'])
    check('published-staged-file/'+e['path'], ident(b) == {'bytes': e['bytes'], 'sha256': e['sha256']})

oldname = 'OntoKin_C271_P28_Required_Images_Early_Recovery_2026-11-23.zip'
check('original-early-zip-byte-identical', (EXTRACTED/'predecessor'/oldname).read_bytes() == (ROOT/'incoming'/oldname).read_bytes())
hist = json.loads((EXTRACTED/'HISTORICAL-DEPENDENCIES.json').read_text())
record = hist['embedded_original_p28_early']
check('predecessor-identity', ident((EXTRACTED/'predecessor'/oldname).read_bytes()) == {'bytes':record['bytes'],'sha256':record['sha256']})
check('original-implementation-unverified', cp['original_p28_implementation_verified'] is False)
check('phase-and-parent-incomplete-at-freeze', cp['phase_complete'] is False and cp['parent_complete'] is False)
check('first-gate-named', cp['blocker'] == 'P28-RECOVERY-BYTES-001')
check('source-time-pending', 'pending' in cp['status'] and 'before its own actual save' in cp['delivery_state'])
check('next-action-missing-bytes', 'exact P28 uploaded tree SHA' in cp['next_action'])
check('requirements-open', cp['requirements'] == {'R01':'done','R02':'done','R03':'not_done','R04':'not_done','R05':'not_done'})
check('parent-plan-open', cp['parent_plan'] == {'P01':'done','P02':'in_progress'})
check('no-main-lease', cp['main_lease_held'] is False)
check('no-product-test-execution', cp['product_tests_executed_this_recovery'] == 0)
check('no-runtime-change', cp['runtime_changes_this_recovery'] == 0)
check('readme-discloses-unavailable-implementation', 'does not contain the unavailable later P28 implementation' in text['README-START-HERE.md'])
check('prior-results-not-accepted', 'unverified reports' in text['README-START-HERE.md'] and 'not accepted as verified recovery results' in text['HANDOFF.md'])
check('uploads-remain-unknown', 'uploads, with intended parent' in text['RECOVERY-STATUS.md'] and 'uploads failed' in text['HANDOFF.md'])
check('no-false-worker-termination', 'Prior worker liveness is unknown' in text['HANDOFF.md'])
for name in ['README-START-HERE.md','PROMPT-1-CONTINUE.md','PROMPT-2-RECOVER.md','HOST-ENVIRONMENT.md']:
    check('ephemeral-host/'+name, 'different disposable execution host' in text[name])
for n, word in [(1,'CONTINUE'),(2,'RECOVER')]:
    name=f'PROMPT-{n}-{word}.md'
    check('prompt-no-new-milestone/'+name, 'another milestone' in text[name])
    check('prompt-no-blind-replay/'+name, 'do not replay blindly' in text[name])
    check('prompt-tree-completeness/'+name, 'intermediate upload group' in text[name])
    detached=ROOT/'packages/final'/f'OntoKin_C271_P28_Prompt_{n}_{word.title()}_2026-11-23.md'
    check('matching-detached-prompt/'+name, detached.read_bytes() == (EXTRACTED/name).read_bytes())

report = {
    'schema':'ontokin.c271.p28-recovery-final-archive-audit/1',
    'reviewer':'/root/archive_audit',
    'observed_at_utc':datetime.now(timezone.utc).isoformat(),
    'verdict':'accepted' if all(e['passed'] for e in checks) else 'changes_required',
    'passed':all(e['passed'] for e in checks),
    'file_name':ZIP.name,
    **ident(ZIP.read_bytes()),
    'source_commit':source_commit,
    'source_tree':source_tree,
    'source_parent':intent['expected_head'],
    'observed_main':cp['observed_main'],
    'zip_members':len(names),
    'manifest_payloads':len(manifest),
    'source_bindings':len(source),
    'checks_passed':sum(e['passed'] for e in checks),
    'checks_failed':sum(not e['passed'] for e in checks),
    'findings':[e for e in checks if not e['passed']],
    'limits':['Audits the exact documentary recovery archive only, not unavailable P28 implementation or reported product tests','Git source identities verified against the current authenticated clone; live publication confirmation inspected separately from root records','Final Library save, external receipt and terminal release necessarily occur after this freeze and require later verification'],
    'checks':checks,
}
(OUT/'AUDIT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['checks']},indent=2))
