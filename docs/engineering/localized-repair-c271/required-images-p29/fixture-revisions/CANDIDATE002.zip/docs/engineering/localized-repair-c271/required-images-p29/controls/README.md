# Independent required-image controls

This is the P29 fixture candidate for all **116 obligations** in the unchanged,
adopted P27 `design/CONTROL-PLAN.json` (SHA-256
`55dc8e776253232e7eb23e51593754f9b69cf72e23732246424adb6ed58ba89f`).
It is new reconstruction, not recovery of the missing original P28 bytes or
verification of its historical 597-test claim.

## Frozen inputs and oracle

`CONTROL-CROSSWALK.json` maps each original ID to exactly one test method and
retains the complete literal P27 expected value, source-case hash, input route,
inert fixture identity or fully materialized logical context, and claim limit.
There are 47 synthetic ELF files and 56 logical contexts. The five unchanged
P27 package-image files are referenced by exact bytes and SHA-256; they remain
inert data and are never loaded as executable code.

`FIXTURE-MANIFEST.json` binds all local control payloads. Its hash is fixed in
the sole new test adapter, `tests/test_current_host_required_images_v01.py`.
`FREEZE.json` binds that adapter, the fixture manifest and all local payloads.
`COMPANIONS.json` pins the adopted design, package images, inherited adapters,
P16/P17 archives, P24 matrices and the Director's 372-method inherited cohort.
No existing test, fixture, oracle or production catalog pin is changed.

The adapter authenticates the complete payload and literal crosswalk before
selecting a test. Synthetic metadata variants cannot meet operational catalog
pins. `BASE-CONTEXT.json` and the contexts under `contexts/` stipulate inherited
source/runtime/host/origin/libc/RTLD/guard observations; their `/required-*`
paths are logical fixture names, not present-host resources. They do not prove
those prerequisite checks or host admission. The new relation constructor and
its `_bound` comparisons remain real. C01/C03 additionally route the new raw
metadata reader to the exact retained inert package bytes.

## Caller and lifecycle boundaries

C01 executes the actual validation and early resolution path, then stops at
the helper-import boundary. C02 obtains its refusal from the actual catalog
comparison. C03 runs two complete rechecks, each with early and final relation
construction. C04 changes one observed SHA only inside the actual constructor's
first `_bound` read. C06 applies that same fault in both actual postflight
rechecks after one pure fake process callback. `MOCK-COMMAND.json` freezes its
command, receipt, timestamp, raw streams, five complete publication payloads
and returned descriptors before execution. It verifies receipt/count retention,
not an OS process or durable publication.

Candidate 002 records every relevant later recheck stage, distinguishes
`_git_state` from the process-reading `_check_git`, and proves each failed
postflight enters only its early resolution. C05 runs the actual enclosing
command and actual launch check against a changed inert temporary file. Its
fake process boundary is counted and remains unentered; the initial preflight
is stipulated. `MOCK-PRELAUNCH.json` freezes the file bytes, three failure
publications and descriptors. These additions strengthen observation without
changing any adopted diagnostic or acceptance value. Candidate 001 remains
preserved at the identity in `REVISION.json`.

Named callback faults invoke the actual zero-argument callback through the
actual checkpoint helper. Descriptor opens, pread ranges and close attempts
are observed. A close fault closes the test-owned descriptor once before
raising the selected error, avoiding a leaked test resource or a retry that
would hide the product failure.
The relation callback control separately records zero descriptor-open calls,
no returned policy and a checkpoint sequence ending at the third subject.
The positive policy control compares every immutable descriptor with the
complete frozen coherent policy, as well as testing nested immutability.

RI-L07/L08 run the unchanged inherited corpora and reconcile exact method IDs.
The separate full inherited command authenticates the Director's cohort,
compares all 372 runtime IDs before running, and retains every result. Its one
unchanged inline Python environment-transport child is separate from Node,
ldd, direct-loader and CPU-checker targets. N34 and historical N57 remain
external review obligations; neither becomes a runtime pass or skip.

## Execution gate

The exact commands are in `COMMANDS.json`. Do not run product controls before
independent acceptance of this freeze. The fixture author executed only byte
construction, hashing and static syntax/inventory inspection. Product results
are **NOT_RUN** at freeze. Use new output directories for every execution and
retain failures. Any later fixture, adapter, command or oracle change needs a
new identified freeze and review; never adjust an expectation to fit output.

No result here closes H0/H1, the original seven/full routine, R03–R05 or C271.

