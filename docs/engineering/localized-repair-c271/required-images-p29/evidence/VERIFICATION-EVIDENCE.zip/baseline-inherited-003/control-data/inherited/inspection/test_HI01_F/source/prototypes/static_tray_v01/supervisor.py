synthetic source: prototypes/static_tray_v01/supervisor.py
