synthetic source: tools/check_local.py
