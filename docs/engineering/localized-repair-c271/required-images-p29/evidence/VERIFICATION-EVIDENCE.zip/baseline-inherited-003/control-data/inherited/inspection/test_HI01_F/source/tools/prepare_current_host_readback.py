synthetic source: tools/prepare_current_host_readback.py
