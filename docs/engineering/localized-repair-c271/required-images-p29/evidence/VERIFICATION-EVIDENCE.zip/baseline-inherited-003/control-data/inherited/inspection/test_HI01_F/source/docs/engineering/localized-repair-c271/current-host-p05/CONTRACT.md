synthetic source: docs/engineering/localized-repair-c271/current-host-p05/CONTRACT.md
