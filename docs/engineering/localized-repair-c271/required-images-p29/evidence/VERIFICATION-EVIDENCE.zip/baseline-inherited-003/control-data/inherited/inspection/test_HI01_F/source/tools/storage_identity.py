synthetic source: tools/storage_identity.py
