"""Author P13 documentary metadata; never import or execute product code."""
from pathlib import Path
import copy
import hashlib
import json
from zipfile import ZipFile

ROOT = Path('/workspace/scratch/82b6b514e749/repo')
BASE = ROOT / 'docs/engineering/localized-repair-c271'
P11 = BASE / 'loader-path-p11/design/candidate004'
OUT = BASE / 'review-boundary-p13/design/candidate001'
REV = 'ef127e60e461dd24d73a40d5fd5b7bfe1cde79fb'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def descriptor(path):
    raw = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(raw), 'sha256': digest(raw)}


def read(path):
    return json.loads(path.read_text())


def write(name, value):
    path = OUT / name
    with path.open('x') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


input_paths = {
    'E01': BASE / 'loader-path-p12/BLOCKER.json',
    'E02': BASE / 'loader-path-p12/evidence/implementation/N57-SURFACE-QUESTION.json',
    'E03': BASE / 'loader-path-p12/evidence/review/ADJUDICATION.json',
    'E04': P11 / 'DECISION.md',
    'E05': P11 / 'CONTROL-CONTRACT.md',
    'E06': P11 / 'FUTURE-SURFACE.json',
    'E07': P11 / 'EXPECTATIONS.json',
    'E08': P11 / 'FIXTURE-MANIFEST.json',
    'E09': P11 / 'CANDIDATE-MANIFEST.json',
    'E10': P11 / 'fixture_inputs/P01_nonselecting_base.json',
    'E11': P11 / 'fixture_inputs/N57_source_variant_unknown.json',
    'E12': ROOT / 'prototypes/static_tray_v01/current_host_inspection_v01.py',
    'E13': BASE / 'loader-path-p12/evidence/review/n57-adjudication/RATIONALE-SOURCE-EVIDENCE.json',
    'E14': P11 / 'SOURCES.json',
    'E15': P11 / 'PROTECTED-SOURCES.json',
    'E16': BASE / 'loader-path-p12/evidence/review/n57-adjudication/ADJUDICATION.json',
    'E17': BASE / 'loader-path-p12/evidence/review/n57-adjudication/OPERATIONAL-SCHEMA-PROJECTION.json',
    'E18': BASE / 'loader-path-p12/evidence/review/n57-adjudication/EXTERNAL-BINDING-OBSERVATIONS.json',
}
archive = Path('/workspace/scratch/82b6b514e749/deliverables/early-attempt002/OntoKin_C271_P13_Review_Policy_Early_Recovery_2026-11-21_Attempt002.zip')
with ZipFile(archive) as z:
    history = json.loads(z.read('HISTORICAL-DEPENDENCIES.json'))
external = copy.deepcopy(history['required_external_candidate_files'][0])
external['author_reverified_archive_member_bytes'] = False
external['verification_attribution'] = 'Director and independent early-recovery reviewers; author checks this descriptor against the unchanged P11 candidate manifest only.'

write('INPUTS.json', {
    'schema': 'ontokin.c271.p13-design-inputs/1',
    'source_revision': REV,
    'revision_observation': 'Local git rev-parse HEAD readback; no Git/index writes by author.',
    'original_p11_candidate': 'candidate004',
    'original_p11_root': str(P11.relative_to(ROOT)),
    'files': {key: descriptor(path) for key, path in input_paths.items()},
    'external_historical_payload': external,
    'external_identity_source': {
        'archive_name': archive.name,
        'archive_sha256': '05e38a85815bbd9026ce565237ebaf1586a48d479429834d15f85d1a0b8d58ca',
        'member': 'HISTORICAL-DEPENDENCIES.json',
    },
    'preservation_scope': {
        'original_cases': 97,
        'original_fixture_files': 131,
        'available_candidate_payloads': 145,
        'external_candidate_payloads': 1,
        'available_supporting_files': 29,
        'mode_claim': 'Historical mode records preserved byte-for-byte; checkout modes are not restored or claimed to equal materialized historical modes.',
    },
})

fixture = read(P11 / 'FIXTURE-MANIFEST.json')
expect = read(P11 / 'EXPECTATIONS.json')
rows = []
for case in sorted(fixture['cases'], key=lambda case: case['id']):
    case_id = case['id']
    ref = {'source': 'E07', 'json_pointer': '/cases/' + case['expected_key']}
    is_review = case_id == 'N57_source_variant_unknown'
    rows.append({
        'id': case_id,
        'original_route': case['route'],
        'original_input': case['input']['path'],
        'original_expected_key': case['expected_key'],
        'original_expectation': ref,
        'classification': 'independent_review_only' if is_review else 'future_runtime_primitive',
        'runtime_expectation': None if is_review else ref,
        'oracle_status': 'historical_runtime_oracle_not_executable_under_p13' if is_review else 'unchanged_future_runtime_obligation',
    })
write('CONTROL-MAPPING.json', {
    'schema': 'ontokin.c271.p13-control-mapping/1',
    'decision': 'ontokin.c271.review-runtime-boundary-decision/1',
    'state': 'proposed_pending_independent_review_and_director_adoption',
    'input_manifest': 'E08',
    'oracle': 'E07',
    'case_count': 97,
    'classification_counts': {'future_runtime_primitive': 96, 'independent_review_only': 1},
    'product_execution': 'not_run',
    'host_qualification': 'not_established',
    'n57_disposition': {
        'historical_oracle_unchanged': True,
        'historical_oracle_satisfied': False,
        'external_review_gate': 'DECISION.md section 3',
        'supplied_evidence_result': 'not_established_by_supplied_inputs',
        'runtime_expectation': None,
        'null_semantics': 'Mapping metadata only; never a runtime policy value or an admission signal.',
        'boundary_controls': ['B01', 'B02', 'B03', 'B04', 'B05', 'B06', 'B08'],
    },
    'future_reporting': 'Report the 96 runtime obligations and external source-completeness review separately. No original case is passed by this mapping; never claim 97 runtime tests passed under P13.',
    'cases': rows,
})

positive = read(input_paths['E10'])
negative = read(input_paths['E11'])


def differences(a, b, path=''):
    if type(a) is dict and type(b) is dict:
        result = []
        for key in sorted(set(a) | set(b)):
            if key not in a or key not in b:
                result.append({'path': path + '/' + key, 'key_presence_differs': True})
            else:
                result += differences(a[key], b[key], path + '/' + key)
        return result
    if a != b:
        return [{'path': path, 'positive': a, 'negative': b}]
    return []


def without_label(obj):
    result = copy.deepcopy(obj)
    del result['variant_review']['completeness']
    return (json.dumps(result, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode()


neutral_p = without_label(positive)
neutral_n = without_label(negative)
code_lines = input_paths['E12'].read_text().splitlines()
rationale_start = next(i for i, line in enumerate(code_lines) if line.startswith('def _check_resolution('))
rationale_excerpt = '\n'.join(code_lines[rationale_start:rationale_start + 6]) + '\n'
write('SOURCE-EVIDENCE.json', {
    'schema': 'ontokin.c271.p13-boundary-source-evidence/1',
    'source_revision': REV,
    'evidence_kind': 'static source/context inspection only',
    'exact_case_differences': differences(positive, negative),
    'review_neutral_contexts': {
        'method': 'Deep-copy each context in memory; remove only /variant_review/completeness; UTF-8 JSON, sorted keys, compact separators, ensure_ascii true, one newline.',
        'positive': {'bytes': len(neutral_p), 'sha256': digest(neutral_p)},
        'negative': {'bytes': len(neutral_n), 'sha256': digest(neutral_n)},
        'equal': neutral_p == neutral_n,
        'operational_document_created': False,
        'original_inputs_written': False,
    },
    'rationale_boundary': {
        'source': 'E12',
        'first_line': rationale_start + 1,
        'last_line': rationale_start + 6,
        'excerpt': rationale_excerpt,
        'observation': 'Nonempty bytes, SHA-256 and descriptor/file binding are checked; these statements do not parse the rationale for source completeness.',
        'independent_cross_check': 'E13',
    },
    'source_anchors': [
        {'source': 'E04', 'anchor': 'section 3, four-field variant object and source review; section 5, independent completeness obligation; section 7, machine policy and caller ordering'},
        {'source': 'E05', 'anchor': 'route table; synthetic context interpretation; frozen oracle; future 175-method obligation'},
        {'source': 'E06', 'anchor': 'preservation matrix K01-K08; new variant-document caller and test adapter are future surface only'},
        {'source': 'E12', 'anchor': 'module docstring: rationale is not tool-generated approval; review honesty is trust boundary; LIMITS; _document; _plan_shape; _check_resolution'},
        {'source': 'E14', 'anchor': 'gaps: no actual loader source/build/suffix review or complete selected closure'},
    ],
    'proposed_operational_variant_keys': ['schema', 'loader', 'source_review', 'suffixes'],
    'actual_source_review_from_supplied_contexts': {
        'P01_nonselecting_base': 'not_established_by_supplied_inputs',
        'N57_source_variant_unknown': 'not_established_by_supplied_inputs',
        'basis': 'Both contexts are operational:false and contain synthetic identities; E03 and E18 record no actual plan or external expected digest. The completeness labels are not evidence.',
    },
    'original_n57_oracle': expect['cases']['N57_source_variant_unknown'],
    'product_imports': 0,
    'product_calls': 0,
    'actual_host_evidence_created': False,
})

controls = [
    {'id': 'B01', 'kind': 'static_context_difference', 'inputs': ['E10', 'E11'], 'expected': {'differences': [{'path': '/variant_review/completeness', 'positive': 'synthetic_declared_complete', 'negative': 'unsupported'}]}},
    {'id': 'B02', 'kind': 'static_review_neutral_equality', 'inputs': ['E10', 'E11'], 'expected': {'equal': True, 'bytes': 3338, 'sha256': 'e33cb05c8e73031f7c720ecee68094ced82f5d3679af4bc1ebf95bca5b0eaa3c', 'operational_document': False}},
    {'id': 'B03', 'kind': 'static_binding_equality', 'inputs': ['E10', 'E11'], 'expected': {'equal_fields': ['plan_selection', 'subject', 'kernel', 'image', 'variants', 'guards', 'absence_guards', 'search_directories', 'closure_images', 'needed_names_claim', 'variant_review.loader_identity', 'variant_review.source_review_identity', 'variant_review.suffixes']}},
    {'id': 'B04', 'kind': 'source_boundary_review', 'inputs': ['E04', 'E12', 'E13', 'E17'], 'expected': {'variant_keys': ['schema', 'loader', 'source_review', 'suffixes'], 'rationale_content_completeness_parser': False, 'independent_semantic_review_required': True}},
    {'id': 'B05', 'kind': 'source_evidence_sufficiency_review', 'inputs': ['E03', 'E10', 'E11', 'E14', 'E18'], 'expected': {'P01_nonselecting_base': 'not_established_by_supplied_inputs', 'N57_source_variant_unknown': 'not_established_by_supplied_inputs', 'runtime_outcome': None, 'independent_semantic_review_required': True}},
    {'id': 'B06', 'kind': 'static_total_mapping_and_preservation', 'inputs': ['E07', 'E08', 'E09', 'CONTROL-MAPPING.json'], 'expected': {'original_cases': 97, 'fixture_files': 131, 'available_candidate_payloads': 145, 'external_candidate_payloads': 1, 'supporting_files': 29, 'future_runtime_primitive': 96, 'independent_review_only': ['N57_source_variant_unknown'], 'original_expectations_changed': False}},
    {'id': 'B07', 'kind': 'static_protected_source_and_limit_preservation', 'inputs': ['E04', 'E06', 'E12', 'E15'], 'expected': {'protected_sources_changed': False, 'document_bytes': 16777216, 'source_operations': 100000, 'source_ms': 30000}},
    {'id': 'B08', 'kind': 'applicability_and_adoption_review', 'inputs': ['DECISION.md', 'CONTROL-CONTRACT.md', 'CONTROL-MAPPING.json'], 'expected': {'candidate_state': 'proposed_pending_independent_review_and_director_adoption', 'runtime_execution': 'not_run', 'host_qualification': 'not_established', 'n57_historical_oracle_satisfied': False, 'independent_semantic_review_required': True}},
]
write('BOUNDARY-CONTROLS.json', {
    'schema': 'ontokin.c271.p13-review-boundary-controls/1',
    'author': '/root/design_author',
    'decision': 'ontokin.c271.review-runtime-boundary-decision/1',
    'expected_values_origin': 'Literal documentary control specification authored from frozen source facts; not derived from product execution.',
    'operational': False,
    'controls': controls,
    'limits': ['Structural checks do not replace independent semantic review.', 'No real positive source-completeness review or operational plan is supplied.', 'No product runtime outcome is produced.'],
})

governing = [
    'AGENTS.md', 'ROLE.md', 'docs/workflow/PROTOCOL.md', 'docs/workflow/templates/WORKER.md',
    '.agents/skills/ontokin-delivery/SKILL.md', 'docs/workflow/HANDOFF.md',
    'docs/engineering/OK-ENG-006-local-validation-and-hosted-ci-policy.md',
]
write('AUTHOR-READ-SET.json', {
    'schema': 'ontokin.c271.p13-author-read-set/1',
    'author': '/root/design_author',
    'director': '/root',
    'source_revision': REV,
    'governing_full_reads': [descriptor(ROOT / path) for path in governing],
    'required_full_content_reads': ['E01', 'E02', 'E03', 'E04', 'E05', 'E06', 'E07', 'E10', 'E11', 'E13', 'E16', 'E17', 'E18'],
    'full_json_structural_and_identity_reads': ['E08', 'E09', 'E14', 'E15'],
    'targeted_source_text_only': {'E12': ['module docstring and constants', '_document', '_plan_shape', '_check_resolution opening rationale and directory checks']},
    'model_configuration': 'Inherited actual parent configuration; no overrides or invented settings.',
    'child_workers': 0,
    'early_recovery_release': {
        'confirmed_at_utc': '2026-11-22T01:28:32.207196+00:00',
        'archive_sha256': '05e38a85815bbd9026ce565237ebaf1586a48d479429834d15f85d1a0b8d58ca',
        'authority': 'Director message confirming independent review and exact saved-byte readback; substantive work began afterward.',
    },
    'ownership': 'Only review-boundary-p13/design/ and external design_work; no Git/index, canonical task, CURRENT, STATUS, integration or delivery ownership.',
})

write('AUTHORING-OBSERVATIONS.json', {
    'schema': 'ontokin.c271.p13-authoring-observations/1',
    'observations': [
        {'kind': 'tool_display_truncation', 'event': 'Combined P11 decision/control/source displays exceeded output display limits.', 'recovery': 'DECISION and EXPECTATIONS were subsequently displayed completely in separate calls; the relevant source anchors and complete JSON structures were read separately.', 'product_effect': 'none'},
        {'kind': 'expected_absent_path_probe', 'event': 'An rg inventory returned exit 1 while the future review-boundary-p13 directory did not yet exist.', 'recovery': 'No implementation was assumed; the author later created only the assigned design subtree.', 'product_effect': 'none'},
        {'kind': 'external_historical_payload', 'event': 'P11 manifest payload REVISION-004.diff is absent from the Git checkout.', 'recovery': 'Director confirmed the exact prior-archive member; its identity is recorded in INPUTS.json and remains external. 145 local payloads and all 29 supports were read/hash-checked.', 'product_effect': 'none'},
        {'kind': 'tool_display_truncation', 'event': 'Broad display of early ZIP historical dependencies was truncated.', 'recovery': 'Only the complete required_external_candidate_files record is used; the generator selects that exact JSON record directly.', 'product_effect': 'none'},
    ],
    'failed_product_checks': [],
    'product_checks_run': False,
    'unresolved_source_evidence': 'Actual-loader source completeness and operational plan evidence remain absent from the supplied synthetic controls.',
})

print(json.dumps({'metadata_files_created': 6, 'mapping_cases': len(rows), 'controls': len(controls), 'neutral_bytes': len(neutral_p), 'neutral_sha256': digest(neutral_p)}, sort_keys=True))
