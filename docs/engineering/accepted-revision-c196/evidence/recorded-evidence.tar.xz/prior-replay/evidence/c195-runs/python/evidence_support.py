import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import time

OUT = Path('/workspace/scratch/3cb1527378cd/c195-runs/python')
REPO = Path('/workspace/scratch/3cb1527378cd/c195-authors/python')
AUTHOR = REPO / 'docs/engineering/ownership-recovery-c195/authors/python'
PROVISION = json.loads((OUT / 'PROVISION.json').read_text())

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def snapshot(name):
    paths = [OUT / 'accepted-source.py', OUT / 'C194-ACCEPTANCE.json']
    paths += sorted(p for p in (OUT / 'accepted-run').rglob('*') if p.is_file())
    files = {str(p.relative_to(OUT)): {'sha256': sha(p), 'bytes': p.stat().st_size, 'mode': oct(p.stat().st_mode & 0o777)} for p in paths}
    result = {'recorded_utc': utc(), 'root': str(OUT), 'file_count': len(files), 'total_bytes': sum(v['bytes'] for v in files.values()), 'files': files}
    result['file_inventory_sha256'] = hashlib.sha256(json.dumps(files, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
    save(OUT / name, result)
    return result

def run(label, argv, timeout=None):
    path = OUT / 'logs' / label
    if path.with_suffix('.json').exists():
        raise RuntimeError('Refusing to overwrite command record ' + label)
    record = {'label': label, 'argv': list(map(str, argv)), 'cwd': str(REPO), 'started_utc': utc(), 'started_unix_s': time.time()}
    save(path.with_suffix('.json'), record)
    started = time.monotonic()
    with path.with_suffix('.stdout.txt').open('wb') as stdout, path.with_suffix('.stderr.txt').open('wb') as stderr:
        try:
            done = subprocess.run(record['argv'], cwd=REPO, stdout=stdout, stderr=stderr, timeout=timeout)
            record['returncode'] = done.returncode
        except subprocess.TimeoutExpired as error:
            record.update(returncode=None, error=str(error), timed_out=True)
    record.update(finished_utc=utc(), elapsed_s=time.monotonic()-started)
    for stream in ('stdout', 'stderr'):
        file = path.with_suffix('.' + stream + '.txt')
        record[stream] = {'path': str(file), 'sha256': sha(file), 'bytes': file.stat().st_size}
    save(path.with_suffix('.json'), record)
    print(json.dumps(record, sort_keys=True), flush=True)
    return record
