#!/usr/bin/env python3
import datetime
import json
import platform
import shutil
from pathlib import Path
from run_control import REPO, ROOT, sha, utc, write_json, snapshot, preservation

AUTHOR = REPO / 'docs/engineering/ownership-recovery-c195/authors/ok'
dispatch = json.loads((ROOT / 'DISPATCH.json').read_text())
negative = json.loads((ROOT / 'negative-result.json').read_text())
variants = json.loads((AUTHOR / 'BUILD-RESULTS.json').read_text())
prior = json.loads((ROOT / 'preservation-before-negative.json').read_text())
final = snapshot('preservation-at-final-submission.json')
final_proof = preservation(prior, final)
assert final_proof['existing_files_preserved'] and final_proof['state_unchanged']
assert final_proof['added'] == json.loads((ROOT / 'negative-preservation.json').read_text())['added']
preserved = json.loads((AUTHOR / 'PRESERVATION.json').read_text())
preserved['at_final_submission'] = final_proof
preserved['raw_evidence']['preservation-at-final-submission.json'] = {
    'path': str(ROOT / 'preservation-at-final-submission.json'),
    'sha256': sha(ROOT / 'preservation-at-final-submission.json')}
write_json(AUTHOR / 'PRESERVATION.json', preserved)

initial_commands = [
    {'shell': "pwd && rg --files -g 'AGENTS.md' -g 'GOAL*' -g 'STATUS*' -g 'PROTOCOL.md' -g 'FREEZE.json' -g 'PROVISION.json' -g 'DISPATCH.json' .", 'returncode': 0},
    {'shell': 'cat GOAL.md AGENTS.md STATUS.md', 'returncode': 0, 'display_output_truncated': True},
    {'shell': 'cat docs/engineering/ownership-recovery-c195/PROTOCOL.md docs/engineering/ownership-recovery-c195/FREEZE.json', 'returncode': 0},
    {'shell': 'cat PROVISION.json DISPATCH.json', 'returncode': 0, 'cwd': str(ROOT)},
    {'shell': "cat AGENTS.md && git status --short && git branch --show-current && sed -n '1,240p' docs/engineering/guide-repair-c193/native/build.py && cat docs/engineering/ownership-recovery-c195/fixtures/candidate.ok && find /workspace/scratch/3cb1527378cd/c195-runs/ok -maxdepth 3 -type f", 'returncode': 0},
    {'shell': "cat /workspace/scratch/3cb1527378cd/c195-runs/ok/accepted-run/store/state.json && cat /workspace/scratch/3cb1527378cd/c195-runs/ok/C194-ACCEPTANCE.json && rg -n 'expected-revision|native_substeps|C193_E_OWNERSHIP' prototypes/guided_contact_v02 docs/engineering/guide-repair-c193/native/author* docs/engineering/contact-preparation-c194 2>/dev/null && sed -n '1,140p' STATUS.md", 'returncode': 2,
     'failure_note': 'Read/search only. rg received an unmatched inspection glob; stderr was suppressed. Exact error text was not available; final chained sed was not executed. No source mutation or native launch.'},
    {'shell': "sed -n '1,300p' prototypes/guided_contact_v02/transaction.py && cat prototypes/guided_contact_v02/__main__.py && sed -n '1,85p' STATUS.md && rg --files docs/engineering/ownership-recovery-c195 docs/engineering/contact-preparation-c194 docs/engineering/guide-repair-c193 | rg 'check|author|manifest|INPUT' ", 'returncode': 0}
]
for entry in initial_commands:
    entry.setdefault('cwd', str(REPO))
    entry['timestamp'] = None
    entry['recording'] = 'Retrospectively transcribed from actual tool calls; stdout remained in tool transcript, not in an original local log.'
write_json(ROOT / 'initial-inspection-commands.json', initial_commands)
commands = [json.loads(line) for line in (ROOT / 'commands.jsonl').read_text().splitlines()]
current_seal = json.loads((ROOT / 'seal-submission-01/command.json').read_text())
current_seal['recording'] = 'Active sealing invocation; completion is appended to the external command journal after this immutable submission is written.'
write_json(ROOT / 'commands-at-submission.json', {'initial_commands': initial_commands,
    'recorded_commands': commands, 'active_sealing_command': current_seal})
source_edit = json.loads((ROOT / 'source-edit.json').read_text())
finished = utc()
elapsed = (datetime.datetime.fromisoformat(finished) - datetime.datetime.fromisoformat(dispatch['dispatched_utc'])).total_seconds()
assert datetime.datetime.fromisoformat(finished) < datetime.datetime.fromisoformat(dispatch['deadline_utc'])
accounting = {
    'schema': 'ontokin.c195.author-accounting/0.1', 'route': 'ok',
    'author': 'c195-author-ok-3cb152', 'branch': 'work/c195-author-ok-3cb152',
    'scope': 'docs/engineering/ownership-recovery-c195/authors/ok only; raw runs outside repository',
    'source_revision_at_execution': dispatch['local_source_revision'],
    'started_utc': dispatch['dispatched_utc'], 'finished_utc': finished,
    'deadline_utc': dispatch['deadline_utc'], 'elapsed_wall_seconds': elapsed,
    'completed_before_deadline': True, 'formal_submissions': 1,
    'formal_submission_history': [{'number': 1, 'submitted_utc': finished,
        'manifest': 'SUBMISSION.json', 'status': 'Submitted for independent coordinator acceptance'}],
    'native_constructions': {'repaired': 1, 'baseline_regeneration': 1,
                            'failed': 0, 'retries': 0, 'reopens': 0, 'receiving_native_checks': 0},
    'source_repairs': 1, 'incorrect_repairs': 0, 'intermediate_alternative_sources': 0,
    'expected_static_rejections': 1, 'unexpected_inspection_command_failures': 1,
    'source_edit': source_edit, 'negative_result': negative,
    'positive_costs': {k: {'cost': v['cost'], 'recorder_elapsed_s': v['build_elapsed_s']} for k,v in variants.items()},
    'charged_operations_total': negative['cost']['operations_consumed'] + sum(v['cost']['operations_consumed'] for v in variants.values()),
    'native_substeps_total': sum(v['cost']['operation_components']['scheduled_native_substeps'] for v in variants.values()),
    'read_only_checks': [
        {'kind': 'C194 artifact reader', 'variant': k, 'passed': v['checker_passed'], 'result': v['read_only_checker']}
        for k,v in variants.items()] + [
        {'kind': 'documentation preservation and navigation', 'passed': True,
         'result': str(ROOT / 'documentation-check-01/stdout.txt')},
        {'kind': 'frozen file preservation', 'passed': True, 'files': 618,
         'result': str(ROOT / 'frozen-input-verification-at-submission.json')}],
    'unmetered_work': 'Read-only checkers, shell inspection, hashing, report creation and Git publication provide no shared runtime operation count; their actual commands and available elapsed times are retained.',
    'commands': {'initial_read_only': initial_commands, 'recorded': commands,
        'active_seal': current_seal, 'append_only_journal_path': str(ROOT / 'commands.jsonl'),
        'snapshot_path': str(ROOT / 'commands-at-submission.json'),
        'snapshot_sha256': sha(ROOT / 'commands-at-submission.json'),
        'post_submission_commit_commands': 'Retained in the external append-only journal; Git commit identity is supplied in the handoff without modifying SUBMISSION.json.'},
    'evidence_scripts': {p.name: {'path': str(p), 'sha256': sha(p)} for p in (
        ROOT / 'run_control.py', ROOT / 'prepare_repair.py', ROOT / 'prepare_submission.py', ROOT / 'seal_submission.py')},
    'environment': {'python': platform.python_version(), 'platform': platform.platform(),
                    'blender': json.loads((ROOT / 'PROVISION.json').read_text())['blender']},
    'provider_telemetry': {'tokens': None, 'provider_cost': None, 'exact_model_snapshot': None,
        'reason': 'Unavailable in this session; no token cutoff or provider-cost comparison claimed.'},
    'model_override': None, 'reasoning_override': None, 'author_delegations': 0,
    'human_interventions': 0, 'coordinator_repair_corrections': 0,
    'limits': ['Supplied public known-defect task in a shared environment.',
        'One pair cannot establish reliability or language/cost superiority.',
        'Coordinator replay, receiving validation, visual review and final acceptance are separate.',
        'Original accepted store remains on 375 mm; repaired build uses a fresh store.',
        'Inherited legacy driver/tail FAILED; thirteen torque methods NOT RUN.']}
write_json(AUTHOR / 'ACCOUNTING.json', accounting)
own_files = {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size}
             for p in sorted(AUTHOR.iterdir()) if p.is_file()}
submission = {
    'schema': 'ontokin.c195.author-submission/0.1', 'route': 'ok', 'submission_number': 1,
    'submitted_utc': finished, 'immutable': True,
    'status': 'Author-complete; independent coordinator acceptance pending',
    'branch': accounting['branch'], 'execution_revision': accounting['source_revision_at_execution'],
    'author_directory': str(AUTHOR), 'output_directory': str(ROOT),
    'variants': variants,
    'negative': {'run': str(ROOT / 'negative-01'), 'result': str(ROOT / 'negative-result.json'),
        'result_sha256': sha(ROOT / 'negative-result.json'), 'attempt_id': negative['attempt_id'],
        'code': negative['diagnostics'][0]['code'], 'candidate_sha256': negative['source_sha256'],
        'previous_revision': negative['previous_revision'], 'accepted_revision': negative['accepted_revision'],
        'levels': negative['levels'], 'operations': negative['cost']['operations_consumed'],
        'native_substeps': 0, 'native_artifacts_absent': True},
    'baseline_preservation': preserved,
    'source_derivation': {'evidence_path': str(ROOT / 'source-edit.json'),
        'evidence_sha256': sha(ROOT / 'source-edit.json'),
        'only_accepted_baseline_delta': 'left_stop X: 375 -> 365 mm',
        'only_malformed_candidate_repair': 'contact.left_shoe owner: body.right -> body.left',
        'prepared_positive_source_or_output_substituted': False},
    'author_files': own_files,
    'allowance_use': {'wall_seconds': elapsed, 'formal_submissions': 1,
        'repaired_native_builds': 1, 'baseline_native_builds': 1, 'native_retries': 0},
    'independent_acceptance_pending': True,
    'raw_evidence_retained': True}
with (AUTHOR / 'SUBMISSION.json').open('x') as stream:
    stream.write(json.dumps(submission, indent=2, sort_keys=True) + '\n')
submission_hash = sha(AUTHOR / 'SUBMISSION.json')
(AUTHOR / 'SUBMISSION.sha256').write_text(submission_hash + '  SUBMISSION.json\n')
(AUTHOR / 'SUBMISSION.json').chmod(0o444)
write_json(ROOT / 'submission-seal.json', {'submitted_utc': finished,
    'submission_path': str(AUTHOR / 'SUBMISSION.json'), 'submission_sha256': submission_hash,
    'source_revision_at_execution': dispatch['local_source_revision'],
    'formal_submissions': 1, 'elapsed_wall_seconds': elapsed})
print(json.dumps({'submission_sha256': submission_hash, 'elapsed_wall_seconds': elapsed,
                  'submitted_utc': finished, 'formal_submissions': 1,
                  'preservation_passed': True, 'artifacts_passed': True}, indent=2))
