from evidence_support import *
import sys

source = Path(sys.argv[1]).resolve()
label = sys.argv[2]
command = [sys.executable, '-B', str(REPO / 'docs/engineering/guide-repair-c193/native/build.py'), '--repo', str(REPO), '--route', 'python', '--source', str(source), '--out', str(OUT / label), '--blender', PROVISION['blender']]
record = run(label, command, timeout=115)
raise SystemExit(0 if record['returncode'] == 0 else 1)
