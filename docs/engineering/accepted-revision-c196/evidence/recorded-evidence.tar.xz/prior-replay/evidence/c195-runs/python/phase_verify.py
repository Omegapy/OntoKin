from evidence_support import *
import sys

checks = OUT / 'verification-01'
checks.mkdir(exist_ok=False)
root = REPO / 'docs/engineering/ownership-recovery-c195'
freeze = json.loads((root / 'FREEZE.json').read_text())
assert sha(root / 'INPUTS.json') == freeze['input_manifest_sha256']
manifest = json.loads((root / 'INPUTS.json').read_text())
changed = []
for row in manifest['files']:
    path = REPO / row['path']
    if not path.is_file() or path.stat().st_size != row['bytes'] or sha(path) != row['sha256']:
        changed.append(row['path'])
frozen_result = {'checked_utc': utc(), 'input_manifest_sha256': sha(root / 'INPUTS.json'), 'files_checked': len(manifest['files']), 'changed_files': changed, 'passed': not changed}
save(checks / 'frozen-inputs.json', frozen_result)
assert not changed

baseline = OUT / 'accepted-run/artifact'
regen = OUT / 'baseline-regenerated-01/artifact'
comparison = {name: {'accepted_sha256': sha(baseline / name), 'regenerated_sha256': sha(regen / name), 'identical': (baseline / name).read_bytes() == (regen / name).read_bytes()} for name in ['canonical-input.json', 'native-transforms.json', 'raw.glb', 'final.glb']}
save(checks / 'baseline-regeneration.json', {'checked_utc': utc(), 'accepted_artifact': str(baseline), 'regenerated_artifact': str(regen), 'files': comparison, 'passed': all(x['identical'] for x in comparison.values())})
assert all(x['identical'] for x in comparison.values())

sys.path.insert(0, str(REPO / 'docs/engineering/contact-preparation-c194'))
import common as c
reader = c.artifact_reader()
reader.verify_frozen()
summary = []
for label, case in [('repaired-01', 'G'), ('baseline-regenerated-01', 'H')]:
    artifact = OUT / label / 'artifact'
    report = reader.review(artifact, case, c.CONTRACT / 'backend.json', c.BACKEND_SHA, c.SOURCE_BINDING)
    save(checks / (label + '-artifact.json'), report)
    receipt = json.loads((OUT / label / 'delivery.json').read_text())
    result = {'run': str(OUT / label), 'artifact': str(artifact), 'case': case, 'producer_successful': receipt['successful'], 'source_unchanged_during_build': receipt['source_unchanged_during_build'], 'artifact_reader_passed': report['passed'], 'failures': report['failures'], 'cost': receipt['cost'], 'build_elapsed_s': receipt['elapsed_s'], 'continuous_mapping_bound_mm': report['mapping_measurements']['maximumContinuousRawToFinalVertexDeviationBoundMm'], 'native_peak_mm': report['diagnosis']['peak']['distance_mm']}
    summary.append(result)
    assert report['passed'] and receipt['successful'] and receipt['source_unchanged_during_build']
current = snapshot('baseline-after-positive-checks.json')
before = json.loads((OUT / 'baseline-before-negative.json').read_text())
assert before['files'] == current['files']
save(checks / 'SUMMARY.json', {'checked_utc': utc(), 'runs': summary, 'baseline_unchanged': True, 'baseline_inventory_sha256': current['file_inventory_sha256'], 'frozen_input_files': len(manifest['files']), 'native_reopens_executed': 0, 'receiving_jobs_executed': 0, 'coordinator_independent_acceptance': 'PENDING'})
print(json.dumps({'runs': summary, 'baseline_unchanged': True, 'baseline_file_count': current['file_count'], 'baseline_total_bytes': current['total_bytes'], 'frozen_input_files': len(manifest['files'])}, sort_keys=True))
