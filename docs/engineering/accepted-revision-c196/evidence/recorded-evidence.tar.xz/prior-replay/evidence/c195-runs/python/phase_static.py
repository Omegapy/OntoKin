from evidence_support import *
import sys

before = snapshot('baseline-before-negative.json')
(AUTHOR / 'accepted-source.py').write_bytes((OUT / 'accepted-source.py').read_bytes())
command = [sys.executable, '-B', str(REPO / 'docs/engineering/guide-repair-c193/native/direct_runner.py'), '--repo', str(REPO), '--design', str(REPO / PROVISION['malformed_candidate']), '--out', str(OUT / 'negative-01'), '--blender', PROVISION['blender']]
record = run('negative-01', command, timeout=110)
after = snapshot('baseline-after-negative.json')
receipt = json.loads((OUT / 'negative-01/build-receipt.json').read_text())
files = sorted(str(p.relative_to(OUT / 'negative-01')) for p in (OUT / 'negative-01').rglob('*') if p.is_file())
check = {'utc': utc(), 'receipt': receipt, 'files': files, 'before_inventory_sha256': before['file_inventory_sha256'], 'after_inventory_sha256': after['file_inventory_sha256'], 'accepted_baseline_unchanged': before['files'] == after['files'], 'no_native_outputs': files == ['build-receipt.json', 'manifest.json'], 'scheduled_native_substeps': receipt['cost'].get('charges', {}).get('scheduled_native_substeps', receipt['cost'].get('categories', {}).get('scheduled_native_substeps', None)), 'direct_runner_sha256': sha(REPO / 'docs/engineering/guide-repair-c193/native/direct_runner.py')}
save(OUT / 'negative-verification.json', check)
print(json.dumps(check, sort_keys=True))
assert record['returncode'] == 1
assert receipt['successful'] is False
assert receipt['error'].startswith('ValueError: $.colliders.contact.left_shoe.owner')
assert before['files'] == after['files']
assert check['no_native_outputs']
