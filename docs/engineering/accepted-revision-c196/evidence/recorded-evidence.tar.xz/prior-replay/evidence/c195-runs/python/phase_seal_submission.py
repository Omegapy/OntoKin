from evidence_support import *
import platform
import sys

assert not (AUTHOR / 'SUBMISSION.json').exists()
assert not (AUTHOR / 'ACCOUNTING.json').exists()
dispatch = json.loads((OUT / 'DISPATCH.json').read_text())
finished = utc()
start = datetime.datetime.fromisoformat(dispatch['dispatched_utc'])
end = datetime.datetime.fromisoformat(finished)
assert end <= datetime.datetime.fromisoformat(dispatch['deadline_utc'])
baseline_final = snapshot('baseline-at-submission.json')
baseline_before = json.loads((OUT / 'baseline-before-negative.json').read_text())
assert baseline_before['files'] == baseline_final['files']

command_index = json.loads((OUT / 'COMMANDS.json').read_text())
(OUT / 'COMMANDS-before-sealing.json').write_bytes((OUT / 'COMMANDS.json').read_bytes())
command_index.update(recorded_utc=finished, execution_records=[json.loads(p.read_text()) for p in sorted((OUT / 'logs').glob('*.json'))])
command_index['script_invocations'].append({'command': 'python3 -B /workspace/scratch/3cb1527378cd/c195-runs/python/phase_seal_submission.py', 'purpose': 'Final baseline hashes, accounting and immutable first submission'})
command_index['additional_documentation_edit'] = 'Before the documentation check, an inline Python block retained DIAGNOSIS-draft-01.md and changed two not-yet-created JSON file links to code references. Source files were unchanged.'
command_index['administrative_followup'] = 'Git staging, commit and status commands are logged separately after this formal seal; they do not edit submitted sources or rebuild artifacts.'
save(OUT / 'COMMANDS.json', command_index)

negative = json.loads((OUT / 'negative-verification-complete.json').read_text())
positive = json.loads((OUT / 'verification-01/SUMMARY.json').read_text())
costs = [{'stage': 'expected-static-rejection', 'cost': negative['receipt']['cost']}]
costs.extend({'stage': row['case'], 'run': row['run'], 'cost': row['cost'], 'build_recorder_elapsed_s': row['build_elapsed_s']} for row in positive['runs'])
accounting = {
    'schema': 'ontokin.c195.author-accounting/0.1', 'route': 'python',
    'started_utc': dispatch['dispatched_utc'], 'ended_utc': finished,
    'deadline_utc': dispatch['deadline_utc'], 'wall_seconds_to_formal_seal': (end-start).total_seconds(),
    'ended_within_deadline': True,
    'formal_submissions': 1, 'formal_submission_limit': 3,
    'native_constructions': {'repaired_365_mm': 1, 'preserved_375_mm': 1, 'total': 2, 'failed': 0, 'automatic_retries': 0},
    'static_rejections': 1, 'expected_command_failures': 1, 'unexpected_command_failures': 0,
    'source_repairs': 1, 'incorrect_repairs': 0, 'source_edit_record': {'path': str(OUT / 'source-edit.json'), 'sha256': sha(OUT / 'source-edit.json')},
    'evidence_recording_corrections': [{'original': str(OUT / 'negative-verification.json'), 'supplement': str(OUT / 'negative-verification-complete.json'), 'description': 'Supplement reads operation_components after the first extraction used charges/categories and reported null. Both records and the actual receipt are retained.'}],
    'per_positive_build_limits': {'requested_operations': 1000000, 'requested_elapsed_ms': 80000, 'outer_watchdog_s': 100},
    'modeled_duration_s': 2,
    'native_reopens': 0, 'receiving_jobs': 0, 'artifact_reader_checks': 2,
    'costs': costs,
    'harness_operations_total': sum(row['cost']['operations_consumed'] for row in costs),
    'scheduled_native_substeps_total': sum(row['cost']['operation_components'].get('scheduled_native_substeps', 0) for row in costs),
    'provider_telemetry': {'available': False, 'tokens': None, 'billed_cost': None, 'exact_model_snapshot': None, 'token_cutoff_claimed': False},
    'author_settings': {'fresh_default_author_requested': True, 'fork_turns': 'none', 'model_override': None, 'reasoning_override': None, 'delegations': 0},
    'human_interventions_after_dispatch': 0,
    'coordinator_setup_rebuild_replay_and_receiving_costs': 'Separate; excluded from author operation and native-run totals.',
    'environment': {'python': platform.python_version(), 'platform': platform.platform(), 'blender': PROVISION['blender']},
    'command_index': {'path': str(OUT / 'COMMANDS.json'), 'sha256': sha(OUT / 'COMMANDS.json')},
    'documentation_check': {'path': str(OUT / 'logs/documentation-check.json'), 'sha256': sha(OUT / 'logs/documentation-check.json'), 'passed': True},
    'scope': 'Supplied public recovery in a shared environment; no blind-diagnosis or comparative-advantage claim.',
    'legacy_status': {'driver': 'FAILED', 'supplemental_tail': 'FAILED', 'torque_methods_not_run': 13, 'full_release_claimed': False}
}
save(AUTHOR / 'ACCOUNTING.json', accounting)

sources = {'malformed_candidate': AUTHOR / 'candidate.py', 'repaired': AUTHOR / 'repaired.py', 'accepted_review_copy': AUTHOR / 'accepted-source.py', 'accepted_original': OUT / 'accepted-source.py'}
runs = []
for label, case, target, source in [('repaired-01', 'G', 365, AUTHOR / 'repaired.py'), ('baseline-regenerated-01', 'H', 375, OUT / 'accepted-source.py')]:
    run_path = OUT / label
    artifact = run_path / 'artifact'
    files = {str(p.relative_to(run_path)): {'bytes': p.stat().st_size, 'sha256': sha(p)} for p in sorted(run_path.rglob('*')) if p.is_file()}
    inventory_path = OUT / (label + '-inventory.json')
    save(inventory_path, {'run': str(run_path), 'files': files})
    receipt = json.loads((run_path / 'delivery.json').read_text())
    assert receipt['successful'] and receipt['source_unchanged_during_build']
    assert receipt['source_sha256'] == sha(source)
    runs.append({'id': 'python-' + case, 'route': 'python', 'case': case, 'left_stop_mm': target, 'repo': str(REPO), 'run': str(run_path), 'source': str(source), 'source_sha256': sha(source), 'artifact': str(artifact), 'producer_successful': True, 'artifact_reader_passed': True, 'run_inventory': {'path': str(inventory_path), 'sha256': sha(inventory_path)}, 'delivery_sha256': sha(run_path / 'delivery.json'), 'artifact_manifest_sha256': sha(artifact / 'manifest.json'), 'core_files': {name: {'path': str(artifact / name), 'sha256': sha(artifact / name)} for name in ['canonical-input.json', 'native-transforms.json', 'raw.glb', 'final.glb', 'scene.blend']}})

evidence_paths = ['PROVISION.json', 'DISPATCH.json', 'C194-ACCEPTANCE.json', 'baseline-before-negative.json', 'baseline-after-negative.json', 'baseline-after-positive-checks.json', 'baseline-at-submission.json', 'negative-01/build-receipt.json', 'negative-01/manifest.json', 'negative-verification.json', 'negative-verification-complete.json', 'source-edit.json', 'verification-01/SUMMARY.json', 'verification-01/frozen-inputs.json', 'verification-01/baseline-regeneration.json', 'verification-01/repaired-01-artifact.json', 'verification-01/baseline-regenerated-01-artifact.json', 'COMMANDS.json']
submission = {
    'schema': 'ontokin.c195.author-submission/0.1', 'route': 'python', 'submission_number': 1,
    'submitted_utc': finished, 'immutable_after_sealing': True,
    'branch': 'work/c195-author-python-3cb152', 'starting_commit': 'b9e62c8a3eaeb267ba11f929c9da168ebf73bc5b',
    'published_same_tree_at_dispatch': dispatch['published_same_tree'],
    'freeze_sha256': sha(REPO / 'docs/engineering/ownership-recovery-c195/FREEZE.json'),
    'state': 'Author producer and read-only artifact checks passed; independent coordinator acceptance pending.',
    'sources': {key: {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size} for key, path in sources.items()},
    'runs': runs,
    'negative': {'run': str(OUT / 'negative-01'), 'successful': False, 'actual_error': negative['receipt']['error'], 'returncode': 1, 'operations_consumed': 25, 'scheduled_native_substeps': 0, 'native_output_files': [], 'retained_files': negative['files']},
    'baseline_preservation': {'method': 'Ordinary file and Git staging; no OntoKin store API or atomic-transaction guarantee.', 'accepted_run': str(OUT / 'accepted-run'), 'accepted_source': str(OUT / 'accepted-source.py'), 'accepted_record': str(OUT / 'C194-ACCEPTANCE.json'), 'all_existing_files_unchanged_before_after_negative_and_at_submission': True, 'file_count': baseline_final['file_count'], 'total_bytes': baseline_final['total_bytes'], 'file_inventory_sha256': baseline_final['file_inventory_sha256'], 'baseline_four_core_files_exactly_regenerated': True, 'regeneration_evidence': str(OUT / 'verification-01/baseline-regeneration.json')},
    'locality': {'repaired_vs_accepted_only_change': 'parts.left_stop.at_mm[0]: 375 -> 365', 'candidate_to_repaired_only_change': 'colliders.contact.left_shoe.owner: body.right -> body.left', 'incorrect_repairs': 0, 'candidate_preserved': True},
    'author_files': {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(AUTHOR.iterdir()) if p.is_file()},
    'raw_evidence_root': str(OUT),
    'evidence': {rel: {'path': str(OUT / rel), 'sha256': sha(OUT / rel)} for rel in evidence_paths},
    'limits': {'wall_seconds': 1200, 'formal_submissions': 3, 'repaired_native_builds': 1, 'baseline_native_builds': 1, 'automatic_retries': False},
    'accounting': str(AUTHOR / 'ACCOUNTING.json'),
    'remaining_coordinator_work': 'Independently audit actual artifacts and provenance, replay saved scenes, perform permitted coordinator rebuilds and receiving checks, compare routes, review visual panels, and decide acceptance.',
    'claim_limit': 'Supplied public recovery, not blind diagnosis; no reliability, cost superiority, full release or general contact claim.'
}
with (AUTHOR / 'SUBMISSION.json').open('x') as stream:
    json.dump(submission, stream, indent=2, sort_keys=True)
    stream.write('\n')
(OUT / 'SUBMISSION-01.json').write_bytes((AUTHOR / 'SUBMISSION.json').read_bytes())
(AUTHOR / 'SUBMISSION.sha256').write_text(sha(AUTHOR / 'SUBMISSION.json') + '  SUBMISSION.json\n')
(AUTHOR / 'SUBMISSION.json').chmod(0o444)
(OUT / 'SUBMISSION-01.json').chmod(0o444)
print(json.dumps({'submitted_utc': finished, 'wall_seconds': accounting['wall_seconds_to_formal_seal'], 'submission_sha256': sha(AUTHOR / 'SUBMISSION.json'), 'runs': [{'id':r['id'], 'run':r['run'], 'source':r['source']} for r in runs], 'harness_operations': accounting['harness_operations_total'], 'native_substeps': accounting['scheduled_native_substeps_total']}))
