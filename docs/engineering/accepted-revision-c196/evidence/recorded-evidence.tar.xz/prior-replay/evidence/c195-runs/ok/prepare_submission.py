#!/usr/bin/env python3
"""Read-only artifact/preservation comparisons and author report preparation."""
import json
import platform
from pathlib import Path
from run_control import REPO, ROOT, sha, utc, write_json, snapshot, preservation

AUTHOR = REPO / 'docs/engineering/ownership-recovery-c195/authors/ok'
before = json.loads((ROOT / 'preservation-before-negative.json').read_text())
immediate = json.loads((ROOT / 'preservation-immediately-after-negative.json').read_text())
at_submission = snapshot('preservation-at-submission.json')
proof = preservation(before, at_submission)
negative = json.loads((ROOT / 'negative-result.json').read_text())
assert proof['existing_files_preserved'] and proof['state_unchanged']
assert proof['added'] == preservation(before, immediate)['added']
assert len(proof['added']) == 1 and proof['added'][0].endswith('/result.json')
original_artifact = ROOT / 'accepted-run/store' / before['state']['artifact_directory']
selected = ('canonical-input.json', 'native-transforms.json', 'raw.glb', 'final.glb')
variants = {}
for name, case, stop, check in [('repaired-01', 'G', 365, 'check-repaired-G.json'),
                              ('baseline-regenerated-01', 'H', 375, 'check-baseline-H.json')]:
    run = ROOT / name
    command = json.loads((run / 'command.json').read_text())
    result = json.loads((run / 'stdout.txt').read_text())
    artifact = Path(command['artifact_directory'])
    assert artifact.is_relative_to(run)
    checker = json.loads((ROOT / check).read_text())
    assert command['successful'] and result['successful'] and checker['passed']
    assert (artifact / 'scene.blend').is_file()
    files = {str(p.relative_to(artifact)): {'sha256': sha(p), 'bytes': p.stat().st_size}
             for p in sorted(artifact.rglob('*')) if p.is_file()}
    write_json(ROOT / (name + '-artifact-closure.json'), {'artifact': str(artifact), 'files': files})
    variants[name] = {
        'case': case, 'left_stop_mm': stop, 'run': str(run), 'artifact': str(artifact),
        'source': command['source'], 'source_sha256': command['source_sha256'],
        'source_unchanged_during_build': command['source_unchanged_during_build'],
        'artifacts': {n: sha(artifact / n) for n in selected},
        'scene_blend_sha256': sha(artifact / 'scene.blend'),
        'artifact_manifest_sha256': sha(artifact / 'manifest.json'),
        'artifact_file_count': len(files),
        'artifact_closure_manifest': str(ROOT / (name + '-artifact-closure.json')),
        'artifact_closure_manifest_sha256': sha(ROOT / (name + '-artifact-closure.json')),
        'receipt_sha256': sha(run / 'stdout.txt'), 'delivery_sha256': sha(run / 'delivery.json'),
        'levels': result['levels'], 'read_only_checker': str(ROOT / check),
        'checker_result_sha256': sha(ROOT / check), 'checker_passed': checker['passed'],
        'checker_failures': checker['failures'], 'cost': command['cost'],
        'build_elapsed_s': command['elapsed_s'],
        'native_peak_mm': checker['diagnosis']['peak']['distance_mm'],
        'continuous_bound_mm': checker['mapping_measurements']['maximumContinuousRawToFinalVertexDeviationBoundMm'],
        'sample_count': checker['diagnosis']['native_sample_count'],
        'left_final_travel_mm': checker['playback']['parts']['left_carriage']['final_displacement_mm'][0],
        'right_final_travel_mm': checker['playback']['parts']['right_carriage']['final_displacement_mm'][0],
        'right_final_clearance_mm': checker['playback']['gaps']['right']['final_mm'],
        'unrelated_pairs_checked': checker['playback']['clearance']['certified_unrelated_pairs']}

regenerated = Path(variants['baseline-regenerated-01']['artifact'])
reproduction = {n: {'original_sha256': sha(original_artifact / n),
                    'regenerated_sha256': sha(regenerated / n),
                    'byte_identical': (original_artifact / n).read_bytes() == (regenerated / n).read_bytes()}
                for n in selected}
assert all(row['byte_identical'] for row in reproduction.values())
accepted_record = json.loads((ROOT / 'C194-ACCEPTANCE.json').read_text())
recorded_baseline = next(x for x in accepted_record['sources_and_artifacts'] if x['id'] == 'ok-reuse')
assert recorded_baseline['source_sha256'] == sha(ROOT / 'accepted-source.ok')
assert all(recorded_baseline['artifacts'][n] == sha(original_artifact / n) for n in selected)
frozen = json.loads((REPO / 'docs/engineering/ownership-recovery-c195/INPUTS.json').read_text())
freeze_failures = [r['path'] for r in frozen['files']
                   if (REPO/r['path']).stat().st_size != r['bytes'] or sha(REPO/r['path']) != r['sha256']]
assert not freeze_failures
write_json(ROOT / 'frozen-input-verification-at-submission.json', {
    'checked_utc': utc(), 'file_count': len(frozen['files']), 'failures': freeze_failures, 'passed': True})

preservation_record = {
    'schema': 'ontokin.c195.ok-preservation/0.1', 'checked_utc': utc(),
    'preserved_file_count': before['file_count'], 'preserved_bytes': before['total_bytes'],
    'before_closure_sha256': before['closure_sha256'],
    'accepted_source_sha256': sha(ROOT / 'accepted-source.ok'),
    'acceptance_record_sha256': sha(ROOT / 'C194-ACCEPTANCE.json'),
    'state_pointer_sha256': sha(ROOT / 'accepted-run/store/state.json'),
    'accepted_revision': before['state']['accepted_revision'],
    'original_artifact': str(original_artifact),
    'immediately_after_negative': preservation(before, immediate),
    'at_submission': proof,
    'baseline_regeneration': reproduction,
    'accepted_record_matches_original_files': True,
    'negative_scheduled_native_substeps': negative['cost']['operation_components'].get('scheduled_native_substeps', 0),
    'negative_native_output_absent': negative['artifact_directory'] is None and negative['artifacts'] == {} and negative['cost']['native_result_bytes'] == 0,
    'raw_evidence': {n: {'path': str(ROOT / n), 'sha256': sha(ROOT / n)} for n in (
        'preservation-before-negative.json', 'preservation-immediately-after-negative.json',
        'preservation-at-submission.json', 'negative-preservation.json', 'negative-result.json',
        'frozen-input-verification-before-builds.json', 'frozen-input-verification-at-submission.json')},
    'store_pointer_advanced_to_repaired_design': False,
    'positive_build_context': 'Two fresh stores; preserved original store remains on the accepted 375 mm revision.'}
write_json(AUTHOR / 'PRESERVATION.json', preservation_record)
write_json(AUTHOR / 'BUILD-RESULTS.json', variants)
write_json(ROOT / 'submission-preparation.json', {'prepared_utc': utc(), 'variants': variants,
                                               'preservation': preservation_record})

report = '''# C195 OntoKin ownership recovery

## Observed result

The malformed candidate was rejected before native execution. One local owner
repair produced the 365 mm design, and one separate regeneration reproduced the
preserved accepted 375 mm design. Both actual builds pass the unchanged C194
artifact checker. This is the first formal submission, pending coordinator audit.

The author used the supplied public candidate and defect description. This is a
recovery exercise with a known defect, not a blind diagnosis or evidence of a
language or cost advantage.

## Relationship conflict and exact repair

`follow.left` makes `left_shoe` follow `left_carriage`. `body.left` owns that
carriage and supplies its physical motion. Therefore the left shoe's collider
must have `body.left` as its mass owner. The candidate instead assigns
`contact.left_shoe` to `body.right`, while leaving the follow relationship on
the left. Spatial following and physical ownership describe different
relationships, but they must agree on which body supplies this collider's
mass and motion. Assigning the right body does not move the follow relationship.

The actual run returned `C193_E_OWNERSHIP`, phase `validate`, with the message
“Collider is assigned to the wrong mass owner”. It identifies `candidate.ok`
line 81, columns 17–29, bytes 2400–2412: the `"body.right"` owner token.
The negative command exited 1, as expected. Its levels were:

| Level | Result |
| --- | --- |
| represented | true |
| constructed | false |
| evaluated | false |
| exported | false |
| destination_validated | false |

The result consumed 921 charged operations (827 source tokens, 82 field checks,
12 reference checks). It scheduled zero native substeps, reported zero native
elapsed time, zero native result/log bytes and zero staged output bytes.
`artifact_directory` was null and `artifacts` was empty. The sole store addition
was its failure receipt. No native construction or retry occurred for rejection.

The repair changes only the candidate's left-shoe owner from `body.right` to
`body.left`. There were no incorrect repairs or intermediate alternative sources.
The original malformed bytes remain in `candidate.ok` and in the frozen fixture.
Compared with the accepted baseline, `repaired.ok` differs only at `left_stop`:
`at = [375, 130, -220][mm]` becomes `at = [365, 130, -220][mm]`.
`candidate-repair.patch` and `source-delta.patch` record both comparisons.
The repaired file was made by editing the supplied malformed bytes; a prepared
positive source or artifact was not copied into either delivery.

## Preservation and regeneration

The original accepted revision and previous revision both remained
`2143515f358e36c1dd9a1deef83dba2519a99be6141b64d8bd9dae987761fbd0`.
Before and immediately after rejection, and again at submission preparation,
all 47 existing preserved files (2,935,277 bytes) match in hash, size and mode.
That closure includes the accepted source, C194 acceptance record, state
pointer, all accepted artifacts and original receipts. The existing lock file
also remains unchanged. One new failure receipt was added; nothing was removed
or modified. `PRESERVATION.json` binds the full before/after manifests.

Both positive constructions used the unchanged C193 `native/build.py` recorder,
the pinned Blender executable, 1,000,000 operations, 80,000 ms and its existing
100-second outer watchdog. The 365 mm build used this author's repaired source.
The 375 mm build used the supplied `accepted-source.ok`. They ran in separate
fresh stores. The original accepted store was not advanced to the repaired
revision.

| Actual output | Left stop | Checker | Native sample error | Continuous mapping bound |
| --- | ---: | --- | ---: | ---: |
| repaired-01 | 365 mm | G passed | 0.067812002 mm | 0.074516468 mm |
| baseline-regenerated-01 | 375 mm | H passed | 0.105950345 mm | 0.116442263 mm |

Both bounds are below the unchanged 0.2 mm limit. Both readers evaluated 481
native samples and all 20 unrelated pairs. Each run retained the actual saved
scene, canonical input, native records, raw and final GLBs, implementation copy,
manifest, command and receipt. The 375 mm canonical input, native transforms,
raw GLB and final GLB are byte-identical to their original accepted counterparts.
Their original hashes also match the supplied C194 acceptance record.

Each build consumed 450,690 operations, including 4,800 scheduled native
substeps. The recorder elapsed times were 3.577691317 seconds for repaired-01
and 3.223345757 seconds for baseline-regenerated-01. The negative transaction
and these builds consumed 902,301 charged operations in total. Read-only check
and evidence-management work is recorded separately, without inventing an
operation count for tools that do not provide one.

## Evidence and limits

`BUILD-RESULTS.json` identifies both actual runs, sources, artifact directories,
hashes, complete operation components and checker results. `ACCOUNTING.json`
records dispatch, completion, commands, failures, allowances and telemetry
limits. `SUBMISSION.json` is the immutable first submission. Detailed command
logs and full closures remain under the provisioned C195 author output path.

One initial read/search shell command exited 2; it included a missing inspection
glob and suppressed stderr, so the precise error text is unavailable. It made
no edits and launched no native work. The expected ownership rejection is the
only failed formal attempt. All such commands are retained in the accounting;
no failed attempt was overwritten or retried.

There was one repaired native build, one baseline native build, one intended
source repair, zero incorrect repairs, zero native retries and no author
delegation or model override. Provider token totals, provider costs and exact
model snapshot are unavailable. The shared environment and prepared backend
limit conclusions from this single pair. Coordinator scene replays, receiving
checks, visual review and independent acceptance are separate and pending.

The inherited legacy driver/tail remain FAILED, and thirteen torque methods
remain NOT RUN. This exercise changes no runtime, checker, backend, tolerance,
contract, original gate or shared STATUS, and makes no full-release or general
contact claim.
'''
(AUTHOR / 'DIAGNOSIS.md').write_text(report)
print(json.dumps({'prepared': True, 'preserved_existing_files': before['file_count'],
                  'baseline_four_outputs_byte_identical': True,
                  'frozen_files_unchanged': len(frozen['files']),
                  'variants': {k: {f: v[f] for f in ('artifact', 'source_sha256', 'checker_passed', 'continuous_bound_mm')}
                               for k, v in variants.items()}}, indent=2))
