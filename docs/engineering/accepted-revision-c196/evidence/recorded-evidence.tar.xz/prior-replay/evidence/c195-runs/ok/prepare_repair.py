#!/usr/bin/env python3
import difflib
import hashlib
import json
from pathlib import Path
from run_control import REPO, ROOT, sha, utc, write_json

target = REPO / 'docs/engineering/ownership-recovery-c195/authors/ok'
target.mkdir(parents=True, exist_ok=False)
original = REPO / 'docs/engineering/ownership-recovery-c195/fixtures/candidate.ok'
baseline = ROOT / 'accepted-source.ok'
negative = json.loads((ROOT / 'negative-result.json').read_text())
assert negative['successful'] is False and negative['committed'] is False
assert negative['diagnostics'][0]['code'] == 'C193_E_OWNERSHIP'
assert negative['cost']['operation_components'].get('scheduled_native_substeps', 0) == 0
assert negative['cost']['native_elapsed_ms'] == 0
assert negative['artifact_directory'] is None and negative['artifacts'] == {}
assert json.loads((ROOT / 'negative-preservation.json').read_text())['existing_files_preserved']

frozen = json.loads((REPO / 'docs/engineering/ownership-recovery-c195/INPUTS.json').read_text())
failures = []
for entry in frozen['files']:
    p = REPO / entry['path']
    if not p.is_file() or p.stat().st_size != entry['bytes'] or sha(p) != entry['sha256']:
        failures.append(entry['path'])
write_json(ROOT / 'frozen-input-verification-before-builds.json', {
    'checked_utc': utc(), 'file_count': len(frozen['files']), 'failures': failures,
    'passed': not failures})
assert not failures, failures

candidate = original.read_bytes()
accepted = baseline.read_bytes()
(target / 'candidate.ok').write_bytes(candidate)
(target / 'accepted-source.ok').write_bytes(accepted)
old = b'collider left_shoe_box @ "contact.left_shoe" {\n        part = "left_shoe";\n        owner = "body.right";'
new = old.replace(b'owner = "body.right"', b'owner = "body.left"')
assert candidate.count(old) == 1
repaired = candidate.replace(old, new)
assert accepted.count(b'at = [375, 130, -220][mm];') == 1
assert repaired == accepted.replace(b'at = [375, 130, -220][mm];', b'at = [365, 130, -220][mm];')
(target / 'repaired.ok').write_bytes(repaired)
for name, prior, current, a, b in [
    ('source-delta.patch', accepted, repaired, 'accepted-source.ok', 'repaired.ok'),
    ('candidate-repair.patch', candidate, repaired, 'candidate.ok', 'repaired.ok')]:
    diff = ''.join(difflib.unified_diff(prior.decode().splitlines(keepends=True),
                                     current.decode().splitlines(keepends=True), fromfile=a, tofile=b))
    (target / name).write_text(diff)
receipt = {'edited_utc': utc(), 'candidate_source_path': str(original),
    'preserved_candidate_path': str(target / 'candidate.ok'), 'candidate_sha256': sha(original),
    'accepted_source_path': str(baseline), 'accepted_source_sha256': sha(baseline),
    'repaired_source_path': str(target / 'repaired.ok'), 'repaired_source_sha256': sha(target / 'repaired.ok'),
    'repair': 'Change only contact.left_shoe owner from body.right to body.left in the malformed candidate.',
    'relative_to_accepted_baseline': 'Only left_stop X coordinate changes from 375 to 365 mm.',
    'incorrect_repairs': 0, 'candidate_preserved_byte_for_byte': original.read_bytes() == (target / 'candidate.ok').read_bytes(),
    'baseline_preserved_byte_for_byte': baseline.read_bytes() == (target / 'accepted-source.ok').read_bytes(),
    'prepared_positive_sources_read_or_copied': False}
write_json(ROOT / 'source-edit.json', receipt)
print(json.dumps(receipt, indent=2))
print((target / 'candidate-repair.patch').read_text())
print((target / 'source-delta.patch').read_text())
