#!/usr/bin/env python3
"""C195 author-side evidence recorder. No runtime or checker changes."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/3cb1527378cd/c195-runs/ok')
REPO = Path('/workspace/scratch/3cb1527378cd/c195-authors/ok')
PROVISION = json.loads((ROOT / 'PROVISION.json').read_text())

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')

def snapshot(name):
    files = {}
    paths = [ROOT / 'accepted-source.ok', ROOT / 'C194-ACCEPTANCE.json']
    paths += sorted(p for p in (ROOT / 'accepted-run').rglob('*') if p.is_file())
    for p in paths:
        files[str(p.relative_to(ROOT))] = {'sha256': sha(p), 'bytes': p.stat().st_size,
                                          'mode': oct(p.stat().st_mode & 0o777)}
    data = {'captured_utc': utc(), 'files': files,
            'closure_sha256': hashlib.sha256(json.dumps(files, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
            'file_count': len(files), 'total_bytes': sum(v['bytes'] for v in files.values()),
            'state': json.loads((ROOT / 'accepted-run/store/state.json').read_text())}
    write_json(ROOT / name, data)
    return data

def preservation(before, after):
    a, b = before['files'], after['files']
    return {'existing_files_preserved': all(b.get(k) == v for k, v in a.items()),
            'changed': [k for k in a if k in b and a[k] != b[k]],
            'removed': [k for k in a if k not in b],
            'added': [k for k in b if k not in a],
            'state_unchanged': before['state'] == after['state']}

def run(name, argv, timeout=None):
    folder = ROOT / name
    folder.mkdir(exist_ok=False)
    record = {'argv': argv, 'cwd': str(REPO), 'started_utc': utc(), 'started_unix_s': time.time(),
              'timeout_s': timeout}
    write_json(folder / 'command.json', record)
    with (folder / 'stdout.txt').open('wb') as out, (folder / 'stderr.txt').open('wb') as err:
        try:
            proc = subprocess.run(argv, cwd=REPO, stdout=out, stderr=err, timeout=timeout)
            record['returncode'] = proc.returncode
        except subprocess.TimeoutExpired:
            record.update(returncode=None, failure='outer command timeout')
    record.update(finished_utc=utc(), finished_unix_s=time.time())
    record['elapsed_s'] = record['finished_unix_s'] - record['started_unix_s']
    write_json(folder / 'command.json', record)
    with (ROOT / 'commands.jsonl').open('a') as log:
        log.write(json.dumps(record, sort_keys=True) + '\n')
    return record, folder

if __name__ == '__main__':
    if sys.argv[1] == 'negative':
        before = snapshot('preservation-before-negative.json')
        expected = sha(ROOT / 'accepted-source.ok')
        assert before['state']['accepted_revision'] == expected
        command = [sys.executable, '-B', '-m', 'prototypes.guided_contact_v02', 'run',
                   str(REPO / PROVISION['malformed_candidate']),
                   '--store', str(ROOT / 'accepted-run/store'), '--blender', PROVISION['blender'],
                   '--host-max-operations', '1000000', '--host-max-elapsed-ms', '80000',
                   '--expected-revision', expected, '--result', str(ROOT / 'negative-result.json')]
        record, folder = run('negative-01', command, 100)
        after = snapshot('preservation-immediately-after-negative.json')
        proof = preservation(before, after)
        write_json(ROOT / 'negative-preservation.json', proof)
        result = json.loads((folder / 'stdout.txt').read_text())
        print(json.dumps({'command': record, 'preservation': proof, 'result': result}, indent=2))
    elif sys.argv[1] == 'record':
        record, folder = run(sys.argv[2], sys.argv[3:])
        print(json.dumps(record, indent=2))
        print((folder / 'stdout.txt').read_text())
        print((folder / 'stderr.txt').read_text(), file=sys.stderr)
        raise SystemExit(record['returncode'] or 0)
    else:
        raise SystemExit('unknown operation')
