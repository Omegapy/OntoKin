from evidence_support import *
import difflib

original = AUTHOR / 'candidate.py'
repaired = AUTHOR / 'repaired.py'
accepted = OUT / 'accepted-source.py'
data = original.read_bytes()
bad = b"                                     'owner': 'body.right',\n                                     'part': 'left_shoe',"
good = b"                                     'owner': 'body.left',\n                                     'part': 'left_shoe',"
assert data.count(bad) == 1
assert not repaired.exists()
repaired.write_bytes(data.replace(bad, good))
expected = accepted.read_bytes().replace(b"'left_stop': {'at_mm': [375, 130, -220]", b"'left_stop': {'at_mm': [365, 130, -220]")
assert expected != accepted.read_bytes()
assert repaired.read_bytes() == expected
for name, before, after, before_name, after_name in [
    ('source-delta.patch', accepted, repaired, 'accepted-source.py', 'repaired.py'),
    ('repair-delta.patch', original, repaired, 'candidate.py', 'repaired.py')]:
    patch = ''.join(difflib.unified_diff(before.read_text().splitlines(keepends=True), after.read_text().splitlines(keepends=True), fromfile=before_name, tofile=after_name))
    (AUTHOR / name).write_text(patch)
record = {'utc': utc(), 'input': str(original), 'input_sha256': sha(original), 'output': str(repaired), 'output_sha256': sha(repaired), 'repair': "contact.left_shoe.owner: body.right -> body.left", 'repair_attempt': 1, 'incorrect_repairs': 0, 'accepted_source': str(accepted), 'accepted_source_sha256': sha(accepted), 'byte_comparison': 'Repaired bytes equal accepted-source.py with only left_stop.at_mm X replaced from 375 to 365.', 'candidate_preserved': original.read_bytes() == (REPO / PROVISION['malformed_candidate']).read_bytes()}
save(OUT / 'source-edit.json', record)
initial = json.loads((OUT / 'negative-verification.json').read_text())
receipt = initial['receipt']
result = {**initial, 'utc': utc(), 'scheduled_native_substeps': receipt['cost']['operation_components'].get('scheduled_native_substeps', 0), 'native_elapsed_ms': receipt['cost']['native_elapsed_ms'], 'native_log_bytes': receipt['cost']['native_log_bytes'], 'native_result_bytes': receipt['cost']['native_result_bytes'], 'note': 'The first verification record looked for the charge in charges/categories and recorded null. This supplemental record uses the actual operation_components mapping; the absent scheduled_native_substeps key means no charge. The original receipt and first verification record remain unchanged.'}
assert result['scheduled_native_substeps'] == 0
assert result['native_elapsed_ms'] == 0
assert result['no_native_outputs']
save(OUT / 'negative-verification-complete.json', result)
print(json.dumps(record, sort_keys=True))
